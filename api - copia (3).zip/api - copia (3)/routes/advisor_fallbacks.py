from flask import Blueprint, jsonify, request
import re
import os
from datetime import datetime

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

DEFAULT_ADVISOR_PHONE = os.environ.get('DEFAULT_ADVISOR_PHONE', '5214427843528' )

bp = Blueprint('advisor_fallbacks', __name__)

@bp.route('/admin/advisor_fallbacks', methods=['GET'])
def list_fallbacks():
   
    from data.db import get_collection
    col = get_collection('advisor_requests')
    docs = list(col.find({'status': 'pending'}).sort('created_at', -1))
    result = []
    for d in docs:
        doc = {
            'id': str(d.get('_id')),
            'created_at': d.get('created_at').isoformat() if d.get('created_at') else None,
            'client_data': d.get('client_data'),
            'pdf_path': d.get('pdf_path'),
            'course_id': d.get('course_id'),
            'status': d.get('status')
        }
        result.append(doc)
    return jsonify(result)


def _extract_client_fields_from_text(texts):
   
    combined = "\n".join([t for t in (texts or []) if t])
    res = {}
    lc = combined.lower()

    lines = [l.strip() for l in combined.splitlines() if l.strip()]


    label_patterns = {
        'name': [r'nombre[:\-]?\s*([A-Za-zÁÉÍÓÚáéíóúñÑ\'\-\s]{3,100})', r'nombre completo[:\-]?\s*([A-Za-zÁÉÍÓÚáéíóúñÑ\'\-\s]{3,100})'],
        'company': [r'empresa[:\-]?\s*([A-Za-z0-9\s&\.,\-]{2,100})', r'raz[oó]n social[:\-]?\s*([A-Za-z0-9\s&\.,\-]{2,100})'],
        'rfc': [r'rfc[:\-]?\s*([A-Za-zÑ&\d]{8,13})'],
        'email': [r'correo[:\-]?\s*([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})', r'email[:\-]?\s*([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})'],
        'website': [r'(?:sitio web|sitio|web)[:\-]?\s*(https?://[^\s,;]+)']
    }

    for field, patterns in label_patterns.items():
        for p in patterns:
            m = re.search(p, combined, re.I)
            if m:
                val = m.group(1).strip()
                res[field] = val
                break


    if 'email' not in res:
        email_m = re.search(r'([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})', combined)
        if email_m:
            res['email'] = email_m.group(1).strip()


    if 'phone' not in res:

        phone_patterns = [
            r'(?:teléfono|telefono|tel|phone)[:\-]?\s*(\+?52)?[\s\-]?(\d{10})',
            r'(?:\+?52)?[\s\-]?(\d{10})',  # Just 10 digits with optional +52
            r'(\d{3})[\s\-](\d{3})[\s\-](\d{4})',  # XXX-XXX-XXXX format
        ]
        
        for pattern in phone_patterns:
            phone_m = re.search(pattern, combined, re.I)
            if phone_m:
                groups = phone_m.groups()
                if len(groups) == 3:  # XXX-XXX-XXXX format
                    res['phone'] = f"52{''.join(groups)}"
                elif len(groups) == 2:  # +52 and 10 digits
                    digits = groups[1] if groups[1] else groups[0]
                    if len(digits) == 10:
                        res['phone'] = f"52{digits}"
                elif len(groups) == 1:  # Just 10 digits
                    digits = groups[0]
                    if len(digits) == 10:
                        res['phone'] = f"52{digits}"
                break


    if 'phone' not in res:
        standalone = re.search(r'(?<!\d)(\d{10})(?!\d)', combined)
        if standalone:
            res['phone'] = f"52{standalone.group(1)}"


    if 'rfc' not in res:
        rfc_m = re.search(r'\b([A-Za-zÑ&]{3,4}\d{6}[A-Za-z0-9]{2,3})\b', combined, re.I)
        if rfc_m:
            res['rfc'] = rfc_m.group(1).strip()


    if 'company' not in res:
        comp_m2 = re.search(r'([A-Z][A-Za-z0-9\s&\.,\-]{2,80}(?:S\.A\.|SA|S\.A\. de C\.V\.|S A))', combined)
        if comp_m2:
            res['company'] = comp_m2.group(0).strip()

   
   
    if 'company' not in res and 'name' in res and lines:

        name_low = res['name'].lower()
        for i, line in enumerate(lines):
            if name_low in line.lower():

                for j in range(i+1, len(lines)):
                    cand = lines[j]
                    if '@' in cand or re.search(r'\d', cand) or re.search(r'(correo|email|tel|telefono|rfc)', cand, re.I):
                        continue

                    if 2 <= len(cand) <= 60:
                        res['company'] = cand.strip()
                        break
                break


    if 'website' not in res:
        url_m = re.search(r'https?://[\w./?=&%-]+', combined)
        if url_m:
            res['website'] = url_m.group(0).strip()



    if 'name' not in res:

        lines = [l.strip() for l in combined.splitlines() if l.strip()]
        for line in lines:

            if re.search(r'(nombre[:\-]|empresa[:\-]|rfc[:\-]|correo[:\-]|email[:\-]|sitio[:\-]|web[:\-])', line, re.I):
                continue
            
            words = re.findall(r"[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-]+", line)
            if 2 <= len(words) <= 4 and len(line) <= 50:

                if '@' not in line and 'http' not in line and not re.search(r'\d{4,}', line):

                    skip_phrases = ['quiero', 'necesito', 'asesor', 'precio', 'cotización', 'contacto', 'hola', 'gracias', 'buenas', 'días']
                    if not any(phrase in line.lower() for phrase in skip_phrases):

                        res['name'] = ' '.join([w.capitalize() for w in words])
                        break
        

        if 'name' not in res:
            name_m = re.search(r"\b([A-Za-zÁÉÍÓÚáéíóúñÑ\'\-]{2,}\s+[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-]{2,}(?:\s+[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-]{2,})?)\b", combined)
            if name_m:
                candidate = name_m.group(1).strip()

                if '@' not in candidate and 'http' not in candidate and not re.search(r'\d', candidate):

                    res['name'] = ' '.join([w.capitalize() for w in candidate.split()])

        if 'name' not in res:
            for line in lines:
                if '@' in line or re.search(r'\d', line) or re.search(r'(empresa|empresa:|correo|tel|telefono|rfc)', line, re.I):
                    continue
                words = re.findall(r"[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-]+", line)
                if len(words) == 1 and 3 <= len(words[0]) <= 20:
                    res['name'] = words[0].capitalize()
                    break


    lines = [l.strip() for l in combined.splitlines() if l.strip()]
    desc_candidates = [l for l in lines if not re.search(r'(nombre|empresa|rfc|correo|email|sitio|web)', l, re.I)]
    if desc_candidates:

        project_keywords = ['instal', 'proyect', 'zona', 'cotiz', 'obra', 'constru', 'ftth', 'fibra', 'instalación', 'servicio']
        filtered = [l for l in desc_candidates if len(l) >= 30 or any(k in l.lower() for k in project_keywords)]
        if filtered:

            lines_sorted = sorted(filtered, key=lambda x: len(x), reverse=True)
        else:
            pass
    else:
        pass

    return res


def _classify_segment(company_name, text):

    segs = {
        'Integrador': ['integrador'],
        'Constructora': ['constructora', 'construcción'],
        'WISP': ['wisp'],
        'ISP': ['isp'],
        'Carrier': ['carrier'],
        'Data Center': ['data center', 'datacenter'],
        'Distribuidor': ['distribuidor'],
        'Usuario Final': ['usuario final', 'cliente final'],
        'Gobierno': ['gobierno'],
        'Consultor-Distribuidor-Integrador': ['consultor'],
        'Distribuidor-Eléctrico': ['eléctrico', 'electrico'],
        'Distribuidor-Integrador': ['distribuidor integrador'],
        'Distribuidor-Computo Electrico': ['computo', 'cómputo', 'computo electrico'],
        'Integrador-Eléctrico': ['integrador eléctrico', 'electrico'],
        'Integrador-Consultor': ['consultor integrador'],
        'Integrador-Data center': ['data center', 'datacenter'],
        'Integrador-Minero': ['minero', 'minería'],
        'ISP/WISP': ['isp', 'wisp']
    }
    text_low = (company_name or '') + ' ' + (text or '')
    text_low = text_low.lower()
    for seg, kws in segs.items():
        for w in kws:
            if w in text_low:
                return seg
    return 'Usuario Final'


def _generate_pdf(client_data: dict, summary: str, out_dir: str = None) -> str:

    if not out_dir:
        out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tmp'))
    os.makedirs(out_dir, exist_ok=True)
    filename = f"advisor_request_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    path = os.path.join(out_dir, filename)
    try:
        if REPORTLAB_AVAILABLE:

            c = canvas.Canvas(path, pagesize=A4)
            width, height = A4
            y = height - 50
            c.setFont('Helvetica-Bold', 14)
            c.drawString(50, y, 'Perfil de cliente / Solicitud')
            y -= 30
            c.setFont('Helvetica', 10)
            for k, v in client_data.items():
                if v:
                    text_line = f"{k}: {v}"
                    c.drawString(50, y, text_line[:120])
                    y -= 14
                    if y < 60:
                        c.showPage()
                        y = height - 50
            y -= 10
            c.setFont('Helvetica-Bold', 12)
            c.drawString(50, y, 'Resumen de la solicitud:')
            y -= 18
            c.setFont('Helvetica', 10)
            for line in summary.splitlines():
                c.drawString(50, y, line[:120])
                y -= 14
                if y < 60:
                    c.showPage()
                    y = height - 50
            c.save()
        else:

            with open(path + '.txt', 'w', encoding='utf-8') as f:
                f.write('Perfil de cliente / Solicitud\n\n')
                for k, v in client_data.items():
                    f.write(f"{k}: {v}\n")
                f.write('\nResumen:\n')
                f.write(summary)
            #
            
            path = path + '.txt'
        return path
    except Exception as e:
        return ''


def generate_client_pdf(client_data: dict, summary: str, out_dir: str = None, filename: str = None) -> str:
    """Generate a PDF with a specific filename. Returns the path or '' on error.
    If ReportLab is not available, creates a .txt file as fallback.
    """
    try:
        # Ensure there is always an output directory
        if not out_dir:
            out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs'))
        os.makedirs(out_dir, exist_ok=True)

        # Validate we have minimum required data
        if not client_data.get('name') or not client_data.get('email'):
            return ''  # Don't generate PDF without minimum data

        # If reportlab is available, create a real PDF
        if REPORTLAB_AVAILABLE:
            if not filename:
                filename = f"advisor_request_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            if not filename.lower().endswith('.pdf'):
                filename = filename + '.pdf'
            path = os.path.join(out_dir, filename)

            c = canvas.Canvas(path, pagesize=A4)
            width, height = A4
            y = height - 50
            c.setFont('Helvetica-Bold', 16)
            c.drawCentredString(width / 2, y, 'SOLICITUD DE CONTACTO CON ASESOR')
            y -= 30

            # Add generation date
            c.setFont('Helvetica', 8)
            c.drawString(50, y, f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
            y -= 20

            c.setFont('Helvetica-Bold', 12)
            c.drawString(50, y, 'Datos del Prospecto:')
            y -= 18
            c.setFont('Helvetica', 10)
            
            # Display fields with Spanish labels
            field_labels = {
                'name': 'Nombre completo',
                'company': 'Empresa',
                'rfc': 'RFC',
                'email': 'Correo electrónico',
                'phone': 'Teléfono',
                'website': 'Sitio web',
                'city': 'Ciudad'
            }
            
            for k, label in field_labels.items():
                v = client_data.get(k) or ''
                if v:  # Only show fields with values
                    c.drawString(50, y, f"{label}: {v}")
                    y -= 14
                    if y < 80:
                        c.showPage()
                        y = height - 50

            y -= 10
            c.setFont('Helvetica-Bold', 12)
            c.drawString(50, y, 'Curso Solicitado:')
            y -= 16
            c.setFont('Helvetica', 10)
            course_info = client_data.get('course', {}) or {}
            if course_info:
                c.drawString(50, y, f"ID del Curso: {course_info.get('id', '')}")
                y -= 14
                c.drawString(50, y, f"Nombre: {course_info.get('name', course_info.get('nombre',''))}")
                y -= 14
                c.drawString(50, y, f"Precio: {course_info.get('price', 'Consultar')}")
                y -= 14
            else:
                c.drawString(50, y, 'No especificado')
                y -= 14

            y -= 10
            c.setFont('Helvetica-Bold', 12)
            y -= 16
            c.setFont('Helvetica', 10)
            
            # Better text wrapping for summary
            summary_text = summary or 'Sin información adicional'
            words = summary_text.split()
            line = ''
            for word in words:
                test_line = line + (' ' if line else '') + word
                if len(test_line) > 100:  # Approximate character limit per line
                    if line:
                        c.drawString(50, y, line)
                        y -= 14
                        if y < 80:
                            c.showPage()
                            y = height - 50
                    line = word
                else:
                    line = test_line
            if line:
                c.drawString(50, y, line)

            c.save()
            return path
        else:
            # ReportLab not available — create a .txt summary that can still be sent as document
            if not filename:
                filename = f"advisor_request_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            if not filename.lower().endswith('.txt'):
                filename = filename + '.txt'
            path = os.path.join(out_dir, filename)
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write('SOLICITUD DE CONTACTO CON ASESOR\n')
                f.write('=' * 50 + '\n\n')
                f.write(f'Generado: {datetime.now().strftime("%d/%m/%Y %H:%M")}\n\n')
                
                f.write('DATOS DEL PROSPECTO:\n')
                f.write('-' * 25 + '\n')
                
                field_labels = {
                    'name': 'Nombre completo',
                    'company': 'Empresa',
                    'rfc': 'RFC',
                    'email': 'Correo electrónico',
                    'phone': 'Teléfono',
                    'website': 'Sitio web',
                    'city': 'Ciudad'
                }
                
                for k, label in field_labels.items():
                    value = client_data.get(k, '')
                    if value:  # Only show fields with values
                        f.write(f'{label}: {value}\n')
                
                f.write('\nCURSO SOLICITADO:\n')
                f.write('-' * 18 + '\n')
                course_info = client_data.get('course', {}) or {}
                if course_info:
                    f.write(f"ID: {course_info.get('id','')}\n")
                    f.write(f"Nombre: {course_info.get('name', '')}\n")
                    f.write(f"Precio: {course_info.get('price', 'Consultar')}\n")
                else:
                    f.write('No especificado\n')
                
                f.write('-' * 40 + '\n')
                f.write(summary or 'Sin información adicional')
                
            return path
    except Exception as e:
        # On any failure return empty string to signal no file
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Error generating PDF: {e}")
        return ''



@bp.route('/admin/process_advisor_request', methods=['POST'])
def process_advisor_request():
   

    payload = request.get_json() or {}
    phone = payload.get('phone')
    texts = payload.get('texts') or []
    advisor_phone = payload.get('advisor_phone') or DEFAULT_ADVISOR_PHONE
    request_type = payload.get('type', 'cotizacion')  # Puede ser 'inscripcion' o 'cotizacion'

    # Extraer campos del cliente
    extracted = _extract_client_fields_from_text(texts)

    # Determinar segmento del cliente
    extracted['segment'] = _classify_segment(extracted.get('company'), " ".join(texts))

    # Crear un resumen breve del proyecto o solicitud
    summary = f"Solicitud de {request_type}"
    if len(summary) > 500:
        summary = summary[:500]

    # Generar el PDF con los datos del cliente
    pdf_path = _generate_pdf(extracted, summary)

    # Guardar la solicitud en la base de datos
    from data.db import get_collection
    col = get_collection('advisor_requests')
    rec = {
        'phone': phone,
        'client_data': extracted,
        'texts': texts,
        'summary': summary,
        'pdf_path': pdf_path,
        'created_at': datetime.now(),
        'status': 'pending'
    }
    try:
        res = col.insert_one(rec)
        rec_id = str(res.inserted_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500

    # Notificar al asesor por WhatsApp
    try:
        from routes.whatsapp import send_document_message, send_text_message
        if pdf_path:
            send_document_message(advisor_phone, pdf_path, caption=f"Solicitud #{rec_id}: {summary[:140]}")
        notify_text = f"Nuevo lead: {extracted.get('name', phone)} - Segmento: {extracted.get('segment')} - Requiere: {summary[:140]}"
        send_text_message(advisor_phone, notify_text)
    except Exception as e:
        logger = bp.logger
        logger.debug(f"Notificación al asesor falló: {e}")

    return jsonify({'ok': True, 'id': rec_id, 'pdf_path': pdf_path})