"""
Manejadores para webinars y eventos
"""
import logging
import re
import unicodedata
import os
import requests
import tempfile
import time
from typing import Optional, List, Dict, Any
from datetime import datetime

try:
    # Try to use dateutil for robust parsing
    from dateutil.parser import parse as _date_parse
except Exception:
    _date_parse = None

logger = logging.getLogger(__name__)


def find_db_item_by_keywords(keywords, collections=('webinars', 'products')):
    """Buscar en las colecciones dadas un documento que contenga alguna de las keywords
    
    Retorna el primer documento encontrado o None.
    """
    try:
        from data.db import get_collection
        # Normalize keywords to lower-case
        kws = [k.lower() for k in (keywords or []) if k]
        if not kws:
            return None

        # Build OR query to match keywords in title, name, description, keywords, tags or summary
        or_clauses = []
        for k in kws:
            or_clauses.extend([
                {"title": {"$regex": k, "$options": "i"}},
                {"name": {"$regex": k, "$options": "i"}},
                {"description": {"$regex": k, "$options": "i"}},
                {"keywords": {"$regex": k, "$options": "i"}},
                {"tags": {"$regex": k, "$options": "i"}},
                {"summary": {"$regex": k, "$options": "i"}}
            ])

        for col_name in collections:
            col = get_collection(col_name)
            if col:
                doc = col.find_one({"$or": or_clauses})
                if doc:
                    # Convert ObjectId to string for JSON serialization
                    if '_id' in doc:
                        doc['_id'] = str(doc['_id'])
                    return doc
    except Exception:
        # If DB module is not available or other error, return None
        return None
    return None


def send_db_or_fallback_message(phone, keywords, fallback_text, fallback_link=None, collections=('webinars','products')):
    """Intenta obtener información desde la DB y enviar; si no hay resultado, envía el fallback_text."""
    from .whatsapp_message_handlers import send_text_message
    
    try:
        doc = find_db_item_by_keywords(keywords, collections=collections)
        if doc:
            title = doc.get('title') or doc.get('name') or 'Sin título'
            desc = doc.get('description') or doc.get('summary') or 'Sin descripción'
            link = doc.get('link') or doc.get('url') or ''
            
            msg = f"📋 {title}\n\n{desc}"
            if link:
                msg += f"\n\n🔗 Más información: {link}"
            
            send_text_message(phone, msg)
            return True
    except Exception:
        # ignore and fallback
        pass

    # Fallback to the hardcoded message if DB lookup failed or returned nothing
    if fallback_link:
        send_text_message(phone, f"{fallback_text}\n\nTe comparto el enlace directo para que veas mas sobre los productos: {fallback_link}")
    else:
        send_text_message(phone, fallback_text)
    return False


def handle_webinar_list_request(phone):
    """Maneja solicitudes de lista de webinars"""
    from .whatsapp_message_handlers import send_text_message
    from services.conversation_memory_utils import save_conversation_memory
    
    try:
        from data.db import get_collection
        webinars_col = get_collection('webinars')

        if not webinars_col:
            send_text_message(phone, "Lo siento, no puedo acceder a la información de webinars en este momento.")
            return

        # Get webinars from DB (limit 50 to have enough to sort)
        cursor = webinars_col.find({}).limit(50)
        webinars = list(cursor)
        
        if not webinars:
            send_text_message(phone, "No hay webinars disponibles en este momento.")
            return
            
        # Try to extract a sortable date for each webinar and sort by it (more recent first)
        def _get_webinar_date(w):
            # Look for common date fields
            candidates = [w.get('date'), w.get('start_date'), w.get('fecha')]
            # Also support a list of fechas
            if not any(candidates):
                if isinstance(w.get('fechas'), (list, tuple)) and w.get('fechas'):
                    first = w.get('fechas')[0]
                    if isinstance(first, dict):
                        candidates.append(first.get('fecha'))
                    else:
                        candidates.append(first)

            for c in candidates:
                if not c:
                    continue
                try:
                    if _date_parse:
                        return _date_parse(str(c))
                    else:
                        # Try common formats
                        for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d'):
                            try:
                                return datetime.strptime(str(c), fmt)
                            except Exception:
                                continue
                except Exception:
                    continue
            return None

        webinars_with_dates = []
        for w in webinars:
            sort_dt = _get_webinar_date(w)
            webinars_with_dates.append((w, sort_dt))

        # Sort by date: more recent (newer) first. If no date, put at the end.
        webinars_with_dates.sort(key=lambda x: (x[1] is None, x[1]), reverse=True)

        sorted_webinars = [t[0] for t in webinars_with_dates]

        # Format response
        reply_parts = ["📅 Webinars disponibles (ordenados por fecha — más reciente primero):"]
        for i, webinar in enumerate(sorted_webinars, start=1):
            title = webinar.get('title') or webinar.get('name') or f'Webinar {i}'
            # attach simple date preview if available
            d = None
            try:
                d = _get_webinar_date(webinar)
            except Exception:
                d = None
            date_preview = f" ({d.date().isoformat()})" if d else ""
            reply_parts.append(f"{i}. {title}{date_preview}")
        
        reply_parts.append("\nResponde con el número del webinar para más información, ejemplo: '1' o 'detalle 1'")
        reply_parts.append("\n💰 Todos nuestros webinars son gratuitos y se imparten en línea todos los martes.")
        
        # Save to memory for follow-up
        webinar_list = [{'_id': str(w.get('_id')), 'title': w.get('title') or w.get('name')} for w in webinars]
        save_conversation_memory(phone, 'last_listed_webinars', webinar_list)
        
        send_text_message(phone, "\n".join(reply_parts))
        
    except Exception as e:
        logger.error(f"Error handling webinar list request: {e}")
        send_text_message(phone, "Ocurrió un error al obtener la lista de webinars. Por favor intenta más tarde.")


def handle_course_list_request(phone):
    """Maneja solicitudes de lista de cursos"""
    from .whatsapp_message_handlers import send_text_message
    from services.conversation_memory_utils import save_conversation_memory
    
    try:
        from data.db import get_collection
        # Catálogo fijo de respaldo siempre disponible
        fixed_catalog = [
            {"id": 1, "title": "Cableado estructurado para redes de fibra y cobre"},
            {"id": 2, "title": "Redes de fibra óptica planta externa"},
            {"id": 3, "title": "Redes de fibra óptica FTTH para WISP e ISP"},
            {"id": 4, "title": "PON/LAN redes pasivas para entornos enterprise"},
            {"id": 5, "title": "Empalmes y mediciones con OTDR de un enlace de fibra óptica"},
        ]

        courses = []
        try:
            courses_col = get_collection('courses')
            if courses_col is not None:
                cursor = courses_col.find({}).limit(10)
                courses = list(cursor)
        except Exception as db_err:
            logger.warning(f"Fallo al consultar cursos en DB, usando catálogo fijo: {db_err}")
            courses = []

        # Fallback a catálogo fijo si no hay datos en DB
        if not courses:
            courses = fixed_catalog

        # Try to extract the next/upcoming date for each course and sort by it (more recent first)
        def _get_course_next_date(c):
            # possible fields: 'proximas_fechas' (list of dicts), 'fechas', 'fecha'
            candidates = []
            if isinstance(c.get('proximas_fechas'), (list, tuple)) and c.get('proximas_fechas'):
                # pick the first fecha in proximas_fechas if dict
                first = c.get('proximas_fechas')[0]
                if isinstance(first, dict):
                    candidates.append(first.get('fecha'))
                else:
                    candidates.append(first)
            if c.get('fechas'):
                if isinstance(c.get('fechas'), (list, tuple)):
                    candidates.append(c.get('fechas')[0])
                else:
                    candidates.append(c.get('fechas'))
            if c.get('fecha'):
                candidates.append(c.get('fecha'))

            for cand in candidates:
                if not cand:
                    continue
                try:
                    if _date_parse:
                        return _date_parse(str(cand))
                    else:
                        for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d'):
                            try:
                                return datetime.strptime(str(cand), fmt)
                            except Exception:
                                continue
                except Exception:
                    continue
            return None

        courses_with_dates = []
        for c in courses:
            sort_dt = _get_course_next_date(c)
            courses_with_dates.append((c, sort_dt))

        # Sort by date: more recent (newer) first; None dates go to the end
        courses_with_dates.sort(key=lambda x: (x[1] is None, x[1]), reverse=True)
        sorted_courses = [t[0] for t in courses_with_dates]

        # Format response
        reply_parts = ["📚 Cursos disponibles (ordenados por fecha — más reciente primero):"]
        for i, course in enumerate(sorted_courses, start=1):
            title = course.get('title') or course.get('name') or course.get('nombre') or f'Curso {i}'
            # show date preview when available
            d = None
            try:
                d = _get_course_next_date(course)
            except Exception:
                d = None
            date_preview = f" ({d.date().isoformat()})" if d else ""
            reply_parts.append(f"{i}. {title}{date_preview}")

        reply_parts.append("\nResponde con el número del curso para más información, ejemplo: '1' o 'temario 1'")
        reply_parts.append("\n💰 Gratis — se imparte en línea todos los martes")

        # Save to memory for follow-up
        course_list = [
            {'_id': str(c.get('_id', c.get('id', idx))),
             'title': (c.get('title') or c.get('name') or f'Curso {idx}')}
            for idx, c in enumerate(courses, 1)
        ]
        save_conversation_memory(phone, 'last_listed_courses', course_list)

        send_text_message(phone, "\n".join(reply_parts))
        
    except Exception as e:
        logger.error(f"Error handling course list request: {e}")
        # Último recurso: enviar catálogo fijo para no dejar al usuario sin respuesta
        try:
            reply_parts = ["📚 Cursos disponibles:"]
            backup = [
                {"id": 1, "title": "Cableado estructurado para redes de fibra y cobre"},
                {"id": 2, "title": "Redes de fibra óptica planta externa"},
                {"id": 3, "title": "Redes de fibra óptica FTTH para WISP e ISP"},
                {"id": 4, "title": "PON/LAN redes pasivas para entornos enterprise"},
                {"id": 5, "title": "Empalmes y mediciones con OTDR de un enlace de fibra óptica"},
            ]
            for i, course in enumerate(backup, start=1):
                reply_parts.append(f"{i}. {course['title']}")
            reply_parts.append("\nResponde con el número del curso para más información, ejemplo: '1' o 'temario 1'")
            reply_parts.append("\n💰 Gratis — se imparte en línea todos los martes")
            send_text_message(phone, "\n".join(reply_parts))
        except Exception:
            send_text_message(phone, "Ocurrió un error al obtener la lista de cursos. Por favor intenta más tarde.")


def detect_and_update_course_selection(phone, message_text):
    """Detect if user wants to change course and update selection using CourseConversationManager."""
    from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
    from .course_handlers import CourseConversationManager
    
    try:
        text_lower = (message_text or '').lower().strip()

        # Handle pending course change confirmations stored in memory
        pending = get_conversation_memory(phone, 'pending_course_change')
        if pending:
            # User had a pending course change confirmation
            if any(word in text_lower for word in ['sí', 'si', 'yes', 'ok', 'confirmo', 'acepto']):
                # Confirm the change
                new_course = pending.get('new_course')
                if new_course:
                    CourseConversationManager.select_course(phone, new_course['id'], new_course['name'], "user_change")
                    save_conversation_memory(phone, 'pending_course_change', None)  # Clear pending
                    logger.info(f"Course change confirmed for {phone}: {new_course}")
                return
            elif any(word in text_lower for word in ['no', 'cancel', 'cancelar', 'mejor no']):
                # Cancel the change
                save_conversation_memory(phone, 'pending_course_change', None)
                logger.info(f"Course change cancelled for {phone}")
                return

        text_lower = (message_text or '').lower()
        current_selection = CourseConversationManager.get_selected_course_info(phone)
        selection_intent = CourseConversationManager.detect_course_selection_intent(message_text)

        # Check for explicit course change keywords
        change_keywords = ['cambiar', 'otro curso', 'cambiar de curso', 'mejor', 'prefiero', 'en lugar', 'cambiar al curso']
        wants_to_change = any(keyword in text_lower for keyword in change_keywords)

        if selection_intent:
            if current_selection and wants_to_change:
                # Handle course change request
                CourseConversationManager._handle_course_switch_offer(phone, message_text, selection_intent, current_selection)
            elif not current_selection:
                # First-time course selection
                CourseConversationManager._handle_course_selection(phone, selection_intent)
            else:
                # User has a course selected but made another query - might be temporary
                CourseConversationManager._handle_temporary_course_query(phone, message_text, selection_intent, current_selection)
        elif current_selection and any(word in text_lower for word in ['no', 'cancelar', 'continuar', 'seguir']):
            # User wants to continue with current selection or clear it
            if any(word in text_lower for word in ['cancelar', 'salir']):
                CourseConversationManager.clear_course_selection(phone)

        return
    except Exception as e:
        logger.debug(f"Error detecting course change: {e}")
        return


def handle_follow_up_selection(phone, message_text):
    """Maneja selección de follow-up para webinars/cursos por número o fragmento de texto"""
    from services.conversation_memory_utils import get_conversation_memory
    from .whatsapp_message_handlers import send_text_message
    
    # Regex para capturar seguimientos como "fechas 2", "temario 1", "inscripcion", "costos", etc.
    follow_up_match = re.match(r'(?:fechas?|fecha|costos?|precio|inscripcion|inscripción|temario|asesor|detalle|completo)\s*(\d+)?', message_text.lower().strip())
    
    if follow_up_match:
        number_str = follow_up_match.group(1)
        
        # Intentar obtener selección por número
        if number_str:
            try:
                selection_num = int(number_str) - 1  # Convert to 0-based index
                
                # Buscar en webinars primero
                last_webinars = get_conversation_memory(phone, 'last_listed_webinars') or []
                if 0 <= selection_num < len(last_webinars):
                    webinar_info = last_webinars[selection_num]
                    send_webinar_details(phone, webinar_info['_id'])
                    return True
                    
                # Buscar en cursos
                last_courses = get_conversation_memory(phone, 'last_listed_courses') or []
                if 0 <= selection_num < len(last_courses):
                    course_info = last_courses[selection_num]
                    send_course_details(phone, course_info['_id'])
                    return True
                    
            except ValueError:
                pass
        
        # Si no hay número o no se encontró, buscar en general
        send_text_message(phone, "Por favor especifica el número del webinar o curso, ejemplo: 'fechas 1' o 'temario 2'")
        return True
    
    return False


def send_webinar_details(phone, webinar_id):
    """Envía detalles completos de un webinar"""
    from .whatsapp_message_handlers import send_text_message
    from data.db import get_collection
    from bson import ObjectId
    
    try:
        webinars_col = get_collection('webinars')
        if not webinars_col:
            send_text_message(phone, "No puedo acceder a la información de webinars en este momento.")
            return
            
        # Buscar webinar por ID
        try:
            webinar = webinars_col.find_one({"_id": ObjectId(webinar_id)})
        except:
            webinar = webinars_col.find_one({"_id": webinar_id})
            
        if not webinar:
            send_text_message(phone, "No se encontró información del webinar solicitado.")
            return
            
        # Formatear información completa
        title = webinar.get('title') or webinar.get('name') or 'Sin título'
        date = webinar.get('date') or webinar.get('start_date') or webinar.get('fecha') or 'Fecha por definir'
        desc = webinar.get('description') or webinar.get('details') or ''
        reg_link = webinar.get('registration') or webinar.get('registration_link') or webinar.get('link') or ''

        parts = [f"📅 Webinar: {title}"]
        parts.append(f"🗓️ Fecha: {date}")
        parts.append(f"💰 Precio: Gratis — se imparte en línea todos los martes")
        
        # If there is an explicit registration link, include it. Otherwise, try to load from local JSON fallback
        if reg_link:
            parts.append(f"📝 Inscripción: {reg_link}")
        else:
            # Try to load from bundled JSON as last-resort fallback
            try:
                api_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
                webinars_json = os.path.join(api_dir, 'splitbot.webinars.json')
                if os.path.exists(webinars_json):
                    import json
                    with open(webinars_json, 'r', encoding='utf-8') as f:
                        list_web = json.load(f)
                        # Try to find by title fragment
                        found = None
                        for w in list_web:
                            t = (w.get('title') or w.get('name') or '').lower()
                            if t and (w.get('_id') == webinar.get('_id') or (title.lower() in t)):
                                found = w
                                break
                        if found and (found.get('link') or found.get('url')):
                            parts.append(f"📝 Inscripción: {found.get('link') or found.get('url')}")
                        else:
                            # Global fallback link requested by user
                            parts.append("📝 Inscripción: https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online")
                else:
                    parts.append("📝 Inscripción: https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online")
            except Exception:
                parts.append("📝 Inscripción: https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online")
            
        if desc:
            parts.append(f"📄 Descripción: {desc}")
            
        # Enviar temario si está disponible
        temario = webinar.get('temario') or webinar.get('syllabus') or webinar.get('pdf')
        if temario:
            send_temario(phone, temario, f"Temario - {title}")
            
        send_text_message(phone, "\n\n".join(parts))
        
    except Exception as e:
        logger.error(f"Error sending webinar details: {e}")
        send_text_message(phone, "Ocurrió un error al obtener la información del webinar.")


def send_course_details(phone, course_id):
    """Envía detalles completos de un curso"""
    from .whatsapp_message_handlers import send_text_message
    from .course_handlers import get_course_details_by_number
    
    try:
        details = get_course_details_by_number(course_id)
        if details and "no disponible" not in details.lower():
            send_text_message(phone, details)
        else:
            send_text_message(phone, f"💰 Gratis — se imparte en línea todos los martes\n\nPara más información sobre este curso, por favor contacta con nuestro equipo de soporte.")
            
    except Exception as e:
        logger.error(f"Error sending course details: {e}")
        send_text_message(phone, "Ocurrió un error al obtener la información del curso.")


def send_temario(phone, temario_data, caption="Temario del curso"):
    """Envía temario ya sea como archivo local, URL de descarga, o texto"""
    from .whatsapp_message_handlers import send_text_message, send_document_message
    
    if not temario_data:
        send_text_message(phone, "Temario no disponible.")
        return
        
    # Si es un diccionario con URL o path
    if isinstance(temario_data, dict):
        url = temario_data.get('url')
        local_path = temario_data.get('path')
        
        if local_path and os.path.exists(local_path):
            # Enviar archivo local
            send_document_message(phone, local_path, caption)
            return
            
        if url:
            # Descargar y enviar
            try:
                response = requests.get(url, stream=True, timeout=30)
                response.raise_for_status()
                
                # Crear archivo temporal
                with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
                    for chunk in response.iter_content(chunk_size=8192):
                        tmp_file.write(chunk)
                    tmp_path = tmp_file.name
                
                # Enviar documento
                result = send_document_message(phone, tmp_path, caption)
                
                # Limpiar archivo temporal
                time.sleep(1)  # Dar tiempo para que se complete el envío
                try:
                    os.unlink(tmp_path)
                except:
                    pass
                    
                if result:
                    return
                    
            except Exception as e:
                logger.error(f"Error downloading/sending temario: {e}")
    
    # Si es string (path local)
    elif isinstance(temario_data, str):
        if os.path.exists(temario_data):
            send_document_message(phone, temario_data, caption)
            return
        else:
            # Podría ser URL o texto
            if temario_data.startswith(('http://', 'https://')):
                send_text_message(phone, f"{caption}\n\nPuedes descargar el temario desde: {temario_data}")
            else:
                send_text_message(phone, f"{caption}\n\n{temario_data}")
            return
    
    # Fallback
    send_text_message(phone, f"{caption} - Información disponible bajo solicitud.")


def handle_direct_info_request(phone, message_text):
    """Maneja peticiones directas como 'dame info del seminario de X'"""
    from .whatsapp_message_handlers import send_text_message
    from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
    
    # Regex para detectar peticiones de información directa
    direct_info_match = re.search(r'(?:dame info|dame detalle|info del|información sobre|informacion sobre|detalles del|detalle del)\s+(?:seminario|webinar|curso)?\s*(?:de|del|sobre)?\s*(.+?)(?:\?|$)', message_text.lower())
    
    if direct_info_match:
        frag = direct_info_match.group(1).strip()
        if frag:
            # Normalizar fragmento y quitar acentos para mejorar matching
            frag = re.sub(r"\?$", "", frag).strip()
            
            def norm(s):
                if not s:
                    return ''
                s = s.lower()
                s = unicodedata.normalize('NFKD', s)
                s = ''.join([c for c in s if not unicodedata.combining(c)])
                return s

            frag_norm = norm(frag)
            matches = []
            
            try:
                from data.db import get_collection
                webinars_col = get_collection('webinars')
                if webinars_col:
                    cursor = webinars_col.find({}).limit(50)
                    for d in cursor:
                        title = (d.get('title') or d.get('name') or '')
                        desc = (d.get('description') or d.get('desc') or '')
                        tags = ' '.join([str(x) for x in (d.get('tags') or d.get('keywords') or [])])
                        hay = ' '.join([title, desc, tags])
                        hay_norm = norm(hay)
                        
                        # Busqueda por contención directa o todas las palabras presentes
                        if frag_norm in hay_norm or all(word in hay_norm for word in frag_norm.split() if len(word) > 2):
                            d['_id'] = str(d.get('_id'))
                            matches.append(d)
            except Exception as _e:
                logger.debug(f"Error buscando webinar por solicitud directa: {_e}")

            if len(matches) == 1:
                wd = matches[0]
                title = wd.get('title') or wd.get('name') or 'Sin título'
                date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                desc = wd.get('description') or wd.get('details') or ''
                reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                
                parts = [f"🔎 Información: {title}"]
                parts.append(f"📅 Fecha: {date}")
                if price:
                    parts.append(f"💰 Precio: {price}")
                if reg_link:
                    parts.append(f"📝 Inscripción: {reg_link}")
                if desc:
                    parts.append(f"📄 Descripción: {desc}")
                    
                save_conversation_memory(phone, 'last_listed_webinars', [{'_id': wd.get('_id'), 'title': title}])
                send_text_message(phone, "\n\n".join(parts))
                return True
                
            elif len(matches) > 1:
                reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                for i, m in enumerate(matches, start=1):
                    reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                
                save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in matches])
                send_text_message(phone, "\n".join(reply_parts))
                return True
    
    return False