import requests
import logging
import json
import traceback
import re
import unicodedata
import os
import copy
import mimetypes
from typing import Optional, Dict, Any
from datetime import datetime
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin

# Configuraciones
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)

# Servicios principales
from services.chat_ai import chat_with_gemini
from services.assistant_orchestrator import handle_with_router

# Importaciones de servicios de memoria y conversación
from services.conversation_memory_utils import save_conversation_memory, get_conversation_memory

# Módulos organizados por funcionalidad
from ..course_handlers import (
    CourseConversationManager, CourseManager, AdvisorRequestManager,
    advisor_request_prompt, get_course_schedule_message, get_course_price_message,
    get_course_location_message, select_course_by_name, parse_course_number_from_text,
    format_course_for_whatsapp, get_course_details_by_number, find_pdf_for_user_message,
    save_selected_course, get_selected_course, clear_selected_course
)

from ..intent_classification import (
    classify_user_intent, is_explicit_course_or_webinar_request,
    detect_topic_shift, detect_course_exit_commands
)

from ..whatsapp_message_handlers import (
    send_text_message, send_document_message, log_webhook_event,
    set_current_webhook_message_id, clear_current_webhook_message_id
)

from ..webinar_handlers import (
    find_db_item_by_keywords, send_db_or_fallback_message,
    handle_webinar_list_request, handle_course_list_request,
    detect_and_update_course_selection, handle_follow_up_selection,
    handle_direct_info_request
)

# Configurar logger para este módulo
logger = logging.getLogger(__name__)

# Crear blueprint para rutas de WhatsApp
whatsapp_bp = Blueprint('whatsapp', __name__)


@whatsapp_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')

    logger.info(f"Verificación de webhook: mode={mode}, token={token != None}")

    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook verificado exitosamente")
        return challenge

    logger.warning("Verificación de webhook fallida")
    return "Verification failed", 403                        

@whatsapp_bp.route('/debug-webhook', methods=['POST'])
def debug_webhook():
    try:
        raw_body = request.get_data(as_text=True)
        headers = dict(request.headers)
        remote_addr = request.remote_addr or 'unknown'

        log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_received.log'))
        os.makedirs(os.path.dirname(log_path), exist_ok=True)

        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"\n=== DEBUG WEBHOOK {datetime.utcnow().isoformat()} ===\n")
            f.write(f"REMOTE_ADDR: {remote_addr}\n")
            f.write(f"HEADERS: {json.dumps(headers)}\n")
            f.write(f"RAW_BODY: {raw_body}\n")
            f.write("=== END DEBUG WEBHOOK ===\n")

        logger.info("Debug webhook received and persisted")
        return jsonify({"status": "debug_received"}), 200

    except Exception as e:
        logger.error(f"Error en debug webhook: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@whatsapp_bp.route('/webhook', methods=['POST'])
def webhook_handler():

    try:
        # Persistir el cuerpo bruto del webhook inmediatamente
        try:
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== RAW WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END RAW WEBHOOK ===\n")
            logger.debug("Raw webhook persisted to logs/webhook_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST recibido")

        # Registrar información estructurada del webhook
        try:
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)

            log_webhook_event(
                event_type="webhook_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )

        except Exception as e:
            logger.error(f"Error al procesar información de webhook: {e}")
            logger.error(traceback.format_exc())

        if not payload:
            logger.warning("Payload vacío recibido")
            return jsonify({"status": "error", "message": "Payload vacío"}), 400

        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload")
            return jsonify({"status": "ok"}), 200

        # Importaciones necesarias para el procesamiento
        from services.chat_ai import query_mongodb
        from utils.ml_adapter import process_message
        from services.conversation_memory import get_conversation_history, clear_topic_context, ConversationMemory

        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})

                # Clasificar tipo de evento
                payload_type = "unknown"
                if 'statuses' in value and not 'messages' in value:
                    payload_type = "status_update"
                elif 'messages' in value:
                    payload_type = "message"
                elif 'errors' in value:
                    payload_type = "error"
                elif 'metadata' in value:
                    payload_type = "metadata"

                logger.info(f"Evento de WhatsApp detectado: {payload_type}")

                # Manejar eventos de estado sin generar respuestas
                if payload_type == "status_update":
                    logger.info("Recibida notificación de estado, procesando sin respuesta")
                    statuses = value.get('statuses', [])
                    for status in statuses:
                        status_id = status.get('id')
                        status_status = status.get('status')
                        recipient_id = status.get('recipient_id')
                        logger.info(f"Status de mensaje: ID={status_id}, Status={status_status}, Recipient={recipient_id}")
                    continue
                elif payload_type == "error":
                    errors = value.get('errors', [])
                    for error in errors:
                        logger.error(f"Error de WhatsApp: {error}")
                    continue
                elif payload_type != "message":
                    logger.info(f"Tipo de evento {payload_type} no procesable, ignorando")
                    continue

                # Solo procesar mensajes reales del usuario
                messages = value.get('messages', [])
                if not messages:
                    logger.info("No hay mensajes reales del usuario en este webhook, ignorando")
                    continue

                for message in messages:
                    if not message:
                        logger.warning("Objeto de mensaje vacío, ignorando")
                        continue

                    # Extraer información del mensaje
                    msg_type = message.get('type')

                    # Extraer texto según el tipo
                    if msg_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                    else:
                        if message.get('text') and isinstance(message.get('text'), dict):
                            message_text = message.get('text', {}).get('body', '')
                        else:
                            message_text = ''

                    if 'timestamp' not in message:
                        logger.warning("Mensaje sin timestamp; se registrará para inspección pero se procesará")

                    # Ignorar mensajes de sistema
                    if message.get('system') or 'notification' in str(message).lower():
                        logger.warning("Mensaje de sistema o notificación detectado, ignorando")
                        continue

                    if not message_text or not str(message_text).strip():
                        logger.warning("Mensaje sin texto extraíble; posible media/attachment - se ignora sin responder")
                        # No procesar mensajes sin texto para evitar respuestas vacías o duplicadas
                        continue

                    # Información del remitente
                    phone = message.get('from')
                    message_id = message.get('id')
                    timestamp = message.get('timestamp')

                    # Marcar mensaje actual para prevenir duplicados
                    set_current_webhook_message_id(message_id)

                    logger.info(f"Mensaje recibido: phone={phone}, text={str(message_text)[:60]}..., timestamp={timestamp}")

                    # Validaciones básicas
                    if not phone or not message_id:
                        logger.warning(f"Mensaje incompleto: phone={phone}, id={message_id}")
                        continue

                    # Evitar reprocesar mensajes
                    if ConversationMemory.is_message_processed(message_id):
                        logger.info(f"Mensaje {message_id} ya fue procesado anteriormente, ignorando")
                        continue

                    # Verificación de timestamp
                    try:
                        if timestamp:
                            msg_time = datetime.fromtimestamp(int(timestamp))
                            time_diff = (datetime.now() - msg_time).total_seconds()

                            if time_diff > 300:  # 5 minutos
                                logger.warning(f"Mensaje antiguo (>{time_diff:.0f}s), procesando con precaución")
                        else:
                            logger.info("Timestamp no disponible, continuando procesamiento")
                    except Exception as e:
                        logger.error(f"Error verificando timestamp del mensaje: {e}")
                        if not str(timestamp).isdigit() or len(str(timestamp)) != 10:
                            logger.warning(f"Timestamp inválido: {timestamp}")

                    # Marcar mensaje como procesado
                    ConversationMemory.mark_message_as_processed(message_id)

                    # Registrar tiempo de procesamiento
                    processing_start_time = datetime.now()

                    # Obtener perfil de WhatsApp si está disponible
                    whatsapp_profile = None
                    if 'contacts' in value and value['contacts']:
                        contact = value['contacts'][0]
                        whatsapp_profile = {
                            "name": contact.get('profile', {}).get('name')
                        }
                        logger.info(f"Perfil de WhatsApp obtenido: {whatsapp_profile}")

                    # Obtener historial de conversación
                    try:
                        conversation_history = get_conversation_history(phone)
                        logger.info(f"Historial recuperado para {phone}: {len(conversation_history)} mensajes")
                    except Exception as history_error:
                        logger.error(f"Error al obtener historial: {history_error}")
                        conversation_history = []

                    # **AQUÍ ES DONDE PROCESAMOS EL MENSAJE DEL USUARIO**
                    process_user_message(phone, message_text, conversation_history, whatsapp_profile)

        # Limpiar ID de mensaje actual
        clear_current_webhook_message_id()
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        logger.error(f"Error procesando webhook: {e}", exc_info=True)
        clear_current_webhook_message_id()
        return jsonify({"status": "error", "message": "Error interno"}), 500
    finally:
        clear_current_webhook_message_id()


def process_user_message(phone: str, message_text: str, conversation_history: list, whatsapp_profile: dict = None):
    """
    Procesa un mensaje individual del usuario 
    Esta es la función principal que orquesta toda la lógica de respuesta.
    """
    try:
        # Usar el AssistantOrchestrator para manejar routing, RAG y generación
        handled = handle_with_router(phone, message_text, conversation_history or [], whatsapp_profile or {})
        if handled:
            return  # El nuevo pipeline manejó completamente la consulta
    except Exception as e:
        logger.error(f"Error procesando mensaje con orchestrator: {e}", exc_info=True)
        # Continuar con lógica legacy si falla
        try:
            pending_pick = get_conversation_memory(phone, 'awaiting_name_pick')
            if pending_pick and isinstance(pending_pick, dict):
                kind = pending_pick.get('kind')  # 'course' | 'product' | 'webinar'
                cands = pending_pick.get('candidates') or []
                from utils.json_catalog import pick_by_name, format_course_full, format_course_temario, format_product_full, format_webinar_full
                picked = pick_by_name(cands, message_text, 'nombre' if kind != 'webinar' else 'title')
                if picked:
                    # Clear state
                    save_conversation_memory(phone, 'awaiting_name_pick', None)
                    # Save selection if course
                    if kind == 'course':
                        try:
                            save_conversation_memory(phone, 'selected_course', {
                                'id': picked.get('id'),
                                'name': picked.get('nombre')
                            })
                        except Exception:
                            pass
                        # If user initially asked for temario, we might have stored a hint
                        wants_temario = get_conversation_memory(phone, 'awaiting_name_pick_temario') or False
                        save_conversation_memory(phone, 'awaiting_name_pick_temario', None)
                        if wants_temario:
                            # Enviar temario y PDF solo si pidieron temario
                            send_text_message(phone, format_course_temario(picked))
                            try:
                                from utils.temario_handler import find_pdf_for_user_message
                                from ..whatsapp_message_handlers import send_document_message
                                pdf_info = find_pdf_for_user_message('temario', {'selected_course': {'id': picked.get('id'), 'name': picked.get('nombre')}})
                                if pdf_info and pdf_info.get('file_path'):
                                    send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                            except Exception:
                                pass
                            return
                        else:
                            # Solo información completa (sin PDF) cuando no piden temario
                            send_text_message(phone, format_course_full(picked))
                            return
                    elif kind == 'product':
                        try:
                            save_conversation_memory(phone, 'selected_product', {
                                'id': picked.get('id'),
                                'name': picked.get('nombre')
                            })
                        except Exception:
                            pass
                        send_text_message(phone, format_product_full(picked))
                        return
                    else:
                        # Guardar webinar seleccionado para consultas posteriores
                        try:
                            save_conversation_memory(phone, 'selected_webinar', {
                                'title': picked.get('title')
                            })
                        except Exception:
                            pass
                        send_text_message(phone, format_webinar_full(picked))
                        return
                else:
                    # Re-prompt with names again
                    names = [ (x.get('nombre') if kind!='webinar' else x.get('title')) for x in cands ]
                    names = [n for n in names if n]
                    if names:
                        send_text_message(phone, "No identifiqué la opción. Por favor responde con el nombre de una de estas: \n- " + "\n- ".join(names))
                        return
        except Exception as e:
            logger.debug(f"Follow-up name pick: {e}")

        # 0) Si previamente pedimos número de curso para temario/PDF, procesar aquí
        try:
            awaiting_temario = get_conversation_memory(phone, 'awaiting_temario_course') or False
            if awaiting_temario:
                from utils.temario_handler import extract_course_number, get_course_temario_message, find_pdf_for_user_message
                course_id = extract_course_number(message_text)
                if not course_id:
                    # Reintentar pedir número válido
                    from utils.temario_handler import ask_for_course_number
                    send_text_message(phone, ask_for_course_number())
                    return

                # Guardar selección y limpiar bandera
                try:
                    from models.courses import CourseManager
                    course = CourseManager.get_course_by_id(course_id)
                    save_conversation_memory(phone, 'selected_course', {
                        'id': course_id,
                        'name': getattr(course, 'nombre', None) or getattr(course, 'name', None) or f"Curso {course_id}"
                    })
                except Exception:
                    pass
                save_conversation_memory(phone, 'awaiting_temario_course', None)

                # Determinar acción deseada (texto o pdf)
                temario_action = get_conversation_memory(phone, 'awaiting_temario_action') or 'text'
                save_conversation_memory(phone, 'awaiting_temario_action', None)

                if temario_action == 'pdf':
                    from ..whatsapp_message_handlers import send_document_message
                    pdf_info = find_pdf_for_user_message(f"curso {course_id}", {
                        'selected_course': get_conversation_memory(phone, 'selected_course')
                    })
                    if pdf_info and pdf_info.get('file_path'):
                        send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                        send_text_message(phone, "Listo, te envié el temario en PDF. ¿Te comparto fechas, precio o te inscribo?")
                        return
                    else:
                        # Fallback a temario en texto
                        temario_msg = get_course_temario_message(course_id)
                        send_text_message(phone, temario_msg)
                        send_text_message(phone, "No encontré el PDF automáticamente. ¿Deseas que un asesor te lo comparta?")
                        return
                else:
                    temario_msg = get_course_temario_message(course_id)
                    send_text_message(phone, temario_msg)
                    send_text_message(phone, "¿Quieres que te envíe el temario en PDF?")
                    return
        except Exception as e:
            logger.debug(f"Follow-up temario handler: {e}")

        # 1.4) Detección de cambio de curso o mención directa de nombre de curso (sin perder contexto)
        # - Si el usuario menciona explícitamente otro curso por nombre, actualizamos la selección
        # - Si pide "otro curso" o "cambiar de curso" sin nombre, pedimos que responda con el nombre
        try:
            from utils.json_catalog import search_courses_by_text, pick_by_name, load_courses, format_course_full

            change_course_intent = any(k in msg_lower for k in [
                'cambiar de curso', 'cambiar curso', 'otro curso', 'ver otro curso',
                'ese no', 'no ese', 'no ese curso', 'prefiero el', 'mejor el'
            ])

            # Flags para decidir si respondemos de inmediato o dejamos que otras rutinas (atributos/temario) contesten
            wants_temario_inline = any(k in msg_lower for k in ['temario', 'contenido', 'programa'])
            attr_keywords_inline = ['precio', 'precios', 'costo', 'costos', 'fecha', 'fechas', 'ubicacion', 'ubicación', 'modalidad', 'duracion', 'duración', 'horario']
            asks_attribute_inline = any(k in msg_lower for k in attr_keywords_inline)

            # Buscar coincidencias sólidas por nombre, aunque no se haya dicho "curso"
            candidates = []
            try:
                candidates = search_courses_by_text(message_text, limit=3) or []
            except Exception:
                candidates = []
            picked = None
            try:
                picked = pick_by_name(candidates, message_text, 'nombre') if candidates else None
            except Exception:
                picked = None

            if picked:
                # Actualizar selección de curso en memoria
                try:
                    save_conversation_memory(phone, 'selected_course', {
                        'id': picked.get('id'),
                        'name': picked.get('nombre')
                    })
                except Exception:
                    pass

                # Si no pide atributo/temario explícito, devolvemos la ficha completa y terminamos.
                # Si pidió atributo o temario, sólo actualizamos la selección y dejamos que los bloques siguientes respondan.
                if not asks_attribute_inline and not wants_temario_inline:
                    send_text_message(phone, format_course_full(picked))
                    return
                # Dejar continuar para que el manejador de atributos/temario responda con el curso ya seleccionado

            elif change_course_intent:
                # Pide cambiar pero no dio nombre claro: pedir selección por nombre sin borrar el curso actual
                try:
                    all_courses = load_courses()
                    names = [c.get('nombre') for c in all_courses if c.get('nombre')]
                    sample = names[:5]
                    save_conversation_memory(phone, 'awaiting_name_pick', {
                        'kind': 'course',
                        'candidates': all_courses
                    })
                    send_text_message(phone, "¿Cuál curso te interesa ahora? Respóndeme con el nombre. Por ejemplo:\n- " + "\n- ".join(sample))
                    return
                except Exception:
                    pass
        except Exception as e:
            logger.debug(f"Direct course name/change detection: {e}")

        # 1.5) Si ya hay curso o webinar seleccionado, responder atributos específicos desde JSON
        try:
            # Cursos: fechas, ubicación, modalidad, duración, horario, precio, temario
            selected_course = get_conversation_memory(phone, 'selected_course')
            if isinstance(selected_course, dict):
                from utils.json_catalog import load_courses, format_course_temario
                course = None
                try:
                    for c in load_courses():
                        if c.get('id') == selected_course.get('id') or c.get('nombre') == selected_course.get('name'):
                            course = c
                            break
                except Exception:
                    course = None
                if course:
                    l = msg_lower
                    def send_attr(label: str, value: str):
                        if value:
                            send_text_message(phone, f"{label}: {value}")
                        else:
                            send_text_message(phone, f"No tengo {label.lower()} en el catálogo.")
                    if any(k in l for k in ['temario', 'contenido', 'programa']):
                        # Temario en texto + PDF si se puede
                        send_text_message(phone, format_course_temario(course))
                        try:
                            from utils.temario_handler import find_pdf_for_user_message
                            from ..whatsapp_message_handlers import send_document_message
                            pdf_info = find_pdf_for_user_message('temario', {'selected_course': selected_course})
                            if pdf_info and pdf_info.get('file_path'):
                                send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                        except Exception:
                            pass
                        return
                    if any(k in l for k in ['fecha', 'fechas', 'dia', 'día', 'cuando']):
                        fechas = course.get('proximas_fechas') or []
                        if fechas:
                            lines = []
                            for f in fechas:
                                if isinstance(f, dict):
                                    fecha = f.get('fecha')
                                    hor = f.get('horario')
                                    lines.append(f"• {fecha} — {hor}" if fecha and hor else f"• {fecha or hor}")
                                else:
                                    lines.append(f"• {str(f)}")
                            send_text_message(phone, "Próximas fechas:\n" + "\n".join(lines))
                        else:
                            send_text_message(phone, "No tengo próximas fechas en el catálogo.")
                        return
                    if any(k in l for k in ['ubicacion', 'ubicación']):
                        send_attr('Ubicación', course.get('ubicacion'))
                        return
                    if 'modalidad' in l:
                        send_attr('Modalidad', course.get('modalidad'))
                        return
                    if any(k in l for k in ['duracion', 'duración', 'dura', 'durar', 'durará', 'cuanto dura', 'cuánto dura']):
                        send_attr('Duración', course.get('duracion'))
                        return
                    if 'horario' in l:
                        send_attr('Horario', course.get('horario'))
                        return
                    if any(k in l for k in ['precio', 'costo']):
                        send_attr('Precio', course.get('precio'))
                        return

            # Webinars: fechas, horario, link
            selected_webinar = get_conversation_memory(phone, 'selected_webinar')
            if isinstance(selected_webinar, dict):
                from utils.json_catalog import load_webinars, format_webinar_full
                w = None
                try:
                    for item in load_webinars():
                        if item.get('title') == selected_webinar.get('title'):
                            w = item
                            break
                except Exception:
                    w = None
                if w:
                    l = msg_lower
                    if any(k in l for k in ['fecha', 'fechas']):
                        fechas = [f for f in (w.get('fechas') or []) if f]
                        send_text_message(phone, "Fechas: " + (", ".join(fechas) if fechas else 'No disponibles'))
                        return
                    if 'horario' in l:
                        horarios = [h for h in (w.get('horario') or []) if h]
                        send_text_message(phone, "Horario: " + (", ".join(horarios) if horarios else 'No disponible'))
                        return
                    if any(k in l for k in ['link', 'registro', 'inscripcion', 'inscripción']):
                        send_text_message(phone, f"Registro: {w.get('link') or 'No disponible'}")
                        return
                    # Si piden info del webinar en general
                    if any(k in l for k in ['info', 'informacion', 'información', 'detalles', 'detalle']):
                        send_text_message(phone, format_webinar_full(w))
                        return

            # Productos: precio, especificaciones, descripción, link
            selected_product = get_conversation_memory(phone, 'selected_product')
            if isinstance(selected_product, dict):
                from utils.json_catalog import load_products, format_product_full
                prod = None
                try:
                    for p in load_products():
                        if p.get('id') == selected_product.get('id') or p.get('nombre') == selected_product.get('name'):
                            prod = p
                            break
                except Exception:
                    prod = None
                if prod:
                    l = msg_lower
                    if any(k in l for k in ['precio', 'costo']):
                        price = prod.get('precio')
                        send_text_message(phone, f"Precio: {price}" if price else 'No disponible')
                        return
                    if any(k in l for k in ['especificacion', 'especificación', 'especificaciones', 'material']):
                        specs = prod.get('especificaciones') or []
                        if specs:
                            send_text_message(phone, "Especificaciones:\n" + "\n".join(f"• {s}" for s in specs))
                        else:
                            send_text_message(phone, 'No hay especificaciones en el catálogo.')
                        return
                    if any(k in l for k in ['descripcion', 'descripción', 'caracteristica', 'características']):
                        desc = prod.get('descripcion')
                        send_text_message(phone, desc or 'No hay descripción en el catálogo.')
                        return
                    if any(k in l for k in ['link', 'mas info', 'más info', 'url']):
                        send_text_message(phone, f"Más info: {prod.get('link') or 'No disponible'}")
                        return
        except Exception as e:
            logger.debug(f"Selected entity attribute handler: {e}")

        # 1.6) Si el usuario pregunta por atributos (precio, fechas, etc.) pero no hay curso seleccionado, pedir el nombre del curso
        try:
            attr_keywords = ['precio', 'precios', 'costo', 'costos', 'fecha', 'fechas', 'ubicacion', 'ubicación', 'modalidad', 'duracion', 'duración', 'dura', 'durar', 'durará', 'horario', 'temario', 'contenido', 'programa', 'cuanto dura', 'cuánto dura']
            if any(k in msg_lower for k in attr_keywords):
                selected_course = get_conversation_memory(phone, 'selected_course')
                if not isinstance(selected_course, dict):
                    from utils.json_catalog import load_courses
                    names = [c.get('nombre') for c in load_courses() if c.get('nombre')]
                    sample = names[:3]
                    prompt = "¿De qué curso necesitas esa información? Respóndeme con el nombre, por ejemplo:\n- " + "\n- ".join(sample)
                    send_text_message(phone, prompt)
                    # Guardar estado para selección por nombre (sugerencias de todos)
                    try:
                        from utils.json_catalog import load_courses
                        save_conversation_memory(phone, 'awaiting_name_pick', {
                            'kind': 'course',
                            'candidates': load_courses()
                        })
                    except Exception:
                        pass
                    return
        except Exception as e:
            logger.debug(f"Attribute-only prompt: {e}")

        # 1) Flujo: Temario y envío de PDF
        try:
            from utils.temario_handler import (
                is_temario_request, extract_course_number, get_course_temario_message,
                ask_for_course_number, find_pdf_for_user_message
            )

            # ¿Piden "temario" o el PDF del temario?
            wants_pdf = any(k in msg_lower for k in ['enviar pdf', 'pdf del temario', 'mandame el pdf', 'mándame el pdf'])
            if is_temario_request(message_text) or wants_pdf:
                # Ver si ya hay curso seleccionado en memoria
                selected_course = get_conversation_memory(phone, 'selected_course')
                course_id = extract_course_number(message_text)
                if not course_id and isinstance(selected_course, dict):
                    course_id = selected_course.get('id')

                if wants_pdf:
                    # Intentar enviar PDF directamente
                    from ..whatsapp_message_handlers import send_document_message
                    pdf_info = find_pdf_for_user_message(message_text, {
                        'selected_course': selected_course
                    })
                    if pdf_info and pdf_info.get('file_path'):
                        send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                        send_text_message(phone, "Listo, te envié el temario en PDF. ¿Te gustaría conocer fechas, precio o inscribirte?")
                        return
                    else:
                        # Si no se pudo inferir, pedir el número de curso
                        save_conversation_memory(phone, 'awaiting_temario_course', True)
                        save_conversation_memory(phone, 'awaiting_temario_action', 'pdf')
                        send_text_message(phone, ask_for_course_number())
                        return

                # Si piden temario en texto
                if not course_id:
                    save_conversation_memory(phone, 'awaiting_temario_course', True)
                    save_conversation_memory(phone, 'awaiting_temario_action', 'text')
                    send_text_message(phone, ask_for_course_number())
                    return

                # Guardar selección de curso en memoria
                try:
                    from services.conversation_memory_utils import save_conversation_memory
                    from models.courses import CourseManager
                    course = CourseManager.get_course_by_id(course_id)
                    if course:
                        save_conversation_memory(phone, 'selected_course', {
                            'id': course_id,
                            'name': getattr(course, 'nombre', None) or getattr(course, 'name', None) or f"Curso {course_id}"
                        })
                except Exception:
                    pass

                # Responder con el temario formateado
                temario_msg = get_course_temario_message(course_id)
                send_text_message(phone, temario_msg)
                send_text_message(phone, "¿Quieres que te envíe el temario en PDF?")
                return
        except Exception as e:
            logger.debug(f"Flujo temario/PDF: {e}")

        # 2) Flujo: Cotización, Facturación, Inscripción (captura de datos)
        try:
            # Detectores básicos
            wants_quote = any(k in msg_lower for k in ['cotización', 'cotizacion', 'cotizar', 'precio de', 'presupuesto'])
            wants_invoice = any(k in msg_lower for k in ['factura', 'facturación', 'facturacion', 'rfc'])
            wants_enroll = any(k in msg_lower for k in ['inscripción', 'inscripcion', 'inscribirme', 'registrarme'])

            # Estado de captura en memoria
            awaiting = get_conversation_memory(phone, 'awaiting_data') or {}

            def prompt_missing(fields, intro=None):
                labels = {
                    'nombre': 'nombre completo',
                    'empresa': 'empresa',
                    'correo': 'correo electrónico',
                    'telefono': 'teléfono',
                    'rfc': 'RFC',
                    'razon_social': 'razón social',
                    'direccion': 'dirección fiscal',
                    'curso': 'curso de interés'
                }
                items = [labels[f] for f in fields]
                base = intro or 'Para continuar, compárteme:'
                return base + "\n- " + "\n- ".join(items)

            # Si ya estamos esperando datos, no reiniciar; intentar detectar si el usuario proporcionó algo
            if awaiting and isinstance(awaiting, dict):
                provided = {}
                # Heurística muy simple para extraer datos básicos
                import re
                email = re.search(r"[\w\.-]+@[\w\.-]+", message_text or '')
                phone_digits = re.sub(r"\D", "", message_text or '')
                if email:
                    provided['correo'] = email.group(0)
                if len(phone_digits) >= 10:
                    provided['telefono'] = phone_digits[-10:]
                # RFC MX aproximado
                rfc = re.search(r"\b[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{0,3}\b", (message_text or '').upper())
                if rfc:
                    provided['rfc'] = rfc.group(0)

                # Nombre simple: primera frase antes de coma o salto de línea
                name_match = re.match(r"^([A-Za-zÁÉÍÓÚÑáéíóúñ'\-\s]{3,})[\,\n]", message_text or '')
                if name_match:
                    provided['nombre'] = name_match.group(1).strip()

                # Merge y volver a preguntar por faltantes
                awaiting.update(provided)
                save_conversation_memory(phone, 'awaiting_data', awaiting)
                missing = [f for f in awaiting.get('required', []) if not awaiting.get(f)]
                if missing:
                    send_text_message(phone, prompt_missing(missing, intro='Perfecto, me faltaría:'))
                    return
                else:
                    # Datos completos
                    purpose = awaiting.get('purpose')
                    save_conversation_memory(phone, 'client_data', awaiting)
                    save_conversation_memory(phone, 'awaiting_data', None)
                    if purpose == 'cotizacion':
                        send_text_message(phone, "Gracias. Con estos datos puedo generar tu cotización o pasarlos a un asesor. ¿Deseas que te contacte un asesor ahora?")
                    elif purpose == 'facturacion':
                        send_text_message(phone, "Gracias. Con estos datos podemos generar tu factura. ¿Deseas que la envíe por correo cuando esté lista?")
                    else:
                        send_text_message(phone, "Perfecto. Ya con tus datos podemos inscribirte. ¿Quieres que te comparta el enlace de pago o prefieres transferencia?")
                    return

            # Iniciar los flujos si el usuario lo pide
            if wants_quote or wants_invoice or wants_enroll:
                selected_course = get_conversation_memory(phone, 'selected_course')
                base_required = ['nombre', 'correo', 'telefono']
                purpose = 'cotizacion' if wants_quote else ('facturacion' if wants_invoice else 'inscripcion')
                required = base_required.copy()
                if purpose == 'facturacion':
                    required += ['rfc', 'razon_social', 'direccion']
                if not selected_course:
                    required += ['curso']

                save_conversation_memory(phone, 'awaiting_data', {
                    'purpose': purpose,
                    'required': required,
                    'nombre': None,
                    'correo': None,
                    'telefono': None,
                    'rfc': None,
                    'razon_social': None,
                    'direccion': None,
                    'curso': selected_course.get('name') if isinstance(selected_course, dict) else None
                })

                intro = {
                    'cotizacion': 'Para preparar tu cotización, necesito:',
                    'facturacion': 'Para generar tu factura, necesito:',
                    'inscripcion': 'Para completar tu inscripción, necesito:'
                }[purpose]
                send_text_message(phone, prompt_missing(required, intro=intro))
                return
        except Exception as e:
            logger.debug(f"Flujo cotización/facturación/inscripción: {e}")

        # 3) Si no se activó ningún flujo específico, usar IA como fallback principal
        # 2.5) Resolver consultas de cursos/webinars/productos contra los JSON por palabras (no números)
        try:
            from utils.json_catalog import (
                search_courses_by_text, search_products_by_text, search_webinars_by_text,
                format_course_full, format_course_temario, format_product_full, format_webinar_full,
                mentions_online_courses, pick_by_name
            )

            lower = msg_lower
            wants_temario = any(k in lower for k in ['temario', 'contenido', 'programa'])
            is_course_query = any(k in lower for k in ['curso', 'cursos', 'capacitacion', 'capacitación', 'clase'])
            is_product_query = any(k in lower for k in ['producto', 'productos', 'bobina', 'ducto', 'tritubo', 'jumper', 'cable', 'conector'])
            is_webinar_query = any(k in lower for k in ['webinar', 'seminario', 'en linea', 'en línea', 'online', 'virtual'])

            # Prioridad: si piden modalidad online o mencionan webinars, responder con webinars
            if mentions_online_courses(message_text) or is_webinar_query:
                w = search_webinars_by_text(message_text, limit=3)
                if not w:
                    w = search_webinars_by_text('webinar', limit=3)
                if w:
                    lines = [format_webinar_full(x) for x in w]
                    send_text_message(phone, "Aquí tienes opciones en línea (webinars):\n\n" + "\n\n".join(lines))
                    return

            # Cursos por texto
            if is_course_query:
                # Si ya hay seleccionado, y piden temario, usar ese
                selected = get_conversation_memory(phone, 'selected_course')
                if wants_temario and isinstance(selected, dict):
                    from utils.json_catalog import load_courses
                    courses = load_courses()
                    match = next((c for c in courses if c.get('id') == selected.get('id') or c.get('nombre') == selected.get('name')), None)
                    if match:
                        send_text_message(phone, format_course_temario(match))
                        return

                results = search_courses_by_text(message_text, limit=3)
                if results:
                    # Si múltiples y el nombre en texto no es obvio, pedir selección por nombre (no números)
                    from utils.json_catalog import pick_by_name
                    # Si hay un match muy obvio por nombre dentro del texto, elegirlo
                    picked = pick_by_name(results, message_text, 'nombre')
                    if not picked and len(results) > 1:
                        names = [r.get('nombre') for r in results if r.get('nombre')]
                        save_conversation_memory(phone, 'awaiting_name_pick', {
                            'kind': 'course',
                            'candidates': results
                        })
                        save_conversation_memory(phone, 'awaiting_name_pick_temario', wants_temario)
                        send_text_message(phone, "Encontré varias opciones, ¿cuál te interesa?\n- " + "\n- ".join(names))
                        return
                    picked = picked or results[0]
                    # Guardar selección para siguientes turnos
                    try:
                        save_conversation_memory(phone, 'selected_course', {
                            'id': picked.get('id'),
                            'name': picked.get('nombre')
                        })
                    except Exception:
                        pass

                    if wants_temario:
                        send_text_message(phone, format_course_temario(picked))
                        return
                    else:
                        # Solo información completa (sin PDF) cuando no piden temario
                        send_text_message(phone, format_course_full(picked))
                        return
            
            # Productos por texto
            if is_product_query:
                pr = search_products_by_text(message_text, limit=3)
                if pr:
                    if len(pr) > 1:
                        names = [p.get('nombre') for p in pr if p.get('nombre')]
                        save_conversation_memory(phone, 'awaiting_name_pick', {
                            'kind': 'product',
                            'candidates': pr
                        })
                        send_text_message(phone, "Tengo varias coincidencias, dime cuál: \n- " + "\n- ".join(names))
                        return
                    # Única coincidencia: guardar selección y responder ficha
                    picked_p = pr[0]
                    try:
                        save_conversation_memory(phone, 'selected_product', {
                            'id': picked_p.get('id'),
                            'name': picked_p.get('nombre')
                        })
                    except Exception:
                        pass
                    send_text_message(phone, "\n\n".join(format_product_full(p) for p in pr))
                    return

            # Webinars por texto si lo piden explícito
            if is_webinar_query:
                w = search_webinars_by_text(message_text, limit=3)
                if w:
                    if len(w) > 1:
                        names = [x.get('title') for x in w if x.get('title')]
                        save_conversation_memory(phone, 'awaiting_name_pick', {
                            'kind': 'webinar',
                            'candidates': w
                        })
                        send_text_message(phone, "¿Cuál webinar te interesa?\n- " + "\n- ".join(names))
                        return
                    send_text_message(phone, "\n\n".join(format_webinar_full(x) for x in w))
                    return
        except Exception as e:
            logger.debug(f"JSON resolver error: {e}")

        # 3) Si no se activó ningún flujo específico, usar IA como fallback principal
        system_prompt = (
            "Eres un asistente conversacional amable y natural. Responde como una persona, breve y claro, "
            "con empatía y sin sonar a vendedor. Si el usuario pide información de cursos, webinars o productos, "
            "usa exclusivamente los datos disponibles en el contexto (BD o los archivos JSON cargados) y no inventes. "
            "Mantén el contexto de la conversación y evita repetir lo ya dicho."
        )

        # Prefer two-pass grounded pipeline to avoid mixing domains and improve name resolution (e.g., PonLAN)
        try:
            from services.chat_ai import chat_with_gemini_two_pass
            ai_response = chat_with_gemini_two_pass(
                phone=phone,
                message=message_text,
                include_whatsapp_profile=whatsapp_profile or {}
            )
        except Exception:
            ai_response = chat_with_gemini(
                phone=phone,
                message=message_text,
                system_prompt=system_prompt,
                include_whatsapp_profile=whatsapp_profile or {}
            )

        if ai_response and ai_response.strip():
            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Gracias por tu mensaje. ¿Podrías darme un poco más de detalle para ayudarte mejor?")
        return
    except Exception as e:
        logger.error(f"Error procesando mensaje de usuario: {e}", exc_info=True)
        send_text_message(phone, "Disculpa, ocurrió un error procesando tu mensaje. Por favor intenta de nuevo.")


def handle_course_intent(phone: str, message_text: str, msg_lower: str):
    """Maneja intenciones relacionadas con cursos"""

    # Detectar solicitudes específicas de lista
    if any(phrase in msg_lower for phrase in ['lista de cursos', 'qué cursos', 'que cursos', 'cursos disponibles']):
        handle_course_list_request(phone)
        return

    if any(phrase in msg_lower for phrase in ['lista de webinars', 'qué webinars', 'que webinars', 'webinars disponibles']):
        handle_webinar_list_request(phone)
        return

    # Respuesta sobre costos
    if any(word in msg_lower for word in ['costo', 'costos', 'precio', 'precios', 'cuánto', 'cuanto']):
        send_text_message(phone, "💰 Gratis — se imparte en línea todos los martes")
        return

    # Usar el manejador de cursos existente
    try:
        result = CourseConversationManager.handle_course_query(phone, message_text)
        if result:
            send_text_message(phone, result)
        else:
            # Fallback a lista de cursos
            handle_course_list_request(phone)
    except Exception as e:
        logger.error(f"Error en handle_course_intent: {e}")
        handle_course_list_request(phone)


def handle_technical_intent(phone: str, message_text: str, conversation_history: list):
    """Maneja intenciones técnicas usando IA"""

    try:
        # Usar el sistema de IA para respuestas técnicas
        ai_response = chat_with_gemini(phone=phone, message=message_text)

        if ai_response and ai_response.strip():
            # Añadir sugerencia de curso si es apropiado
            if any(word in message_text.lower() for word in ['empalme', 'fibra', 'otdr', 'fusionadora', 'conector']):
                ai_response += "\n\n💡 Si te interesa profundizar en este tema, tenemos cursos especializados. Escribe 'cursos' para ver las opciones disponibles."

            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Para consultas técnicas detalladas, nuestro equipo estará encantado de ayudarte. ¿Te gustaría que un asesor se ponga en contacto contigo?")
    except Exception as e:
        logger.error(f"Error en respuesta técnica: {e}")
        send_text_message(phone, "Para consultas técnicas detalladas, te recomendamos contactar directamente con nuestro equipo de soporte especializado.")


def handle_product_intent(phone: str, message_text: str):
    """Maneja intenciones sobre productos"""

    # Extraer keywords de productos del mensaje
    product_keywords = []
    for word in ['bobina', 'ducto', 'tritubo', 'jumper', 'cable', 'conector']:
        if word in message_text.lower():
            product_keywords.append(word)

    # Intentar respuesta desde base de datos
    fallback_text = "Contamos con una amplia gama de productos para redes de fibra óptica: bobinas, ductos, tritubos, jumpers, cables y conectores. Para información específica de productos y cotizaciones, por favor contacta con nuestro equipo comercial."
    fallback_link = "https://splitel.com/productos"

    send_db_or_fallback_message(
        phone,
        product_keywords or ['productos', 'fibra optica'],
        fallback_text,
        fallback_link,
        collections=('products',)
    )


def handle_advisor_intent(phone: str, message_text: str):
    """Maneja solicitudes de asesoría"""

    prompt = advisor_request_prompt()
    send_text_message(phone, prompt)


def handle_general_intent(phone: str, message_text: str, conversation_history: list):
    """Maneja intenciones generales"""

    msg_lower = message_text.lower()

    # Saludos y información básica
    if any(word in msg_lower for word in ['hola', 'buenos', 'buenas']):
        # Evitar enviar saludos duplicados en ventana corta (120s)
        try:
            from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
            import time
            last_greet = get_conversation_memory(phone, 'last_greeting_ts') or 0
            now = int(time.time())
            if now - int(last_greet) < 120:
                logger.info(f"Saltando saludo duplicado para {phone} (cooldown activo)")
                return
            save_conversation_memory(phone, 'last_greeting_ts', now)
        except Exception:
            pass
        send_text_message(phone, "¡Hola! Soy el asistente de Splitel. Puedo ayudarte con:\n\n🔧 Consultas técnicas\n📚 Información sobre cursos y webinars\n🛒 Productos y servicios\n📞 Contacto con asesores\n\n¿En qué puedo ayudarte hoy?")
        return

    # Información de la empresa
    if any(word in msg_lower for word in ['quién', 'quien', 'empresa', 'splitel']):
        send_text_message(phone, "Splitel es una empresa especializada en soluciones de fibra óptica y redes de telecomunicaciones. Ofrecemos productos, servicios y capacitación técnica especializada.\n\n¿Te gustaría saber más sobre algún servicio específico?")
        return

    # Horarios y contacto
    if any(word in msg_lower for word in ['horario', 'contacto', 'teléfono', 'telefono']):
        send_text_message(phone, "📞 Información de contacto:\n• Horario: Lunes a Viernes 9:00 - 18:00\n• Teléfono: [Número de contacto]\n• Email: [Email de contacto]\n\n¿Necesitas que un asesor se comunique contigo?")
        return

    # Ubicación
    if any(word in msg_lower for word in ['dónde', 'donde', 'ubicación', 'ubicacion', 'dirección', 'direccion']):
        send_text_message(phone, "📍 Nos encontramos en [Dirección de la empresa].\n\n¿Necesitas direcciones específicas o información sobre cómo llegar?")
        return

    # Fallback usando IA para preguntas generales
    try:
        ai_response = chat_with_gemini(phone=phone, message=message_text)
        if ai_response and ai_response.strip():
            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Gracias por tu mensaje. ¿Podrías ser más específico sobre lo que necesitas? Puedo ayudarte con consultas técnicas, información sobre cursos, productos o ponerte en contacto con un asesor.")
    except Exception as e:
        logger.error(f"Error en respuesta general: {e}")
        send_text_message(phone, "Gracias por tu mensaje. ¿Podrías ser más específico sobre lo que necesitas? Puedo ayudarte con consultas técnicas, información sobre cursos, productos o ponerte en contacto con un asesor.")