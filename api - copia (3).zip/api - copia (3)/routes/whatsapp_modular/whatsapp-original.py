import requests
import logging
import json
import traceback
import re
import unicodedata
import os
import copy
import mimetypes
import importlib
from typing import Optional, Dict, Any
from datetime import datetime
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin
from services.chat_ai import chat_with_gemini
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)
from utils.socketio_utils import safe_emit

# Configurar logger para este módulo
logger = logging.getLogger(__name__)
from services.ml_service import ml_service
# Importación global de funciones de memoria de conversación
from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
# Bring default advisor phone into module scope so notification code can always use it
try:
    from routes.advisor_fallbacks import DEFAULT_ADVISOR_PHONE
except Exception:
    DEFAULT_ADVISOR_PHONE = os.environ.get('DEFAULT_ADVISOR_PHONE', '5214427843528')

def _import_courses_adapter():

    try:
        return importlib.import_module('utils.courses_adapter')
    except Exception as e:
        # Keep debug-level log for diagnostics but don't raise.
        logger.debug(f"_import_courses_adapter import failed: {e}")
        return None

# === RESPUESTA DINÁMICA DE CURSOS POR MODALIDAD ===
def get_courses_by_modalidad_response(modalidad: str) -> str:
    """Busca cursos disponibles en la modalidad solicitada y genera una respuesta natural."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            cursos = [c for c in data if modalidad.lower() in (c.get('modalidad','').lower())]
            if not cursos:
                return f"Por el momento no tenemos cursos en modalidad '{modalidad}'. ¿Te gustaría recibir información de los cursos presenciales o de otra modalidad?"
            response = f"Estos son los cursos disponibles en modalidad *{modalidad.title()}*:\n\n"
            for c in cursos:
                nombre = c.get('nombre','')
                fechas = c.get('proximas_fechas',[])
                fecha_str = fechas[0]['fecha'] if fechas and 'fecha' in fechas[0] else 'Próxima fecha por definir'
                response += f"• {nombre}\n  Próxima fecha: {fecha_str}\n"
            response += "\n¿Te interesa alguno? Puedo enviarte el temario, precio o ayudarte a inscribirte."
            return response
        else:
            return "No pude acceder a la base de cursos. Intenta más tarde."
    except Exception as e:
        logger.error(f"Error en get_courses_by_modalidad_response: {e}")
        return "Ocurrió un error buscando los cursos por modalidad."

def _load_local_webinars():
   
    try:
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.webinars.json'))
        if not os.path.exists(path):
            return []
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        webinars = []
        for i, item in enumerate(data, start=1):
            # Normalize keys to be compatible with DB documents used elsewhere
            w = {}
            w['_id'] = str(i)
            w['title'] = item.get('title') or item.get('name')
            w['description'] = item.get('description')
            # JSON uses 'fechas' and 'horario'
            fechas = item.get('fechas') or item.get('fechas', [])
            if isinstance(fechas, list):
                # join non-empty
                w['date'] = ", ".join([f for f in fechas if f])
            else:
                w['date'] = fechas or ''
            horario = item.get('horario') or item.get('horario', [])
            if isinstance(horario, list) and horario:
                w['start_date'] = horario[0]
            else:
                w['start_date'] = (horario if isinstance(horario, str) else '')
            w['link'] = item.get('link') or item.get('registration') or item.get('enroll_link')
            w['temario'] = item.get('temario') or item.get('syllabus') or item.get('materials') or item.get('pdf')
            w['modalidad'] = item.get('modalidad') or 'en línea'
            webinars.append(w)
        return webinars
    except Exception as e:
        logger.debug(f"_load_local_webinars error: {e}")
        return []

def _normalize_phone_value(phone):
    try:
        if phone is None:
            return None
        s = str(phone).strip()
        if not s:
            return None
        s = re.sub(r'[\s\-()]+', '', s)
        if s.startswith('+'):
            s = s[1:]
        # Si empieza con '521' y tiene más de 10 dígitos, recorta a los últimos 10
        if s.startswith('521') and len(s) > 10:
            s = s[-10:]
        # Solo acepta números de 10 dígitos
        if not re.fullmatch(r'\d{10}', s):
            return None
        return s
    except Exception:
        return str(phone) if phone is not None else None

def send_message_parts(phone: str, parts: list, meta_key: str = 'pending_message_parts') -> bool:
   
    try:
        if not parts:
            return False
        # Send first part
        first = parts[0]
        send_text_message(phone, first)
        if len(parts) > 1:
            remaining = parts[1:]
            save_conversation_memory(phone, meta_key, {
                'parts': remaining,
                'index': 0,
                'created_at': datetime.now().isoformat()
            })
        else:
            # ensure no pending data
            try:
                save_conversation_memory(phone, meta_key, None)
            except Exception:
                pass
        return True
        # If more parts remain, save them along with current index
        if len(parts) > 1:
            remaining = parts[1:]
            save_conversation_memory(phone, meta_key, {
                'parts': remaining,
                'index': 0,
                'created_at': datetime.now().isoformat()
            })
        else:
            # ensure no pending data
            try:
                save_conversation_memory(phone, meta_key, None)
            except Exception:
                pass
        return True
    except Exception as e:
        logger.error(f"send_message_parts error: {e}")
        return False

def continue_pending_parts(phone: str, meta_key: str = 'pending_message_parts') -> bool:
    try:
        mem = get_conversation_memory(phone, meta_key)
        if not mem or not isinstance(mem, dict):
            return False
        parts = mem.get('parts') or []
        idx = mem.get('index', 0)
        if idx >= len(parts):
            # cleanup
            try:
                save_conversation_memory(phone, meta_key, None)
            except Exception:
                pass
            return False
        # send current
        send_text_message(phone, parts[idx])
        # update index
        idx += 1
        if idx >= len(parts):
            try:
                save_conversation_memory(phone, meta_key, None)
            except Exception:
                pass
        else:
            try:
                save_conversation_memory(phone, meta_key, {'parts': parts, 'index': idx, 'created_at': mem.get('created_at')})
            except Exception:
                pass
        return True
    except Exception as e:
        logger.error(f"continue_pending_parts error: {e}")
        return False

def find_pdf_for_user_message(query: str, context: Dict[str, Any] = None):

    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'find_pdf_for_user_message'):
        try:
            return ca.find_pdf_for_user_message(query, context=context)
        except Exception as e:
            logger.debug(f"find_pdf_for_user_message adapter error: {e}")
            return None
    return None

def find_local_asset_pdf_for_course(course_id: Any):

    try:
        # assets folder is sibling of the api package (api/assets)
        assets_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
        # Map known course ids to filenames (based on assets folder contents)
        mapping = {
            1: '1.Cableado estructurado para redes de fibra y cobre.pdf',
            2: '2.Redes de fibra óptica planta externa.pdf',
            3: '3.Redes de fibra óptica FTTH para WISP e ISP.pdf',
            4: '4.PONLAN redes pasivas para entornos enterprise.pdf',
            5: '5.Empalmes y mediciones con OTDR de un enlace de fibra óptica.pdf'
        }
        # Accept str ids too
        try:
            key = int(course_id)
        except Exception:
            # If course_id is a dict or has 'id' key, handle it
            if isinstance(course_id, dict) and course_id.get('id'):
                try:
                    key = int(course_id.get('id'))
                except Exception:
                    key = None
            else:
                key = None

        filename = mapping.get(key)
        if not filename:
            return None

        full_path = os.path.join(assets_dir, filename)
        if os.path.exists(full_path):
            logger.info(f"Using local asset PDF for course {course_id}: {full_path}")
            return {'pdf_path': full_path, 'source': 'assets'}
    except Exception as e:
        logger.debug(f"find_local_asset_pdf_for_course error: {e}")
    return None

def strip_course_mentions_from_text(text: str) -> str:
    if not text or not isinstance(text, str):
        return text
    course_kw = ['curso', 'cursos', 'temario', 'capacitación', 'capacitación', 'inscrib', 'precio', 'fechas', 'duración', 'duracion', 'horario', 'instructor', 'material didáctico']
    lines = text.splitlines()
    filtered = []
    for ln in lines:
        low = ln.lower()
        if any(kw in low for kw in course_kw):
            # skip this line
            continue
        filtered.append(ln)
    # Clean up excessive blank lines
    result = '\n'.join([l for l in filtered]).strip()
    return result

def send_course_temario_pdf(phone: str, course_id: Any, course_name: str = None) -> bool:
    
    try:
        pdf_res = None
        try:
            pdf_res = find_pdf_for_user_message(f"temario {course_id}", context={'relevant_courses': [{'id': course_id, 'name': course_name}]})
        except Exception:
            pdf_res = None

        if not pdf_res:
            pdf_res = find_local_asset_pdf_for_course(course_id)

        if pdf_res and pdf_res.get('pdf_path') and os.path.exists(pdf_res['pdf_path']):
            try:
                res = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario - {course_name or ''}")
                return bool(res)
            except Exception as e:
                logger.debug(f"send_course_temario_pdf send error: {e}")
                return False
    except Exception as e:
        logger.debug(f"send_course_temario_pdf error: {e}")
    return False

def get_course_schedule_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_schedule_message'):
        try:
            return ca.get_course_schedule_message(cid)
        except Exception as e:
            logger.debug(f"get_course_schedule_message adapter error: {e}")
    # Fallback: try reading local JSON file with course listings
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # Accept dict-like cid
            try:
                key = int(cid)
            except Exception:
                # try to extract id from dict
                if isinstance(cid, dict) and cid.get('id'):
                    try:
                        key = int(cid.get('id'))
                    except Exception:
                        key = None
                else:
                    key = None

            for item in (data or []):
                if item.get('id') == key:
                    fechas = item.get('proximas_fechas') or []
                    if not fechas:
                        horario = item.get('horario') or ''
                        duracion = item.get('duracion') or ''
                        return f"Próximas fechas no listadas. Horario: {horario}. Duración: {duracion}."
                    # Build a concise schedule message
                    parts = []
                    for fobj in fechas:
                        fr = fobj.get('fecha')
                        hr = fobj.get('horario') or item.get('horario')
                        if fr:
                            parts.append(f"{fr} — {hr}")
                    return "; ".join(parts) if parts else "Fechas próximas no disponibles."
    except Exception as e:
        logger.debug(f"get_course_schedule_message JSON fallback error: {e}")

    return "Información de fechas no disponible."

def get_course_price_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_price_message'):
        try:
            return ca.get_course_price_message(cid)
        except Exception as e:
            logger.debug(f"get_course_price_message adapter error: {e}")
    # Fallback: try reading local JSON file
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            try:
                key = int(cid)
            except Exception:
                if isinstance(cid, dict) and cid.get('id'):
                    try:
                        key = int(cid.get('id'))
                    except Exception:
                        key = None
                else:
                    key = None

            for item in (data or []):
                if item.get('id') == key:
                    precio = item.get('precio') or item.get('price')
                    if precio:
                        return precio
                    else:
                        return "Precio no disponible para este curso."
    except Exception as e:
        logger.debug(f"get_course_price_message JSON fallback error: {e}")

    return "Información de precios no disponible."

def get_course_location_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_location_message'):
        try:
            res = ca.get_course_location_message(cid)
            if isinstance(res, str) and res.strip() and 'no disponible' not in res.lower():
                return res
        except Exception as e:
            logger.debug(f"get_course_location_message adapter error: {e}")

    try:
        from utils.courses_adapter import get_course_by_id
        course = get_course_by_id(cid)
        if course:
            ubicacion = course.get('ubicacion') or course.get('location') or course.get('ubicación')
            if ubicacion:
                return f"El curso se imparte en: {ubicacion}"
    except Exception as e:
        logger.debug(f"get_course_location_message direct lookup error: {e}")

    return "Por ahora nuestros cursos solo se imparten en Queretaró de manera presencial"

def select_course_by_name(phone, text):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'select_course_by_name'):
        try:
            return ca.select_course_by_name(phone, text)
        except Exception as e:
            logger.debug(f"select_course_by_name adapter error: {e}")
        return {'selected': False, 'candidates': [], 'message': 'No encontré cursos que coincidan con esa búsqueda.'}

def format_course_for_whatsapp(details):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'format_course_for_whatsapp'):
        try:
            return ca.format_course_for_whatsapp(details)
        except Exception as e:
            logger.debug(f"format_course_for_whatsapp adapter error: {e}")
    return "Información del curso no disponible."

# ==========================================
# FUNCIONES SIMPLES Y DIRECTAS
# ==========================================

def send_course_pdf_simple(phone: str, message_text: str) -> bool:
    try:
        logger.info(f"[PDF_SIMPLE] Procesando solicitud de {phone}: {message_text}")
        
        course_id = None
        course_name = None
        
        message_lower = message_text.lower()
        
        # Mapeo de palabras clave a cursos
        course_keywords = {
            1: {
                'name': 'Cableado estructurado para redes de fibra y cobre',
                'keywords': ['cableado', 'estructurado'],
                'short_name': 'Cableado Estructurado'
            },
            2: {
                'name': 'Redes de fibra óptica planta externa',
                'keywords': ['planta externa'],
                'short_name': 'Planta Externa'
            },
            3: {
                'name': 'Redes de fibra óptica FTTH para WISP e ISP',
                'keywords': ['wisp e isp'],
                'short_name': 'FTTH para WISP e ISP'
            },
            4: {
                'name': 'PON/LAN redes pasivas para entornos enterprise',
                'keywords': ['pon', 'lan', 'ponlan'],
                'short_name': 'PON/LAN Enterprise'
            },
            5: {
                'name': 'Empalmes y mediciones con OTDR',
                'keywords': ['empalm', 'otdr', 'empalmes'],
                'short_name': 'Empalmes y OTDR'
            }
        }
        
        # Buscar por número primero
        course_match = re.search(r'curso\s*(\d+)|(\d+)', message_text)
        if course_match:
            try:
                course_id = int(course_match.group(1) or course_match.group(2))
                if course_id in course_keywords:
                    course_name = course_keywords[course_id]['short_name']
                    logger.info(f"[PDF_SIMPLE] Curso detectado por número: {course_id}")
            except:
                pass
        
        # Si no hay número, buscar por palabras clave
        if not course_id:
            max_matches = 0
            best_course = None
            
            for cid, info in course_keywords.items():
                matches = sum(1 for keyword in info['keywords'] if keyword in message_lower)
                if matches > max_matches:
                    max_matches = matches
                    best_course = cid
            
            if best_course and max_matches > 0:
                course_id = best_course
                course_name = course_keywords[course_id]['short_name']
                logger.info(f"[PDF_SIMPLE] Curso detectado por palabras clave: {course_id} ({max_matches} coincidencias)")
        
        # Si no detectamos curso específico, mostrar opciones
        if not course_id:
            logger.info(f"[PDF_SIMPLE] No se detectó curso específico, mostrando opciones")
            # Build and save a candidate list so a short reply like '1' or the name resolves
            candidates = []
            for cid, info in course_keywords.items():
                candidates.append({'id': cid, 'nombre': info.get('name') or info.get('short_name'), 'display_index': cid})

            # Save into conversation memory so resolve_course_selection can pick it up
            try:
                _save_last_listed_courses(phone, candidates, expire_seconds=300)
            except Exception:
                logger.debug("_save_last_listed_courses failed")

            send_text_message(phone, "Elige el número o el nombre del curso que te interese para recibir temario, fechas y modalidades.")
            return True
        
        # Mapeo de cursos a PDFs
        pdf_mapping = {
            1: "1.Cableado estructurado para redes de fibra y cobre.pdf",
            2: "2.Redes de fibra óptica planta externa.pdf", 
            3: "3.Redes de fibra óptica FTTH para WISP e ISP.pdf",
            4: "4.PONLAN redes pasivas para entornos enterprise.pdf",
            5: "5.Empalmes y mediciones con OTDR de un enlace de fibra óptica.pdf"
        }
        
        pdf_filename = pdf_mapping.get(course_id)
        if not pdf_filename:
            logger.warning(f"[PDF_SIMPLE] No hay PDF para curso {course_id}")
            send_text_message(phone, "No encontré el temario para ese curso. Pregúntame por el temario de algún curso específico.")
            return False
        
        # Construir ruta del PDF
        assets_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
        pdf_path = os.path.join(assets_dir, pdf_filename)
        
        logger.info(f"[PDF_SIMPLE] Buscando PDF en: {pdf_path}")
        
        if not os.path.exists(pdf_path):
            logger.error(f"[PDF_SIMPLE] PDF no encontrado: {pdf_path}")
            send_text_message(phone, "No encontré el archivo del temario. Contacta con soporte.")
            return False
        
        # Enviar el PDF con nombre inteligente
        logger.info(f"[PDF_SIMPLE] Enviando PDF: {pdf_filename}")
        caption = f"📚 Temario: {course_name}"
        result = send_document_message(phone, pdf_path, caption=caption)
        
        if result:
            logger.info(f"[PDF_SIMPLE] PDF enviado exitosamente a {phone}")
            # Enviar mensaje de seguimiento
            follow_up = f"""✅ Te envié el temario de **{course_name}**

            ¿Te interesa este curso? Puedo ayudarte con:
            • 📅 Fechas disponibles
            • 💰 Precios e inscripción  
            • 📞 Contacto con asesor comercial"""
            
            send_text_message(phone, follow_up)
            return True
        else:
            logger.error(f"[PDF_SIMPLE] Error enviando PDF a {phone}")
            send_text_message(phone, "Hubo un problema enviando el temario. Intenta de nuevo en unos momentos.")
            return False
            
    except Exception as e:
        logger.error(f"[PDF_SIMPLE] Error general: {e}")
        send_text_message(phone, "Ocurrió un error. Pregúntame por el temario de algún curso específico.")
        return False

def start_advisor_simple(phone: str) -> bool:
    """Inicia el proceso unificado de recopilación de datos paso a paso."""
    try:
        logger.info(f"[ADVISOR_SIMPLE] Iniciando proceso de asesor para {phone}")
        
        # Verificar si ya está en proceso
        from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
        
        advisor_data = get_conversation_memory(phone, 'advisor_data')
        if advisor_data and advisor_data.get('step') == 'waiting_info':
            logger.info(f"[ADVISOR_SIMPLE] Ya hay proceso activo en paso: {advisor_data.get('step')}")
            # Continuar con el proceso existente
            return continue_advisor_process(phone, advisor_data)
        
        # Iniciar nuevo proceso
        logger.info(f"[ADVISOR_SIMPLE] Iniciando nuevo proceso de asesor")
        
        # Campos simplificados (sin descripción del proyecto)
        expected_fields = ['nombre', 'telefono', 'email', 'empresa', 'curso_solicitado']
        total_fields = len(expected_fields)
        
        intro = (
            "¡Perfecto! � Un asesor te contactará pronto.\n\n"
            "Para generar tu solicitud necesito algunos datos:\n\n"
            "📝 Nombre completo\n"
            "📱 Teléfono\n"
            "📧 Correo electrónico\n"
            "🏢 Empresa\n"
            "🎯 Curso de interés\n\n"
            f"Son solo {total_fields} pasos. ¡Empezamos!\n"
        )
        
        # Guardar estado del proceso
        save_conversation_memory(phone, 'advisor_data', {
            'step': 'waiting_info',
            'process_type': 'general',
            'fields_needed': expected_fields,
            'current_field': 0,
            'data': {},
            'started_at': datetime.now().isoformat(),
            'completed': False
        })

        # Flags para coordinar con otros handlers
        save_conversation_memory(phone, 'advisor_prompt_sent', True)
        save_conversation_memory(phone, 'waiting_for_advisor_data', True)
        save_conversation_memory(phone, 'advisor_intentos', 0)
        
        # Enviar intro y primera pregunta
        first_prompt = f"📝 **Nombre (1 de {total_fields})**\n\nPor favor compárteme tu **nombre completo**:"
        send_text_message(phone, intro + "\n" + first_prompt)
        logger.info(f"[ADVISOR_SIMPLE] Proceso iniciado exitosamente para {phone}")
        return True
        
    except Exception as e:
        logger.error(f"[ADVISOR_SIMPLE] Error: {e}")
        send_text_message(phone, "Hubo un problema iniciando el contacto con el asesor. Intenta de nuevo escribiendo 'asesor'.")
        return False

def continue_advisor_process(phone: str, advisor_data: dict) -> bool:
    """Continúa el proceso de asesor en curso."""
    try:
        step = advisor_data.get('step')
        
        if step == 'waiting_info':
            send_text_message(phone, "Estoy esperando tu información de contacto. Por favor envía:\n\n📝 Nombre completo\n🏢 Empresa\n📧 Correo\n📱 Teléfono\n💼 ¿Qué necesitas?")
        elif step == 'processing':
            send_text_message(phone, "Estoy procesando tu información. Un asesor te contactará pronto.")
        else:
            # Reiniciar proceso
            return start_advisor_simple(phone)
            
        return True
        
    except Exception as e:
        logger.error(f"continue_advisor_process error: {e}")
        return False

def process_advisor_data(phone: str, message_text: str) -> bool:
    try:
        logger.info(f"[ADVISOR_STEP_BY_STEP] Procesando datos de {phone}: {message_text[:50]}...")
        
        from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
        from services.ml_service import ml_service
        
        # Obtener estado actual del proceso
        advisor_data = get_conversation_memory(phone, 'advisor_data')
        if not advisor_data or advisor_data.get('step') != 'waiting_info':
            return False
        
        # Campos requeridos
        fields = advisor_data.get('fields_needed', ['nombre', 'telefono', 'email', 'empresa'])
        current_field_index = advisor_data.get('current_field', 0)
        data = advisor_data.get('data', {})
        process_type = advisor_data.get('process_type', 'general')
        
        # First, try to extract structured fields automatically using ML
        try:
            ml_res = ml_service.process_message(message_text, conversation_history=[{'text': message_text, 'from_client': True}], phone=phone)
            extracted = ml_res.get('client_data', {}) or {}
            classification = ml_res.get('classification', {})
            lead_pred = ml_res.get('lead_prediction', {})
            # Map common extractor keys to our form keys
            key_map = {
                'nombre': 'nombre', 'name': 'nombre',
                'empresa': 'empresa', 'company': 'empresa',
                'rfc': 'rfc',
                'correo': 'email', 'email': 'email',
                'telefono': 'telefono', 'phone': 'telefono', 'tel': 'telefono',
                'web': 'web', 'website': 'web'
            }
            for k, v in extracted.items():
                if not v:
                    continue
                target = key_map.get(k, None)
                if not target:
                    # try lowercased keys
                    target = key_map.get(k.lower()) if isinstance(k, str) else None
                if target and (not data.get(target)):
                    data[target] = v
                    logger.info(f"[ADVISOR_STEP_BY_STEP] Auto-extraído {target}: {str(v)[:60]}")
        except Exception as e:
            logger.debug(f"ML extraction failed: {e}")

        # If ML didn't fill anything relevant, fallback to single-field save
        if current_field_index < len(fields):
            field_name = fields[current_field_index]
            if not data.get(field_name):
                # Only save the raw message as the current expected field if ML didn't fill it
                data[field_name] = message_text.strip()
                logger.info(f"[ADVISOR_STEP_BY_STEP] Guardado manual {field_name}: {message_text[:30]}...")
        
        # Determinar siguiente paso
        next_field_index = current_field_index + 1
        
        if next_field_index < len(fields):
            # Pedir siguiente campo
            next_field = fields[next_field_index]
            step_num = next_field_index + 1
            
            field_prompts = {
                'nombre': f"📝 **Nombre ({step_num} de {len(fields)})**\n\nPor favor compárteme tu **nombre completo**:",
                'telefono': f"📱 **Teléfono ({step_num} de {len(fields)})**\n\n¡Perfecto {data.get('nombre', '')}!\n\nAhora, ¿cuál es tu **número de teléfono** de contacto?\n\n_(Incluye lada, ejemplo: 5214421234567)_",
                'email': f"📧 **Email ({step_num} de {len(fields)})**\n\nGracias. Ahora compárteme tu **correo electrónico**:",
                'empresa': f"🏢 **Empresa ({step_num} de {len(fields)})**\n\n¿Cuál es el **nombre de tu empresa** o proyecto?\n\n_(Si no aplica, escribe 'Independiente')_",
                'rfc': f"📝 **RFC / Razón Social ({step_num} de {len(fields)})**\n\nPor favor indica tu **RFC** o **Razón Social**:\n\n_(Si no aplica, escribe 'N/A')_",
                'web': f"🌐 **Sitio Web ({step_num} de {len(fields)})**\n\nCompárteme el **sitio web** de tu empresa:\n\n_(Si no tienes, escribe 'No tengo')_",
                'curso_solicitado': f"📝 **Curso (5 de {len(fields)})**\n\n¿Qué **curso** te interesa?\n\nTenemos:\n1️⃣ Cableado Estructurado\n2️⃣ Planta Externa\n3️⃣ FTTH para WISP e ISP\n4️⃣ PON/LAN\n5️⃣ Empalmes y OTDR\n\n_(Escribe el nombre o número)_",
                'rfc': f"📝 **RFC ({next_field_index + 1} de {len(fields)})**\n\nPor favor indica tu **RFC** o razón social:\n\n_(Si no aplica, escribe 'N/A')_",
                'web': f"🌐 **Sitio Web ({next_field_index + 1} de {len(fields)})**\n\nSi tienes sitio web, compárteme el enlace:\n\n_(Si no tienes, escribe 'No tengo')_",
                'ciudad': f"📍 **Ciudad ({next_field_index + 1} de {len(fields)})**\n\n¿En qué **ciudad** te encuentras?",
            }
            
            prompt = field_prompts.get(next_field, f"Por favor proporciona: {next_field}")
            send_text_message(phone, prompt)
            
            # Actualizar estado
            advisor_data.update({
                'current_field': next_field_index,
                'data': data
            })
            save_conversation_memory(phone, 'advisor_data', advisor_data)
            
        else:
            # Proceso completado - generar PDF y notificar
            # Before completing, enrich data with ML classification/lead prediction if available
            try:
                ml_res = ml_service.process_message(' '.join([v for v in data.values() if isinstance(v, str)]), conversation_history=None, phone=phone)
            except Exception:
                ml_res = {}

            classification = ml_res.get('classification') if isinstance(ml_res, dict) else {}
            lead_pred = ml_res.get('lead_prediction') if isinstance(ml_res, dict) else {}

            pdf_path = None
            try:
                # Prepare client_data expected by ML PDF generator
                client_data = {
                    'nombre': data.get('nombre'),
                    'empresa': data.get('empresa'),
                    'rfc': data.get('rfc'),
                    'correo': data.get('email') or data.get('correo'),
                    'telefono': data.get('telefono'),
                    'web': data.get('web'),
                }
                pdf_path = ml_service.generate_client_pdf(client_data, classification or {})
            except Exception as e:
                logger.error(f"Error generando PDF con MLService: {e}")

            # Notify advisor with PDF and a short pre-classification summary
            try:
                advisor_phone = DEFAULT_ADVISOR_PHONE if 'DEFAULT_ADVISOR_PHONE' in globals() and DEFAULT_ADVISOR_PHONE else '+5214427843528'
                
                # Clasificar segmento del cliente
                segmento = classify_client_segment(data.get('web', ''), data.get('empresa', ''))
                
                # Build notification message
                user_need = data.get('necesidad') or data.get('need') or data.get('curso_solicitado', '')
                category = (classification.get('category') if isinstance(classification, dict) else None) or 'asesor'
                lead_type = (lead_pred.get('lead_type') if isinstance(lead_pred, dict) else None) or 'no determinado'
                lead_conf = (lead_pred.get('confidence') if isinstance(lead_pred, dict) else None) or 0.0

                notif = (
                    f"🔔 NUEVA SOLICITUD - {category.upper()}\n\n"
                    f"👤 Cliente: {client_data.get('nombre','N/D')}\n"
                    f"🏢 Empresa: {client_data.get('empresa','N/D')}\n"
                    f"🏷️ RFC: {data.get('rfc','N/D')}\n"
                    f"📱 Teléfono: {client_data.get('telefono','N/D')}\n"
                    f"📧 Email: {client_data.get('correo','N/D')}\n"
                    f"🌐 Web: {client_data.get('web','N/D')}\n\n"
                    f"🎯 **SEGMENTO: {segmento}**\n"
                    f"📚 Curso: {user_need or 'No especificado'}\n"
                    f"🤖 ML: {category} | Lead: {lead_type} ({lead_conf:.2f})\n\n"
                    f"📄 Se adjunta PDF con todos los datos."
                )

                send_text_message(advisor_phone, notif)
                if pdf_path and os.path.exists(pdf_path):
                    send_document_message(advisor_phone, pdf_path, caption=f"Solicitud - {client_data.get('nombre','Cliente')}")
                
                # Confirmar al usuario con mensaje personalizado según el tipo de proceso
                if process_type == 'inscripcion':
                    confirmation_msg = (
                        f"✅ **¡SOLICITUD ENVIADA!**\n\n"
                        f"Gracias {client_data.get('nombre', '')}. Tu solicitud de **inscripción** ha sido registrada.\n\n"
                        f"📋 **RESUMEN:**\n"
                        f"• Curso: {data.get('curso_solicitado', 'No especificado')}\n"
                        f"• Nombre: {client_data.get('nombre', 'N/A')}\n"
                        f"• Teléfono: {client_data.get('telefono', 'N/A')}\n"
                        f"• Email: {client_data.get('correo', 'N/A')}\n\n"
                        f"🤝 **Un asesor te contactará en máximo 2 horas hábiles** para confirmar fechas, modalidad y proceso de pago.\n\n"
                        f"¿Hay algo más en lo que pueda ayudarte?"
                    )
                else:
                    confirmation_msg = "✅ Gracias — envié tu solicitud al asesor. En breve te contactarán."
                
                send_text_message(phone, confirmation_msg)
            except Exception as e:
                logger.error(f"Error notificando al asesor: {e}")

            # Mark completed and cleanup
            try:
                save_conversation_memory(phone, 'advisor_data', {'step': 'completed'})
                save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                save_conversation_memory(phone, 'advisor_form_state', None)
                save_conversation_memory(phone, 'advisor_prompt_sent', None)
            except Exception:
                pass
        
        return True
        
    except Exception as e:
        logger.error(f"[ADVISOR_STEP_BY_STEP] Error procesando datos: {e}")
        send_text_message(phone, "Hubo un problema. Un asesor se pondrá en contacto contigo pronto.")
        return True

def complete_advisor_process(phone: str, data: dict, process_type: str):
    """Completa el proceso de asesor con todos los datos recopilados."""
    try:
        # Confirmar al usuario
        nombre = data.get('nombre', 'Cliente')
        
        process_names = {
            'inscripcion': 'inscripción',
            'cotizacion': 'cotización',
            'facturacion': 'facturación',
            'general': 'solicitud'
        }
        
        process_name = process_names.get(process_type, 'solicitud')
        
        confirmation_msg = f"""✅ **DATOS COMPLETADOS**

        Gracias {nombre}, tu solicitud de **{process_name}** ha sido registrada.

        📋 **RESUMEN:**
        • Nombre: {data.get('nombre', 'N/A')}
        • Teléfono: {data.get('telefono', 'N/A')}
        • Email: {data.get('email', 'N/A')}
        • Empresa: {data.get('empresa', 'N/A')}

        🤝 **Un asesor especializado te contactará en máximo 2 horas hábiles.**

        ¿Hay algo más en lo que pueda ayudarte mientras tanto?"""
        
        send_text_message(phone, confirmation_msg)
        
        # Generar PDF para el asesor
        pdf_content = generate_advisor_pdf_content(data, process_type, phone)

        # Build advisor notification and send to advisor phone (not to user)
        advisor_notification = (
            f"🔔 NUEVA SOLICITUD - {process_name.upper()}\n\n"
            f"Cliente: {data.get('nombre', 'N/A')}\n"
            f"Teléfono: {data.get('telefono', 'N/A')}\n"
            f"Email: {data.get('email', 'N/A')}\n"
            f"Empresa: {data.get('empresa', 'N/A')}\n\n"
            f"WhatsApp: {phone}\n"
            f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            f"Tipo de solicitud: {process_name}\n\n"
            f"SIGUIENTE ACCIÓN:\n{get_next_action_for_process(process_type)}\n\n"
            f"(El asesor recibirá el PDF con los datos del cliente en este chat.)"
        )

        # Send the notification and the generated PDF to the advisor contact
        try:
            send_text_message(DEFAULT_ADVISOR_PHONE, advisor_notification)
            # generate a temporary PDF file path for the advisor (implementation detail of send_document_message will upload/send)
            # We will not attach or send the PDF to the end user to avoid exposing sensitive data.
            temp_pdf_path = None
            try:
                # If generate_advisor_pdf_content returns raw text, create a simple PDF for advisor
                from fpdf import FPDF
                pdf = FPDF()
                pdf.add_page()
                pdf.set_auto_page_break(auto=True, margin=15)
                pdf.set_font('Arial', size=12)
                for line in pdf_content.split('\n'):
                    pdf.multi_cell(0, 6, line)
                tmp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'logs'))
                os.makedirs(tmp_dir, exist_ok=True)
                temp_pdf_path = os.path.join(tmp_dir, f'advisor_request_{phone.replace("+","_").replace(" ","_")}.pdf')
                pdf.output(temp_pdf_path)
            except Exception:
                temp_pdf_path = None

            if temp_pdf_path and os.path.exists(temp_pdf_path):
                send_document_message(DEFAULT_ADVISOR_PHONE, temp_pdf_path, caption=f"Solicitud - {nombre}")
        except Exception as e:
            logger.error(f"Error notificando al asesor: {e}")
        logger.info(f"[ADVISOR_COMPLETE] Proceso completado para {phone}")
        
        # Limpiar memoria y flags para que el flujo no quede bloqueado
        from services.conversation_memory_utils import save_conversation_memory
        save_conversation_memory(phone, 'advisor_data', {'step': 'completed'})
        try:
            # unset waiting flag so normal handlers resume
            save_conversation_memory(phone, 'waiting_for_advisor_data', False)
            # mark that prompt was handled
            save_conversation_memory(phone, 'advisor_prompt_sent', None)
            # clear any lightweight form state
            save_conversation_memory(phone, 'advisor_form_state', None)
            # reset attempt counter
            save_conversation_memory(phone, 'advisor_intentos', 0)
        except Exception:
            # ignore memory cleanup errors
            pass
        
    except Exception as e:
        logger.error(f"Error completando proceso de asesor: {e}")

def classify_client_segment(website: str, empresa: str) -> str:
    """
    Clasifica el segmento del cliente basándose en su sitio web y nombre de empresa.
    Utiliza IA para analizar el contenido y determinar el segmento.
    
    Segmentos disponibles:
    - Integrador
    - Constructora
    - WISP
    - ISP
    - Carrier
    - Data Center
    - Distribuidor
    - Usuario Final
    - Gobierno
    - Consultor-Distribuidor-Integrador
    - Distribuidor-Eléctrico
    - Distribuidor-Integrador
    - Distribuidor-Computo
    - Electrico
    - Integrador-Eléctrico
    - Integrador-Consultor
    - Integrador-Data center
    - Integrador-Minero
    - ISP/WISP
    """
    try:
        # Si no hay sitio web, clasificar por nombre de empresa
        if not website or website.lower() in ['no tengo', 'n/a', 'no', 'ninguno', 'na']:
            # Clasificación básica por palabras clave en el nombre de la empresa
            empresa_lower = empresa.lower() if empresa else ''
            
            if any(word in empresa_lower for word in ['isp', 'internet', 'telecomunicaciones', 'telecom']):
                return 'ISP/WISP'
            elif any(word in empresa_lower for word in ['integrador', 'integracion', 'soluciones', 'tecnología']):
                return 'Integrador'
            elif any(word in empresa_lower for word in ['constructora', 'construccion', 'obras']):
                return 'Constructora'
            elif any(word in empresa_lower for word in ['distribuidor', 'distribuidora']):
                return 'Distribuidor'
            elif any(word in empresa_lower for word in ['data center', 'datacenter']):
                return 'Data Center'
            elif any(word in empresa_lower for word in ['gobierno', 'municipal', 'estatal', 'federal']):
                return 'Gobierno'
            else:
                return 'Usuario Final'
        
        # Si hay sitio web, usar IA para analizar
        try:
            from services.chat_ai import chat_with_gemini
            
            prompt = f"""Analiza el siguiente sitio web y nombre de empresa para clasificar el tipo de cliente en UNO de estos segmentos:

Segmentos disponibles:
- Integrador
- Constructora
- WISP
- ISP
- Carrier
- Data Center
- Distribuidor
- Usuario Final
- Gobierno
- Consultor-Distribuidor-Integrador
- Distribuidor-Eléctrico
- Distribuidor-Integrador
- Distribuidor-Computo
- Electrico
- Integrador-Eléctrico
- Integrador-Consultor
- Integrador-Data center
- Integrador-Minero
- ISP/WISP

Sitio Web: {website}
Nombre Empresa: {empresa}

Responde ÚNICAMENTE con el nombre del segmento que mejor corresponda. No agregues explicaciones."""

            response = chat_with_gemini(prompt, conversation_history=[])
            segment = response.strip()
            
            # Validar que la respuesta esté en la lista de segmentos
            valid_segments = [
                'Integrador', 'Constructora', 'WISP', 'ISP', 'Carrier', 'Data Center',
                'Distribuidor', 'Usuario Final', 'Gobierno', 'Consultor-Distribuidor-Integrador',
                'Distribuidor-Eléctrico', 'Distribuidor-Integrador', 'Distribuidor-Computo',
                'Electrico', 'Integrador-Eléctrico', 'Integrador-Consultor',
                'Integrador-Data center', 'Integrador-Minero', 'ISP/WISP'
            ]
            
            # Buscar coincidencia (case insensitive)
            for valid_seg in valid_segments:
                if valid_seg.lower() in segment.lower():
                    return valid_seg
            
            # Si no hay coincidencia, retornar Usuario Final como default
            logger.warning(f"Segmento no reconocido de IA: {segment}")
            return 'Usuario Final'
            
        except Exception as e:
            logger.error(f"Error clasificando con IA: {e}")
            return 'Usuario Final'
            
    except Exception as e:
        logger.error(f"Error en classify_client_segment: {e}")
        return 'Usuario Final'

def generate_advisor_pdf_content(data: dict, process_type: str, phone: str) -> str:

    fecha = datetime.now().strftime('%d/%m/%Y %H:%M')
    nombre = data.get('nombre', 'No especificado')
    empresa = data.get('empresa', '')
    rfc = data.get('rfc', '')
    correo = data.get('email') or data.get('correo') or ''
    telefono = data.get('telefono', '')
    sitio = data.get('web') or ''
    puesto = data.get('puesto') or ''
    ciudad = data.get('ciudad') or ''
    curso = data.get('curso_solicitado') or data.get('curso') or 'No especificado'
    
    # Clasificar segmento del cliente
    segmento = classify_client_segment(sitio, empresa)

    lines = []
    lines.append('SOLICITUD DE CONTACTO CON ASESOR')
    lines.append('')
    lines.append(f'Generado: {fecha}')
    lines.append('')
    lines.append('Datos del Prospecto:')
    lines.append('')
    lines.append(f'Nombre completo: {nombre}')
    if empresa:
        lines.append(f'Empresa: {empresa}')
    if rfc:
        lines.append(f'RFC: {rfc}')
    if correo:
        lines.append(f'Correo electrónico: {correo}')
    if telefono:
        lines.append(f'Teléfono: {telefono}')
    if sitio:
        lines.append(f'Sitio web: {sitio}')
    
    # Agregar segmento clasificado
    lines.append('')
    lines.append(f'SEGMENTO IDENTIFICADO: {segmento}')
    lines.append('')
    
    if puesto:
        lines.append(f'Puesto: {puesto}')
    if ciudad:
        lines.append(f'Ciudad: {ciudad}')
    lines.append('')
    lines.append('Curso Solicitado:')
    lines.append(curso)
    lines.append('')
    

    return '\n'.join(lines)

def get_next_action_for_process(process_type: str) -> str:
    """Retorna las acciones específicas que debe realizar el asesor."""
    actions = {
        'inscripcion': """
        1. Confirmar disponibilidad de cupo en fecha solicitada
        2. Enviar información de pago y condiciones
        3. Procesar inscripción una vez confirmado el pago
        4. Enviar confirmación y datos de acceso""",
                
                'cotizacion': """
        Solicitar los datos del usuario en partes si es necesario los puede enviar en un msj completo o en partes""",
                
                'facturacion': """
        1. Validar datos fiscales del cliente
        2. Verificar información del pedido
        3. Generar CFDI correspondiente
        4. Enviar factura en formato PDF y XML""",
                
                'general': """
        1. Contactar al cliente para identificar necesidad específica
        2. Proporcionar información técnica/comercial requerida
        3. Hacer seguimiento según el tipo de requerimiento
        4. Cerrar la solicitud o derivar al área correspondiente"""
    }
    
    return actions.get(process_type, actions['general'])

def get_all_courses_summary():
    """Devuelve un resumen de todos los cursos disponibles."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            summary_lines = ["🎓 **Cursos Disponibles:**\n"]
            
            for course in data:
                course_id = course.get('id')
                nombre = course.get('nombre', 'Sin nombre')
                # No mostrar precios en el listado inicial, solo id y nombre
                summary_lines.append(f"**{course_id}.** {nombre}")
                summary_lines.append("")

            summary_lines.append("Elige el número o el nombre del curso que te interese para recibir temario, fechas y modalidades.")
            return "\n".join(summary_lines)
    except Exception as e:
        logger.error(f"Error obteniendo resumen de cursos: {e}")
    
    return "Tenemos 5 cursos de fibra óptica disponibles. Pregúntame por el temario, fechas o precios de algún curso específico."

def _save_last_listed_courses(phone: str, candidates: list, expire_seconds: int = 300):
    """Guarda en la memoria de conversación la última lista de cursos mostrada al usuario.

    Estructura guardada: [{'id': 1, 'nombre': '...'}, ...]
    Se guarda con key 'last_listed_courses' para que un seguimiento como '1' o el nombre
    pueda resolverse contra esta lista.
    """
    try:
        from services.conversation_memory_utils import save_conversation_memory
        save_conversation_memory(phone, 'last_listed_courses', {
            'candidates': candidates,
            'saved_at': datetime.now().isoformat(),
            'expire_seconds': expire_seconds
        })
    except Exception as e:
        logger.debug(f"_save_last_listed_courses error: {e}")

def resolve_course_selection(phone: str, message_text: str) -> bool:
    """Resuelve una selección del usuario basada en la última lista de cursos.

    - Si el usuario responde con un número (p.ej. '1'), selecciona por índice
    - Si responde con texto, intenta hacer match por substring en el nombre
    - Si se encuentra una coincidencia, envía la información completa del curso
      usando `get_complete_course_info` y retorna True.
    - Si no hay candidatos guardados o no hay coincidencias, retorna False.
    """
    try:
        from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
        mem = get_conversation_memory(phone, 'last_listed_courses')
        if not mem or not isinstance(mem, dict):
            return False

        candidates = mem.get('candidates') or []
        if not candidates:
            return False

        low = (message_text or '').strip().lower()
        # Check numeric selection like '1' or 'curso 1'
        import re
        m = re.search(r"\b(\d+)\b", low)
        selected = None
        if m:
            idx = int(m.group(1))
            # Candidates may be 1-indexed in display
            for c in candidates:
                try:
                    # candidate id may be int or str
                    if int(c.get('id')) == idx or (isinstance(c.get('display_index'), int) and c.get('display_index') == idx):
                        selected = c
                        break
                except Exception:
                    continue

            # Fallback: if idx refers to position in list (1..n)
            if not selected and 1 <= idx <= len(candidates):
                selected = candidates[idx - 1]

        # If not numeric, try name substring match
        if not selected:
            for c in candidates:
                nombre = (c.get('nombre') or c.get('title') or '').lower()
                if nombre and low in nombre:
                    selected = c
                    break

        # If still not found, try loose token matching
        if not selected:
            tokens = [t for t in re.split(r"\s+", low) if t]
            if tokens:
                for c in candidates:
                    nombre = (c.get('nombre') or c.get('title') or '').lower()
                    if nombre and any(tok in nombre for tok in tokens):
                        selected = c
                        break

        if not selected:
            # No match — nothing to do
            return False

        # Found one — send the detailed info
        try:
            cid = int(selected.get('id')) if selected.get('id') is not None else None
        except Exception:
            cid = None

        if cid is None:
            # If no numeric id, attempt to use a stored mapping key
            cid = selected.get('id')

        # Use existing helper to get full info
        try:
            detail = get_complete_course_info(cid) if cid is not None else format_course_for_whatsapp(selected)
            send_text_message(phone, detail)

            # Save selected course in conversation memory so follow-ups (sí/no) map to it
            try:
                course_name = selected.get('nombre') or selected.get('name') or selected.get('title') or (f'Curso {cid}' if cid is not None else 'Curso')
            except Exception:
                course_name = f'Curso {cid}' if cid is not None else 'Curso'

            try:
                # Prefer the small helper wrapper to normalize
                save_selected_course(phone, cid, course_name, details=selected)
            except Exception:
                # Fallback to direct memory save
                try:
                    save_conversation_memory(phone, 'selected_course', {'id': str(cid) if cid is not None else cid, 'name': course_name, 'details': selected or {}})
                except Exception:
                    pass

            # Ask whether the user wants the temario and set a short-lived awaiting flag
            try:
                save_conversation_memory(phone, 'awaiting_temario_confirmation', True)
            except Exception:
                pass

            try:
                send_text_message(phone, "¿Quieres que te envíe el temario de este curso? (sí/no)")
            except Exception:
                # If prompt send fails, ignore — we already saved state
                pass

            # Clear last listed courses to avoid accidental re-use
            save_conversation_memory(phone, 'last_listed_courses', None)
            return True
        except Exception as e:
            logger.error(f"resolve_course_selection send error: {e}")
            return False

    except Exception as e:
        logger.debug(f"resolve_course_selection error: {e}")
        return False

def get_course_specific_info(course_id: int, info_type: str):
    """Devuelve información específica de un curso según el tipo solicitado."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            course = None
            for c in data:
                if c.get('id') == course_id:
                    course = c
                    break
            
            if not course:
                return f"No encontré información del curso {course_id}."
            
            nombre = course.get('nombre', 'Sin nombre')
            
            if info_type == 'fechas':
                fechas = course.get('proximas_fechas', [])
                if fechas:
                    fecha_info = fechas[0].get('fecha', 'Fecha por definir')
                    horario = fechas[0].get('horario', course.get('horario', ''))
                    return f"📅 **{nombre}**\n\nFechas: {fecha_info}\nHorario: {horario}"
                else:
                    return f"📅 **{nombre}**\n\nFechas por definir. Contacta con un asesor para más información."
            
            elif info_type == 'precio':
                precio = course.get('precio', 'Consultar')
                modalidad = course.get('modalidad', 'Presencial')
                duracion = course.get('duracion', '')
                return f"💰 **{nombre}**\n\nPrecio: {precio}\nModalidad: {modalidad}\nDuración: {duracion}"
            
            elif info_type == 'temario':
                temario = course.get('temario', [])
                if temario:
                    temario_text = f"📚 **{nombre}**\n\n"
                    for i, tema in enumerate(temario, 1):
                        titulo = tema.get('titulo', f'Módulo {i}')
                        temario_text += f"**{i}. {titulo}**\n"
                        subtemas = tema.get('subtemas', [])
                        for subtema in subtemas:
                            temario_text += f"• {subtema}\n"
                        temario_text += "\n"
                    return temario_text
                else:
                    return f"📚 **{nombre}**\n\nTemario disponible en PDF. Pregúntame por el material del curso."
            
            else:  # info_type == 'completa'
                info_lines = [f"🎓 **{nombre}**\n"]
                
                precio = course.get('precio', 'Consultar')
                info_lines.append(f"💰 **Precio:** {precio}")
                
                fechas = course.get('proximas_fechas', [])
                if fechas:
                    fecha_info = fechas[0].get('fecha', 'Fecha por definir')
                    info_lines.append(f"📅 **Fechas:** {fecha_info}")
                
                modalidad = course.get('modalidad', 'Presencial')
                duracion = course.get('duracion', '')
                info_lines.append(f"🎯 **Modalidad:** {modalidad}")
                if duracion:
                    info_lines.append(f"⏱️ **Duración:** {duracion}")
                
                info_lines.append(f"\n¿Te interesa el temario o quieres contactar con un asesor?")
                
                return "\n".join(info_lines)
                
    except Exception as e:
        logger.error(f"Error obteniendo info específica del curso {course_id}: {e}")
    
    return f"No pude obtener la información del curso {course_id}. Intenta de nuevo o contacta con soporte."

# ==========================================
# SISTEMA DE DETECCIÓN DE PRODUCTOS Y CURSOS
# ==========================================

def get_all_courses_duration_text():
    """Devuelve un texto con la duración de todos los cursos listados en splitbot.courses.json."""
    import os
    import json
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
    if not os.path.exists(path):
        return "No se encontró la información de los cursos."
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if not data:
        return "No hay cursos registrados."
    lines = ["La duración de nuestros cursos es:"]
    for curso in data:
        nombre = curso.get('nombre', 'Curso sin nombre')
        duracion = curso.get('duracion', 'Duración no especificada')
        lines.append(f"- {nombre}: {duracion}")
    return "\n".join(lines)

# En el flujo de manejo de intents, cuando se detecte 'duracion' general:
# if intent == 'duracion' and not curso_especifico:
#     send_text_message(phone, get_all_courses_duration_text())
#     return

def detect_course_info_request(phone: str, message_text: str) -> bool:
    """
    Detecta solicitudes específicas de información de cursos y responde según el contexto.
    Maneja: fechas, precios, modalidad, ubicación, duración, temario, etc.
    """
    try:
        message_lower = message_text.lower()
        
        # DETECTAR SOLICITUD DE INSCRIPCIÓN PRIMERO
        inscripcion_keywords = ['quiero inscribirme', 'inscribirme', 'inscripción', 'inscripcion', 
                                'me quiero inscribir', 'quiero inscribir', 'como me inscribo', 
                                'cómo me inscribo', 'proceso de inscripción']
        
        if any(keyword in message_lower for keyword in inscripcion_keywords):
            logger.info(f"[INSCRIPCION] Detectada solicitud de inscripción de {phone}")
            
            # Iniciar proceso de recopilación de datos paso a paso
            advisor_data = {
                'step': 'waiting_info',
                'fields_needed': ['nombre', 'telefono', 'email', 'empresa', 'curso_solicitado'],
                'current_field': 0,
                'data': {},
                'process_type': 'inscripcion'
            }
            save_conversation_memory(phone, 'advisor_data', advisor_data)
            save_conversation_memory(phone, 'waiting_for_advisor_data', True)
            
            # Enviar el primer mensaje para solicitar el nombre
            send_text_message(phone, "📝 **Nombre (1 de 5)**\n\n¡Perfecto! Para procesar tu inscripción necesito algunos datos.\n\nPor favor compárteme tu **nombre completo**:")
            return True
        
        # VERIFICAR QUE ES UNA CONSULTA DE CURSO (no de producto ni webinar)
        message_type = classify_message_type(message_text)
        if message_type not in ['COURSE', 'GENERAL']:
            logger.info(f"[COURSE_INFO] Mensaje clasificado como {message_type}, no como COURSE. Saliendo.")
            return False
        
        # Palabras clave para diferentes tipos de información
        fecha_keywords = ['fecha', 'fechas', 'cuando son ', 'cuándo', 'próxima', 'próximas', 'calendario', 'dias' ]
        precio_keywords = ['precio', 'precios', 'cuesta', 'costo', 'costos', 'inversión', 'cuánto', 'cuanto']
        modalidad_keywords = ['modalidad', 'presencial', 'online', 'virtual', 'distancia', 'híbrido', 'en línea', 'en linea', 'en vivo', 'a distancia']
        ubicacion_keywords = ['ubicación', 'ubicacion', 'dónde', 'donde', 'lugar', 'sede', 'dirección', 'direccion']
        duracion_keywords = ['duración', 'duracion', 'tiempo', 'horas', 'días', 'dias', 'semanas']
        temario_keywords = ['temario', 'programa', 'contenido', 'temas', 'módulos', 'modulos', 'qué veremos', 'que veremos', 'tematica', 'temáticas', 'temario completo']
        
        # Detectar si menciona un curso específico
        course_mentioned = None
        course_keywords = {
            1: ['cableado', 'estructurado', 'cableado estructurado'],
            2: ['planta externa', 'externa'],
            3: ['ftth', 'wisp a isp'],
            4: ['pon', 'lan', 'ponlan'],
            5: ['empalm', 'empalmes']
        }
        
        for course_id, keywords in course_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                course_mentioned = course_id
                break
        
        # Detectar tipo de información solicitada
        info_types_requested = []
        if any(keyword in message_lower for keyword in fecha_keywords):
            info_types_requested.append('fechas')
        if any(keyword in message_lower for keyword in precio_keywords):
            info_types_requested.append('precios')
        if any(keyword in message_lower for keyword in modalidad_keywords):
            info_types_requested.append('modalidad')
        if any(keyword in message_lower for keyword in ubicacion_keywords):
            info_types_requested.append('ubicacion')
        if any(keyword in message_lower for keyword in duracion_keywords):
            info_types_requested.append('duracion')
        if any(keyword in message_lower for keyword in temario_keywords):
            info_types_requested.append('temario')
        
        # Si se menciona un curso específico
        if course_mentioned:
            logger.info(f"[COURSE_INFO] Curso detectado: {course_mentioned}, Info solicitada: {info_types_requested}")

            # Si no se especifica qué información, dar información completa
            if not info_types_requested:
                response = get_complete_course_info(course_mentioned)
                # Enviar la info completa primero
                send_text_message(phone, response)

                # Enviar también el PDF del temario y el temario en texto para que el usuario lo tenga completo
                try:
                    # Intentar enviar PDF (adapter o asset local)
                    sent_pdf = False
                    try:
                        sent_pdf = send_course_temario_pdf(phone, course_mentioned)
                    except Exception:
                        sent_pdf = False

                    # Enviar versión textual del temario (si existe)
                    try:
                        temario_info = get_course_temario_text(course_mentioned)
                        if temario_info:
                            # Si el PDF fue enviado, esperar un poco no es necesario aquí; solo seguir con el texto
                            send_text_message(phone, temario_info)
                    except Exception:
                        # si falla obtener temario textual, no bloquear la respuesta principal
                        pass
                except Exception as e:
                    logger.debug(f"Error enviando temario junto con info completa: {e}")

                return True
            
            # Si se solicita temario específicamente, intentar enviar el PDF y siempre complementar con el temario textual
            if 'temario' in info_types_requested:
                try:
                    sent_pdf = False
                    try:
                        sent_pdf = send_course_temario_pdf(phone, course_mentioned)
                    except Exception:
                        sent_pdf = False

                    # Enviar versión textual (completa) del temario como complemento
                    try:
                        temario_info = get_course_temario_text(course_mentioned)
                        if temario_info:
                            send_text_message(phone, temario_info)
                    except Exception:
                        # Si falla obtener temario textual y no se envió PDF, notificar
                        if not sent_pdf:
                            send_text_message(phone, "📚 El temario está disponible en PDF. ¿Quieres que te lo envíe?")
                except Exception as e:
                    logger.debug(f"Error manejando petición de temario: {e}")
                    send_text_message(phone, "Ocurrió un error al intentar enviar el temario. ¿Quieres que te lo envíe en PDF?")

                return True
            
            # Responder con información específica solicitada
            response = get_specific_course_info(course_mentioned, info_types_requested)
            send_text_message(phone, response)
            return True
        
        # Si se pregunta por información general sin curso específico
        elif info_types_requested:
            response = get_general_course_info_response(info_types_requested)
            send_text_message(phone, response)
            return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error en detect_course_info_request: {e}")
        return False

def classify_message_type(message_text: str) -> str:
    """
     CLASIFICADOR CENTRAL - Evita mezclar información de productos, cursos y webinars
    
    Esta función es el punto de entrada para determinar el tipo de consulta antes de 
    ejecutar los handlers específicos. Esto previene respuestas mixtas confusas.
    
    Retorna: 'PRODUCT', 'COURSE', 'WEBINAR', 'ASESOR', 'GENERAL'
    
     PRIORIDAD DE CLASIFICACIÓN:
    1. PRODUCT: Productos físicos (bobina, ducto, cable, conectores, etc.)
        Handler: detect_and_respond_to_product_queries()
       
    2. WEBINAR: Eventos gratuitos online (webinar/seminario/gratis)
        Handler: detect_webinar_request()
       
    3. COURSE: Capacitaciones pagadas con certificación (curso/capacitación/DC3)
        Handler: detect_course_info_request()
       
    4. ASESOR: Solicitudes de cotización/contacto comercial
        Handler: detect_process_request() o advisor flow
       
    5. GENERAL: Consultas técnicas o generales
        Se procesa por IA o handlers técnicos
    
    📋 ESTRATEGIA:
    - Cada handler verifica la clasificación antes de procesar
    - Si no coincide con su tipo, retorna False inmediatamente
    - Esto garantiza respuestas específicas sin mezclar contextos
    """
    message_lower = message_text.lower()
    
    # 1. DETECTAR PRODUCTOS FÍSICOS (máxima prioridad para evitar confusión)
    product_strong_indicators = [
        'bobina', 'bobinas', 'par trenzado', 'cable utp', 'cat5e', 'cat6', 'cat6a', 'cat 6a',
        'ducto', 'ductos', 'hdpe', 'tubería', 'canalización',
        'tritubo', 'tri tubo', 'tritubo hdpe',
        'mpo', 'mtp', 'jumper', 'conector', 'conectores',
        'fibra optica cable', 'cable de fibra', 'cable multimodo', 'cable monomodo',
        'patch cord', 'pigtail', 'transceiver', 'sfp', 'gbic',
        'comprar', 'cotización de producto', 'precio de producto', 'cuánto cuesta la bobina',
        'cuánto cuesta el ducto', 'especificaciones del cable', 'ficha técnica'
    ]
    
    # 2. DETECTAR WEBINARS (segunda prioridad)
    webinar_strong_indicators = [
        'webinar', 'webinars', 'seminario', 'seminarios', 'seminario online',
        'gratis', 'gratuito', 'free', 'evento gratis', 'charla gratis',
        'martes', 'todos los martes', 'próximo webinar',
        'preconectorizada', 'instalacion subterranea', 'wisp a fibra',
        'odn en fttx', 'redes de distribucion', 'centro de datos webinar'
    ]
    
    # 3. DETECTAR CURSOS (tercera prioridad)
    course_strong_indicators = [
        'curso', 'cursos', 'capacitación', 'capacitacion', 'entrenamiento',
        'certificación', 'certificacion', 'dc3', 'certificado',
        'inscripción', 'inscripcion', 'inscribir', 'inscribirme',
        'temario', 'programa del curso', 'fechas del curso', 'precio del curso',
        'cuánto cuesta el curso', 'cuando es el curso', 'duración del curso',
        'presencial', 'modalidad del curso'
    ]
    
    # 4. DETECTAR ASESOR
    asesor_indicators = [
        'asesor', 'asesoría', 'cotizar proyecto', 'cotización proyecto',
        'hablar con', 'contactar', 'necesito ayuda con proyecto',
        'proyecto de fibra', 'implementación', 'instalación de red'
    ]
    
    # Contar coincidencias
    product_score = sum(1 for ind in product_strong_indicators if ind in message_lower)
    webinar_score = sum(1 for ind in webinar_strong_indicators if ind in message_lower)
    course_score = sum(1 for ind in course_strong_indicators if ind in message_lower)
    asesor_score = sum(1 for ind in asesor_indicators if ind in message_lower)
    
    logger.info(f" [CLASSIFIER] Puntuación → PRODUCT:{product_score} | WEBINAR:{webinar_score} | COURSE:{course_score} | ASESOR:{asesor_score}")
    
    # Decisión basada en prioridad y scores
    result = None
    if product_score > 0:
        result = 'PRODUCT'
    elif webinar_score > 0 and course_score == 0:
        result = 'WEBINAR'
    elif course_score > 0 and webinar_score == 0:
        result = 'COURSE'
    elif asesor_score > 0:
        result = 'ASESOR'
    elif course_score > webinar_score:
        result = 'COURSE'
    elif webinar_score > course_score:
        result = 'WEBINAR'
    else:
        result = 'GENERAL'
    
    logger.info(f"✅ [CLASSIFIER] Resultado final: {result}")
    return result

def detect_and_respond_to_product_queries(phone: str, message_text: str) -> bool:
    """Detecta consultas sobre productos específicos y responde con información detallada."""
    try:
        # Priorizar: si el mensaje es una CONSULTA TÉCNICA amplia, responder con IA
        message_lower = (message_text or '').lower()

        technical_indicators = [
            'induc', 'inducción', 'indución', 'magnét', 'magnético', 'magnet', 'campo magn', 'campo',
            'tensión', 'tension', 'volt', 'corriente', 'interferencia', 'atenuación', 'atenuac', 'ohm',
            'medición', 'mediciones', 'otdr', 'empalm', 'instalar', 'instalación', 'enterrar', 'enterrado',
            'armadura', 'armadura metálica', 'armadura metalica', 'perturb', 'ruido', 'induct', 'inductor'
        ]

        # Heurística: considerar técnica si es larga, tiene signos de pregunta o contiene indicadores técnicos
        is_long = len(message_text or '') > 140
        has_question = '?' in (message_text or '') or '¿' in (message_text or '') or any(w in message_lower for w in ['cómo', 'como', 'qué', 'que', 'por qué', 'por que', 'cómo se', 'como se'])
        contains_technical_kw = any(ind in message_lower for ind in technical_indicators)

        is_technical_consult = (is_long or has_question) and contains_technical_kw

        if is_technical_consult:
            logger.info(f"[PRODUCT_DETECTION] Mensaje técnico detectado, usando IA para responder a {phone}")
            try:
                prompt = (
                    "Eres un asistente técnico experto en redes y fibra óptica. Responde en español de forma concisa y técnica "
                    "al siguiente requerimiento de un usuario. No promociones ni envíes fichas de producto ni cursos completos. "
                    "Si la respuesta requiere calcular o describir riesgos, explica las causas y sugiere medidas prácticas. "
                    "Al final, si procede, ofrece brevemente opciones: 'cotización', 'ficha técnica' o 'asesor' y pide confirmar. "
                    f"Pregunta: {message_text}"
                )
                ai_resp = chat_with_gemini(prompt, conversation_history=[])
                # Seguridad: si la IA responde sugiriendo productos explícitos, neutralizar ofreciendo sugerencias en vez de enviar archivos
                if ai_resp:
                    # Añadir nota breve si el usuario también mencionó productos/curso/webinar
                    product_like_terms = ['bobina', 'cable', 'ducto', 'cat6', 'cat6a', 'curso', 'webinar', 'temario']
                    if any(t in message_lower for t in product_like_terms):
                        ai_resp = ai_resp.strip() + "\n\nNota: Si además requieres cotización, ficha técnica o información comercial del producto/curso mencionado, puedo proporcionarla como sugerencia. ¿Cuál prefieres?"
                    send_text_message(phone, ai_resp)
                    return True
            except Exception as e:
                logger.debug(f"IA fallback error en product detector: {e}")

        # Si no es una consulta técnica amplia, proceder con detección de producto pero SIN enviar automáticamente ficha completa
        # Cargar productos desde el JSON
        import os
        products_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.products.json'))
        if not os.path.exists(products_path):
            return False
        with open(products_path, 'r', encoding='utf-8') as f:
            products = json.load(f)

        # Tokenizar y buscar mejor coincidencia
        import re

        def _tokens(text: str):
            if not text:
                return []
            text = text.lower()
            text = re.sub(r"[^a-z0-9áéíóúñü]+", " ", text)
            toks = [t for t in text.split() if len(t) >= 3]
            return toks

        message_tokens = set(_tokens(message_text))
        best_product = None
        best_score = 0

        for product in products:
            prod_text = ' '.join([product.get('nombre', ''), product.get('descripcion', '')] + product.get('especificaciones', []))
            prod_tokens = set(_tokens(prod_text))
            score = len(message_tokens & prod_tokens)
            name_tokens = set(_tokens(product.get('nombre', '')))
            if name_tokens and len(message_tokens & name_tokens) > 0:
                score += 2

            if score > best_score:
                best_score = score
                best_product = product

        matched_product = best_product if best_score > 0 else None

        if matched_product:
            # No enviar ficha completa: evaluar el requerimiento y sugerir acciones
            wants_purchase_intent = any(k in message_lower for k in ['comprar', 'cotiz', 'precio', 'cuánto cuesta', 'cuanto cuesta', 'cotización', 'cotizacion', 'disponible', 'stock'])

            # Guardar en memoria que el usuario mencionó este producto recientemente
            try:
                save_conversation_memory(phone, 'last_mentioned_product', {'id': matched_product.get('id'), 'nombre': matched_product.get('nombre'), 'saved_at': datetime.now().isoformat()})
            except Exception:
                pass

            if wants_purchase_intent or len(message_text or '') < 120:
                # Mensaje corto o intención de compra → no dar ficha extensa, sino opciones
                short_msg = f"Veo que mencionas *{matched_product.get('nombre')}*. Puedo:"
                short_msg += "\n\n1) Cotización\n2) Ficha técnica (PDF)\n3) Conectar con un asesor comercial\n\nResponde con el número de la opción o escribe 'cotizar', 'ficha técnica' o 'asesor'."
                send_text_message(phone, short_msg)
                return True

            # Mensaje más largo pero no técnico → ofrecer opciones (sin pedir 'evaluar')
            send_text_message(phone, f"Veo que mencionas *{matched_product.get('nombre')}*. ¿Qué prefieres?\n\n1) Cotización\n2) Ficha técnica (PDF)\n3) Conectar con un asesor comercial\n\nResponde con el número o escribe la opción.")
            return True

        return False
    except Exception as e:
        logger.error(f"[PRODUCT_DETECTION] Error: {e}")
        return False


def get_complete_course_info(course_id: int) -> str:
    """Información completa del curso cuando no se especifica qué información necesita."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            course = None
            for c in data:
                if c.get('id') == course_id:
                    course = c
                    break
            
            if not course:
                return f"No encontré información del curso."
            
            nombre = course.get('nombre', 'Sin nombre')
            precio = course.get('precio', 'Consultar')
            duracion = course.get('duracion', '')
            modalidad = course.get('modalidad', 'Presencial')
            ubicacion = course.get('ubicacion', 'Querétaro, Qro.')
            
            # Obtener fechas
            fechas = course.get('proximas_fechas', [])
            fecha_info = "📅 Fechas por confirmar"
            if fechas:
                if len(fechas) == 1:
                    fecha_info = f"📅 **PRÓXIMA FECHA:** {fechas[0].get('fecha', 'Por definir')}"
                else:
                    fecha_info = "📅 **PRÓXIMAS FECHAS:**\n"
                    for fecha in fechas[:3]:  # Máximo 3 fechas
                        fecha_info += f"• {fecha.get('fecha', 'Por definir')}\n"
            
            # Construir temario resumido
            temario = course.get('temario', [])
            temario_text = ""
            if temario:
                temario_text = "\n📚 **TEMARIO RESUMIDO:**\n"
                for i, tema in enumerate(temario[:4], 1):  # Primeros 4 temas
                    titulo = tema.get('titulo', f'Módulo {i}')
                    temario_text += f"• {titulo}\n"
                if len(temario) > 4:
                    temario_text += f"• Y {len(temario) - 4} módulos más...\n"
            
            response = f"""🎓 **{nombre.upper()}**

            💰 **PRECIO:** {precio}
            {fecha_info}
            ⏱️ **DURACIÓN:** {duracion}
            🏢 **MODALIDAD:** {modalidad}
            📍 **UBICACIÓN:** {ubicacion}
            {temario_text}
            ✅ **INCLUYE:**
            • Material didáctico especializado
            • Certificación DC3 oficial
            • Prácticas con equipos profesionales
            • Coffee breaks y almuerzo
                """
            
            return response
            
    except Exception as e:
        logger.error(f"Error obteniendo info completa del curso {course_id}: {e}")
    
    return "No pude obtener la información del curso. ¿Puedes especificar cuál curso te interesa?"

def get_specific_course_info(course_id: int, info_types: list) -> str:
    """Información específica según lo que solicite el usuario."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            course = None
            for c in data:
                if c.get('id') == course_id:
                    course = c
                    break
            
            if not course:
                return "No encontré información del curso."
            
            nombre = course.get('nombre', 'Sin nombre')
            response_parts = [f"🎓 **{nombre.upper()}**\n"]
            
            # Información específica solicitada
            if 'precios' in info_types:
                precio = course.get('precio', 'Consultar')
                response_parts.append(f"💰 **PRECIO:** {precio}")
            
            if 'fechas' in info_types:
                fechas = course.get('proximas_fechas', [])
                if fechas:
                    if len(fechas) == 1:
                        response_parts.append(f"📅 **PRÓXIMA FECHA:** {fechas[0].get('fecha', 'Por definir')}")
                    else:
                        fecha_info = "📅 **PRÓXIMAS FECHAS:**"
                        for fecha in fechas:
                            fecha_info += f"\n• {fecha.get('fecha', 'Por definir')}"
                        response_parts.append(fecha_info)
                else:
                    response_parts.append("📅 **FECHAS:** Por confirmar")
            
            if 'duracion' in info_types:
                duracion = course.get('duracion', 'Consultar')
                response_parts.append(f"⏱️ **DURACIÓN:** {duracion}")
            
            if 'modalidad' in info_types:
                modalidad = course.get('modalidad', 'Presencial')
                response_parts.append(f"🏢 **MODALIDAD:** {modalidad}")
            
            if 'ubicacion' in info_types:
                ubicacion = course.get('ubicacion', 'Querétaro, Qro.')
                response_parts.append(f"📍 **UBICACIÓN:** {ubicacion}")
            
            
            return "\n".join(response_parts)
            
    except Exception as e:
        logger.error(f"Error obteniendo info específica del curso {course_id}: {e}")
    
    return "No pude obtener la información específica. ¿Puedes ser más específico sobre qué información necesitas?"

def get_course_temario_text(course_id: int) -> str:
    """Información textual del temario antes de enviar el PDF."""
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            course = None
            for c in data:
                if c.get('id') == course_id:
                    course = c
                    break
            
            if not course:
                return "No encontré el temario del curso."
            
            nombre = course.get('nombre', 'Sin nombre')
            temario = course.get('temario', [])
            
            if not temario:
                return f"📚 El temario detallado de **{nombre}** se está enviando en el PDF adjunto."
            
            response = f"📚 **TEMARIO DE {nombre.upper()}**\n\n"
            
            for i, tema in enumerate(temario, 1):
                titulo = tema.get('titulo', f'Módulo {i}')
                response += f"**{i}. {titulo}**\n"
                
                subtemas = tema.get('subtemas', [])
                if subtemas:
                    for subtema in subtemas[:3]:  # Máximo 3 subtemas por tema
                        response += f"   • {subtema}\n"
                    if len(subtemas) > 3:
                        response += f"   • Y {len(subtemas) - 3} temas más...\n"
                response += "\n"
            
            response += "📎 **Te estoy enviando el PDF completo con todos los detalles...**\n\n"
            response += "🚀 **¿LISTO PARA INSCRIBIRTE?**\n"
            response += "Escribe \"inscribir\" y te ayudo con el proceso paso a paso."
            
            return response
            
    except Exception as e:
        logger.error(f"Error obteniendo temario textual del curso {course_id}: {e}")
    
    return "📚 Te estoy enviando el temario completo en PDF..."

from utils.pdf_utils import generar_pdf_datos_prospecto
# Asegura que la función esté definida antes de usarse
def notificar_asesor_con_pdf(datos_usuario, phone):
    from routes.advisor_fallbacks import DEFAULT_ADVISOR_PHONE
    import os
    pdf_path = os.path.join("pdfs", f"prospecto_{phone}.pdf")
    abs_pdf_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', pdf_path))
    generar_pdf_datos_prospecto(datos_usuario, abs_pdf_path)
    send_document_message(DEFAULT_ADVISOR_PHONE, abs_pdf_path, caption="Nuevo prospecto generado desde WhatsApp")
    send_text_message(DEFAULT_ADVISOR_PHONE, f"Nuevo prospecto generado:\nNombre: {datos_usuario.get('nombre')}\nEmpresa: {datos_usuario.get('empresa')}\nTeléfono: {datos_usuario.get('telefono')}")

def get_general_course_info_response(info_types: list) -> str:
    """Respuesta cuando se pregunta por información general sin especificar curso."""
    # Si solo pregunta por modalidad
    if 'modalidad' in info_types and len(info_types) == 1:
        # Si el usuario pregunta por modalidad online/en línea/webinar, mostrar webinars
        import inspect
        frame = inspect.currentframe().f_back
        user_message = frame.f_locals.get('message_text', '') if frame and 'message_text' in frame.f_locals else ''
        user_message = user_message.lower() if user_message else ''
        online_keywords = ['online', 'en línea', 'en linea', 'virtual en vivo', 'a distancia', 'webinar', 'webinars', 'seminario', 'seminarios']
        for kw in online_keywords:
            if kw in user_message:
                # Mostrar lista de webinars
                return get_all_webinars_info()
        # Si no especificó modalidad online, sugerir aclaración
        return "¿Te interesa modalidad presencial o en línea? Si quieres ver la lista de webinars escribe 'webinars' y si deseas la lista de cursos escribe 'cursos'."

    # Si solo pregunta por temario/temas
    if 'temario' in info_types and len(info_types) == 1:
        return (
            "📚 *TEMARIO DE NUESTROS CURSOS:*\n"
            "Para enviarte el temario necesito que me digas el nombre o número del curso que te interesa. Escribe 'cursos' para ver la lista."
        )

    # Si pregunta por modalidad y temario juntos
    if set(info_types) == {'modalidad', 'temario'}:
        return (
            "🏢 *MODALIDADES DISPONIBLES:*\n"
            "• Presencial (Querétaro)\n"
            "• Online\n"
            "• In-company (en tu empresa)\n\n"
            "📚 *TEMARIO:* Dime el nombre o número del curso que te interesa para que te envíe el temario completo."
        )

    # Construir respuestas concisas según lo solicitado
    parts = []
    # Si el usuario pregunta directamente por alguno de los campos, devolvemos la info por cada curso
    lookups = set(info_types or []) & {'precios', 'fechas', 'duracion', 'ubicacion', 'temario'}
    if lookups:
        try:
            courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
            if os.path.exists(courses_path):
                with open(courses_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                lines = []
                for c in (data or []):
                    cid = c.get('id')
                    nombre = c.get('nombre', 'Sin nombre')
                    parts_for_course = []
                    if 'precios' in lookups:
                        precio = c.get('precio', 'Consultar')
                        parts_for_course.append(f"Precio: {precio}")
                    if 'fechas' in lookups:
                        fechas = c.get('proximas_fechas', [])
                        if fechas:
                            fecha_info = ', '.join([f.get('fecha', '') for f in fechas if isinstance(f, dict)])
                        else:
                            fecha_info = 'Fechas por confirmar'
                        parts_for_course.append(f"Fechas: {fecha_info}")
                    if 'duracion' in lookups:
                        duracion = c.get('duracion', c.get('duration', 'Consultar'))
                        parts_for_course.append(f"Duración: {duracion}")
                    if 'ubicacion' in lookups:
                        ubicacion = c.get('ubicacion') or c.get('location') or 'Por definir'
                        parts_for_course.append(f"Ubicación: {ubicacion}")
                    if 'temario' in lookups:
                        temario = c.get('temario', [])
                        if temario:
                            # mostrar hasta 3 títulos de módulo
                            mods = []
                            for i, t in enumerate(temario[:3], 1):
                                if isinstance(t, dict):
                                    titulo = t.get('titulo') or t.get('title') or f'Módulo {i}'
                                else:
                                    titulo = str(t)
                                mods.append(titulo)
                            tem_text = '; '.join(mods)
                            parts_for_course.append(f"Temario (resumido): {tem_text}")
                        else:
                            parts_for_course.append("Temario: Disponible en PDF")

                    # montar linea por curso
                    if parts_for_course:
                        lines.append(f"• {cid}. {nombre} — " + ' | '.join(parts_for_course))

                if lines:
                    parts.append('\n'.join(lines))
                else:
                    # fallback
                    parts.append("No pude obtener la información de los cursos. Intenta más tarde.")
            else:
                # fallback: indicar al usuario que especifique
                parts.append("Dime cuál curso te interesa (nombre o número) o escribe 'cursos' para ver la lista completa.")
        except Exception as e:
            logger.error(f"Error obteniendo datos de cursos en get_general_course_info_response: {e}")
            parts.append("Dime cuál curso te interesa (nombre o número) o escribe 'cursos' para ver la lista completa.")

    # Si no se pudo determinar un tema específico, pedir que el usuario especifique
    if not parts:
        return "¿Puedes especificar qué información necesitas? Por ejemplo: 'precio del curso 1', 'fechas FTTH', o escribe 'cursos' para ver la lista."

    return "\n\n".join(parts)

# ==========================================
# SISTEMA DE DIFERENCIACIÓN CURSOS VS WEBINARS
# ==========================================

def classify_course_vs_webinar_intent(message_text: str) -> str:
    """
    Clasifica si el usuario pregunta por cursos o webinars para evitar confusiones.
    Retorna: 'course', 'webinar', 'unclear'
    """
    message_lower = message_text.lower()
    
    # Indicadores FUERTES de CURSOS
    strong_course_indicators = [
        'curso', 'cursos', 'capacitacion', 'capacitación', 'entrenamiento',
        'presencial', 'certificacion', 'certificación', 'dc3', 
        'inscribir', 'inscripcion', 'inscripción', 'temario',
        'precio del curso', 'costo del curso', 'fechas del curso'
    ]
    
    # Indicadores FUERTES de WEBINARS  
    strong_webinar_indicators = [
        'webinar', 'webinars', 'seminario', 'seminarios',
        'gratis', 'gratuito', 'gratuitos', 'free',
        'online gratis', 'evento gratis', 'charla gratis',
        'martes', 'todos los martes'
    ]
    
    # Indicadores MODERADOS de CURSOS
    moderate_course_indicators = [
        'cableado estructurado', 'planta externa', 'ftth', 'pon', 'empalmes',
        'otdr', 'certificado', 'diploma', 'pago', 'pagos'
    ]
    
    # Indicadores MODERADOS de WEBINARS
    moderate_webinar_indicators = [
        'preconectorizada', 'instalacion subterranea', 'wisp a fibra',
        'centro de datos', 'redes lan', 'odn', 'distribucion optica'
    ]
    
    # Contar indicadores
    strong_course_score = sum(1 for indicator in strong_course_indicators if indicator in message_lower)
    strong_webinar_score = sum(1 for indicator in strong_webinar_indicators if indicator in message_lower)
    moderate_course_score = sum(1 for indicator in moderate_course_indicators if indicator in message_lower)
    moderate_webinar_score = sum(1 for indicator in moderate_webinar_indicators if indicator in message_lower)
    
    # Calcular puntuaciones totales
    total_course_score = (strong_course_score * 3) + moderate_course_score
    total_webinar_score = (strong_webinar_score * 3) + moderate_webinar_score
    
    # Decisión
    if strong_course_score > 0 and strong_webinar_score == 0:
        return 'course'
    elif strong_webinar_score > 0 and strong_course_score == 0:
        return 'webinar'
    elif total_course_score > total_webinar_score:
        return 'course'
    elif total_webinar_score > total_course_score:
        return 'webinar'
    else:
        return 'unclear'

# ==========================================
# SISTEMA DE WEBINARS
# ==========================================

def detect_webinar_request(phone: str, message_text: str) -> bool:
    """Detecta solicitudes de información sobre webinars usando clasificación inteligente."""
    try:
        # VERIFICAR QUE ES UNA CONSULTA DE WEBINAR (no de curso ni producto)
        message_type = classify_message_type(message_text)
        if message_type not in ['WEBINAR', 'GENERAL']:
            logger.info(f"[WEBINAR_DETECTION] Mensaje clasificado como {message_type}, no como WEBINAR. Saliendo.")
            return False
        
        # Usar la función de clasificación inteligente adicional
        intent_type = classify_course_vs_webinar_intent(message_text)
        
        if intent_type == 'webinar' or message_type == 'WEBINAR':
            logger.info(f"[WEBINAR_DETECTION] Detectada solicitud de webinars de {phone}")
            
            # Enviar información de todos los webinars
            webinars_info = get_all_webinars_info()
            send_text_message(phone, webinars_info)
            return True
        elif intent_type == 'course':
            # Es claramente una consulta de curso, no procesar como webinar
            return False
        else:
            # Si no está claro, verificar palabras clave simples de webinar
            message_lower = message_text.lower()
            simple_webinar_keywords = ['webinar', 'seminario', 'gratis', 'gratuito']
            
            if any(keyword in message_lower for keyword in simple_webinar_keywords):
                logger.info(f"[WEBINAR_DETECTION] Detectada solicitud ambigua de webinars de {phone}")
                webinars_info = get_all_webinars_info()
                send_text_message(phone, webinars_info)
                return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error en detect_webinar_request: {e}")
        return False

def get_all_webinars_info() -> str:
    """Obtiene información de todos los webinars disponibles."""
    try:
        webinars_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.webinars.json'))
        if os.path.exists(webinars_path):
            with open(webinars_path, 'r', encoding='utf-8') as f:
                webinars = json.load(f)
            
            if not webinars:
                return "No hay webinars disponibles en este momento."
            
            response = "🎯 **WEBINARS GRATUITOS DISPONIBLES**\n\n"
            response += "📅 **Todos los martes a las 11:00 AM**\n\n"
            
            for i, webinar in enumerate(webinars, 1):
                title = webinar.get('title', 'Sin título')
                description = webinar.get('description', '')
                fechas = webinar.get('fechas', [])
                
                response += f"**{i}. {title}**\n"
                if description:
                    # Truncar descripción si es muy larga
                    desc_short = description[:100] + "..." if len(description) > 100 else description
                    response += f"📋 {desc_short}\n"
                
                if fechas and fechas[0]:  # Solo mostrar si hay fecha válida
                    response += f"📅 Próxima fecha: {fechas[0]}\n"
                
                response += "\n"
            
            response += "🔍 **¿CUÁL TE INTERESA?**\n"
            response += "💡 **Todos nuestros webinars son GRATUITOS**\n\n"
            response += "🔗 **INFORMACIÓN GENERAL DE WEBINARS:**\n"
            response += "https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
            response += "📧 Solo necesitas registrarte con tu email para participar."
            
            return response
            
    except Exception as e:
        logger.error(f"Error obteniendo información de webinars: {e}")
    
    return "No pude obtener la información de webinars. Por favor intenta más tarde."

def detect_webinar_selection(phone: str, message_text: str) -> bool:
    """Detecta cuando un usuario selecciona un webinar específico POR NOMBRE COMPLETO (no por número)."""
    try:
        # Normalize incoming message for robust matching (remove accents, punctuation, collapse whitespace)
        import unicodedata, re

        def _normalize_text(s: str) -> str:
            if not s or not isinstance(s, str):
                return ''
            # Normalize unicode characters (separate accents), remove combining marks
            s_norm = unicodedata.normalize('NFKD', s)
            s_norm = ''.join(c for c in s_norm if not unicodedata.combining(c))
            s_norm = s_norm.lower()
            # Replace non-word characters with spaces and collapse repeats
            s_norm = re.sub(r"[^a-z0-9\s]+", ' ', s_norm)
            s_norm = re.sub(r"\s+", ' ', s_norm).strip()
            return s_norm

        message_norm = _normalize_text(message_text)

        webinars_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.webinars.json'))
        if os.path.exists(webinars_path):
            with open(webinars_path, 'r', encoding='utf-8') as f:
                webinars = json.load(f)

            for idx, webinar in enumerate(webinars):
                title_raw = webinar.get('title', '')
                title = _normalize_text(title_raw)

                # Fast path: exact normalized substring
                if title and title in message_norm:
                    logger.info(f"[WEBINAR_MATCH] matched by substring -> {title_raw}")
                    webinar_info = get_specific_webinar_info(idx + 1)
                    if webinar_info:
                        send_text_message(phone, webinar_info)
                        return True

                # Word-overlap heuristic: consider a match if a majority of title words appear in message
                if title:
                    title_words = [w for w in title.split() if len(w) > 2]
                    if title_words:
                        msg_words = set(message_norm.split())
                        matched = sum(1 for w in title_words if w in msg_words)
                        try:
                            ratio = matched / len(title_words)
                        except Exception:
                            ratio = 0
                        if ratio >= 0.6:  # 60% of significant words match
                            logger.info(f"[WEBINAR_MATCH] matched by word-overlap ({matched}/{len(title_words)}) -> {title_raw}")
                            webinar_info = get_specific_webinar_info(idx + 1)
                            if webinar_info:
                                send_text_message(phone, webinar_info)
                                return True

                # Also check topics/keywords of the webinar
                topics = webinar.get('topics', []) or []
                for topic in topics:
                    topic_norm = _normalize_text(topic)
                    if topic_norm and (topic_norm in message_norm):
                        logger.info(f"[WEBINAR_MATCH] matched by topic substring -> {topic}")
                        webinar_info = get_specific_webinar_info(idx + 1)
                        if webinar_info:
                            send_text_message(phone, webinar_info)
                            return True
                    # topic word-overlap as well
                    twords = [w for w in topic_norm.split() if len(w) > 2]
                    if twords:
                        matched = sum(1 for w in twords if w in message_norm.split())
                        if matched and (matched / len(twords)) >= 0.6:
                            logger.info(f"[WEBINAR_MATCH] matched by topic word-overlap -> {topic}")
                            webinar_info = get_specific_webinar_info(idx + 1)
                            if webinar_info:
                                send_text_message(phone, webinar_info)
                                return True

        return False
    except Exception as e:
        logger.error(f"Error en detect_webinar_selection: {e}")
        return False

def get_specific_webinar_info(webinar_number: int) -> str:
    """Obtiene información detallada de un webinar específico."""
    try:
        webinars_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.webinars.json'))
        if os.path.exists(webinars_path):
            with open(webinars_path, 'r', encoding='utf-8') as f:
                webinars = json.load(f)
            
            if webinar_number < 1 or webinar_number > len(webinars):
                return None
            
            webinar = webinars[webinar_number - 1]
            title = webinar.get('title', 'Sin título')
            description = webinar.get('description', '')
            topics = webinar.get('topics', [])
            link = webinar.get('link', '')
            fechas = webinar.get('fechas', [])
            horario = webinar.get('horario', ['11:00 AM'])
            
            response = f"🎯 **{title.upper()}**\n\n"
            
            if description:
                response += f"📋 **DESCRIPCIÓN:**\n{description}\n\n"
            
            if topics:
                response += "📚 **TEMAS QUE VEREMOS:**\n"
                for topic in topics:
                    response += f"• {topic}\n"
                response += "\n"
            
            if fechas and fechas[0]:
                response += f"📅 **PRÓXIMA FECHA:** {fechas[0]}\n"
            
            response += f"⏰ **HORARIO:** {horario[0] if horario else '11:00 AM'}\n"
            response += "💰 **COSTO:** GRATUITO\n\n"
            
            # Asegurar que siempre haya un link de registro
            if link and link.strip():
                response += f"🔗 **LINK DE REGISTRO ESPECÍFICO:**\n{link}\n\n"
            else:
                response += f"🔗 **INFORMACIÓN Y REGISTRO:**\n"
                response += f"https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
            
            response += "✅ **REGISTRO DIRECTO:**\n"
            response += "Haz clic en el link de arriba para registrarte. Es completamente gratuito.\n\n"
            response += "🎓 **¿Te interesan también nuestros cursos presenciales con certificación?**\n"
            response += "Escribe \"cursos\" para ver programas completos con certificación DC3."
            
            return response
            
    except Exception as e:
        logger.error(f"Error obteniendo webinar específico {webinar_number}: {e}")
    
    return None

# ==========================================
# SISTEMA MEJORADO DE ASESOR CON PASOS DETALLADOS
# ==========================================

def detect_process_request(phone: str, message_text: str) -> bool:
    """Detecta solicitudes de información sobre procesos de inscripción, cotización, facturación."""
    try:
        message_lower = message_text.lower()
        
        # Palabras clave para procesos - detección más específica
        inscripcion_keywords = ['quiero inscribirme', 'me quiero inscribir', 'quiero inscribir', 
                                'inscribirme', 'como me inscribo', 'cómo me inscribo',
                                'proceso de inscripción', 'inscripcion al curso']
        cotizacion_keywords = ['cotizar', 'cotización', 'cotizacion', 'presupuesto', 'cuánto cuesta']
        facturacion_keywords = ['facturar', 'factura', 'facturación', 'facturacion']
        
        process_type = None
        if any(keyword in message_lower for keyword in inscripcion_keywords):
            process_type = 'inscripcion'
        elif any(keyword in message_lower for keyword in cotizacion_keywords):
            process_type = 'cotizacion'
        elif any(keyword in message_lower for keyword in facturacion_keywords):
            process_type = 'facturacion'
        
        if process_type:
            logger.info(f"[PROCESS_REQUEST] Detectada solicitud de {process_type} de {phone}")
            
            # Guardar el tipo de proceso y iniciar la recopilación de datos
            save_conversation_memory(phone, 'advisor_data', {
                'step': 'waiting_info',
                'fields_needed': ['nombre', 'telefono', 'email', 'empresa', 'rfc', 'web', 'curso_solicitado'],
                'current_field': 0,
                'data': {},
                'process_type': process_type,
                'started_at': datetime.now().isoformat(),
                'completed': False
            })
            save_conversation_memory(phone, 'waiting_for_advisor_data', True)
            save_conversation_memory(phone, 'advisor_prompt_sent', True)
            save_conversation_memory(phone, 'advisor_intentos', 0)
            
            # Mensaje personalizado según el tipo
            if process_type == 'inscripcion':
                intro = "¡Perfecto! 🎓 Para procesar tu inscripción necesito algunos datos.\n\n"
            elif process_type == 'cotizacion':
                intro = "¡Perfecto! 💰 Para generar tu cotización necesito algunos datos.\n\n"
            else:
                intro = "¡Perfecto! 📋 Para ayudarte necesito algunos datos.\n\n"
            
            intro += (
                "📝 Nombre completo\n"
                "📱 Teléfono\n"
                "📧 Correo electrónico\n"
                "🏢 Empresa\n"
                "�️ RFC / Razón Social\n"
                "🌐 Sitio web\n"
                "�🎯 Curso de interés\n\n"
                "Son 7 pasos. ¡Empezamos!\n\n"
                "📝 **Nombre (1 de 7)**\n\n"
                "Por favor compárteme tu **nombre completo**:"
            )
            
            send_text_message(phone, intro)
            return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error en detect_process_request: {e}")
        return False

def detect_follow_up_requests(phone: str, message_text: str) -> bool:
    """
    Detecta respuestas de seguimiento simples como 'sí', 'más info', 'temario', etc.
    y responde según el contexto del curso seleccionado.
    """
    try:
        message_lower = message_text.lower().strip()

        # Obtener curso actualmente seleccionado
        try:
            from services.conversation_memory_utils import get_conversation_memory
            selected_course = get_conversation_memory(phone, 'selected_course')
        except Exception:
            selected_course = None

        if not selected_course:
            return False

        course_id = selected_course.get('id')
        course_name = selected_course.get('name', f'Curso {course_id}')

        # Respuestas simples que indican interés
        interest_keywords = [
            'si', 'sí', 's', 'ok', 'claro', 'vale', 'adelante', 'perfecto',
            'genial', 'excelente', 'me interesa', 'quiero', 'necesito',
            'más info', 'mas info', 'más información', 'mas informacion'
        ]

        # Respuestas específicas para temario
        temario_keywords = [
            'temario', 'programa', 'contenido', 'temas', 'módulos', 'modulos',
            'qué veremos', 'que veremos', 'plan de estudios', 'syllabus'
        ]

        # Respuestas para inscripción
        inscripcion_keywords = [
            'inscribir', 'inscripción', 'inscripcion', 'registrar', 'apuntar',
            'proceso', 'cómo me inscribo', 'como me inscribo', 'quiero inscribirme'
        ]

        # First, check if there are any pending multi-part messages the user may want to continue
        try:
            if any(k in message_lower for k in ['continuar', 'siguiente', 'sigue', 'más', 'mas', 'seguir', 'ver más']):
                sent = continue_pending_parts(phone)
                if sent:
                    return True
        except Exception:
            pass

        # First, check if we're awaiting a temario confirmation specifically
        try:
            awaiting = get_conversation_memory(phone, 'awaiting_temario_confirmation')
        except Exception:
            awaiting = False

        if awaiting:
            # Interpret affirmative/negative with common variants
            affirm = ['si', 'sí', 's', 'claro', 'ok', 'vale', 'adelante', 'quiero', 'me interesa', 'sí, por favor', 'si por favor']
            neg = ['no', 'n', 'no gracias', 'nop', 'no, gracias', 'no por ahora']

            if any(a == message_lower or message_lower.startswith(a + ' ') or (' ' + a + ' ') in (' ' + message_lower + ' ') for a in affirm):
                # Send temario for the selected course
                logger.info(f"[FOLLOW_UP] Usuario confirmó envío de temario para curso {course_id}")
                sent = False
                try:
                    # Normalize course_id to int when possible
                    try:
                        cid = int(course_id)
                    except Exception:
                        cid = course_id
                    sent = send_course_temario_pdf(phone, cid, course_name)
                except Exception as e:
                    logger.debug(f"Error sending temario PDF: {e}")

                # Also send textual temario if available
                try:
                    temario_text = get_course_temario_text(cid)
                except Exception:
                    temario_text = None

                if temario_text:
                    send_text_message(phone, temario_text)

                # Clear awaiting flag and selected course
                try:
                    save_conversation_memory(phone, 'awaiting_temario_confirmation', None)
                    save_conversation_memory(phone, 'selected_course', None)
                except Exception:
                    pass

                return True

            if any(n == message_lower or message_lower.startswith(n + ' ') or (' ' + n + ' ') in (' ' + message_lower + ' ') for n in neg):
                logger.info(f"[FOLLOW_UP] Usuario rechazó envío de temario para curso {course_id}")
                try:
                    save_conversation_memory(phone, 'awaiting_temario_confirmation', None)
                    save_conversation_memory(phone, 'selected_course', None)
                except Exception:
                    pass
                send_text_message(phone, "Está bien — seguimos entonces. ¿En qué más puedo ayudarte?")
                return True

            # If user replied with a course name or number while awaiting, try to resolve it
            # e.g., user was asked "Which course?" and replied with a name directly
            if re.search(r"\b(\d+)\b", message_lower) or any(k in message_lower for k in ['cableado','planta','ftth','pon','empalm']):
                try:
                    resolved = resolve_course_selection(phone, message_text)
                    if resolved:
                        # resolve_course_selection will re-ask the temario confirmation after sending details
                        return True
                except Exception:
                    pass

        # Detectar solicitud directa de temario
        if any(keyword in message_lower for keyword in temario_keywords):
            logger.info(f"[FOLLOW_UP] Detectada solicitud de temario para curso {course_id}")

            # Enviar PDF del temario
            try:
                pdf_sent = send_course_temario_pdf(phone, course_id, course_name)
            except Exception:
                pdf_sent = False

            # Decide whether to send textual temario immediately or in parts
            try:
                temario_text = get_course_temario_text(course_id)
            except Exception:
                temario_text = None

            if temario_text:
                # Split into parts by paragraphs or lines if long
                parts = []
                # Prefer splitting on double newlines to get logical blocks
                blocks = [b.strip() for b in re.split(r"\n\n+", temario_text) if b.strip()]
                if len(blocks) <= 1:
                    # fallback: split by lines into chunks of ~800 chars
                    text = temario_text
                    chunk_size = 800
                    for i in range(0, len(text), chunk_size):
                        parts.append(text[i:i+chunk_size])
                else:
                    parts = blocks

                # Add guidance to each part except the last
                for i in range(len(parts)-1):
                    if 'responder' not in parts[i].lower() and 'continuar' not in parts[i].lower():
                        parts[i] = parts[i].rstrip() + "\n\n[Responde 'continuar' para ver la siguiente parte.]"

                # Send using send_message_parts (persists remaining parts)
                send_message_parts(phone, parts, meta_key=f'pending_message_parts_course_{course_id}')

            # If PDF wasn't sent, still return True since we handled the temario text
            return True
            return True

        # Detectar solicitud de inscripción
        if any(keyword in message_lower for keyword in inscripcion_keywords):
            logger.info(f"[FOLLOW_UP] Detectada solicitud de inscripción para curso {course_id}")

            # Mostrar pasos de inscripción E iniciar recolección de datos
            process_info = get_process_steps_info('inscripcion')
            send_text_message(phone, process_info)
            start_advisor_with_context(phone, 'inscripcion')
            return True

        # Detectar interés general
        if any(keyword in message_lower for keyword in interest_keywords):
            logger.info(f"[FOLLOW_UP] Detectado interés general para curso {course_id}")

            # Detectar intención de inscripción o cotización
            intent = None
            inscripcion_keywords = ['inscripcion', 'inscripción', 'inscribir', 'registrar', 'apuntar']
            cotizacion_keywords = ['cotizar', 'cotización', 'cotizacion', 'presupuesto', 'precio']
            if any(keyword in message_lower for keyword in inscripcion_keywords):
                intent = 'inscripcion'
            elif any(keyword in message_lower for keyword in cotizacion_keywords):
                intent = 'cotizacion'

            if intent in ('inscripcion', 'cotizacion'):
                send_text_message(phone, "Ok, para este proceso necesitaré algunos datos para poder ayudarte.")
                # Aquí inicia la recolección de datos del usuario (flujo ya existente)
                # iniciar_recoleccion_datos_usuario(phone)
                return

            # Ofrecer opciones específicas SIN saludo
            response = f"**¿Qué te gustaría saber sobre {course_name}?**\n\n"
            response += "Puedes pedirme:\n"
            response += "📚 **\"Temario\"** - Te envío el programa completo\n"
            response += "📅 **\"Fechas\"** - Próximas fechas disponibles\n"
            response += "💰 **\"Precio\"** - Costo e información de pago\n"
            response += "📍 **\"Ubicación\"** - Dónde se imparte\n"
            response += "📝 **\"Inscribir\"** - Proceso de inscripción\n"
            response += "🤝 **\"Asesor\"** - Hablar con un especialista\n\n"
            response += "Solo escribe lo que necesitas."

            send_text_message(phone, response)
            return True

        return False

    except Exception as e:
        logger.error(f"Error en detect_follow_up_requests: {e}")
        return False

def get_course_info_detailed(course_id: int, message_text: str) -> str:
    """Información detallada de cursos con enfoque comercial - LEGACY."""
    # Esta función se mantiene para compatibilidad, pero ahora usa las nuevas funciones
    return get_complete_course_info(course_id)

def process_advisor_submission(phone: str, message_text: str) -> bool:

    try:
        logger.info(f"[ADVISOR_DATA] Procesando datos de {phone}: {message_text[:100]}...")
        
        from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
        
        # Guardar los datos del usuario
        advisor_data = get_conversation_memory(phone, 'advisor_data') or {}
        advisor_data.update({
            'step': 'processing',
            'user_data': message_text,
            'received_at': datetime.now().isoformat(),
            'completed': True
        })
        
        save_conversation_memory(phone, 'advisor_data', advisor_data)
        
        # Enviar confirmación al usuario
        confirmation_message = """✅ **Información recibida correctamente**

Gracias por proporcionar tus datos. Un asesor de nuestro equipo se pondrá en contacto contigo dentro de las próximas 2 horas hábiles.

📞 **¿Necesitas atención inmediata?**
Puedes llamarnos directamente al: **442 784 3528**

¿Hay algo más en lo que pueda ayudarte mientras tanto?"""
        
        send_text_message(phone, confirmation_message)
        
        # Enviar notificación al asesor
        try:
            advisor_notification = f"""🔔 **NUEVA SOLICITUD DE ASESOR**

📱 **Teléfono:** {phone}
🕐 **Fecha:** {datetime.now().strftime('%d/%m/%Y %H:%M')}

📋 **Datos del cliente:**
{message_text}

---
Por favor contactar al cliente lo antes posible."""
            
            # Enviar al asesor por defecto
            send_text_message(DEFAULT_ADVISOR_PHONE, advisor_notification)
            logger.info(f"[ADVISOR_DATA] Notificación enviada al asesor {DEFAULT_ADVISOR_PHONE}")
            
        except Exception as e:
            logger.error(f"[ADVISOR_DATA] Error enviando notificación al asesor: {e}")
        
        # Limpiar proceso de asesor (reiniciar para futuros contactos)
        save_conversation_memory(phone, 'advisor_data', {
            'step': 'completed',
            'last_contact': datetime.now().isoformat()
        })
        
        logger.info(f"[ADVISOR_DATA] Datos procesados exitosamente para {phone}")
        return True
        
    except Exception as e:
        logger.error(f"[ADVISOR_DATA] Error procesando datos: {e}")
        send_text_message(phone, "Hubo un problema procesando tu información. Por favor intenta enviar tus datos de nuevo o escribe 'asesor' para reiniciar el proceso.")
        return False

def get_course_details_by_number(num):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_full_details_message'):
        try:
            result = ca.get_course_full_details_message(num)
            if result and "no disponible" not in result.lower():
                return result
        except Exception as e:
            logger.debug(f"get_course_full_details_message adapter error: {e}")

    # Fallback: use temario_handler
    try:
        from utils.temario_handler import get_course_temario_message
        result = get_course_temario_message(num)
        if result and "error" not in result.lower() and "ocurr" not in result.lower():
            return result
    except Exception as e:
        logger.debug(f"temario_handler fallback error: {e}")
    # Final fallback: try local JSON file for temario and course details
    try:
        courses_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'splitbot.courses.json'))
        if os.path.exists(courses_path):
            with open(courses_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            try:
                key = int(num)
            except Exception:
                key = None
            for item in (data or []):
                if key is not None and item.get('id') == key:
                    # Build temario message
                    title = item.get('nombre') or item.get('title') or 'Curso'
                    duracion = item.get('duracion') or ''
                    modalidad = item.get('modalidad') or ''
                    temario = item.get('temario') or []
                    msg_lines = [f"{title}", f"Modalidad: {modalidad}", f"Duración: {duracion}", "\nTemario:"]
                    for t in temario:
                        titulo = t.get('titulo') or ''
                        sub = t.get('subtemas') or []
                        msg_lines.append(f"- {titulo}")
                        for s in sub:
                            msg_lines.append(f"   • {s}")
                    return "\n".join([l for l in msg_lines if l])
    except Exception as e:
        logger.debug(f"get_course_details_by_number JSON fallback error: {e}")

    return "Información del curso no disponible."


def detect_and_update_course_selection(phone, message_text):
    """Detect if user wants to change course and update selection using CourseConversationManager."""
    try:
        text_lower = (message_text or '').lower().strip()

        # Handle pending course change confirmations stored in memory
        pending = get_conversation_memory(phone, 'pending_course_change')
        if pending:
            # Accept short affirmative/negative replies without asking user to type 'si' explicitly
            if text_lower in ['si', 'sí', 's', 'ok', 'claro', 'vale', 'adelante']:
                # Build selection_intent from pending
                selection_intent = {
                    'intent': pending.get('intent') or 'select_by_number',
                    'course_number': pending.get('course_number'),
                    'course': pending.get('course')
                }
                # Clear pending
                try:
                    save_conversation_memory(phone, 'pending_course_change', None)
                except Exception:
                    pass 
                # Proceed with selection
                response = CourseConversationManager._handle_course_selection(phone, selection_intent)
                if response:
                    send_text_message(phone, response)
                    return True, selection_intent.get('course', {}).get('title') or selection_intent.get('course_number') or None
                return False, None

            if text_lower in ['no', 'n', 'cancelar', 'no gracias']:
                # User declined pending change
                try:
                    save_conversation_memory(phone, 'pending_course_change', None)
                except Exception:
                    pass
                current_selection = CourseConversationManager.get_selected_course_info(phone)
                if current_selection:
                    response = f"Perfecto, continuamos con el curso '{current_selection.get('name')}'. ¿Qué más te gustaría saber sobre este curso?"
                else:
                    response = "Perfecto, no se realizó ningún cambio. ¿En qué más te puedo ayudar?"
                send_text_message(phone, response)
                return False, None

        text_lower = (message_text or '').lower()
        current_selection = CourseConversationManager.get_selected_course_info(phone)
        selection_intent = CourseConversationManager.detect_course_selection_intent(message_text)

        # Check for explicit course change keywords
        change_keywords = ['cambiar', 'otro curso', 'cambiar de curso', 'mejor', 'prefiero', 'en lugar', 'cambiar al curso']
        wants_to_change = any(keyword in text_lower for keyword in change_keywords)

        if selection_intent:
            # If user already has a course selected
            if current_selection:
                current_course_id = current_selection.get('id')
                new_course_id = selection_intent.get('course_number') or selection_intent.get('course', {}).get('id')

                # Normalize ids to string for robust comparison (handles int vs str)
                try:
                    cur_id_str = str(current_course_id) if current_course_id is not None else None
                except Exception:
                    cur_id_str = current_course_id
                try:
                    new_id_str = str(new_course_id) if new_course_id is not None else None
                except Exception:
                    new_id_str = new_course_id

                # If it's the same course, no need to change
                if new_id_str == cur_id_str:
                    return False, None
                # Immediately proceed with course change (no explicit confirmation required)
                response = CourseConversationManager._handle_course_selection(phone, selection_intent)
                if response:
                    send_text_message(phone, response)
                    return True, selection_intent.get('course', {}).get('title') or selection_intent.get('course', {}).get('nombre') or f"Curso {selection_intent.get('course_number', '')}"
                return False, None

            else:
                # No current selection, proceed directly
                response = CourseConversationManager._handle_course_selection(phone, selection_intent)
                if response:
                    send_text_message(phone, response)
                    return True, selection_intent.get('course', {}).get('title') or selection_intent.get('course', {}).get('nombre') or f"Curso {selection_intent.get('course_number', '')}"

        # Handle "no" responses to course change confirmations
        elif current_selection and any(word in text_lower for word in ['no', 'cancelar', 'continuar', 'seguir']):
            # User wants to stay with current course
            response = f"Perfecto, continuamos con el curso '{current_selection.get('name')}'. ¿Qué más te gustaría saber sobre este curso?"
            send_text_message(phone, response)
            return False, None

        return False, None
    except Exception as e:
        logger.debug(f"Error detecting course change: {e}")
        return False, None


# CourseManager wrapper that uses the adapter when available
class CourseManager:
    @staticmethod
    def parse_course_query(text: str):
        # Prefer adapter if present
        ca = _import_courses_adapter()
        if ca and hasattr(ca, 'parse_course_query'):
            try:
                return ca.parse_course_query(text)
            except Exception:
                pass

        # Fallback to ML-based parsing using ml_service
        try:
            if not text or not isinstance(text, str):
                return {'course_ids': [], 'query_types': [], 'keywords': []}

            ml_res = ml_service.process_message(text, conversation_history=None)
            classification = ml_res.get('classification') or {}
            entities = ml_res.get('client_data') or {}

            # Build keywords from entities and tokens
            keywords = []
            for v in entities.values():
                if isinstance(v, str) and v.strip():
                    for w in re.split(r"[\s,;:\.]+", v):
                        if len(w) > 2 and w.lower() not in keywords:
                            keywords.append(w.lower())

            # naive tokenization from text
            for t in re.split(r"[^\w]+", text.lower()):
                if len(t) > 3 and t not in keywords:
                    keywords.append(t)

            return {
                'course_ids': [],
                'query_types': [classification.get('category')],
                'keywords': keywords,
                'raw_classification': classification,
                'entities': entities
            }
        except Exception as e:
            logger.debug(f"CourseManager.parse_course_query fallback ML error: {e}")
            return {'course_ids': [], 'query_types': [], 'keywords': []}

    @staticmethod
    def get_course_by_id(cid):
        ca = _import_courses_adapter()
        if ca and hasattr(ca, 'get_course_by_id'):
            try:
                return ca.get_course_by_id(cid)
            except Exception:
                pass

        # Try DB lookup by numeric id or by title/name containing cid
        try:
            # If numeric, search by a numeric id field
            from data.db import get_collection
            # search courses, webinars, products collections
            for col in ('courses', 'webinars', 'products'):
                coll = get_collection(col)
                if not coll:
                    continue
                # try exact id match
                try:
                    doc = coll.find_one({'id': cid}) if cid is not None else None
                    if doc:
                        return doc
                except Exception:
                    pass

                # try by title/name regex
                try:
                    if cid is not None:
                        pattern = str(cid)
                        doc = coll.find_one({'$or': [{'title': {'$regex': pattern, '$options': 'i'}}, {'name': {'$regex': pattern, '$options': 'i'}}]})
                        if doc:
                            return doc
                except Exception:
                    pass
        except Exception:
            pass
        return None

    @staticmethod
    def search_courses_by_keywords(keywords, limit=1):
        ca = _import_courses_adapter()
        if ca and hasattr(ca, 'search_courses_by_keywords'):
            try:
                return ca.search_courses_by_keywords(keywords, limit=limit)
            except Exception:
                pass

        # Fallback: use DB helper to find first matching document
        try:
            if not keywords:
                return []
            kws = [str(k) for k in keywords if k]
            doc = find_db_item_by_keywords(kws, collections=('courses','webinars','products'))
            return [doc] if doc else []
        except Exception as e:
            logger.debug(f"CourseManager.search_courses_by_keywords fallback error: {e}")
            return []


class AdvisorRequestManager:
    @staticmethod
    def is_advisor_request(text: str) -> bool:
        """Only consider advisor/contact requests when user explicitly asks for quote/billing/payment.

        The requirement: "la unica manera de contactara un asesor es cuando se quiere cotizar o facturar"
        So we return True only when message mentions cotizar/cotización/factura/pago/facturar.
        """
        t = (text or '').lower()
        keywords = ['cotiz', 'cotización', 'cotizacion', 'factura', 'facturar', 'pago', 'pagar']
        return any(k in t for k in keywords)


class CourseConversationManager:
    """Centralized manager for course-related conversations to maintain context and flow."""

    @staticmethod
    def get_selected_course_info(phone):
        """Get current selected course with enhanced context."""
        selected = get_selected_course(phone)
        if selected:
            return {
                'id': selected.get('id'),
                'name': selected.get('name'),
                'details': selected.get('details', {}),
                'last_topic': get_conversation_memory(phone, 'course_last_topic'),
                'conversation_state': get_conversation_memory(phone, 'course_conversation_state', 'normal'),
                'last_interaction': get_conversation_memory(phone, 'course_last_interaction')
            }
        return None

    @staticmethod
    def select_course(phone, course_id, course_name, selection_method="manual"):
        """Select a course and update conversation context."""
        details = {
            'selected_at': datetime.now().isoformat(),
            'selection_method': selection_method
        }
        save_selected_course(phone, course_id, course_name, details)
        save_conversation_memory(phone, 'course_conversation_state', 'course_selected')
        save_conversation_memory(phone, 'course_last_topic', 'selection')
        save_conversation_memory(phone, 'course_last_interaction', datetime.now().isoformat())
        logger.info(f"Course selected: {course_name} (ID: {course_id}) for {phone} via {selection_method}")

    @staticmethod
    def clear_course_selection(phone):
        """Clear course selection and reset conversation state."""
        clear_selected_course(phone)
        save_conversation_memory(phone, 'course_conversation_state', 'no_course')
        save_conversation_memory(phone, 'course_last_topic', None)
        save_conversation_memory(phone, 'course_last_interaction', None)

    @staticmethod
    def update_conversation_topic(phone, topic):
        """Update the last discussed topic for context."""
        save_conversation_memory(phone, 'course_last_topic', topic)
        save_conversation_memory(phone, 'course_last_interaction', datetime.now().isoformat())

    
    @staticmethod
    def handle_course_query(phone, message_text):
        """Main handler for course-related queries using improved intent detection."""
        try:
            # Import the new conversation engine
            from services.course_conversation_engine import (
                CourseIntentEngine, CourseConversationFlow, CourseResponseGenerator
            )
            
            # Analyze user intent with advanced engine
            intent, confidence, details = CourseIntentEngine.analyze_message_intent(message_text)
            
            # If confidence is too low, it's probably not a course query
            if confidence < 0.1:
                return None
            
            # Get current conversation context
            selected_course = CourseConversationManager.get_selected_course_info(phone)
            current_stage = CourseConversationFlow.get_conversation_stage(phone)
            
            # Handle course selection/change logic with improved detection
            detected_course = details.get('detected_course')
            if detected_course and selected_course and detected_course != selected_course.get('id'):
                # User mentioned a different course
                return CourseConversationManager._handle_course_switch_offer(phone, message_text, {'intent': 'select_by_number', 'course_number': detected_course}, selected_course)
            
            # If user mentioned a specific course and we don't have selection, select it
            if detected_course and not selected_course:
                selection_intent = {
                    'intent': 'select_by_number', 
                    'course_number': detected_course,
                    'course': CourseManager.get_course_by_id(detected_course)
                }
                return CourseConversationManager._handle_course_selection(phone, selection_intent)
            
            # Generate contextual response using AI with improved prompts
            course_context = {
                'detected_course': detected_course,
                'selected_course': selected_course,
                'confidence': confidence,
                'details': details
            }
            
            # Determine next conversation stage
            next_stage = CourseConversationFlow.determine_next_stage(intent, current_stage)
            if next_stage != current_stage:
                CourseConversationFlow.update_conversation_stage(phone, next_stage, course_context)
            
            # Generate contextual AI prompt
            contextual_prompt = CourseResponseGenerator.generate_contextual_prompt(
                intent, next_stage, course_context, message_text
            )
            
            # Use AI to generate response
            from services.chat_ai import chat_with_gemini
            response = chat_with_gemini(
                phone=phone,
                message=message_text,
                system_prompt=contextual_prompt,
                include_whatsapp_profile=False  # Avoid generic context for focused responses
            )
            
            # Update conversation memory with relevant context
            CourseConversationManager.update_conversation_topic(phone, intent)
            
            return response
            
        except Exception as e:
            logger.error(f"Error in improved course query handler: {e}")
            # Fallback to original logic if new system fails
            return CourseConversationManager._handle_course_query_fallback(phone, message_text)

    @staticmethod
    def _handle_course_query_fallback(phone, message_text):
        """Fallback handler using original logic."""
        text_lower = (message_text or '').lower()
        selected_course = CourseConversationManager.get_selected_course_info(phone)

        # Check for conversation continuity
        last_interaction = selected_course.get('last_interaction') if selected_course else None
        if last_interaction:
            try:
                last_time = datetime.fromisoformat(last_interaction)
                if (datetime.now() - last_time).days > 1:  # Reset context after 1 day
                    CourseConversationManager.clear_course_selection(phone)
                    selected_course = None
            except:
                pass

        # Handle course selection first
        selection_intent = CourseConversationManager.detect_course_selection_intent(message_text)
        if selection_intent:
            return CourseConversationManager._handle_course_selection(phone, selection_intent)

        # Handle general course inquiries
        if CourseConversationManager._is_general_course_inquiry(text_lower):
            return CourseConversationManager._handle_general_course_inquiry(phone, message_text)

        # Handle specific course information requests
        if selected_course:
            return CourseConversationManager._handle_selected_course_query(phone, message_text, selected_course)

        # Handle course-specific queries without selection
        course_query = CourseConversationManager._detect_course_specific_query(message_text)
        if course_query:
            # First, try ML-based parsing and DB search to suggest candidates
            try:
                parsed = CourseManager.parse_course_query(message_text)
                kws = parsed.get('keywords') if parsed and isinstance(parsed, dict) else None
                if kws:
                    candidates = CourseManager.search_courses_by_keywords(kws, limit=3)
                    if candidates:
                        # Save the last listed courses so numeric replies map to these
                        try:
                            save_conversation_memory(phone, 'last_listed_courses', {'items': candidates, 'timestamp': datetime.now().isoformat()})
                        except Exception:
                            pass

                        # Build a short list message
                        resp = "Encontré estos recursos que podrían coincidir con lo que pides:\n\n"
                        for i, c in enumerate(candidates, start=1):
                            title = c.get('title') or c.get('name') or c.get('nombre') or 'Sin título'
                            summary = c.get('summary') or c.get('description') or ''
                            # keep summary short
                            if summary and len(summary) > 200:
                                summary = summary[:197] + '...'
                            resp += f"{i}. {title}\n   {summary}\n\n"
                        resp += "Responde con el número (1-3) del recurso que te interesa o escribe el nombre para más precisión."
                        return resp
            except Exception:
                pass

            # Try to resolve a course id from recent user messages (last_user_messages) when no selected_course
            try:
                hist = get_conversation_memory(phone, 'last_user_messages') or []
                for msg in reversed(hist):
                    num = CourseConversationManager._extract_course_number_from_message(msg)
                    if num:
                        course = CourseManager.get_course_by_id(num)
                        if course:
                            CourseConversationManager.select_course(phone, num, course.get('title') or course.get('nombre', ''), 'history')
                            sel = {'id': num, 'name': course.get('title') or course.get('nombre', ''), 'details': course}
                            return CourseConversationManager._handle_selected_course_query(phone, message_text, sel)
            except Exception:
                pass

            return CourseConversationManager._handle_unspecified_course_query(phone, message_text, course_query)

        return None  # Not a course-related query

    @staticmethod
    def _handle_course_selection(phone, selection_intent):
        """Handle course selection intents with intelligent temario detection."""
        if selection_intent['intent'] == 'select_by_number':
            num = selection_intent['course_number']
            course = CourseManager.get_course_by_id(num)
            if course:
                course_name = course.get('title') or course.get('nombre', f'Curso {num}')
                CourseConversationManager.select_course(phone, num, course_name, 'number')
                
                # Enviar información completa del curso
                complete_info = get_complete_course_info(num)
                
                # También intentar enviar el temario PDF automáticamente
                try:
                    logger.info(f"[AUTO_TEMARIO] Enviando temario automático para curso {num} a {phone}")
                    pdf_sent = send_course_temario_pdf(phone, num, course_name)
                    if pdf_sent:
                        complete_info += "\n\n📎 **Te he enviado el temario completo en PDF** para que puedas revisarlo en detalle."
                    else:
                        complete_info += "\n\n� **¿Quieres el temario en PDF?** Solo escribe \"temario\" y te lo envío inmediatamente."
                except Exception as e:
                    logger.error(f"Error enviando temario automático: {e}")
                    complete_info += "\n\n📧 **¿Quieres el temario completo?** Solo escribe \"temario\" y te lo envío."
                
                return complete_info

        elif selection_intent['intent'] in ['select_by_name', 'select_by_intent']:
            course = selection_intent['course']
            course_id = course.get('id')
            course_name = course.get('title') or course.get('nombre', '')
            if course_id and course_name:
                CourseConversationManager.select_course(phone, course_id, course_name, selection_intent['intent'])
                
                # Enviar información completa del curso
                complete_info = get_complete_course_info(course_id)
                
                # También intentar enviar el temario PDF automáticamente
                try:
                    logger.info(f"[AUTO_TEMARIO] Enviando temario automático para curso {course_id} a {phone}")
                    pdf_sent = send_course_temario_pdf(phone, course_id, course_name)
                    if pdf_sent:
                        complete_info += "\n\n📎 **Te he enviado el temario completo en PDF** para que revises todos los detalles."
                    else:
                        complete_info += "\n\n📧 **¿Necesitas el temario en PDF?** Solo escribe \"temario\" y te lo envío al instante."
                except Exception as e:
                    logger.error(f"Error enviando temario automático: {e}")
                    complete_info += "\n\n📧 **¿Quieres el temario detallado?** Escribe \"temario\" y te lo comparto."
                
                return complete_info

        return "No pude identificar el curso que mencionas. ¿Puedes decirme el nombre completo o número del curso? (1-5)"

    @staticmethod
    def _handle_general_course_inquiry(phone, message_text):
        """Handle general questions about courses."""
        try:
            from utils.courses_adapter import get_courses_recommendation_message
            response = get_courses_recommendation_message(message_text)
            response += "\n\nPara obtener información específica de un curso, solo dime su nombre o número (1-5)."
            return response
        except Exception:
            # If adapter is not available, attempt to generate a conversational discovery question
            try:
                from services.course_conversation_engine import CourseResponseGenerator
                from services.chat_ai import chat_with_gemini

                # Build a short contextual prompt asking one discovery question and suggesting 2-3 courses
                base_prompt = CourseResponseGenerator._get_base_course_context()
                system_prompt = CourseResponseGenerator._generate_discovery_prompt(base_prompt, message_text)

                ai_reply = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt)
                if ai_reply and ai_reply.strip():
                    return ai_reply
            except Exception as ai_err:
                logger.debug(f"AI fallback for general course inquiry failed: {ai_err}")

            # Final fallback: avoid sending unsolicited long lists. Ask user to specify.
            # If we're in the middle of an advisor data collection flow, avoid sending a greeting
            try:
                waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
            except Exception:
                waiting_for_advisor = False

            response = (
                "Puedo ayudarte a elegir un curso relevante. Dime brevemente qué necesitas (por ejemplo: 'instalar FTTH', 'mediciones OTDR', 'cableado estructurado') "
                "o escribe 'cursos' para ver la lista completa."
            )
            return response

    @staticmethod
    def _handle_selected_course_query(phone, message_text, selected_course):
        """Handle queries about the currently selected course via LLM.

        All course-specific replies (temario, fechas, precio, ubicación, inscripción,
        asesor, duración, modalidad) are generated by the AI using a contextual prompt
        that includes the selected course. This ensures the temario sent corresponds
        to the currently selected course and avoids returning the wrong course temario.
        """
        try:
            from services.course_conversation_engine import CourseResponseGenerator
            from services.chat_ai import chat_with_gemini
        except Exception as e:
            logger.debug(f"LLM course handler imports failed: {e}")
            return None

        # Build course context for the AI
        course_context = {
            'detected_course': selected_course.get('id'),
            'selected_course': selected_course,
            'confidence': 1.0,
            'details': {}
        }

        # Determine the user's sub-intent (temario, fechas, precio...)
        sub_intent = CourseConversationManager._detect_course_specific_query(message_text)
        if not sub_intent:
            # fallback to 'specific_course_info'
            sub_intent = 'specific_course_info'

        # Map sub_intent to CourseResponseGenerator intent names
        intent_map = {
            'temario': 'temario_request',
            'fechas': 'practical_info',
            'precio': 'practical_info',
            'ubicacion': 'practical_info',
            'inscripcion': 'enrollment',
            'asesor': 'enrollment',
            'duracion': 'specific_course_info',
            'modalidad': 'specific_course_info',
            'specific_course_info': 'specific_course_info'
        }

        intent = intent_map.get(sub_intent, 'specific_course_info')

        # Generate prompt and ask the LLM
        # Enforce brevity and restrict the model to only mention the selected course
        brevity_instruction = "RESPONDE MUY BREVE (1-3 frases). SOLO HABLA SOBRE EL CURSO SELECCIONADO."
        system_prompt = brevity_instruction + " " + CourseResponseGenerator.generate_contextual_prompt(intent, 'course_details', course_context, message_text)
        ai_reply = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt)
        # Truncate to first paragraph to keep replies concise
        if ai_reply:
            ai_reply = ai_reply.split('\n\n')[0].strip()

        # If temario requested, attempt to send the temario PDF for the selected course
        if sub_intent == 'temario':
            try:
                sent = send_course_temario_pdf(phone, selected_course.get('id'), selected_course.get('name') or selected_course.get('nombre', ''))
                if sent:
                    ai_reply = (ai_reply or '') + "\n\nTe envié el temario en PDF. 📄"
                else:
                    # keep ai_reply as-is; the textual temario (if any) will still be returned
                    ai_reply = (ai_reply or '') + "\n\nNo pude adjuntar el PDF ahora; te doy la información en texto." if not ai_reply else ai_reply
            except Exception as pdf_err:
                logger.debug(f"send_course_temario_pdf failed: {pdf_err}")

        # Update context topic and return AI reply
        CourseConversationManager.update_conversation_topic(phone, sub_intent)
        return ai_reply or None

    @staticmethod
    def _handle_unspecified_course_query(phone, message_text, query_type):
        """Handle course queries when no course is selected."""
        if query_type == 'temario':
            return ("Para enviarte el temario completo, necesito saber qué curso te interesa. 🤔\n\n"
                   "Tenemos estos cursos disponibles:\n"
                   "1. Cableado estructurado para redes de fibra y cobre\n"
                   "2. Redes de fibra óptica planta externa\n"
                   "3. Redes de fibra óptica FTTH para WISP e ISP\n"
                   "4. PON/LAN redes pasivas para entornos enterprise\n"
                   "5. Empalmes y mediciones con OTDR\n\n"
                   "¿Cuál te interesa? Solo dime el número o el nombre del curso.")

        elif query_type in ['fechas', 'precio', 'ubicacion']:
            query_names = {'fechas': 'fechas', 'precio': 'precio', 'ubicacion': 'ubicación'}
            return (f"Para darte información específica de {query_names[query_type]}, primero necesito saber qué curso te interesa. 📋\n\n"
                   "Tenemos estos cursos disponibles:\n"
                   "1. Cableado estructurado para redes de fibra y cobre\n"
                   "2. Redes de fibra óptica planta externa\n"
                   "3. Redes de fibra óptica FTTH para WISP e ISP\n"
                   "4. PON/LAN redes pasivas para entornos enterprise\n"
                   "5. Empalmes y mediciones con OTDR\n\n"
                   "¿Sobre cuál curso quieres saber?")

        return None

    @staticmethod
    def _is_general_course_inquiry(text_lower):
        """Check if message is a general inquiry about courses."""
        keywords = [
            'recomien', 'sugier', 'cursos tienes', 'cursos disponibles',
            'opciones de curso', 'que me recomiendas', 'cual me conviene',
            'que curso', 'interesado en curso', 'busco curso', 'cursos relacionados'
        ]
        return any(word in text_lower for word in keywords)

    @staticmethod
    def _detect_course_specific_query(message_text):
        """Detect specific course-related queries."""
        text_lower = (message_text or '').lower()

        if any(w in text_lower for w in ['temario', 'contenido', 'programa', 'syllabus']):
            return 'temario'
        # fechas / días / cuándo
        if any(w in text_lower for w in ['fecha', 'fechas', 'horarios', 'horario', 'día', 'dia', 'días', 'dias', 'cuando', 'cuándo', 'inicio', 'empieza', 'empiezan']):
            return 'fechas'
        if any(w in text_lower for w in ['precio', 'costo', 'cotización', 'cotizacion']):
            return 'precio'
        if any(w in text_lower for w in ['ubicación', 'ubicacion', 'dónde', 'donde', 'lugar', 'sede']):
            return 'ubicacion'

        # ML-based fallback: ask CourseManager to parse the query and infer intent
        try:
            parsed = CourseManager.parse_course_query(message_text)
            if parsed and isinstance(parsed, dict):
                # check keywords returned by ML parsing
                kws = [k.lower() for k in (parsed.get('keywords') or [])]
                if any(w in kws for w in ['temario', 'contenido', 'programa', 'syllabus']):
                    return 'temario'
                if any(w in kws for w in ['fecha', 'fechas', 'horario', 'horarios', 'cuando', 'inicio']):
                    return 'fechas'
                if any(w in kws for w in ['precio', 'costo', 'cotizacion', 'cotización']):
                    return 'precio'
                if any(w in kws for w in ['ubicación', 'ubicacion', 'donde', 'lugar', 'sede']):
                    return 'ubicacion'

                # If ML classified the message as courses/webinars, treat as general specific info
                raw = parsed.get('raw_classification') or parsed.get('raw_classification', {})
                cat = None
                if isinstance(raw, dict):
                    cat = raw.get('category')
                else:
                    cat = parsed.get('query_types') and parsed.get('query_types')[0]
                if cat in ['cursos', 'webinars']:
                    return 'specific_course_info'
        except Exception:
            pass

        return None

    @staticmethod
    def _extract_course_name_from_message(message_text):
        """Extract course name keywords from message."""
        text_lower = (message_text or '').lower()

        course_keywords = {
            1: ['cableado', 'estructurado', 'cobre'],
            2: ['fibra', 'externa', 'planta', 'wisp', 'isp'],
            3: ['fibra', 'ftth'],
            4: ['pon', 'lan', 'pasivas', 'enterprise', 'empresarial'],
            5: ['empalmes', 'otdr', 'mediciones']
        }

        for course_num, keywords in course_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                return course_num

        return None

    @staticmethod
    def _handle_course_switch_offer(phone, message_text, new_selection_intent, current_selection):
        """Handle when user mentions a different course than currently selected."""
        text_lower = (message_text or '').lower()

        # Check if user wants information about a different course without switching
        info_keywords = ['informacion', 'info', 'detalles', 'saber', 'sobre', 'que incluye', 'temario', 'precio', 'fechas', 'ubicacion', 'cual es']
        wants_info = any(keyword in text_lower for keyword in info_keywords)

        # Check for explicit info request
        if 'info' in text_lower or wants_info:
            # User wants info about a different course, provide it without switching
            return CourseConversationManager._handle_temporary_course_query(phone, message_text, new_selection_intent, current_selection)

        # Check for explicit change request
        change_keywords = ['cambiar', 'cambio', 'prefiero', 'mejor', 'en lugar', 'otro curso', 'cambiarme']
        wants_to_change = any(keyword in text_lower for keyword in change_keywords)

        if wants_to_change:
            # User explicitly wants to change — perform immediate switch
            return CourseConversationManager._handle_course_selection(phone, new_selection_intent)

        # If user explicitly referenced the new course by number or said "curso <n>", switch immediately
        try:
            explicit_num = CourseConversationManager._extract_course_number_from_message(message_text)
            if explicit_num and explicit_num == new_selection_intent.get('course_number'):
                return CourseConversationManager._handle_course_selection(phone, new_selection_intent)
        except Exception:
            pass

        # Default: offer options and save pending change
        if current_selection:
            old_course = current_selection.get('name', 'curso actual')
            new_course_name = (new_selection_intent.get('course', {}).get('title') or
                             new_selection_intent.get('course', {}).get('nombre') or
                             f"Curso {new_selection_intent.get('course_number')}")

            # Save the pending course change for later confirmation as a structured object
            pending_change = {
                'intent': new_selection_intent.get('intent'),
                'course_number': new_selection_intent.get('course_number'),
                'course': new_selection_intent.get('course'),
                'timestamp': datetime.now().isoformat()
            }
            # Store as a dict (if backend serializes, that's fine) to avoid fragile string parsing later
            try:
                save_conversation_memory(phone, 'pending_course_change', pending_change)
            except Exception:
                # Fallback to string if storage doesn't support objects
                save_conversation_memory(phone, 'pending_course_change', str(pending_change))

            response = f"Veo que tienes seleccionado '{old_course}', pero estás preguntando sobre '{new_course_name}'.\n\n"
            response += "¿Qué quieres hacer?\n\n"
            response += "• Escribe 'cambiar' para cambiar a este curso\n"
            response += "• Escribe 'info' para obtener información sin cambiar\n"
            response += "• Escribe 'continuar' para seguir con tu curso actual"
            return response
        else:
            # No current selection, proceed with selection
            return CourseConversationManager._handle_course_selection(phone, new_selection_intent)

    @staticmethod
    def _handle_temporary_course_query(phone, message_text, temp_selection_intent, current_selection):
        """Handle queries about courses other than the currently selected one."""
        text_lower = (message_text or '').lower()

        # Get the temporary course info
        if temp_selection_intent.get('intent') == 'select_by_number':
            course_num = temp_selection_intent['course_number']
            course = CourseManager.get_course_by_id(course_num)
            temp_course_name = course.get('title') or course.get('nombre', f'Curso {course_num}') if course else f'Curso {course_num}'
            temp_course_id = course_num
        else:
            course = temp_selection_intent.get('course', {})
            temp_course_name = course.get('title') or course.get('nombre', 'Curso')
            temp_course_id = course.get('id')

        # Handle specific queries about the temporary course
        if any(w in text_lower for w in ['temario', 'contenido', 'programa']):
            try:
                temario_msg = get_course_details_by_number(temp_course_id)
                # Split temario into logical blocks by double newline, fallback to 800-char chunks
                parts = [b.strip() for b in re.split(r"\n\n+", temario_msg) if b.strip()]
                if len(parts) <= 1:
                    text = temario_msg or ''
                    chunk_size = 800
                    parts = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)] if text else []

                # Add guidance to parts that are not the last
                for i in range(len(parts)-1):
                    if 'continuar' not in parts[i].lower() and 'responde' not in parts[i].lower():
                        parts[i] = parts[i].rstrip() + "\n\n[Responde 'continuar' para ver la siguiente parte.]"

                if parts:
                    send_message_parts(phone, parts, meta_key=f'pending_message_parts_course_{temp_course_id}')

                # Try to send the PDF as well (adapter or local assets)
                try:
                    sent_pdf = send_course_temario_pdf(phone, temp_course_id, temp_course_name)
                    if sent_pdf:
                        # If PDF sent, notify user in the short confirmation
                        confirmation = f"📚 Te envié el temario del curso '{temp_course_name}'. Lo estoy enviando en partes por texto y también envié el PDF si está disponible. Responde 'continuar' para ver más." 
                    else:
                        confirmation = f"📚 Te envié el temario del curso '{temp_course_name}' en partes por texto. Responde 'continuar' para ver la siguiente parte. Si quieres el PDF, escribe 'PDF' o 'enviar temario en PDF'."
                except Exception:
                    confirmation = f"📚 Te envié el temario del curso '{temp_course_name}' en partes por texto. Responde 'continuar' para ver la siguiente parte. Si quieres el PDF, escribe 'PDF' o 'enviar temario en PDF'."

                if current_selection:
                    confirmation += f"\n\n(Tu curso actual seleccionado es '{current_selection.get('name')}'. Si quieres cambiar, dime 'cambiar al curso {temp_course_name}')"

                return confirmation
            except Exception:
                return f"Información del temario para '{temp_course_name}' no disponible."

        elif any(w in text_lower for w in ['precio', 'costo']):
            price_msg = get_course_price_message(temp_course_id)
            response = f"💰 Precio del curso '{temp_course_name}':\n\n{price_msg}"
            if current_selection:
                response += f"\n\n(Tu curso actual es '{current_selection.get('name')}'.)"
            return response

        elif any(w in text_lower for w in ['fecha', 'fechas', 'horarios']):
            sched_msg = get_course_schedule_message(temp_course_id)
            response = f"📅 Fechas del curso '{temp_course_name}':\n\n{sched_msg}"
            if current_selection:
                response += f"\n\n(Tu curso actual es '{current_selection.get('name')}'.)"
            return response

        elif any(w in text_lower for w in ['ubicacion', 'ubicación', 'donde', 'lugar']):
            loc_msg = get_course_location_message(temp_course_id)
            response = f"📍 Ubicación del curso '{temp_course_name}':\n\n{loc_msg}"
            if current_selection:
                response += f"\n\n(Tu curso actual es '{current_selection.get('name')}'.)"
            return response

        # General info about the temporary course
        try:
            overview = CourseConversationManager._get_course_overview(course) if course else f"Curso {temp_course_id}"
            response = f"Información sobre '{temp_course_name}':\n\n{overview}"
            if current_selection:
                response += f"\n\nTu curso actualmente seleccionado es '{current_selection.get('name')}'. ¿Quieres cambiar a este curso?"
            return response
        except Exception:
            return f"Información sobre '{temp_course_name}' no disponible."

    @staticmethod
    def _get_course_overview(course):
        """Get a brief overview of a course."""
        try:
            from utils.courses_adapter import get_course_full_details_message
            details = get_course_full_details_message(course.get('id'))
            # Return first few lines as overview
            lines = details.split('\n')[:5]
            return '\n'.join(lines)
        except Exception:
            course_name = course.get('title') or course.get('nombre', 'Sin nombre')
            return f"🏆 {course_name}\n\nCurso especializado en tecnologías de fibra óptica y redes. Incluye teoría práctica y certificación reconocida."


# --- Helpers para obtener información de productos/webinars desde la base de datos ---
def find_db_item_by_keywords(keywords, collections=('webinars', 'products')):
    """Buscar en las colecciones dadas un documento que contenga alguna de las keywords

    Retorna el primer documento encontrado o None.
    """
    try:
        from data.db import get_collection
        # Normalize keywords to lower-case
        kws = [k.lower() for k in (keywords or []) if k]
        if not kws:
            return None

        # Build OR query to match keywords in title, name, description, keywords, tags or summary
        or_clauses = []
        for k in kws:
            # regex case-insensitive search in text fields
            or_clauses.extend([
                {'title': {'$regex': k, '$options': 'i'}},
                {'name': {'$regex': k, '$options': 'i'}},
                {'description': {'$regex': k, '$options': 'i'}},
                {'summary': {'$regex': k, '$options': 'i'}},
                {'keywords': {'$in': [k]}},
                {'tags': {'$in': [k]}}
            ])

        for col_name in collections:
            try:
                col = get_collection(col_name)
                # limit to 1 document to be fast
                doc = col.find_one({'$or': or_clauses})
                if doc:
                    return doc
            except Exception:
                # ignore DB errors per-call to avoid breaking webhook
                continue
    except Exception:
        # If DB module is not available or other error, return None
        return None
    return None


def send_db_or_fallback_message(phone, keywords, fallback_text, fallback_link=None, collections=('webinars','products')):
    """Intenta obtener información desde la DB y enviar; si no hay resultado, envía el fallback_text."""
    try:
        # Try DB first
        doc = find_db_item_by_keywords(keywords, collections=collections)
        if doc:
            title = doc.get('title') or doc.get('name') or doc.get('nombre') or ''
            description = doc.get('description') or doc.get('summary') or ''
            link = doc.get('link') or doc.get('url') or fallback_link or ''

            # If DB doc has no link, try local JSON fallback for a matching item
            if not link:
                try:
                    local = _search_local_json_for_keywords(keywords)
                    if local and local.get('link'):
                        link = local.get('link')
                except Exception:
                    pass

            parts = []
            if title:
                parts.append(f"**{title}**")
            if description:
                parts.append(description)
            if link:
                parts.append(f"Te comparto el enlace directo para que veas más: {link}")

            send_text_message(phone, "\n\n".join(parts) if parts else fallback_text)
            return True

        # Try local JSON as fallback
        try:
            local = _search_local_json_for_keywords(keywords)
            if local:
                parts = []
                title = local.get('title') or local.get('name') or ''
                desc = local.get('description') or local.get('summary') or ''
                link = local.get('link') or fallback_link or ''
                if title:
                    parts.append(f"**{title}**")
                if desc:
                    parts.append(desc)
                dates = local.get('fechas') or local.get('proximas_fechas')
                if dates:
                    try:
                        if isinstance(dates, list):
                            parts.append('Fechas: ' + ', '.join([str(d) for d in dates if d]))
                        else:
                            parts.append(f'Fechas: {dates}')
                    except Exception:
                        pass
                if link:
                    parts.append(f"Te comparto el enlace directo para que veas más: {link}")

                send_text_message(phone, "\n\n".join(parts) if parts else fallback_text)
                return True
        except Exception:
            pass

    except Exception:
        # ignore and fallback
        pass

    # Final fallback
    if fallback_link:
        send_text_message(phone, f"{fallback_text}\n\nTe comparto el enlace directo para que veas mas sobre los productos: {fallback_link}")
    else:
        send_text_message(phone, fallback_text)

    return False


def start_advisor_flow(phone, course_id=None):
    """Initialize the guided advisor form - Redirige a la función unificada."""
    try:
        logger.info(f"[ADVISOR_FLOW] Redirigiendo a start_advisor_simple para {phone}")
        # Guardar course_id si se proporciona
        if course_id:
            save_conversation_memory(phone, 'advisor_course_id', course_id)
        # Usar la función unificada
        return start_advisor_simple(phone)
    except Exception as e:
        logger.debug(f"start_advisor_flow error: {e}")
        return False


def _search_local_json_for_keywords(keywords):
    """Search local JSON files (webinars and courses) for any of the provided keywords.

    Returns the first matching entry as a dict or None.
    """
    try:
        import os, json
        api_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        candidates = [
            os.path.join(api_root, 'splitbot.webinars.json'),
            os.path.join(api_root, 'splitbot.courses.json')
        ]
        kws = [k.lower() for k in (keywords or []) if isinstance(k, str)]
        for fp in candidates:
            try:
                if not os.path.isfile(fp):
                    continue
                with open(fp, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for entry in data:
                    text_fields = []
                    for key in ('title','name','nombre','nombre_corto'):
                        v = entry.get(key)
                        if v and isinstance(v, str):
                            text_fields.append(v.lower())
                    # Also include topics/proximas_fechas
                    for key in ('topics','temario','proximas_fechas','fechas'):
                        v = entry.get(key)
                        if v:
                            if isinstance(v, list):
                                text_fields.extend([str(x).lower() for x in v if x])
                            elif isinstance(v, str):
                                text_fields.append(v.lower())

                    # Match any keyword in any of the text fields
                    for kw in kws:
                        for tf in text_fields:
                            if kw in tf:
                                return entry
            except Exception:
                continue
    except Exception:
        return None
    return None


# Importar helpers de memoria de conversación a nivel de módulo para evitar importaciones locales
from services.conversation_memory_utils import save_conversation_memory, get_conversation_memory

# --- COURSE REMOVAL HELPERS ---
# Provide local no-op wrappers so existing calls to save_selected_course/get_selected_course/clear_selected_course
# don't raise ImportError and the rest of the flow continues. These intentionally do minimal work.
def save_selected_course(phone, course_id, course_name, details=None):
    try:
        # Normalize course id to string to avoid type mismatches across different callers
        try:
            cid = str(course_id) if course_id is not None else None
        except Exception:
            cid = course_id
        save_conversation_memory(phone, 'selected_course', {'id': cid, 'name': course_name, 'details': details or {}})
    except Exception:
        pass

def get_selected_course(phone):
    try:
        return get_conversation_memory(phone, 'selected_course') or None
    except Exception:
        return None

def clear_selected_course(phone):
    try:
        # Remove the selected_course entry from conversation memory
        save_conversation_memory(phone, 'selected_course', None)
    except Exception:
        pass


def log_webhook_event(event_type: str, details: Dict[str, Any], level: str = "info") -> None:
    """
    Registrar información detallada sobre eventos del webhook de manera estructurada.
    
    Args:
        event_type: Tipo de evento (mensaje, status, error, etc.)
        details: Detalles específicos del evento
        level: Nivel de log (info, warning, error)
    """
    log_data = {
        "event_type": event_type,
        "timestamp": datetime.now().isoformat(),
        "details": details
    }
    
    # Limitar la longitud de los datos para evitar logs demasiado grandes
    log_message = json.dumps(log_data, default=str)[:500]
    
    if level == "warning":
        logger.warning(f"WEBHOOK_EVENT: {log_message}")
    elif level == "error":
        logger.error(f"WEBHOOK_EVENT: {log_message}")
    else:
        logger.info(f"WEBHOOK_EVENT: {log_message}")

# Crear blueprint para rutas de WhatsApp
whatsapp_bp = Blueprint('whatsapp', __name__)

# Runtime guard to avoid duplicate sends for the same incoming webhook message
# _CURRENT_WEBHOOK_MESSAGE_ID is set while processing a single incoming message
# _SENT_RESPONSES stores message_ids for which we've already sent a reply in this process
_CURRENT_WEBHOOK_MESSAGE_ID = None
_SENT_RESPONSES = set()


def send_text_message(to, text):
    """Envía un mensaje de texto a través de WhatsApp API"""
    # Prevent duplicate replies for the same incoming webhook message
    try:
        current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
        if current_id and current_id in globals().get('_SENT_RESPONSES', set()):
            logger.info(f"Skipping duplicate send for incoming message {current_id}")
            return None
    except Exception:
        pass
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.error("Credenciales de WhatsApp no configuradas")
        return None
        
    # Check for empty or None text
    if not text:
        logger.warning(f"Attempted to send empty message to {to}")
        return None
    # If the user is currently in the advisor data-collection flow, strip any leading greetings
    try:
        from services.conversation_memory_utils import get_conversation_memory
        waiting_flag = bool(get_conversation_memory(to, 'waiting_for_advisor_data'))
    except Exception:
        waiting_flag = False

    if waiting_flag:
        # Remove common greeting prefixes such as "¡Hola!", "¡Hola, Nombre!" or "Hola Nombre," at the start
        try:
            # remove emoji greeting first
            text = re.sub(r'^\s*¡Hola!\s*👋\s*', '', text, flags=re.IGNORECASE)
            # generic Hola patterns (Hola, Hola Nombre, ¡Hola Nombre! etc.)
            text = re.sub(r"^\s*(?:¡?Hola[!,\.]?\s*(?:[A-Za-zÁÉÍÓÚáéíóúñÑ0-9_\-]{1,40})[!,\.]?\s*)", '', text, flags=re.IGNORECASE)
            # If message becomes empty after stripping greeting, skip sending (avoid greeting-only replies)
            if not text or not text.strip():
                logger.info(f"Omitting greeting-only reply to {to} while collecting advisor data")
                return None
        except Exception:
            # If regex fails for any reason, fall back to original text
            pass
    # Additionally, strip common auto-greeting prefixes from outgoing messages to avoid
    # sending repeated salutations like "¡Hola! Un placer ayudarte nuevamente." on every reply.
    try:
        import re

        def _strip_outgoing_greeting(s: str) -> str:
            if not s:
                return s
            txt = s.lstrip()
            # Patterns that indicate an auto-greeting at the start
            if re.match(r'^(?:¡?Hola\b|Hola de nuevo\b|Hola nuevamente\b|¡?Bienvenido\b|¡?Bienvenida\b)', txt, flags=re.IGNORECASE):
                # Find a natural break: double newline, single newline, or end of first sentence
                separators = ['\n\n', '\n', '. ', '! ', '? ']
                for sep in separators:
                    idx = txt.find(sep)
                    if idx != -1 and idx < 200:
                        # remove the greeting prefix including the separator
                        return txt[idx + len(sep):].lstrip()
                # If no separator found but the greeting is short (<120 chars), remove whole first 120 chars
                if len(txt) <= 200:
                    # Heuristic: if the whole text seems like a greeting-only message, return empty
                    # or if it's short, drop the leading sentence up to 120 chars
                    return ''.join(txt.splitlines()[1:]).lstrip() if '\n' in txt else ''
            return s

        cleaned_text = _strip_outgoing_greeting(text)
        if cleaned_text != text:
            logger.info(f"Stripped outgoing greeting prefix for recipient {to}")
            text = cleaned_text
    except Exception:
        # If anything fails, keep original text
        pass
        
    # WhatsApp has a message length limit (~4,000 characters)
    MAX_MESSAGE_LENGTH = 4000
    
    if len(text) <= MAX_MESSAGE_LENGTH:
        # Mensaje normal, enviar directamente
        result = _send_single_text_message(to, text)
        if result:
            try:
                # Mark that we've sent a response for this incoming message id (if present)
                current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
                if current_id:
                    globals().setdefault('_SENT_RESPONSES', set()).add(current_id)
            except Exception:
                pass
            logger.info(f"Respuesta enviada exitosamente a {to}")
            return result
        else:
            logger.error(f"FALLÓ el envío del mensaje a {to}")
            return None
    else:
        # Mensaje largo: truncar para enviar solo UN mensaje y ofrecer continuar.
        logger.info(f"Mensaje largo detectado ({len(text)} chars), truncando para un solo envío...")
        truncated = text[:MAX_MESSAGE_LENGTH - 200].rstrip()
        truncated += "\n\n[Mensaje resumido — responde 'continuar' para que amplíe esta respuesta.]"
        result = _send_single_text_message(to, truncated)
        if result:
            try:
                current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
                if current_id:
                    globals().setdefault('_SENT_RESPONSES', set()).add(current_id)
            except Exception:
                pass
            logger.info(f"Mensaje largo truncado enviado a {to} (un solo envío)")
            return result
        else:
            logger.error(f"FALLÓ el envío del mensaje truncado a {to}")
            return None


def _send_single_text_message(to, text, max_retries=3):
    """Envía un único mensaje de texto a través de WhatsApp API con reintentos"""
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.error("Credenciales de WhatsApp no configuradas")
        return None

    # Validar formato del número mexicano
    if not isinstance(to, str) or not to.startswith('521') or len(to) != 13:
        logger.error(f"Formato de número inválido: {to}. Debe ser '521XXXXXXXXXX'")
        return None

    # Check for empty or None text
    if not text or not text.strip():
        logger.warning(f"Attempted to send empty message to {f'PHONE_XXXXX{str(to)[-4:]}'}")
        return None

    url = f"{WHATSAPP_API_BASE}{WHATSAPP_PHONE_NUMBER_ID}/messages"

    headers = {
        'Authorization': f'Bearer {WHATSAPP_TOKEN}',
        'Content-Type': 'application/json'
    }

    # Payload corregido para WhatsApp Business API México
    payload = {
        'messaging_product': 'whatsapp',
        'recipient_type': 'individual',
        'to': to,
        'type': 'text',
        'text': {
            'preview_url': False,
            'body': text.strip()
        }
    }

    # Lógica de reintentos: intentar hasta max_retries veces
    import time
    for attempt in range(1, max_retries + 1):
        try:
            import requests
            logger.info(f"Sending WhatsApp message to {f'PHONE_XXXXX{str(to)[-4:]}'} (Intento {attempt}/{max_retries})")
            if attempt == 1:
                logger.debug(f"Payload completo: {payload}")
                logger.debug(f"Headers (sin token): {{'Authorization': 'Bearer ***', 'Content-Type': 'application/json'}}")

            response = requests.post(url, json=payload, headers=headers, timeout=30)
            
            logger.info(f"Status Code recibido: {response.status_code} (Intento {attempt})")
            if attempt == 1:
                logger.debug(f"Respuesta completa: {response.text}")

            if response.status_code == 200:
                response_data = response.json()
                message_id = response_data.get('messages', [{}])[0].get('id', 'unknown')
                logger.info(f"✅ Mensaje enviado exitosamente en intento {attempt}. ID: {message_id}")
                return message_id
            else:
                logger.error(f"❌ Error HTTP {response.status_code} en intento {attempt}")
                if attempt == 1:  # Solo mostrar detalles completos en el primer intento
                    logger.error(f"Respuesta del servidor: {response.text}")
                    logger.error(f"URL utilizada: {url}")
                    
                    # Intentar parsear el error JSON de WhatsApp
                    try:
                        error_data = response.json()
                        if 'error' in error_data:
                            error_detail = error_data['error']
                            logger.error(f"Detalle del error: {error_detail.get('message', 'Sin detalle')}")
                            logger.error(f"Código de error: {error_detail.get('code', 'Sin código')}")
                            logger.error(f"Tipo de error: {error_detail.get('type', 'Sin tipo')}")
                    except:
                        logger.error("No se pudo parsear la respuesta de error como JSON")
                
                # Si no es el último intento, esperar antes de reintentar
                if attempt < max_retries:
                    wait_time = attempt * 2  # Espera progresiva: 2s, 4s, 6s
                    logger.info(f"⏳ Esperando {wait_time}s antes del siguiente intento...")
                    time.sleep(wait_time)

        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Error de conexión en intento {attempt}: {str(e)}")
            if attempt < max_retries:
                wait_time = attempt * 2
                logger.info(f"⏳ Esperando {wait_time}s antes del siguiente intento...")
                time.sleep(wait_time)
        except Exception as e:
            logger.error(f"❌ Error inesperado en intento {attempt}: {str(e)}")
            if attempt < max_retries:
                wait_time = attempt * 2
                logger.info(f"⏳ Esperando {wait_time}s antes del siguiente intento...")
                time.sleep(wait_time)

    # Si llegamos aquí, todos los intentos fallaron
    logger.error(f"💥 TODOS LOS INTENTOS FALLARON para {f'PHONE_XXXXX{str(to)[-4:]}'} después de {max_retries} intentos")
    return None


def _upload_media(file_path: str) -> Optional[str]:
    """Upload a file to WhatsApp media endpoint and return media_id if successful."""
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.warning('_upload_media: WhatsApp credentials not configured; skipping upload')
        return None

    # Endpoint: /{phone-number-id}/media
    url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/media")
    headers = {'Authorization': f'Bearer {WHATSAPP_TOKEN}'}

    try:
        import os
        import mimetypes
        # Determinar el tipo MIME basado en la extensión del archivo
        file_name = os.path.basename(file_path)
        mime_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'
        
        # Para PDFs asegurar que usamos application/pdf
        if file_path.lower().endswith('.pdf'):
            mime_type = 'application/pdf'
            
        logger.info(f"Subiendo archivo {file_name} con tipo MIME {mime_type}")
        
        with open(file_path, 'rb') as f:
            files = {
                'file': (file_name, f, mime_type)
            }
            # Some Graph API media endpoints require the 'messaging_product' form field
            resp = requests.post(url, files=files, data={'messaging_product': 'whatsapp'}, headers=headers, timeout=30)
            # Log response body on failure to aid debugging
            if resp.status_code // 100 != 2:
                try:
                    logger.error(f"Upload response ({resp.status_code}): {resp.text}")
                except Exception:
                    logger.error(f"Upload response status: {resp.status_code} (could not read body)")
            resp.raise_for_status()
            data = resp.json()
            media_id = data.get('id') or data.get('media', {}).get('id')
            logger.info(f'Uploaded media {file_path}, received media_id={media_id}')
            return media_id
    except Exception as e:
        import traceback
        logger.error(f"Failed to upload media {file_path}: {str(e)}")
        logger.error(traceback.format_exc())
        return None


def send_document_message(to: str, file_path: str, caption: str = None) -> Optional[dict]:
    """Send a document message (PDF) to a WhatsApp user by uploading media and sending a document message."""
    # Prefer using the local utils.whatsapp helpers if present. That module
    # supports sending by public link or simulation (WHATSAPP_DIRECT_SEND) and
    # avoids uploading to Graph when possible.
    try:
        from utils import whatsapp as whatsapp_utils
    except Exception:
        whatsapp_utils = None

    # If the path looks like a URL, send as a document.link (no upload needed)
    try:
        if isinstance(file_path, str) and file_path.lower().startswith(('http://', 'https://')):
            # If utils.whatsapp provides a direct send helper, prefer it
            if whatsapp_utils and hasattr(whatsapp_utils, 'send_document_to_phone'):
                try:
                    res = whatsapp_utils.send_document_to_phone(to, file_path, caption=caption)
                    if res:
                        return res
                except Exception:
                    logger.debug('whatsapp_utils.send_document_to_phone failed for URL, falling back')

            # Fallback to Graph API send-by-link using configured credentials
            if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
                logger.warning('send_document_message: no WhatsApp credentials to send link')
                return None
            url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/messages")
            payload = {
                'messaging_product': 'whatsapp',
                'to': to,
                'type': 'document',
                'document': {'link': file_path, 'caption': caption or ''}
            }
            headers = {'Authorization': f'Bearer {WHATSAPP_TOKEN}', 'Content-Type': 'application/json'}
            try:
                resp = requests.post(url, json=payload, headers=headers, timeout=10)
                resp.raise_for_status()
                return resp.json()
            except Exception as e:
                logger.error(f'Error sending document by link: {e}')
                return None

        # If it's a local file path, prefer whatsapp_utils.send_document_to_phone which
        # knows how to simulate or send via media_base without uploading.
        import os
        if os.path.exists(file_path):
            if whatsapp_utils and hasattr(whatsapp_utils, 'send_document_to_phone'):
                try:
                    res = whatsapp_utils.send_document_to_phone(to, file_path, caption=caption)
                    if res:
                        return res
                except Exception as e:
                    logger.debug(f'whatsapp_utils.send_document_to_phone failed: {e}')

            # If whatsapp_utils not available or failed, fall back to old upload flow
            if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
                logger.warning('send_document_message: WhatsApp credentials not configured; skipping send')
                return None

            media_id = _upload_media(file_path)
            if not media_id:
                logger.error('send_document_message: upload failed, cannot send document')
                return None

            url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/messages")
            payload = {
                'messaging_product': 'whatsapp',
                'to': to,
                'type': 'document',
                'document': {'id': media_id, 'caption': caption or ''}
            }
            headers = {'Authorization': f'Bearer {WHATSAPP_TOKEN}', 'Content-Type': 'application/json'}
            try:
                logger.info(f'Enviando documento con media_id={media_id} a {to}')
                resp = requests.post(url, json=payload, headers=headers, timeout=10)
                resp.raise_for_status()
                logger.info(f'Document sent to {to}, media_id={media_id}')
                return resp.json()
            except Exception as e:
                import traceback
                logger.error(f'Error sending document message: {str(e)}')
                logger.error(traceback.format_exc())
                return None

        # If file doesn't exist and isn't a URL
        logger.error(f'send_document_message: file does not exist or is not a URL: {file_path}')
        return None
    except Exception as e:
        logger.error(f'send_document_message: unexpected error: {e}', exc_info=True)
        return None
        return None


@whatsapp_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verifica el webhook para WhatsApp API"""
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    logger.info(f"Verificación de webhook: mode={mode}, token={token != None}")
    
    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook verificado exitosamente")
        return challenge, 200
    
    logger.warning("Verificación de webhook fallida")
    return 'Forbidden', 403


@whatsapp_bp.route('/debug-webhook', methods=['POST'])
def debug_webhook():
    """Endpoint mínimo para depurar entregas desde Meta/ngrok. Persiste cuerpo y headers y devuelve 200."""
    try:
        import os
        raw_body = request.get_data(as_text=True)
        headers = dict(request.headers)
        remote_addr = request.remote_addr or 'unknown'
        log_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs'))
        os.makedirs(log_dir, exist_ok=True)
        debug_log = os.path.join(log_dir, 'debug_webhook.log')
        with open(debug_log, 'a', encoding='utf-8') as f:
            f.write(f"\n=== DEBUG WEBHOOK {datetime.utcnow().isoformat()} ===\n")
            f.write(f"REMOTE_ADDR: {remote_addr}\n")
            f.write(f"HEADERS: {json.dumps(headers)}\n")
            f.write(f"RAW_BODY: {raw_body}\n")
            f.write("=== END DEBUG WEBHOOK ===\n")

        # Also return a minimal JSON so Meta sees 200
        return jsonify({"status": "ok", "message": "debug received"}), 200
    except Exception as e:
        logger.error(f"Error en debug_webhook: {e}")
        return jsonify({"status": "error"}), 500



# Ejemplo de integración ML-first en el webhook handler
def webhook_handler_ml_example(phone, message_text, conversation_history):
    """
    Ejemplo de cómo integrar las funciones ML-first en el webhook handler principal.
    Este código debe integrarse en el webhook handler real (típicamente en respuesta.py)
    
    Args:
        phone: número de teléfono del cliente
        message_text: texto del mensaje del usuario
        conversation_history: historial de conversación
    """
    try:
        # 2. Clasificar con ML-first
        intent_classification = classify_user_intent_ml(message_text, phone, conversation_history)
        user_intent_type = intent_classification['type']  
        intent_confidence = intent_classification['confidence']
        ml_details = intent_classification['details']

        logger.info(f"🤖 ML Classification: {user_intent_type} (confidence: {intent_confidence:.2f})")

        # 3. Actualizar contexto de conversación con información ML
        ml_result = ml_details.get('full_ml_result', {})
        update_conversation_context(phone, ml_result, user_intent_type)

        # 4. Generar prompt contextual basado en ML
        contextual_prompt = generate_contextual_system_prompt(ml_result, user_intent_type, message_text)

        # 5. Generar respuesta con contexto enriquecido
        respuesta = enhanced_chat_with_context(phone, message_text, contextual_prompt)

        # 6. Manejar acciones específicas basadas en ML
        client_data = ml_result.get('client_data', {})
        lead_prediction = ml_result.get('lead_prediction', {})

        # Si es lead caliente con datos completos, generar PDF para asesor
        if (lead_prediction.get('lead_type') == 'caliente' and 
            client_data.get('nombre') and (client_data.get('correo') or client_data.get('empresa'))):
            try:
                pdf_path = ml_service.generate_client_pdf(client_data, ml_result.get('classification', {}))
                logger.info(f"🔥 PDF generado para lead caliente: {pdf_path}")
            except Exception as e:
                logger.error(f"Error generando PDF: {e}")

        # Si requiere atención humana, marcar para seguimiento
        if ml_result.get('requires_human_attention'):
            save_conversation_memory(phone, 'needs_human_followup', True)
            logger.warning(f"⚠️ Cliente {phone} requiere atención humana")

        # 7. Post-procesar y enviar respuesta
        try:
            # If ML says it's a technical intent, remove any course mentions from the technical reply
            if user_intent_type in ('soporte_tecnico', 'soporte', 'technical', 'technical_question'):
                cleaned = strip_course_mentions_from_text(respuesta)
                # If cleaning removed too much, fallback to original
                if not cleaned or len(cleaned) < 20:
                    cleaned = respuesta
                # Try to append course suggestions (non-invasive)
                try:
                    from routes.course_handlers import CourseManager
                    from utils.courses_adapter import compose_course_suggestion_via_ai
                    keywords = [w for w in re.findall(r"\w+", message_text.lower()) if len(w) > 3][:6]
                    candidates = CourseManager.search_courses_by_keywords(keywords, limit=2)
                    suggestions = []
                    for c in candidates:
                        try:
                            suggestions.append(compose_course_suggestion_via_ai(c, user_query=message_text, phone=phone))
                        except Exception:
                            try:
                                suggestions.append(format_course_for_whatsapp(c))
                            except Exception:
                                pass
                    if suggestions:
                        cleaned = cleaned.strip() + "\n\nSi te interesa, también puedo recomendar estos cursos relacionados:\n\n" + "\n\n".join(suggestions)
                except Exception:
                    # ignore suggestion errors
                    pass
                send_text_message(phone, cleaned)
                return cleaned
            else:
                send_text_message(phone, respuesta)
                return respuesta
        except Exception:
            # Fallback send
            send_text_message(phone, respuesta)
            return respuesta
        
    except Exception as e:
        logger.error(f"Error en webhook_handler_ml_example: {e}")
        return "Disculpa, hubo un error procesando tu mensaje. ¿Podrías intentar de nuevo?"

# ============================================================================
# 🤖 FUNCIONES ML-FIRST PARA WEBHOOK HANDLER
# ============================================================================

def classify_user_intent_ml(message_text, phone=None, conversation_history=None):
    """
    Clasificación centrada en ML que usa ml_service para entender la intención real del usuario.
    Enriquece con DB si la confianza es baja y mantiene contexto de conversación.
    """
    import re
    try:
        if not message_text:
            return {'type': 'general', 'confidence': 0.5, 'details': 'Mensaje vacío'}

        # Procesar con ML Service - incluye clasificación, extracción de datos y predicción de leads
        ml_result = ml_service.process_message(message_text, conversation_history or [], phone=phone)
        
        classification = ml_result.get('classification', {})
        client_data = ml_result.get('client_data', {})
        lead_prediction = ml_result.get('lead_prediction', {})
        
        # Mapear categorías ML a intenciones del flujo
        mapping = {
            'soporte_tecnico': 'tecnica',
            'ventas': 'productos', 
            'cotizacion': 'productos',
            'precios': 'productos',
            'pagos': 'productos',
            'quejas': 'general',
            'contacto_asesor': 'asesoria',
            'info_general': 'general',
            'cursos': 'cursos',
            'webinars': 'webinars'
        }
        
        intent_type = mapping.get(classification.get('category'), 'general')
        confidence = float(classification.get('confidence', 0.0))

        # Post-processing adjustments to reduce false positives for 'cursos'
        try:
            msg_lower = (message_text or '').lower()
            tech_priority_phrases = ['problema', 'error', 'falla', 'otdr', 'empalme', 'empalmes', 'fusion', 'fusión', 'pérdida', 'pérdidas', 'atenuación', 'atenuacion', 'medición', 'medicion', 'cómo', 'como', 'qué es', 'que es', 'para qué sirve', 'para que sirve']
            has_tech_priority = any(p in msg_lower for p in tech_priority_phrases)

            course_keywords = ['curso', 'cursos', 'temario', 'inscripción', 'inscripcion', 'fechas', 'precio', 'costo', 'cotizar']
            has_course_keyword = any(k in msg_lower for k in course_keywords)
            user_mentions_also = ('tambien' in msg_lower) or ('también' in msg_lower) or ('además' in msg_lower)

            # If ML indicates 'cursos' but there are clear technical indicators and the ML confidence is not very strong, prefer technical
            if intent_type == 'cursos' and has_tech_priority and not user_mentions_also and confidence < 0.70:
                intent_type = 'tecnica'
                confidence = max(confidence, 0.85)

            # If ML says 'general' but strong technical indicators exist, prefer 'tecnica'
            if intent_type == 'general' and has_tech_priority:
                intent_type = 'tecnica'
                confidence = max(confidence, 0.75)

            # If user explicitly asked to recommend a course, keep 'cursos'
            recommend_phrases = ['qué curso', 'que curso', 'curso recomiendan', 'qué curso recomiendan', 'recomiendan curso', 'qué curso recomiendas', 'recomiendan para', 'que me recomiendas']
            if any(p in msg_lower for p in recommend_phrases) and has_course_keyword:
                intent_type = 'cursos'
                confidence = max(confidence, 0.85)
        except Exception:
            pass
        
        details = {
            'ml_raw': classification,
            'client_data': client_data,
            'lead_prediction': lead_prediction,
            'full_ml_result': ml_result
        }

        # Si confianza baja, enriquecer con búsqueda en DB
        if confidence < 0.65:
            # Extraer keywords de entidades ML y mensaje
            keywords = []
            
            # Keywords de datos extraídos del cliente
            for field_value in client_data.values():
                if isinstance(field_value, str) and len(field_value) > 2:
                    words = re.findall(r'\w{3,}', field_value.lower())
                    keywords.extend([w for w in words if w not in keywords])
            
            # Keywords del mensaje
            msg_words = re.findall(r'\w{3,}', (message_text or '').lower())
            keywords.extend([w for w in msg_words if w not in keywords])

            if keywords:
                try:
                    # Buscar en DB para enriquecer clasificación
                    doc = find_db_item_by_keywords(keywords, collections=('webinars', 'products', 'courses'))
                    if doc:
                        details['db_enrichment'] = {
                            'title': doc.get('title') or doc.get('name'),
                            'id': doc.get('_id') or doc.get('id'),
                            'collection': doc.get('_collection') or doc.get('collection')
                        }
                        
                        # Ajustar intención basado en DB match
                        title_lower = (doc.get('title') or '').lower()
                        tags = [t.lower() for t in (doc.get('tags') or [])]
                        
                        if 'curso' in title_lower or 'curso' in tags:
                            intent_type = 'cursos'
                        elif 'webinar' in title_lower or 'webinar' in tags:
                            intent_type = 'webinars'
                        elif doc.get('_collection') == 'products':
                            intent_type = 'productos'
                            
                        confidence = max(confidence, 0.7)  # Aumentar confianza con DB match
                        
                except Exception as e:
                    logger.debug(f"Error en enriquecimiento DB: {e}")

        # Priorizar leads calientes
        if lead_prediction.get('lead_type') == 'caliente':
            details['priority'] = 'hot_lead'
            confidence = max(confidence, 0.75)
            if intent_type == 'general':
                intent_type = 'productos'  # Leads calientes probablemente buscan productos

        # Persistir resultado de clasificación ML para análisis posterior
        try:
            from data.db import get_collection
            ml_col = get_collection('ml_classifications')
            ml_entry = {
                'phone': phone,
                'message': message_text,
                'mapped_intent': intent_type,
                'confidence': float(confidence),
                'ml_raw': classification,
                'timestamp': datetime.utcnow().isoformat()
            }
            if ml_col is not None:
                try:
                    ml_col.insert_one(ml_entry)
                except Exception:
                    logger.debug('No se pudo insertar en la colección ml_classifications')

            # También agregar a la conversación del usuario para histórico
            conv_col = get_collection('conversaciones')
            if conv_col is not None and phone:
                try:
                    conv_col.update_one({'phone': phone}, {'$push': {'ml_history': ml_entry}}, upsert=True)
                except Exception:
                    logger.debug('No se pudo actualizar conversaciones.ml_history')
        except Exception as _persist_err:
            logger.debug(f"Error persisting ML classification: {_persist_err}")

        return {
            'type': intent_type,
            'confidence': confidence,
            'details': details
        }
        
    except Exception as e:
        logger.error(f"Error en classify_user_intent_ml: {e}", exc_info=True)
        return {'type': 'general', 'confidence': 0.4, 'details': {'error': str(e)}}


def generate_contextual_system_prompt(ml_result, intent_type, message_text):
    """
    Genera system prompts contextuales basados en los resultados del ML
    """
    client_data = ml_result.get('client_data', {})
    lead_prediction = ml_result.get('lead_prediction', {})
    classification = ml_result.get('classification', {})
    
    # Base prompt según intención
    base_prompts = {
        'tecnica': """Eres un EXPERTO TÉCNICO en fibra óptica y telecomunicaciones.
RESPONDE con información técnica precisa, procedimientos paso a paso y recomendaciones específicas.
ENFÓCATE en resolver el problema técnico actual del usuario.""",
        
        'productos': """Eres un ESPECIALISTA EN PRODUCTOS de fibra óptica.
PROPORCIONA especificaciones técnicas detalladas, aplicaciones y ventajas.
SOLICITA información específica para cotización cuando sea apropiado.""",
        
        'cursos': """Eres un CONSULTOR EDUCATIVO especializado en cursos de fibra óptica.
PROPORCIONA información completa de fechas, precios, temarios y modalidades.
RECOMIENDA el curso más adecuado según las necesidades del usuario.""",
        
        'webinars': """Eres un COORDINADOR DE WEBINARS especializando en formación online.
INFORMA sobre webinars gratuitos disponibles cada martes.
PROPORCIONA detalles de inscripción y temarios específicos.""",
        
        'asesoria': """Eres un COORDINADOR DE ASESORÍAS.
RECOPILA información de contacto y detalles del proyecto.
CONECTA al usuario con un asesor especializado."""
    }
    
    prompt = base_prompts.get(intent_type, base_prompts.get('tecnica', ''))
    
    if client_data:
        context_parts = []
        
        if client_data.get('nombre'):
            context_parts.append(f"Cliente: {client_data['nombre']}")
        
        if client_data.get('empresa'):
            context_parts.append(f"Empresa: {client_data['empresa']}")
            
        
        if context_parts:
            prompt += f"\n\nCONTEXTO DEL CLIENTE:\n" + "\n".join(context_parts)
    
    if lead_prediction.get('lead_type') == 'caliente':
        prompt += f"\n\nPRIORIDAD ALTA: Este es un LEAD CALIENTE (confianza: {lead_prediction.get('confidence', 0):.1f}). Prioriza información de productos, precios y contacto con asesor."
    
    confidence = classification.get('confidence', 0)
    if confidence < 0.6:
        prompt += f"\n\nNOTA: Clasificación con confianza media ({confidence:.1f}). Verifica la intención del usuario y pregunta si necesitas aclaración."
    
    return prompt


def update_conversation_context(phone, ml_result, intent_type):
    """
    Actualiza el contexto de conversación con información ML
    """
    try:
        from services.conversation_memory import ConversationMemory
        client_data = ml_result.get('client_data', {})
        lead_prediction = ml_result.get('lead_prediction', {})
        
        # Guardar datos del cliente extraídos
        for field, value in client_data.items():
            if value and len(str(value).strip()) > 2:
                ConversationMemory.add_entity_to_memory(phone, f'client_{field}', value)
        
        # Guardar contexto de intención
        ConversationMemory.add_entity_to_memory(phone, 'last_intent', intent_type)
        ConversationMemory.add_entity_to_memory(phone, 'last_intent_confidence', ml_result.get('classification', {}).get('confidence', 0))
        
        # Guardar información de lead
        if lead_prediction.get('lead_type') in ['caliente', 'frío']:
            ConversationMemory.add_entity_to_memory(phone, 'lead_type', lead_prediction['lead_type'])
            ConversationMemory.add_entity_to_memory(phone, 'lead_confidence', lead_prediction['confidence'])
        
        # Marcar si requiere atención humana
        if ml_result.get('requires_human_attention'):
            ConversationMemory.add_entity_to_memory(phone, 'requires_human_attention', True)
            
    except Exception as e:
        logger.error(f"Error actualizando contexto: {e}")


def enhanced_chat_with_context(phone, message, system_prompt):
    """
    Chat con contexto enriquecido del ML y conversaciones previas
    """
    try:
        from services.conversation_memory import ConversationMemory
        from services.chat_ai import chat_with_gemini
        
        # Recuperar contexto previo
        context_parts = []
        memory = ConversationMemory.get_client_memory(phone)
        entities = memory.get('entities', {})
        
        # Información del cliente extraída
        client_name = entities.get('client_nombre')
        client_company = entities.get('client_empresa')
        
        if client_name:
            context_parts.append(f"Cliente: {client_name}")
        if client_company:
            context_parts.append(f"Empresa: {client_company}")
        
        
        # Intención previa
        last_intent = entities.get('last_intent')
        if last_intent:
            context_parts.append(f"Contexto previo: {last_intent}")
        
        # Tipo de lead
        lead_type = entities.get('lead_type')
        if lead_type == 'caliente':
            context_parts.append("🔥 LEAD CALIENTE - Priorizar productos/cotización")
        
        # Enriquecer system prompt con contexto
        if context_parts:
            enhanced_prompt = system_prompt + f"\n\nCONTEXTO HISTÓRICO:\n" + "\n".join(context_parts)
        else:
            enhanced_prompt = system_prompt
        
        return chat_with_gemini(phone, message, enhanced_prompt)
        
    except Exception as e:
        logger.error(f"Error en enhanced_chat_with_context: {e}")
        # Fallback a chat normal
        from services.chat_ai import chat_with_gemini
        return chat_with_gemini(phone, message, system_prompt)


def webhook_handler():
    """Maneja mensajes entrantes de WhatsApp utilizando el sistema de memoria de conversación y ML"""
    try:
        # Persistir el cuerpo bruto del webhook inmediatamente para capturar cualquier entrega
        # incluso si no se puede parsear como JSON (esto ayuda a depurar entregas reales desde Meta/ngrok)
        try:
            import os
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== RAW WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END RAW WEBHOOK ===\n")
            logger.debug("Raw webhook persisted to logs/webhook_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST recibido")
        # Definir indicador técnico por defecto lo antes posible para evitar UnboundLocalError
        is_technical_question = False
        
        # Registrar información estructurada del webhook para depuración avanzada
        try:
            # Analizar el payload para determinar su tipo
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)
            
            # Registrar evento de forma estructurada
            log_webhook_event(
                event_type="webhook_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
            
            # Registrar una versión sanitizada del payload (sin información sensible)
            # Omitir información potencialmente sensible - HACER COPIA PROFUNDA
            import copy
            sanitized_payload = {}
            if isinstance(payload, dict):
                sanitized_payload = copy.deepcopy(payload)  # Copia profunda para no afectar el original
                # Ocultar números de teléfono completos SOLO en la copia
                if 'entry' in sanitized_payload and isinstance(sanitized_payload['entry'], list):
                    for entry in sanitized_payload['entry']:
                        if 'changes' in entry and isinstance(entry['changes'], list):
                            for change in entry['changes']:
                                if 'value' in change and isinstance(change['value'], dict):
                                    value = change['value']
                                    # Sanitizar mensajes SOLO en la copia
                                    if 'messages' in value and isinstance(value['messages'], list):
                                        for msg in value['messages']:
                                            if 'from' in msg:
                                                msg['from'] = f"PHONE_XXXXX{str(msg['from'])[-4:]}"
            
            logger.debug(f"Payload sanitizado: {json.dumps(sanitized_payload, default=str)[:1000]}")
        except Exception as e:
            logger.error(f"Error al procesar información de webhook: {e}")
            logger.error(traceback.format_exc())
        
        if not payload:
            logger.warning("Payload vacío recibido")
            return jsonify({"status": "error", "message": "Payload vacío"}), 400
        
        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload")
            return jsonify({"status": "ok"}), 200  # No es un error, podría ser otro tipo de notificación
        
        # Importaciones necesarias para el procesamiento de ML
        from services.chat_ai import query_mongodb, chat_with_gemini
        from utils.ml_adapter import process_message
        from services.conversation_memory import get_conversation_history, clear_topic_context, ConversationMemory, save_selected_course, get_selected_course
        
        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                
                # LOG: Inicio de procesamiento del payload
                logger.info("📨 Iniciando procesamiento de payload WhatsApp")
                
                # Clasificar y procesar correctamente según el tipo de evento de WhatsApp
                # Identificar el tipo de payload basado en su estructura
                payload_type = "unknown"
                if 'statuses' in value and not 'messages' in value:
                    payload_type = "status_update"
                elif 'messages' in value:
                    payload_type = "message"
                elif 'errors' in value:
                    payload_type = "error"
                elif 'metadata' in value:
                    payload_type = "metadata"                # Registrar el tipo de evento para monitoreo
                logger.info(f"Evento de WhatsApp detectado: {payload_type}")
                
                # Manejar cada tipo de evento adecuadamente
                if payload_type == "status_update":
                    # Procesar notificaciones de estado sin generar respuestas
                    logger.info("Recibida notificación de estado, procesando sin respuesta")
                    statuses = value.get('statuses', [])
                    for status in statuses:
                        status_id = status.get('id')
                        status_status = status.get('status')  # sent, delivered, read, failed
                        recipient_id = status.get('recipient_id')
                        logger.info(f"Status de mensaje: ID={status_id}, Status={status_status}, Recipient={recipient_id}")
                        
                        # TODO: Aquí se podría implementar seguimiento de entrega de mensajes si es necesario
                    continue
                elif payload_type == "error":
                    # Registrar errores para investigación
                    errors = value.get('errors', [])
                    for error in errors:
                        logger.error(f"Error de WhatsApp: {error}")
                    continue
                elif payload_type != "message":
                    # Ignorar cualquier otro tipo de evento que no sea un mensaje
                    logger.info(f"Tipo de evento {payload_type} no procesable, ignorando")
                    continue
                    
                # Solo procesar si hay mensajes reales del usuario
                messages = value.get('messages', [])
                if not messages:
                    logger.info("No hay mensajes reales del usuario en este webhook, ignorando")
                    continue
                    
                for message in messages:
                    # Verificar que sea un mensaje válido
                    if not message:
                        logger.warning("Objeto de mensaje vacío, ignorando")
                        continue

                    # Determinar tipo (puede faltar en algunos payloads)
                    msg_type = message.get('type')
                    if not msg_type:
                        logger.warning("Mensaje recibido sin campo 'type' definido, continuando para registro")

                    # Extraer texto disponible según el tipo
                    if msg_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                    else:
                        # Para otros tipos intentamos obtener captions/fields comunes
                        if message.get('text') and isinstance(message.get('text'), dict):
                            message_text = message.get('text', {}).get('body', '')
                        else:
                            message_text = message.get('caption') or message.get('body') or ''

                    # Si falta timestamp, lo registramos pero no descartamos el mensaje automáticamente
                    if 'timestamp' not in message:
                        logger.warning("Mensaje sin timestamp; se registrará para inspección pero se procesará")

                    # Ignorar explícitamente mensajes de sistema o notificaciones
                    if message.get('system') or 'notification' in str(message).lower():
                        logger.warning("Mensaje de sistema o notificación detectado, ignorando")
                        continue

                    # Si no hay texto extraíble, lo registramos y seguimos (algunos attachments no tienen body)
                    if not message_text or not str(message_text).strip():
                        logger.warning("Mensaje sin texto extraíble; posible media/attachment - registrando y continuando")

                    # Extraer información del mensaje
                    phone = message.get('from')
                    message_id = message.get('id')
                    timestamp = message.get('timestamp')

                    # Mark current incoming message id for duplicate-send guarding
                    try:
                        globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = message_id
                    except Exception:
                        pass

                    logger.info(f"📨 Mensaje recibido: phone={phone}, text={str(message_text)[:60]}..., timestamp={timestamp}")

                    # --- DEBUG ROUTING: record key memory flags and routing state ---
                    try:
                        try:
                            waiting_flag_dbg = bool(get_conversation_memory(phone, 'waiting_for_advisor_data'))
                        except Exception:
                            waiting_flag_dbg = None

                        try:
                            advisor_data_dbg = get_conversation_memory(phone, 'advisor_data')
                        except Exception:
                            advisor_data_dbg = None

                        try:
                            advisor_prompt_sent_dbg = get_conversation_memory(phone, 'advisor_prompt_sent')
                        except Exception:
                            advisor_prompt_sent_dbg = None

                        try:
                            last_listed_webinars_dbg = get_conversation_memory(phone, 'last_listed_webinars')
                        except Exception:
                            last_listed_webinars_dbg = None

                        try:
                            sent_responses = globals().get('_SENT_RESPONSES', set())
                            current_id_dbg = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
                            already_sent = (current_id_dbg in sent_responses) if (current_id_dbg and sent_responses is not None) else False
                        except Exception:
                            already_sent = None

                        # Try to read ai_mode for this contact if available in DB (best-effort)
                        ai_mode_dbg = None
                        try:
                            from data.db import get_collection
                            conversaciones_col = get_collection('conversaciones')
                            if conversaciones_col is not None:
                                conv = conversaciones_col.find_one({"phone": phone})
                                if conv is not None:
                                    ai_mode_dbg = conv.get('ai_mode', True)
                        except Exception:
                            ai_mode_dbg = None

                        debug_payload = {
                            'phone': phone,
                            'message_id': message_id,
                            'waiting_for_advisor_data': waiting_flag_dbg,
                            'advisor_data_step': advisor_data_dbg.get('step') if isinstance(advisor_data_dbg, dict) else advisor_data_dbg,
                            'advisor_prompt_sent': advisor_prompt_sent_dbg,
                            'last_listed_webinars': bool(last_listed_webinars_dbg),
                            'already_sent_for_message': already_sent,
                            'ai_mode': ai_mode_dbg
                        }
                        logger.info(f"DEBUG_ROUTING: {json.dumps(debug_payload, default=str)}")
                        # Also emit structured webhook event for easier aggregation
                        try:
                            log_webhook_event('debug_routing', debug_payload)
                        except Exception:
                            pass
                    except Exception as _dbg_e:
                        logger.debug(f"Error emitting debug routing info: {_dbg_e}")

                    # Quick advisor shortcut: if the user explicitly asks to speak with an advisor,
                    # start the guided advisor flow immediately and skip other handlers.
                    try:
                        # Use the centralized AdvisorRequestManager to determine whether
                        # this message legitimately requests an advisor (strict criteria).
                        # This avoids starting the advisor flow on generic words like
                        # 'contactar' that appear in other contexts (courses, webinars, etc.).
                        if AdvisorRequestManager.is_advisor_request(message_text):
                            logger.info(f"Detección estricta: solicitud de asesor por parte de {phone}, iniciando flujo de asesor.")
                            try:
                                started = start_advisor_flow(phone)
                            except Exception as _e:
                                logger.error(f"Error iniciando start_advisor_flow: {_e}")
                                started = False
                            if started:
                                # We successfully started the advisor flow; continue to next message
                                continue
                    except Exception as _e:
                        logger.error(f"Error en advisor strict detection: {_e}")

                    # Validaciones básicas
                    if not phone or not message_id:
                        logger.warning(f"❌ Mensaje incompleto: phone={phone}, id={message_id}")
                        continue

                    # Evitar reprocesar mensajes
                    if ConversationMemory.is_message_processed(message_id):
                        logger.info(f"Mensaje {message_id} ya fue procesado anteriormente, ignorando")
                        continue

                    # Verificación de timestamp: si existe lo validamos, si no existe no bloqueamos
                    try:
                        if timestamp:
                            message_time = datetime.fromtimestamp(int(timestamp))
                            current_time = datetime.now()
                            time_diff = current_time - message_time
                            time_diff_seconds = time_diff.total_seconds()

                            # Mensaje demasiado antiguo (más de 5 minutos)
                            if time_diff_seconds > 300:
                                logger.warning(f"Mensaje {message_id} es antiguo ({time_diff_seconds} segundos), ignorando")
                                continue

                            # Mensaje con timestamp futuro (más de 10 segundos en el futuro)
                            if time_diff_seconds < -10:
                                logger.warning(f"Mensaje {message_id} tiene timestamp futuro ({-time_diff_seconds} segundos), ignorando")
                                continue

                            if time_diff_seconds > 60:
                                logger.info(f"Mensaje con retraso significativo: {time_diff_seconds} segundos")
                        else:
                            logger.debug(f"Mensaje {message_id} no tiene timestamp; omitiendo validación temporal")
                    except Exception as e:
                        logger.error(f"Error verificando timestamp del mensaje: {e}")
                        # En caso de error, verificamos si el formato del timestamp parece válido
                        if not str(timestamp).isdigit() or len(str(timestamp)) != 10:
                            logger.warning(f"Timestamp con formato inválido: {timestamp} - ignorando mensaje")
                            continue
                        
                    # Marcar este mensaje como procesado
                    ConversationMemory.mark_message_as_processed(message_id)
                    
                    # Registrar inicio del tiempo de procesamiento
                    processing_start_time = datetime.now()
                    
                    # NUEVO: Función que procesa TODOS los mensajes con IA PRIMERO
                    def process_message_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, ml_adapter_result, is_technical_question=False):
                        """
                        Esta función procesa TODOS los mensajes con IA sin excepción.
                        Garantiza que ningún mensaje se quede sin respuesta de IA.
                        """
                        logger.info(f"🚀 AI block entry: Procesando mensaje con IA para {phone}")
                        
                        try:
                            # System prompt mejorado que responde a TODO usando IA
                            system_prompt = """
Eres el asistente conversacional de Fibremex, experto en fibra óptica, redes y productos relacionados.

Instrucciones generales:
- Usa siempre IA para generar la respuesta.
- Si el mensaje del usuario es corto (menos de 120 caracteres) entrega una respuesta clara y concisa (1-3 frases).
- Si el mensaje es largo o técnico, entrega una respuesta técnica y bien estructurada (puntos, causas, recomendaciones), pero evita texto innecesario.
- No envíes automáticamente PDFs o listados extensos sin que el usuario lo pida explícitamente.
- Si el usuario menciona productos, sugiere las opciones disponibles y ofrece enviar cotización, ficha técnica o contactar a un asesor (no envíes la ficha sin confirmación).
- Si es una consulta técnica, explica causas, procedimientos y medidas prácticas.
- Evita palabras como 'evaluar' en las instrucciones al usuario; muestra opciones concretas para que responda.

Datos útiles (puedes mencionarlos si es relevante y breve):
- Productos: Bobinas UTP Cat5e/6/6A, Ductos HDPE, Tritubo, Jumpers MPO/MTP
- Cursos: capacitaciones presenciales en Querétaro y webinars online gratuitos

Tono: profesional y directo. Responde en español.
"""
                            
                            # Asegurar que chat_with_gemini esté disponible en este scope
                            try:
                                from services.chat_ai import chat_with_gemini as _local_chat
                            except Exception:
                                _local_chat = None

                            # Generar respuesta con IA
                            if _local_chat:
                                respuesta = _local_chat(
                                    phone=phone,
                                    message=message_text,
                                    system_prompt=system_prompt,
                                    include_whatsapp_profile=whatsapp_profile
                                )
                            else:
                                # Fallback si no está disponible
                                respuesta = None
                            
                            logger.info(f"🤖 AI processing: Respuesta generada para {phone}: {respuesta[:50]}...")
                            logger.info(f"🔍 Validación respuesta: tipo={type(respuesta)}, len={len(str(respuesta)) if respuesta else 0}, contenido_vacio={not respuesta}")
                            
                            # ESTRATEGIA MEJORADA: múltiples intentos con IA, sin fallbacks genéricos
                            if not respuesta or len(respuesta.strip()) < 5:
                                logger.warning(f"🔄 Primera respuesta de IA insuficiente para {phone}, intentando métodos alternativos...")
                                
                                # INTENTO 2: Usar ML service como alternativa
                                try:
                                    from services.ml_service import ml_service as _ml
                                    ml_result = _ml.process_message(message_text, conversation_history=conversation_history, phone=phone)
                                    bot_reply = ml_result.get('bot_reply') if isinstance(ml_result, dict) else None
                                    if bot_reply and len(bot_reply.strip()) >= 5:
                                        respuesta = bot_reply
                                        logger.info(f"✅ ML service generó respuesta alternativa: {len(respuesta)} caracteres")
                                except Exception as ml_error:
                                    logger.error(f"Error en ML service: {ml_error}")
                                
                                # INTENTO 3: Intentar con prompt más específico si aún no hay respuesta
                                if not respuesta or len(respuesta.strip()) < 5:
                                    try:
                                        enhanced_prompt = f"""
Eres un experto en fibra óptica y telecomunicaciones de Fibremex.

MENSAJE DEL USUARIO: "{message_text}"

INSTRUCCIONES:
1. Responde de forma útil y específica.
2. Si es técnico, explica causas y pasos prácticos.
3. Si pregunta por productos/cursos, ofrece opciones y pide confirmación antes de enviar PDFs o listados.
4. Si es un saludo corto, responde con una bienvenida concisa y pregunta cómo ayudar.
5. Mantén respuestas cortas para mensajes breves y detalladas para mensajes largos.
"""
                                        if _local_chat:
                                            respuesta = _local_chat(
                                                phone=phone,
                                                message=message_text,
                                                system_prompt=enhanced_prompt,
                                                include_whatsapp_profile=whatsapp_profile
                                            )
                                            if respuesta and len(respuesta.strip()) >= 5:
                                                logger.info(f"✅ Prompt mejorado generó respuesta: {len(respuesta)} caracteres")
                                    except Exception as enhanced_error:
                                        logger.error(f"Error con prompt mejorado: {enhanced_error}")
                                
                                # INTENTO 4: Si todo falla, intentar funciones determinísticas específicas
                                if not respuesta or len(respuesta.strip()) < 5:
                                    try:
                                        # Intentar funciones de cursos específicas
                                        handled = detect_course_info_request(phone, message_text)
                                        if handled:
                                            logger.info(f"✅ Función de cursos manejó la consulta para {phone}")
                                            return True
                                    except Exception:
                                        pass

                                    try:
                                        # Como último recurso, dar una respuesta breve que pida especificación
                                        respuesta = (
                                            "¡Hola! Soy el asistente de Fibremex. "
                                            "Puedo ayudarte con consultas técnicas, cursos, webinars o productos. "
                                            "Por favor, dime específicamente qué necesitas: por ejemplo 'precio curso 1', 'fechas FTTH', 'webinars', o 'productos'."
                                        )
                                        logger.info(f"✅ Usando respuesta informativa concisa como último recurso: {len(respuesta)} caracteres")
                                    except Exception:
                                        respuesta = "Hola, soy el asistente de Fibremex. ¿En qué puedo ayudarte?"
                                else:
                                    logger.info(f"✅ Respuesta de IA válida desde el primer intento: {len(respuesta)} caracteres")
                            
                            # Enviar respuesta
                            logger.info(f"📤 Enviando respuesta: {len(respuesta)} caracteres")
                            try:
                                send_result = send_text_message(phone, respuesta)
                                if send_result:
                                    logger.info(f"✅ Respuesta enviada exitosamente a {phone}")
                                else:
                                    logger.error(f"❌ Error enviando respuesta a {phone} (problema de WhatsApp, pero respuesta generada correctamente)")
                            except Exception as send_error:
                                logger.error(f"❌ Excepción enviando mensaje a {phone}: {send_error}")
                            
                            # IMPORTANTE: Retornar éxito si tenemos una respuesta válida, independientemente del estado del envío
                            # Esto evita que el sistema caiga en el fallback genérico cuando hay problemas de WhatsApp
                            logger.info(f"✅ Procesamiento IA completado para {phone} (respuesta: {len(respuesta)} chars)")
                            return True
                                
                        except Exception as e:
                            logger.error(f"❌ Error en process_message_with_ai_always: {e}", exc_info=True)
                            # Respuesta de emergencia
                            try:
                                emergency_response = "Disculpa, tuve un problema procesando tu mensaje. ¿Puedes intentar de nuevo? Estoy aquí para ayudarte con consultas técnicas, productos o cursos de fibra óptica."
                                send_text_message(phone, emergency_response)
                                return True
                            except Exception as e2:
                                logger.error(f"❌ Error crítico enviando respuesta de emergencia: {e2}")
                                return False
                    
                    # Obtener datos del perfil de WhatsApp si están disponibles
                    whatsapp_profile = None
                    if 'contacts' in value and value['contacts']:
                        contact = value['contacts'][0]
                        whatsapp_profile = {
                            "name": contact.get('profile', {}).get('name')
                        }
                        logger.info(f"Perfil de WhatsApp obtenido: {whatsapp_profile}")
                    
                    # Obtener el historial de conversación para el procesamiento ML
                    try:
                        conversation_history = get_conversation_history(phone)
                        logger.info(f"Historial recuperado para {phone}: {len(conversation_history)} mensajes")
                    except Exception as history_error:
                        logger.error(f"Error al obtener historial: {history_error}")
                        # Si falla, inicializar un historial vacío para continuar
                        conversation_history = []
                    
                    # **DETECTAR USUARIO NUEVO Y ENVIAR MENSAJE DE BIENVENIDA**
                    # Si no hay historial previo o es el primer mensaje, enviar introducción
                    is_new_user = len(conversation_history) == 0
                    is_greeting = False
                    if message_text:
                        text_lower = message_text.lower().strip()
                        greeting_words = ['hola', 'buenos dias', 'buenas tardes', 'buenas noches', 'buen dia', 'hi', 'hello', 'que tal']
                        is_greeting = any(greeting in text_lower for greeting in greeting_words) and len(text_lower) < 30
                    
                    if is_new_user or (is_greeting and len(conversation_history) <= 2):
                        # Welcome messages have been disabled. Log detection and continue processing the message.
                        logger.info(f"👋 (silenciado) Usuario nuevo o saludo detectado para {phone}. No se enviará mensaje de bienvenida.")
                    
                    # Inicializar indicador técnico por defecto (evita UnboundLocalError si no se asigna más abajo)
                    is_technical_question = False

                    # **VERIFICAR MODO AI ANTES DE PROCESAR**
                    # Comprobar si el AI mode está activado para este contacto
                    ai_mode_enabled = True  # Default: AI habilitado
                    try:
                        from data.db import get_collection
                        conversaciones_col = get_collection('conversaciones')
                        conversation = None

                        if conversaciones_col is not None:
                            phone_norm = _normalize_phone_value(phone)
                            candidates = set()
                            if phone:
                                candidates.add(str(phone).strip())
                            if phone_norm:
                                candidates.add(phone_norm)
                            if phone_norm and not phone_norm.startswith('+'):
                                candidates.add(f"+{phone_norm}")
                            phone_str = str(phone).strip() if phone else None
                            if phone_str and not phone_str.startswith('+'):
                                candidates.add(f"+{phone_str}")

                            filters = []
                            for value in candidates:
                                filters.append({'phone': value})
                                filters.append({'telefono': value})
                                filters.append({'customer_phone': value})
                                filters.append({'customerPhone': value})

                            if filters:
                                conversation = conversaciones_col.find_one({'$or': filters})

                        if conversation:
                            ai_value = conversation.get('ai_mode')
                            if ai_value is None:
                                ai_value = conversation.get('aiMode')
                            ai_mode_enabled = bool(ai_value) if ai_value is not None else True
                            logger.info(f"📋 AI Mode para {phone}: {'HABILITADO' if ai_mode_enabled else 'DESHABILITADO'}")
                        else:
                            logger.info(f"📋 Nueva conversación para {phone}, AI Mode: HABILITADO (default)")

                    except Exception as e:
                        logger.error(f"Error verificando AI mode para {phone}: {e}")
                        ai_mode_enabled = True  # Fallback: mantener AI habilitado
                    
                    # **SI AI MODE ESTÁ DESHABILITADO, SOLO GUARDAR EL MENSAJE SIN RESPONDER**
                    if not ai_mode_enabled:
                        logger.info(f"🚫 AI Mode DESHABILITADO para {phone}. Guardando mensaje sin generar respuesta automática.")
                        
                        # Guardar el mensaje del usuario en la base de datos
                        try:
                            from utils.conversation_utils import add_message_to_conversation
                            add_message_to_conversation(
                                phone=phone,
                                message_text=message_text,
                                sender="user", 
                                message_type=msg_type or "text"
                            )
                            logger.info(f"✅ Mensaje guardado para {phone} (AI Mode OFF)")
                        except Exception as e:
                            logger.error(f"Error guardando mensaje para {phone}: {e}")
                        
                        # Emitir evento para notificar a la interfaz sobre el nuevo mensaje
                        try:
                            from flask import current_app
                            socketio = getattr(current_app, 'socketio', None)
                            if socketio:
                                safe_emit(socketio, 'new_message', {
                                    'phone': phone,
                                    'text': message_text,
                                    'sender': 'user',
                                    'timestamp': datetime.utcnow().isoformat(),
                                    'ai_mode': False
                                })

                                safe_emit(socketio, 'update_contact', {
                                    'phone': phone,
                                    'lastMessage': message_text,
                                    'lastMessageSender': 'user',
                                    'lastMessageAt': datetime.utcnow().isoformat(),
                                    'ai_mode': False,
                                    'unread': True
                                })
                                
                                logger.info(f"📡 Eventos SocketIO emitidos para {phone} (AI Mode OFF)")
                        except Exception as e:
                            logger.error(f"Error emitiendo eventos SocketIO: {e}")
                        
                        # Continuar con el siguiente mensaje sin generar respuesta de IA
                        continue

                    # **PROCESAMIENTO CON IA SOLO SI ESTÁ HABILITADO**
                    # Priorizamos respuestas determinísticas para PETICIONES EXPLÍCITAS de cursos/webinars/productos
                    import re
                    # Detect explicit course request and technical indicators to spot mixed intents
                    explicit_course_or_ad_request = False
                    mixed_course_and_technical = False
                    try:
                        low_tmp = (message_text or '').lower()
                        if re.search(r"\b(curso|cursos|temario|inscripci[oó]n|inscripcion|webinar|webinars|fechas|precio|costo|cotizar|cotización)\b", low_tmp):
                            explicit_course_or_ad_request = True
                            logger.info(f"🔎 Petición explícita de cursos/webinars/productos detectada para {phone}, se priorizará respuesta determinística")

                        # Technical quick indicators
                        temp_match = re.search(r"\b\d{1,3}\s*(?:°|deg|grados|c|celsius|centigrados)\b", low_tmp)
                        tech_words_quick = ['otdr','empalme','empalmes','empalmando','empalmar','fusion','fusión','temperatura','grados','pérdida','pérdidas','atenuación','atenuacion','medición','medicion']
                        early_tech = bool(temp_match or any(k in low_tmp for k in tech_words_quick))

                        # If both appear, mark as mixed and prefer technical first
                        if explicit_course_or_ad_request and early_tech:
                            mixed_course_and_technical = True
                            is_technical_question = True
                            explicit_course_or_ad_request = False
                            logger.info(f"🔧 Mensaje mixto detectado (técnico + cursos) para {phone}; priorizando técnico y dejando sugerencias para después.")
                        else:
                            # If no mix and early_tech detected, prefer technical
                            if early_tech:
                                is_technical_question = True
                                logger.info(f"🔧 Early technical heuristic matched for {phone}; will prioritize technical processing")
                    except Exception:
                        pass

                    # Early override: if the same message contains clear technical indicators,
                    # prefer treating it as a technical question even if it mentions 'curso' loosely.
                    try:
                        if explicit_course_or_ad_request:
                            low = (message_text or '').lower()
                            tech_early_indicators = ['otdr', 'empalme', 'empalmes', 'empalmando', 'empalmar', 'fusion', 'fusión', 'pérdida', 'pérdidas', 'atenuación', 'atenuacion', 'medición', 'medicion', 'cómo usar', 'como usar', 'cómo', 'como', 'qué es', 'que es', 'temperatura', 'grados', 'celsius', 'centigrados']
                            # detect numeric temperature patterns like 40°C, 40 C, 40 c, 40 grados
                            temp_match = re.search(r"\b\d{1,3}\s*(?:°|deg|grados|c|celsius|centigrados)\b", low)
                            if temp_match or any(re.search(rf"\b{re.escape(k)}\b", low) for k in tech_early_indicators):
                                logger.info(f"🔧 Indicadores técnicos tempranos detectados en el mensaje de {phone}; priorizando flujo técnico sobre petición de cursos.")
                                explicit_course_or_ad_request = False
                    except Exception:
                        pass

                    # ==========================================
                    # PROCESAMIENTO SIMPLE Y DIRECTO PRIMERO
                    # ==========================================
                    
                    # 1. Verificar si el usuario está en proceso de asesor y enviar sus datos
                    try:
                        from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
                        advisor_data = get_conversation_memory(phone, 'advisor_data')
                        
                        if advisor_data and advisor_data.get('step') == 'waiting_info' and message_text:
                            logger.info(f"[ADVISOR_SIMPLE] Procesando datos del usuario {phone}")
                            
                            # Procesar los datos enviados
                            processed = process_advisor_data(phone, message_text)
                            if processed:
                                continue
                                
                    except Exception as e:
                        logger.error(f"Error verificando datos de asesor: {e}")
                    
                    # 2. Detectar solicitudes de procesos (inscripción, cotización, facturación) - PRIORIDAD ALTA
                    if message_text:
                        process_response = detect_process_request(phone, message_text)
                        if process_response:
                            continue
                    
                    # 3. Detectar solicitudes de PDF temario
                    if message_text and re.search(r'(temario|material|pdf)', message_text.lower()):
                        logger.info(f"[PDF_SIMPLE] Detectada solicitud de temario de {phone}")
                        pdf_sent = send_course_pdf_simple(phone, message_text)
                        if pdf_sent:
                            continue
                    
                    # 4. Detectar consultas de productos específicos
                    if message_text:
                        product_response = detect_and_respond_to_product_queries(phone, message_text)
                        if product_response:
                            continue
                    
                    # 5. Detectar solicitudes de webinars
                    if message_text:
                        webinar_response = detect_webinar_request(phone, message_text)
                        if webinar_response:
                            continue
                    
                    # 6. Detectar selección de webinar específico
                    if message_text:
                        webinar_selection = detect_webinar_selection(phone, message_text)
                        if webinar_selection:
                            continue
                    
                    # 7. Detectar solicitudes de información específica de cursos
                    if message_text:
                        course_info_response = detect_course_info_request(phone, message_text)
                        if course_info_response:
                            continue
                    
                    # 8. Detectar respuestas de seguimiento simples (sí, temario, más info, etc.)
                    if message_text:
                        follow_up_response = detect_follow_up_requests(phone, message_text)
                        if follow_up_response:
                            continue

                    # If user replied with a short selection like '1' or course name, try resolving against last listed courses
                    try:
                        try:
                            resolved = resolve_course_selection(phone, message_text)
                        except Exception:
                            resolved = False
                        if resolved:
                            # resolve_course_selection already sent the detailed info
                            continue
                    except Exception as _:
                        pass
                    
                    # 9. Detectar solicitudes de asesor (mejorado)
                    try:
                        waiting_flag = bool(get_conversation_memory(phone, 'waiting_for_advisor_data'))
                    except Exception:
                        waiting_flag = False

                    # Heurísticas para iniciar/continuar flujo de asesor:
                    # - Continuar si ya hay un waiting_flag en memoria (recopilación en curso)
                    # - Iniciar nuevo flujo SOLO si AdvisorRequestManager indica una petición de cotización/facturación/pago
                    try:
                        if waiting_flag:
                            # if a flow is already waiting for advisor data, try to process it
                            logger.info(f"[ADVISOR_SIMPLE] Resumiendo flujo de asesor para {phone} (waiting_flag)")
                            processed = process_advisor_data(phone, message_text)
                            if processed:
                                continue

                        # Strict advisor start: only when intent explicitly requests cotización/facturación/pago
                        if AdvisorRequestManager.is_advisor_request(message_text):
                            logger.info(f"[ADVISOR_SIMPLE] Detectada intención explícita de contacto/asesor para {phone} (AdvisorRequestManager)")
                            # if advisor_data already exists, continue it; else start a new simple flow
                            try:
                                advisor_data = get_conversation_memory(phone, 'advisor_data')
                            except Exception:
                                advisor_data = None

                            if advisor_data and advisor_data.get('step') == 'waiting_info':
                                processed = process_advisor_data(phone, message_text)
                                if processed:
                                    continue
                            else:
                                advisor_started = start_advisor_simple(phone)
                                if advisor_started:
                                    # mark waiting flag in memory so subsequent messages are routed
                                    try:
                                        save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                    except Exception:
                                        pass
                                    continue
                    except Exception as e:
                        logger.error(f"Error en advisor detection logic: {e}")

                    # Ejecutar bloque IA si es una consulta técnica o si NO es una petición explícita de cursos
                    if is_technical_question or not explicit_course_or_ad_request:
                        logger.info(f"🚀 AI block entry: Iniciando procesamiento con IA para {phone}")
                        try:
                            # Llamar a la función que garantiza respuesta con IA para TODOS los mensajes
                            ai_success = process_message_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, {}, is_technical_question=is_technical_question)
                            if ai_success:
                                logger.info(f"✅ Mensaje procesado exitosamente con IA para {phone}")
                                # El mensaje ya fue procesado (respuesta generada y enviada/intentada), continuar con el siguiente
                                continue
                            else:
                                logger.warning(f"⚠️ AI processing failed, continuando con lógica compleja para {phone}")
                        except Exception as ai_error:
                            logger.error(f"❌ Error en procesamiento con IA: {ai_error}")
                            # Si falla la IA, continuar con la lógica compleja como fallback
                    else:
                        logger.info(f"⏭️ Saltando bloque IA para {phone} porque la solicitud es explícita de cursos/productos/webinars")

                    # Early deterministic handlers: if user asks for the "link" of webinars, send all links
                    msg_lower = (message_text or '').lower()
                    if ('link' in msg_lower or 'enlace' in msg_lower) and ('webinar' in msg_lower or 'webinars' in msg_lower):
                        sent = send_webinars_links(phone)
                        if not sent:
                            # fallback generic response
                            send_text_message(phone, "Puedes registrarte o ver los webinars aquí: https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online")
                        continue

                    # Early advisor shortcut: only trigger on explicit advisor mentions to avoid
                    # intercepting other intents like cursos/webinars.
                    advisor_keywords = ['asesor', 'asesoría', 'asesoria', 'consultor', 'representante', 'vendedor']
                    # match whole words to reduce false positives
                    if any(re.search(rf"\b{re.escape(k)}\b", msg_lower) for k in advisor_keywords):
                        # start advisor flow (no need to run AI)
                        start_advisor_flow(phone)
                        continue
                    
                    # Sistema inteligente de clasificación de requerimientos del usuario
                    def classify_user_intent(message_text, conversation_history=None):
                        """
                        Clasifica la intención del usuario en: técnica, general, cursos, productos, o asesoría
                        """
                        if not message_text:
                            return {'type': 'general', 'confidence': 0.5, 'details': 'Mensaje vacío'}
                        msg_lower = message_text.lower().strip()

                        # Patrones de detección por categoría (pesos ajustados)
                        patterns = {
                            'tecnica': {
                                'keywords': ['problema', 'problemas', 'error', 'falla', 'no funciona', 'cómo solucionar', 'cómo arreglar',
                                             'diagnóstico', 'calibrar', 'configurar', 'instalar', 'conectar', 'instalación',
                                             'fusionadora', 'cleaver', 'otdr', 'pérdida de señal', 'atenuación', 'dbm', 'reflectometr',
                                             'backscatter', 'splice', 'empalme', 'empalmes', 'fibra rota', 'medición', 'troubleshoot', 'reparar',
                                             'conector', 'conectores', 'conectorización', 'conectorizacion', 'conectorizar', 'fusionar',
                                             'dificultad', 'ayuda con', 'cómo hacer', 'procedimiento', 'técnica', 'método', 'pasos para',
                                             'fibra', 'multimodo', 'monomodo', 'enlace', 'extender', 'metros', 'distancia', 'pigtal', 'pigtail',
                                             'om1', 'om2', 'om3', 'om4', 'om5', 'g652', 'g657', 'conectar', 'unir', 'proyecto', 'red',
                                             'implementar', 'diseñar', 'recomendar', 'recomendación', 'mejor opción', 'alternativa',
                                             'especificación', 'característica', 'ventaja', 'diferencia', 'comparar', 'qué usar'],
                                'phrases': ['ayuda técnica', 'necesito ayuda', 'no se enciende', 'no arranca', 'no pasa señal', 'cómo reparar',
                                           'tengo problema', 'hay problema', 'necesito resolver', 'cómo funciona', 'qué recomiendan',
                                           'cuál usar', 'mejor opción', 'cómo extender', 'cómo conectar', 'qué necesito',
                                           'es posible', 'se puede', 'puedo usar', 'funciona con', 'compatible con'],
                                'weight': 2.2
                            },
                            'general': {
                                'keywords': ['hola', 'quién', 'quien', 'horario', 'dónde', 'donde', 'contacto', 'información', 'informacion',
                                             'servicios', 'empresa', 'ubicación', 'horarios', 'buenos días', 'buenas tardes', 'buenas noches'],
                                'phrases': ['qué hacen', 'quiénes son', 'dónde están ubicados', 'cómo puedo contactarlos', 'información general'],
                                'weight': 1.0
                            },
                            'cursos': {
                                'keywords': ['curso', 'cursos', 'temario', 'certificación', 'capacitación', 'formación', 'formacion', 'inscripcion', 
                                           'inscribirme', 'recomiendan', 'recomienda', 'webinar', 'webinars', 'seminario', 'seminarios', 
                                           'online', 'on-line', 'en línea', 'en linea', 'fechas', 'costo', 'precio del curso', 'cuánto cuesta'],
                                'phrases': ['quiero aprender', 'me interesa el curso', 'información del curso', 'cuánto cuesta el curso', 
                                           'cuando empieza', 'qué curso recomiendan', 'próximas fechas', 'fechas disponibles'],
                                'weight': 1.5
                            },
                            'productos': {
                                'keywords': ['bobina', 'ducto', 'tritubo', 'jumper', 'cable', 'cotización', 'comprar', 'adquirir', 
                                           'disponibilidad', 'stock', 'mpo', 'mtp', 'utp', 'par trenzado', 'cobre'],
                                'phrases': ['qué productos tienen', 'dónde comprar', 'necesito cotización', 'quiero información de',
                                           'me gustaría cotizar', 'quiero cotizar', 'más información del'],
                                'weight': 1.8
                            },
                            'asesoria': {
                                'keywords': ['asesor', 'asesoría', 'asesoria', 'contactar', 'hablar con', 'consultor', 'vendedor', 'representante'],
                                'phrases': ['quiero hablar con', 'necesito que me contacten', 'consulta personalizada', 'ayuda especializada'],
                                'weight': 1.3
                            }
                        }

                        # Calcular puntuación para cada categoría
                        scores = {}
                        for category, config in patterns.items():
                            score = 0
                            matched_items = []

                            # Verificar keywords
                            for keyword in config.get('keywords', []):
                                if keyword in msg_lower:
                                    score += config.get('weight', 1.0)
                                    matched_items.append(keyword)

                            # Verificar phrases (mayor peso)
                            for phrase in config.get('phrases', []):
                                if phrase in msg_lower:
                                    score += config.get('weight', 1.0) * 1.5
                                    matched_items.append(phrase)

                            scores[category] = {
                                'score': score,
                                'matches': matched_items
                            }

                        # Encontrar la categoría con mayor puntuación
                        best_category = max(scores.keys(), key=lambda k: scores[k]['score'])
                        best_score = scores[best_category]['score']

                        # Reglas de desempate y priorización
                        has_course_keyword = any(k in msg_lower for k in ['curso', 'cursos', 'temario', 'inscripcion', 'inscribirme'])
                        recommend_phrases = ['qué curso', 'que curso', 'curso recomiendan', 'qué curso recomiendan', 'recomiendan curso', 'qué curso recomiendas', 'recomiendan para']
                        has_recommend_phrase = any(p in msg_lower for p in recommend_phrases)

                        tech_priority_phrases = ['problema', 'problemas', 'ayuda técnica', 'necesito ayuda', 'instalación', 'problema con', 'error en', 'no funciona']
                        has_tech_priority = any(p in msg_lower for p in tech_priority_phrases)

                        tecnica_score = scores.get('tecnica', {}).get('score', 0)
                        general_score = scores.get('general', {}).get('score', 0)
                        cursos_score = scores.get('cursos', {}).get('score', 0)

                        # Si el usuario pregunta explícitamente por qué curso, preferir 'cursos'
                        if has_recommend_phrase and has_course_keyword:
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si el usuario expresa interés en aprender y menciona curso (ej. 'Me interesa aprender', 'tienen algún curso'),
                        # preferir 'cursos' incluso si también aparecen términos técnicos.
                        course_interest_phrases = ['me interesa aprender', 'me interesa', 'tienen algún curso', 'tienen algun curso', 'tienen curso', 'tienen algún', 'tienen']
                        has_course_interest = any(p in msg_lower for p in course_interest_phrases)
                        if has_course_interest and has_course_keyword:
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si el usuario utiliza verbos/ofertas (tienen, ofrecen, hay) junto a 'curso'/'webinar', forzar 'cursos'
                        offer_verbs = ['tienen', 'tienen algun', 'tienen algún', 'ofrecen', 'ofrece', 'hay', 'ofrecemos', 'ofrecer']
                        has_offer_verb = any(v in msg_lower for v in offer_verbs)
                        if has_offer_verb and any(k in msg_lower for k in ['curso', 'cursos', 'webinar', 'webinars', 'seminario', 'seminarios', 'opciones online']):
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si hay señales técnicas claras y también aparece 'curso', preferir 'tecnica' SOLO si no hay interés explícito en cursos
                        if has_tech_priority and has_course_keyword and not has_course_interest:
                            best_category = 'tecnica'
                            best_score = max(best_score, tecnica_score)

                        # Si cursos tiene la mejor puntuación pero tecnica está muy cerca (>=75%), preferir tecnica
                        if best_category == 'cursos' and tecnica_score >= 0.75 * max(1.0, best_score):
                            best_category = 'tecnica'
                            best_score = tecnica_score

                        # Si cursos y general están muy parejos y no hay señales técnicas, preferir general
                        if best_category == 'cursos' and general_score >= 0.9 * max(1.0, best_score) and not has_tech_priority:
                            best_category = 'general'
                            best_score = general_score

                        # Si no hay puntuación significativa, clasificar como general
                        if best_score == 0:
                            return {
                                'type': 'general',
                                'confidence': 0.45,
                                'details': 'No se encontraron patrones específicos',
                                'scores': scores
                            }

                        # Calcular confianza basada en la diferencia con la segunda opción
                        sorted_scores = sorted(scores.values(), key=lambda x: x['score'], reverse=True)
                        if len(sorted_scores) > 1:
                            second_score = sorted_scores[1]['score']
                            if best_score + second_score > 0:
                                confidence = min(0.95, float(best_score) / float(best_score + second_score))
                            else:
                                confidence = 0.95
                        else:
                            confidence = 0.95

                        return {
                            'type': best_category,
                            'confidence': confidence,
                            'details': f"Matches: {scores[best_category]['matches']}",
                            'scores': scores
                        }
                    
                    # Función para manejar mensajes de publicidad específicos
                    def handle_advertising_messages(message_text):
                        """Maneja mensajes específicos de publicidad y los redirige a información relevante"""
                        text_lower = message_text.lower().strip()
                        
                        # Patrones de mensajes de publicidad por productos
                        advertising_patterns = {
                            'bobinas_utp': {
                                'patterns': ['bobina', 'par trenzado', '100% cobre', 'utp', 'cable utp', 'bobinas utp'],
                                'response': '''🔧 **Bobinas UTP - Cable Par Trenzado 100% Cobre**

¡Excelente elección! Nuestras bobinas UTP ofrecen:
✅ Cobre 100% puro para máxima conductividad
✅ Disponibles en Cat. 5e, Cat. 6 y Cat. 6A
✅ Longitudes estándar de 305m
✅ Certificación internacional TIA/EIA

**Especificaciones técnicas:**
• Impedancia: 100 ohms ± 15%
• Capacitancia: < 56 pF/m
• Resistencia DC: < 9.38 ohms/100m
• Temperatura operativa: -20°C a +60°C

Para cotización personalizada, compárteme:
- Categoría requerida (5e, 6, 6A)
- Cantidad de bobinas
- Ubicación de entrega

**CURSO RELACIONADO:**
📚 "Cableado Estructurado para Redes de Fibra y Cobre"
📅 Próxima fecha: 3-4 Noviembre 2025
💰 $269 USD + IVA
⏱️ 16 horas (2 días)

¿Te interesa el curso? ¡Responde "curso 1" para más información!'''
                            },
                            'ductos': {
                                'patterns': ['ducto', 'ductos', 'tubo', 'conduit', 'cotizar ductos'],
                                'response': '''🏗️ **Ductos para Fibra Óptica**

Nuestros ductos ofrecen la mejor protección para tus instalaciones:
✅ Alta resistencia UV y química
✅ Flexibilidad para instalaciones complejas
✅ Disponibles en múltiples diámetros
✅ Cumple normas internacionales

**Tipos disponibles:**
• Ducto corrugado para enterrado
• Ducto liso para interior
• Ducto de alta densidad (HDPE)
• Microductos para fibra

**Aplicaciones:**
- Redes FTTH
- Planta externa
- Campus universitarios
- Edificios corporativos

Para cotización, necesito:
- Tipo de ducto requerido
- Diámetro y longitud
- Aplicación específica

**CURSO RELACIONADO:**
📚 "Redes de Fibra Óptica Planta Externa"
📅 Próxima fecha: 5-6 Noviembre 2025
💰 $269 USD + IVA
⏱️ 16 horas (2 días)

¿Quieres capacitarte en instalación de ductos? ¡Responde "curso 2" para más información!'''
                            },
                            'tritubo': {
                                'patterns': ['tritubo', 'tri-tubo', 'tri tubo', 'más información del tritubo'],
                                'response': '''🌐 **Tritubo para Fibra Óptica**

Solución innovadora para máxima densidad de fibra:
✅ Tres tubos en una sola estructura
✅ Optimiza espacio en ductos
✅ Fácil identificación por colores
✅ Reducción de costos de instalación

**Características técnicas:**
• Material: HDPE de alta calidad
• Colores estándar: Azul, Rojo, Verde
• Diámetros: 7mm, 10mm, 12mm
• Longitudes: 2000m por carrete

**Ventajas:**
- 50% menos espacio que tubos individuales
- Instalación más rápida
- Mejor organización de la red
- Menor costo por metro

Para cotización personalizada, compárteme:
- Diámetro requerido
- Longitud total
- Proyecto específico

**CURSO RELACIONADO:**
📚 "Redes de Fibra Óptica FTTH para WISP e ISP"
📅 Próxima fecha: 10-11 Noviembre 2025
💰 $299 USD + IVA
⏱️ 16 horas (2 días)

¿Te interesa aprender sobre FTTH? ¡Responde "curso 3" para más información!'''
                            },
                            'mpo_mtp': {
                                'patterns': ['mpo', 'mtp', 'mtp pro', 'jumper mpo', 'jumper mtp', 'cotizar jumper'],
                                'response': '''🔗 **Jumpers MPO/MTP y MTP Pro**

Conectividad de alta densidad para centros de datos:
✅ MPO/MTP estándar y MTP Pro disponibles
✅ Conectores de precisión
✅ Baja pérdida de inserción (<0.5dB)
✅ Alta durabilidad (>1000 ciclos)

**Configuraciones disponibles:**
• 8, 12, 24 fibras
• Singlemode y Multimode
• Polaridad A, B, C
• Longitudes: 1m a 100m

**Tipos de conectores:**
- MPO: Multi-fiber Push On
- MTP: Mechanical Transfer Push On
- MTP Pro: Versión premium con mejor rendimiento

**Aplicaciones:**
- Data centers
- Redes empresariales
- Backbone de alta velocidad
- Conexiones 40G/100G/400G

Para cotización, especifica:
- Tipo de conector (MPO/MTP/MTP Pro)
- Número de fibras
- Tipo de fibra (SM/MM)
- Longitudes requeridas

**CURSO RELACIONADO:**
📚 "PONLAN Redes Pasivas para Entornos Enterprise"
📅 Próxima fecha: 12-13 Noviembre 2025
💰 Consultar con asesor
⏱️ 16 horas (2 días)

¿Quieres especializarte en redes enterprise? ¡Responde "curso 4" para más información!'''
                            },
                            'cursos_generales': {
                                'patterns': ['curso de cableado estructurado', 'curso de fibra óptica planta externa', 
                                           'curso redes de fibra óptica ftth', 'curso de redes ópticas pasivas', 
                                           'curso de empalmes y mediciones'],
                                'response': '''📚 **NUESTROS CURSOS ESPECIALIZADOS**

Tenemos 5 cursos profesionales disponibles:

**1. Cableado Estructurado para Redes de Fibra y Cobre** 🔧
📅 3-4 Noviembre 2025 | ⏱️ 16 horas | 💰 $269 USD + IVA

**2. Redes de Fibra Óptica Planta Externa** 🏗️
📅 5-6 Noviembre 2025 | ⏱️ 16 horas | 💰 $269 USD + IVA

**3. Redes de Fibra Óptica FTTH para WISP e ISP** 🌐
📅 10-11 Noviembre 2025 | ⏱️ 16 horas | 💰 $299 USD + IVA

**4. PONLAN Redes Pasivas para Entornos Enterprise** 🏢
📅 12-13 Noviembre 2025 | ⏱️ 16 horas | 💰 Consultar con asesor

**5. Empalmes y Mediciones con OTDR** 🎯
📅 5-6 Noviembre 2025 | ⏱️ 16 horas | 💰 Consultar con asesor

📍 Ubicación: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
🕘 Horario: 9:00 a 19:00 hrs

¿Cuál te interesa? Responde con el número o nombre del curso para ver el temario completo.'''
                            }
                        }
                        
                        # Buscar coincidencias con patrones de publicidad (orden de prioridad)
                        
                        # Mensajes específicos de publicidad de cursos
                        curso_patterns = {
                            'información del curso de cableado estructurado': '📚 **CURSO: Cableado Estructurado para Redes de Fibra y Cobre**\n\n✅ **Temario completo:**\n• Fundamentos de cableado estructurado\n• Instalación de fibra y cobre\n• Normativas TIA/EIA\n• Certificación de enlaces\n• Práticas con equipos profesionales\n\n📅 **Fecha:** 3-4 Noviembre 2025\n💰 **Precio:** $269 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de fibra óptica planta externa': '📚 **CURSO: Redes de Fibra Óptica Planta Externa**\n\n✅ **Temario completo:**\n• Diseño de redes exteriores\n• Instalación aérea y subterránea\n• Tipos de fibra para exterior\n• Presupuestos ópticos\n• Mediciones con OTDR\n\n📅 **Fecha:** 5-6 Noviembre 2025\n💰 **Precio:** $269 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso redes de fibra óptica ftth': '📚 **CURSO: Redes de Fibra Óptica FTTH para WISP e ISP**\n\n✅ **Temario completo:**\n• Arquitectura FTTH/GPON\n• Equipos OLT y ONT\n• Splitters y divisores\n• Instalación residencial\n• Gestión de red FTTH\n\n📅 **Fecha:** 10-11 Noviembre 2025\n💰 **Precio:** $299 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de redes ópticas pasivas': '📚 **CURSO: PONLAN Redes Pasivas para Entornos Enterprise**\n\n✅ **Temario completo:**\n• Redes PON para empresas\n• Arquitectura PONLAN\n• Equipos especializados\n• Diseño corporativo\n• Certificación empresarial\n\n📅 **Fecha:** 12-13 Noviembre 2025\n💰 **Precio:** Consultar con asesor\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de empalmes y mediciones': '📚 **CURSO: Empalmes y Mediciones con OTDR**\n\n✅ **Temario completo:**\n• Técnicas de empalme\n• Uso profesional de OTDR\n• Interpretación de trazas\n• Certificación de enlaces\n• Resolución de problemas\n\n📅 **Fecha:** 5-6 Noviembre 2025\n💰 **Precio:** Consultar con asesor\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!'
                        }
                        
                        for curso_pattern, response in curso_patterns.items():
                            if curso_pattern in text_lower:
                                return response
                        
                        # Mensajes específicos de productos (más específicos primero)
                        specific_messages = {
                            'información de bobina de par trenzado 100% cobre': 'bobinas_utp',
                            'quiero información de bobina de par trenzado 100% cobre': 'bobinas_utp',
                            'me gustaría cotizar ductos': 'ductos',
                            'quiero cotizar ductos': 'ductos',
                            'más información del tritubo': 'tritubo',
                            'quiero más información del tritubo': 'tritubo',
                            'cotizar jumper mpo y mtp': 'mpo_mtp',
                            'quiero cotizar jumper mpo y mtp': 'mpo_mtp'
                        }
                        
                        for specific_msg, product_type in specific_messages.items():
                            if specific_msg in text_lower:
                                return advertising_patterns[product_type]['response']
                        
                        # Patrones generales por categoría
                        for product_type, config in advertising_patterns.items():
                            if product_type == 'cursos_generales':
                                continue  # Ya manejado arriba
                            for pattern in config['patterns']:
                                if pattern in text_lower:
                                    # Verificar contexto para evitar falsos positivos
                                    if any(context_word in text_lower for context_word in ['quiero', 'información', 'cotizar', 'más información']):
                                        return config['response']
                        
                        return None
                    
                    # Detectar cambios de tema intencionales
                    topic_shift_keywords = ['cambio de tema', 'otra pregunta', 'nuevo tema', 'diferente', 'otra cosa', 
                                           'hablemos de', 'cuéntame sobre', 'donde esta', 'donde se encuentra',
                                           'no quiero', 'quiero saber', 'quiero hablar', 'pregunta', 'dime sobre']
                    
                    # Detectar comandos para finalizar la conversación enfocada en cursos
                    clear_course_commands = ['finalizar curso', 'terminar curso', 'salir del curso', 'salir curso', 
                                           'cancelar curso', 'no más cursos', 'no mas cursos']
                    
                    # 🤖 Usar el sistema ML-first mejorado
                    intent_classification = classify_user_intent_ml(message_text, phone, conversation_history)
                    user_intent_type = intent_classification['type']
                    intent_confidence = intent_classification['confidence']
                    ml_details = intent_classification['details']

                    logger.info(f"� ML Classification: {user_intent_type} (confidence: {intent_confidence:.2f})")
                    
                    # Actualizar contexto de conversación con información ML
                    ml_result = ml_details.get('full_ml_result', {})
                    update_conversation_context(phone, ml_result, user_intent_type)

                    # Generar system prompt contextual basado en ML
                    contextual_prompt = generate_contextual_system_prompt(ml_result, user_intent_type, message_text)
                    
                    # Manejar leads calientes automáticamente
                    client_data = ml_result.get('client_data', {})
                    lead_prediction = ml_result.get('lead_prediction', {})
                    
                    # Si es lead caliente con datos completos, generar PDF para asesor
                    if (lead_prediction.get('lead_type') == 'caliente' and 
                        client_data.get('nombre') and (client_data.get('correo') or client_data.get('empresa'))):
                        try:
                            from services.ml_service import ml_service
                            pdf_path = ml_service.generate_client_pdf(client_data, ml_result.get('classification', {}))
                            logger.info(f"🔥 PDF generado para lead caliente: {pdf_path}")
                        except Exception as e:
                            logger.error(f"Error generando PDF: {e}")

                    # Si requiere atención humana, marcar para seguimiento
                    if ml_result.get('requires_human_attention'):
                        from services.conversation_memory import ConversationMemory
                        ConversationMemory.add_entity_to_memory(phone, 'needs_human_followup', True)
                        logger.warning(f"⚠️ Cliente {phone} requiere atención humana")

                    # Función para detectar consultas técnicas específicas (movida arriba para prioridad)
                    def is_technical_consultation(message_text):
                        """Detecta si es una consulta técnica que debe procesarse inmediatamente"""
                        text_lower = (message_text or '').lower().strip()
                        # Patrones de consultas técnicas claras (ampliados para cubrir preguntas cortas y términos generales)
                        technical_indicators = [
                            # Términos generales
                            'fibra', 'fibra óptica', 'fibra optica', 'dispers', 'dispersión', 'dispercion', 'dispersión cromática', 'dispercion cromatica',
                            # Productos y especificaciones
                            'fibra multimodo', 'fibra monomodo', 'om1', 'om2', 'om3', 'om4', 'om5',
                            'g652', 'g657', 'pigtail', 'pigtal', 'conector sc', 'conector fc', 'conector lc', 'conector',
                            # Consultas de implementación
                            'extender', 'conectar', 'unir', 'enlace', 'distancia', 'metros', 'ducto', 'ductos', 'empalme', 'empalmes', 'fusion', 'fusión',
                            'otdr', 'reflectómetro', 'reflectometro',
                            'es posible', 'se puede', 'puedo usar', 'funciona con', 'compatible', 'cómo', 'como', 'qué es', 'que es', 'para qué sirve',
                            # Recomendaciones técnicas
                            'qué recomiendan', 'cuál usar', 'mejor opción', 'alternativa', 'recomiendan', 'recomend',
                            # Especificaciones
                            'características', 'especificaciones', 'diferencia entre', 'atenuación', 'pérdida', 'loss', 'attenuation',
                            # Proyectos y diseño
                            'proyecto', 'implementar', 'diseñar', 'instalar', 'presupuesto', 'presupuesto óptico', 'presupuesto optico'
                        ]

                        # Short question heuristic: if user asks "qué es X" or "para que sirve X" where X matches a technical term
                        short_question_patterns = ['qué es', 'que es', 'para que sirve', 'para qué sirve', 'qué es la', 'que es la']

                        if any(s in text_lower for s in short_question_patterns) and any(k in text_lower for k in ['fibra', 'otdr', 'pigtail', 'dispersion', 'dispersión', 'conector']):
                            return True

                        return any(indicator in text_lower for indicator in technical_indicators)

                    # Priorizar consultas técnicas: si detectamos indicadores técnicos, marcamos la intención y
                    # evitamos que los detectores de publicidad/curso la sobreescriban o la cortocircuiten.
                    is_technical_question = False
                    if is_technical_consultation(message_text):
                        user_intent_type = 'tecnica'
                        intent_confidence = max(intent_confidence, 0.9)
                        is_technical_question = True
                        logger.info(f"🔧 Consulta técnica específica detectada para {phone}: {message_text[:50]}...")

                    # === PROCESAMIENTO AI-FIRST: TODAS LAS CONSULTAS PASAN POR IA ===
                    logger.info(f"🚀 PROCESANDO CON IA PRIMERO - Teléfono: {phone}")
                    
                    def process_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, user_intent_type, is_technical_question=False):
                        """Procesa TODOS los mensajes con IA sin excepción"""
                        try:
                            # System prompt mejorado para responder a TODO
                            ai_system_prompt = """
ERES UN CONSULTOR EXPERTO EN FIBRA ÓPTICA Y TELECOMUNICACIONES DE FIBREMEX.

INSTRUCCIONES PRINCIPALES:
1. RESPONDE A TODAS LAS CONSULTAS SIN EXCEPCIÓN
2. Si preguntan sobre productos (bobinas, ductos, tritubo, jumpers MPO/MTP): proporciona información técnica detallada
3. Si preguntan sobre cursos: proporciona información completa de fechas, precios y temarios
4. Si preguntan consultas técnicas: responde como experto con detalles específicos
5. Si preguntan por opciones online: menciona los webinars gratuitos cada martes
6. NUNCA digas que no puedes ayudar - SIEMPRE da una respuesta útil

INFORMACIÓN DE PRODUCTOS:
• Bobinas UTP: Cat 5e, 6, 6A - 100% cobre, 305m, certificación TIA/EIA
• Ductos: HDPE alta densidad, corrugado/liso, múltiples diámetros
• Tritubo: 3 tubos en una estructura, optimiza espacio, colores estándar
• Jumpers MPO/MTP: 8-24 fibras, SM/MM, polaridades A/B/C

INFORMACIÓN DE CURSOS:
1. Cableado Estructurado - 13-14 Oct 2025 - $269 USD + IVA
2. Fibra Óptica Planta Externa - 15-16 Octv 2025 - $269 USD + IVA
3. FTTH para WISP e ISP - 10-11 Nov 2025 - $299 USD + IVA
4. PONLAN Enterprise - 12-13 Nov 2025 -  $249 USD +IVA
5. Empalmes y OTDR - 5-6 Nov 2025 - $189 USD + IVA

UBICACIÓN: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
WEBINARS: Gratuitos cada martes en línea

REGLA DORADA: RESPONDE SIEMPRE CON INFORMACIÓN ÚTIL Y ESPECÍFICA
"""
                            
                            # Asegurar chat_with_gemini disponible localmente
                            try:
                                from services.chat_ai import chat_with_gemini as _local_chat
                            except Exception:
                                _local_chat = None

                            # Choose prompt: use strict technical prompt from the start when this is a technical query
                            try:
                                if is_technical_question:
                                    strict_technical_prompt = (
                                        "Eres un experto técnico en fibra óptica y telecomunicaciones. "
                                        "RESPONDE SOLO LA PARTE TÉCNICA: proporciona diagnóstico, pasos, procedimientos, comandos y pruebas concretas. "
                                        "NO MENCIONES CURSOS, FECHAS, PRECIOS, INSCRIPCIONES, O PROMOCIONES BAJO NINGUNA CIRCUNSTANCIA. "
                                        "Si falta información pide solo los datos técnicos necesarios (modelo de equipo, tipo de fibra, lecturas OTDR) y espera respuesta."
                                    )
                                    prompt_to_use = strict_technical_prompt
                                else:
                                    prompt_to_use = ai_system_prompt

                                # Generar respuesta con IA usando el prompt seleccionado
                                if _local_chat:
                                    ai_response = _local_chat(
                                        phone=phone,
                                        message=message_text,
                                        system_prompt=prompt_to_use,
                                        include_whatsapp_profile=whatsapp_profile
                                    )
                                else:
                                    ai_response = None

                                # Safety: if for any reason the strict prompt still returned course mentions, try one regeneration
                                if is_technical_question and ai_response:
                                    low = ai_response.lower()
                                    if any(k in low for k in ['curso', 'cursos', 'temario', 'inscripción', 'inscripcion', 'fechas', 'precio']):
                                        logger.info(f"🔒 Strict prompt still produced course mentions for {phone}; attempting one regeneration with extra constraints")
                                        try:
                                            regen_prompt = strict_technical_prompt + "\nINSTRUCCIÓN ADICIONAL: RESPONDE SOLO TÉCNICA. Si no puedes, pide información técnica adicional."
                                            if _local_chat:
                                                ai_response_strict = _local_chat(
                                                    phone=phone,
                                                    message=message_text,
                                                    system_prompt=regen_prompt,
                                                    include_whatsapp_profile=whatsapp_profile
                                                )
                                            else:
                                                ai_response_strict = None
                                            if ai_response_strict and len(ai_response_strict.strip()) > 10:
                                                ai_response = ai_response_strict
                                        except Exception as _re:
                                            logger.debug(f"Error regenerating strict AI response: {_re}")
                            except Exception as _gen_e:
                                logger.debug(f"Error selecting prompt for AI generation: {_gen_e}")
                            
                            logger.info(f"✅ IA procesó exitosamente para {phone}: {len(ai_response)} caracteres")
                            return ai_response
                            
                        except Exception as e:
                            logger.error(f"❌ Error en procesamiento IA: {e}")
                            return f"He analizado tu consulta. Para brindarte información específica sobre {message_text[:50]}..., ¿podrías darme más detalles sobre tu proyecto o necesidad específica?"
                    
                    # PROCESAR CON IA INMEDIATAMENTE
                    try:
                        ai_response = process_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, user_intent_type, is_technical_question=is_technical_question)

                        # ENVIAR RESPUESTA IA INMEDIATAMENTE (PARA CONSULTAS TÉCNICAS: respuesta estricta sin cursos)
                        if ai_response and len(ai_response.strip()) > 10:
                            logger.info(f"📤 Enviando respuesta IA a {phone}")

                            # If technical question, ensure the reply does not contain course mentions
                            try:
                                if is_technical_question:
                                    low = ai_response.lower()
                                    if any(k in low for k in ['curso', 'cursos', 'temario', 'inscripción', 'inscripcion', 'fechas', 'precio']):
                                        logger.info(f"🔒 AI respuesta técnica incluye menciones de cursos, regenerando con prompt estricto para {phone}")
                                        # Regenerate stricter technical-only response
                                        strict_prompt = (
                                            "El usuario hizo una consulta TÉCNICA. RESPONDE SOLO LA PARTE TÉCNICA. "
                                            "No menciones cursos, fechas, precios, inscripciones ni promociones. "
                                            "Da pasos concretos, comandos, procedimientos, y enlaces técnicos si aplica."
                                        )
                                        try:
                                            from services.chat_ai import chat_with_gemini as _regen_chat
                                            regen = _regen_chat(phone=phone, message=message_text, system_prompt=strict_prompt, include_whatsapp_profile=whatsapp_profile)
                                            if regen and len(regen.strip()) > 10:
                                                ai_response = regen
                                        except Exception as _re:
                                            logger.debug(f"Error regenerando respuesta estricta: {_re}")

                                # Send the technical response now
                                send_text_message(phone, ai_response.strip())
                            except Exception as send_err:
                                logger.error(f"Error enviando respuesta IA a {phone}: {send_err}")

                            # After sending the technical answer, optionally append course suggestions (non-invasive)
                            try:
                                if is_technical_question:
                                    # Try to find relevant courses by keywords in the user message
                                    from utils.courses_adapter import search_courses_by_keywords, compose_course_suggestion_via_ai
                                    # Build keyword list from a simple split of important words (limit to 5)
                                    kws = re.findall(r"[a-zA-ZñÑáéíóúÁÉÍÓÚ0-9]+", (message_text or ''))
                                    kws = [w for w in kws if len(w) > 3][:5]
                                    candidates = search_courses_by_keywords(kws, limit=3)
                                    if candidates:
                                        # Compose one short suggestion message that lists up to 2 courses
                                        suggestions = []
                                        for c in candidates[:2]:
                                            try:
                                                suggestions.append(compose_course_suggestion_via_ai(c, user_query=message_text, phone=phone))
                                            except Exception:
                                                suggestions.append(format_course_for_whatsapp(c))

                                        if suggestions:
                                            # Send a gentle suggestion message after a short pause
                                            suggestion_text = (
                                                "Si te interesa, también puedo recomendar cursos relacionados (opcional):\n\n" + "\n\n".join(suggestions)
                                            )
                                            try:
                                                send_text_message(phone, suggestion_text)
                                            except Exception as _s:
                                                logger.debug(f"No se pudo enviar sugerencia de cursos a {phone}: {_s}")

                            except Exception as sug_err:
                                logger.debug(f"Error preparando sugerencias de cursos: {sug_err}")

                            # Marcar como procesado y continuar al siguiente webhook
                            save_conversation_memory(phone, 'last_response_type', 'ai_processed')
                            logger.info(f"✅ Mensaje procesado con IA para {phone} - COMPLETADO")
                            continue
                        else:
                            logger.warning(f"⚠️ Respuesta IA vacía o muy corta para {phone}")
                    except Exception as e:
                        logger.error(f"❌ Fallo crítico en procesamiento IA para {phone}: {e}")
                    
                    # Verificar si es un mensaje de publicidad específico (SOLO como fallback)
                    advertising_response = None
                    if not is_technical_question:
                        advertising_response = handle_advertising_messages(message_text)
                        if advertising_response:
                            logger.info(f"Mensaje de publicidad detectado para {phone} (fallback)")
                            send_text_message(phone, advertising_response)
                            continue
                    
                    # Manejar solicitudes específicas de información de cursos
                    def handle_course_info_requests(message_text):
                        """Maneja solicitudes específicas de información de cursos"""
                        text_lower = message_text.lower().strip()
                        
                        # Lista general de cursos
                        if any(pattern in text_lower for pattern in ['cursos', 'qué cursos', 'que cursos', 'lista de cursos', 'cursos disponibles']):
                            if not any(specific in text_lower for specific in ['temario', 'fechas', 'precio', 'información de']):
                                return get_all_courses_summary()
                        
                        # Mapeo de palabras clave a IDs de curso (orden de especificidad)
                        course_keywords = {
                            4: ['ponlan', 'enterprise', 'pol', 'pasivas', 'corporativo', 'empresarial'],  # Más específico primero
                            5: ['otdr', 'empalmes', 'fusión', 'fusion', 'mediciones', 'reflectómetro', 'reflectometro'],
                            3: ['ftth', 'wisp', 'isp', 'gpon', 'fiber to the home'],  # 'pon' removido para evitar conflicto con ponlan
                            1: ['cableado', 'estructurado', 'cobre', 'cat6', 'cat5e', 'utp'],
                            2: ['planta externa', 'exterior', 'outdoor', 'fibra óptica planta', 'fibra optica planta']
                        }
                        
                        # Patrones para diferentes tipos de solicitud
                        import re
                        
                        # Solicitud por número específico
                        number_match = re.search(r'(?:curso\s+|información\s+curso\s+|temario\s+|fechas?\s+curso\s+|precio\s+curso\s+)(\d+)', text_lower)
                        if number_match:
                            course_id = int(number_match.group(1))
                            return get_course_complete_info(course_id=course_id)
                        
                        # Solicitud de información específica (fechas, precios, temario)
                        info_patterns = [
                            (r'(?:fechas?|cuando|cuándo)\s+(.+)', 'fechas'),
                            (r'(?:precio|costo|cuánto cuesta|cuanto cuesta)\s+(.+)', 'precio'),
                            (r'(?:temario|contenido|programa)\s+(.+)', 'temario'),
                            (r'(?:información|info)\s+(?:del\s+|sobre\s+)?(.+)', 'completa')
                        ]
                        
                        for pattern, info_type in info_patterns:
                            match = re.search(pattern, text_lower)
                            if match:
                                course_text = match.group(1).strip()
                                
                                # Si es un número directo
                                if course_text.isdigit():
                                    course_id = int(course_text)
                                    return get_course_specific_info(course_id, info_type)
                                
                                # Buscar por palabras clave
                                for course_id, keywords in course_keywords.items():
                                    if any(keyword in course_text for keyword in keywords):
                                        return get_course_specific_info(course_id, info_type)
                        
                        # Solicitud general por palabras clave
                        for course_id, keywords in course_keywords.items():
                            if any(keyword in text_lower for keyword in keywords):
                                # Si menciona información específica
                                if any(word in text_lower for word in ['información', 'info', 'temario', 'fechas', 'precio', 'costo']):
                                    return get_course_complete_info(course_id=course_id)
                        
                        return None
                    
                    # Verificar si es una solicitud de información de cursos (sólo si no es técnica)
                    course_info_response = None
                    if not is_technical_question:
                        course_info_response = handle_course_info_requests(message_text)
                        if course_info_response:
                            logger.info(f"Solicitud de información de curso detectada para {phone}")
                            send_text_message(phone, course_info_response)

                            # Quick-path: if user explicitly asked for 'temario', attempt to send PDF
                            try:
                                if 'temario' in (message_text or '').lower():
                                    # Try to detect course id: look for a numeric mention first
                                    cid = None
                                    nm = re.search(r'curso\s*(\d+)', (message_text or '').lower())
                                    if nm:
                                        try:
                                            cid = int(nm.group(1))
                                        except Exception:
                                            cid = None
                                    if cid is None:
                                        # Try CourseConversationManager helper
                                        try:
                                            cid = CourseConversationManager._extract_course_name_from_message(message_text)
                                        except Exception:
                                            cid = None

                                    if cid:
                                        logger.info(f"Quick-path: resolved course id {cid} for temario request from {phone}")
                                        # Ensure phone format starts with 521XXXXXXXXXX
                                        original_phone = phone
                                        try:
                                            if isinstance(phone, str) and not phone.startswith('521') and re.match(r'^\+?\d{10,13}$', phone):
                                                # normalize Mexican numbers lacking country code
                                                p = re.sub(r'[^0-9]', '', phone)
                                                if len(p) == 10:
                                                    phone = '521' + p
                                        except Exception:
                                            pass
                                        sent_pdf = send_course_temario_pdf(phone, cid, None)
                                        if sent_pdf:
                                            logger.info(f"Temario PDF enviado (quick-path) para curso {cid} a {phone}")
                                        else:
                                            logger.info(f"Temario PDF no encontrado/enviado (quick-path) para curso {cid} a {phone}")
                                    else:
                                        # No course id found; try to send a temario for any selected course
                                        sel = get_selected_course(phone)
                                        if sel and isinstance(sel, dict):
                                            logger.info(f"Quick-path: sending temario for selected course {sel.get('id')} to {phone}")
                                            # normalize phone if needed
                                            try:
                                                p = phone
                                                if isinstance(p, str) and not p.startswith('521') and re.match(r'^\+?\d{10,13}$', p):
                                                    pn = re.sub(r'[^0-9]', '', p)
                                                    if len(pn) == 10:
                                                        p = '521' + pn
                                                _sent = send_course_temario_pdf(p, sel.get('id'), sel.get('name'))
                                            except Exception as _e:
                                                logger.debug(f"Error normalizing phone for temario send: {_e}")
                                                _sent = send_course_temario_pdf(phone, sel.get('id'), sel.get('name'))
                                            if _sent:
                                                logger.info(f"Temario PDF enviado para curso seleccionado {sel.get('id')} to {phone}")
                            except Exception as _t:
                                logger.debug(f"Error quick-sending temario PDF: {_t}")

                            # Quick-path: if user is asking to contact an advisor, start advisor flow
                            try:
                                advisor_triggers = ['asesor', 'contactar', 'quiero hablar', 'hablar con', 'contacto']
                                if any(k in (message_text or '').lower() for k in advisor_triggers):
                                    # Normalize phone before starting advisor flow
                                    pnum = phone
                                    try:
                                        if isinstance(pnum, str) and not pnum.startswith('521') and re.match(r'^\+?\d{10,13}$', pnum):
                                            pn = re.sub(r'[^0-9]', '', pnum)
                                            if len(pn) == 10:
                                                pnum = '521' + pn
                                    except Exception:
                                        pass
                                    # Start advisor flow and stop further processing
                                    started = start_advisor_flow(pnum, course_id=None)
                                    if started:
                                        logger.info(f"Started advisor flow (quick-path) for {pnum} (original {phone})")
                                        continue
                            except Exception:
                                pass

                            continue

                    # Si el usuario es nuevo y no sabe qué curso elegir, iniciar flujo de descubrimiento
                    # Detectar frases tipo: "no se que curso tomar", "no se que elegir", "que me recomiendas"
                    try:
                        newbie_phrases = ['no se que curso', 'no sé que curso', 'no se que elegir', 'no sé que elegir', 'que me recomiendas', 'qué me recomiendas', 'no se que tomar']
                        if any(p in (message_text or '').lower() for p in newbie_phrases) and not is_technical_question:
                            # Preguntar 2-3 preguntas abiertas para recomendar curso
                            discovery_q = (
                                "Perfecto — para recomendarte el mejor curso, cuéntame brevemente:\n"
                                "1) ¿Qué tema te interesa aprender o qué quieres mejorar? (ej. empalmes, FTTH, cableado estructurado)\n"
                                "2) ¿Trabajas en campo o en proyecto/planificación?\n"
                                "3) ¿Tienes experiencia previa en fibra o redes? (principiante/intermedio/avanzado)"
                            )
                            send_text_message(phone, discovery_q)
                            try:
                                save_conversation_memory(phone, 'awaiting_discovery_answers', True)
                            except Exception:
                                logger.debug('No se pudo guardar awaiting_discovery_answers')
                            continue
                    except Exception as _disc_e:
                        logger.debug(f"Error iniciando flujo de descubrimiento: {_disc_e}")
                    
                    # La detección de consultas técnicas se maneja arriba y prioriza ese flujo.
                    # Evitamos redefinir la función o re-evaluar aquí para mantener la prioridad aplicada.
                    
                    # Variables para el flujo posterior
                    avoid_curso_intent = False
                    is_technical_question = (user_intent_type == 'tecnica')
                    is_course_question = (user_intent_type == 'cursos')
                    is_product_question = (user_intent_type == 'productos')
                    is_advisor_request = (user_intent_type == 'asesoria')
                    system_prompt_override = None
                    
                    # Crear system prompts específicos según el tipo de intent
                    intent_prompts = {
                        'tecnica': """
ERES UN EXPERTO TÉCNICO EN FIBRA ÓPTICA Y REDES DE TELECOMUNICACIONES.

ESPECIALIDADES:
- Fibra óptica y sus aplicaciones
- Redes FTTH, GPON, PON, PONLAN
- Equipos: OTDR, fusionadoras, cleavers, power meters
- Cableado estructurado UTP/STP
- Mediciones y pruebas de fibra
- Instalación y mantenimiento
- Diagnóstico y resolución de problemas

INSTRUCCIONES:
1. Responde con información técnica precisa y detallada
2. Usa terminología profesional apropiada
3. Incluye valores específicos, procedimientos paso a paso
4. Menciona herramientas y equipos necesarios
5. Proporciona soluciones prácticas
6. NO ofrezcas cursos a menos que sea estrictamente relevante
7. Enfócate en resolver la consulta técnica específica

Responde de manera profesional y técnica a la consulta del usuario.
""",
                        'cursos': """
ERES UN CONSULTOR EDUCATIVO ESPECIALIZADO EN CURSOS DE FIBRA ÓPTICA Y TELECOMUNICACIONES.

INFORMACIÓN DE CURSOS:
1. Cableado Estructurado - 13-14 Oct 2025 - Precio: Consultar
2. Fibra Óptica Planta Externa - 15-16 Oct 2025 - Precio: Consultar  
3. FTTH para WISP e ISP - 10-11 Sep 2025 - Precio: $299 USD + IVA
4. PONLAN Enterprise - 12-13 Nov 2025 - Precio: Consultar
5. Empalmes y OTDR - 7 Nov 2025 - Precio: Consultar

UBICACIÓN: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
HORARIO: 9:00 a 19:00 hrs
DURACIÓN: 16 horas (2 días)

INSTRUCCIONES:
1. Proporciona información completa de fechas, precios y temarios
2. Recomienda el curso más adecuado según la consulta
3. Incluye detalles de ubicación y modalidad
4. Menciona certificación DC3 cuando aplique
5. Ofrece temarios detallados si se solicitan

Ayuda al usuario a encontrar el curso perfecto para sus necesidades.
""",
                        'productos': """
ERES UN ESPECIALISTA EN PRODUCTOS DE FIBRA ÓPTICA Y CABLEADO.

PRODUCTOS PRINCIPALES:
- Bobinas UTP (Cat. 5e, 6, 6A) - 100% cobre
- Ductos para fibra óptica (HDPE, corrugado, liso)
- Tritubo para optimización de espacio
- Jumpers MPO/MTP/MTP Pro para data centers

INSTRUCCIONES:
1. Proporciona especificaciones técnicas detalladas
2. Explica aplicaciones y ventajas
3. Solicita información específica para cotización
4. Relaciona con cursos relevantes cuando sea apropiado
5. Incluye datos de rendimiento y certificaciones

Ayuda al usuario a encontrar el producto adecuado para su proyecto.
""",
                        'general': """
ERES UN ASISTENTE ESPECIALIZADO DE FIBREMEX, EMPRESA LÍDER EN FIBRA ÓPTICA.

INFORMACIÓN EMPRESA:
- Especialistas en fibra óptica y telecomunicaciones
- Cursos presenciales en Querétaro
- Productos de alta calidad
- Ubicación: Parque Industrial Tecnológico Innovación, Qro.

INSTRUCCIONES:
1. Responde consultas generales sobre la empresa
2. Proporciona información de contacto y ubicación
3. Explica servicios y productos disponibles
4. Mantén un tono profesional y amigable
5. Deriva a especialistas cuando sea necesario

Ayuda al usuario con información general sobre Fibremex.
"""
                    }
                    
                    msg_lower = message_text.lower()

                    # Helper: detectar peticiones explícitas de cursos/webinars (evitar false-positives)
                    def is_explicit_course_or_webinar_request(text: str) -> bool:
                        t = (text or '').lower()
                        # casos claros: menciona 'webinar' o 'webinars' o 'seminario'
                        if any(k in t for k in ['webinar', 'webinars', 'seminario', 'seminarios']):
                            return True
                        # peticiones directas de curso: 'quiero información sobre el curso', 'tienen curso', 'qué cursos', 'cuentas con cursos', 'cuentas con opciones online'
                        direct_phrases = ['quiero información sobre el curso', 'quiero informacion sobre el curso', 'qué cursos', 'que cursos', 'tienen curso', 'tienen cursos', 'cuentas con', 'cuentas con opciones', 'me interesa el curso', 'me interesa aprender', 'qué curso recomiendan', 'curso recomiendan', 'curso recomiendas']
                        if any(p in t for p in direct_phrases):
                            return True
                        # también si pregunta con palabras clave 'temario' o 'inscripcion' de forma directa
                        if any(k in t for k in ['temario', 'inscripción', 'inscripcion', 'fechas del curso', 'fecha del curso', 'fechas']):
                            # asegúrate de que no está dentro de una frase claramente técnica
                            if not any(k in t for k in ['problema', 'error', 'no funciona', 'fallo', 'instal']):
                                return True
                        return False
                    
                    # Detectar si el usuario explícitamente no quiere hablar de cursos
                    if ('no quiero' in msg_lower and 
                        any(curso_word in msg_lower for curso_word in ['curso', 'cursos', 'hablar de eso'])):
                        avoid_curso_intent = True
                        logger.warning(f"Usuario explícitamente no quiere hablar de cursos: {message_text}")
                    
                    # Log detallado de la clasificación
                    if intent_confidence > 0.7:
                        logger.info(f"Alta confianza en clasificación: {user_intent_type}")
                    else:
                        logger.warning(f"Baja confianza en clasificación: {user_intent_type} ({intent_confidence:.2f})")
                        # En caso de baja confianza, usar contexto adicional
                        if conversation_history and len(conversation_history) > 0:
                            # Analizar el contexto previo PARA MEJORAR LA CLASIFICACIÓN
                            # IMPORTANT: use only prior USER messages (user_message) and avoid
                            # using bot responses or previously generated AI content because
                            # that can create false positives for course/product detection.
                            recent_user_messages = ' '.join([
                                turn.get('user_message', '') for turn in conversation_history[-3:]
                            ])
                            context_classification = classify_user_intent(recent_user_messages + ' ' + message_text)
                            if context_classification['confidence'] > intent_confidence:
                                logger.info(f"Mejorando clasificación con contexto: {context_classification['type']}")
                                user_intent_type = context_classification['type']
                                intent_confidence = context_classification['confidence']

                    # Manejo si previamente pedimos una aclaración: NO pedir al usuario, sino
                    # re-clasificar automáticamente usando el texto completo y limpiar la bandera.
                    pending_clarify = get_conversation_memory(phone, 'awaiting_intent_clarification')
                    if pending_clarify:
                        try:
                            reclass = classify_user_intent(message_text, conversation_history)
                            user_intent_type = reclass.get('type') or user_intent_type
                            intent_confidence = reclass.get('confidence', intent_confidence)
                            is_technical_question = (user_intent_type == 'tecnica')
                            is_course_question = (user_intent_type == 'cursos')
                            is_product_question = (user_intent_type == 'productos')
                            is_advisor_request = (user_intent_type == 'asesoria')
                            try:
                                save_conversation_memory(phone, 'awaiting_intent_clarification', False)
                                save_conversation_memory(phone, 'intent_clarified', user_intent_type)
                            except Exception:
                                logger.debug('No se pudo limpiar awaiting_intent_clarification')
                            logger.info(f"Intención automáticamente reclasificada para {phone}: {user_intent_type} (conf {intent_confidence:.2f})")
                        except Exception as e:
                            # Si hay error, simplemente limpiar la bandera y continuar con la clasificación actual
                            try:
                                save_conversation_memory(phone, 'awaiting_intent_clarification', False)
                            except Exception:
                                logger.debug('No se pudo limpiar awaiting_intent_clarification tras error')
                            logger.debug(f"Error reclasificando durante awaiting_intent_clarification: {e}")

                    # Si el usuario pide terminar el flujo de curso, limpiar la selección

                    # Si el usuario pide terminar el flujo de curso, limpiar la selección
                    if any(cmd in message_text.lower() for cmd in clear_course_commands):
                        try:
                            clear_selected_course(phone)
                            send_text_message(phone, "He finalizado la selección de curso. ¿En qué más puedo ayudarte?")
                            logger.info(f"Curso seleccionado limpiado para {phone} por comando del usuario")
                            # Continue to next webhook processing (no course-specific behavior)
                            continue
                        except Exception:
                            logger.debug("No se pudo limpiar la selección de curso (o no existía)")
                    
                    # Verificar si el usuario explícitamente no quiere hablar de cursos
                    if ('no quiero' in message_text.lower() and 
                        any(curso_word in message_text.lower() for curso_word in ['curso', 'cursos', 'hablar de eso'])):
                        avoid_curso_intent = True
                        logger.warning(f"Usuario explícitamente no quiere hablar de cursos: {message_text}")
                    
                    is_topic_shift = any(keyword in message_text.lower() for keyword in topic_shift_keywords)
                    
                    # Sistema inteligente de manejo de contexto basado en la clasificación
                    should_reset_context = False
                    context_reset_reason = ""
                    
                    # Definir system prompts específicos por tipo de intención
                    intent_prompts = {
                        'tecnica': (
                            "El usuario ha hecho una PREGUNTA TÉCNICA sobre fibra óptica, redes o telecomunicaciones. "
                            "Responde como un experto técnico proporcionando información técnica precisa, paso a paso. "
                            "Al final, OPCIONALMENTE puedes sugerir un curso relacionado si es relevante, pero la prioridad "
                            "es resolver su problema técnico actual."
                        ),
                        'cursos': (
                            "El usuario está interesado en CURSOS y CAPACITACIONES. Proporciona información detallada "
                            "sobre los cursos disponibles, incluyendo temarios, fechas, precios, modalidades y beneficios. "
                            "Ayúdalo a seleccionar el curso más adecuado para sus necesidades."
                        ),
                        'productos': (
                            "El usuario está consultando sobre PRODUCTOS (bobinas, ductos, cables, etc.). "
                            "Proporciona información técnica de los productos, características, disponibilidad y precios. "
                            "Si necesita cotización personalizada, ofrece conectarlo con un asesor."
                        ),
                        'asesoria': (
                            "El usuario solicita ASESORÍA PERSONALIZADA. Recopila sus datos de contacto y información "
                            "sobre su proyecto o necesidades específicas para conectarlo con un asesor especializado."
                        ),
                        'general': (
                            "El usuario hace una consulta GENERAL sobre la empresa, servicios o información básica. "
                            "Proporciona información útil y oriéntalo hacia los servicios más relevantes según su consulta."
                        )
                    }
                    
                    # Determinar si necesitamos resetear el contexto
                    if avoid_curso_intent:
                        should_reset_context = True
                        context_reset_reason = "Usuario rechaza explícitamente cursos"
                        system_prompt_override = "El usuario explícitamente NO quiere hablar de cursos. Responde a su pregunta actual sin mencionar cursos ni formaciones."
                    elif is_topic_shift and len(conversation_history) > 3:
                        should_reset_context = True
                        context_reset_reason = "Cambio de tema detectado"
                        system_prompt_override = intent_prompts.get(user_intent_type, intent_prompts['general'])
                    elif user_intent_type != 'general' and intent_confidence > 0.6:
                        # Si tenemos alta confianza en una intención específica, usar su prompt
                        system_prompt_override = intent_prompts[user_intent_type]
                        # Solo resetear contexto si es muy diferente del tema anterior
                        if len(conversation_history) > 2:
                            should_reset_context = True
                            context_reset_reason = f"Cambio a intención específica: {user_intent_type}"
                    
                    # Aplicar reset de contexto si es necesario
                    if should_reset_context:
                        logger.info(f"Reseteando contexto para {phone}. Razón: {context_reset_reason}")
                        clear_topic_context(phone)
                        # Refrescar el historial después de limpiar
                        try:
                            conversation_history = get_conversation_history(phone)
                        except Exception as refresh_error:
                            logger.error(f"Error al refrescar historial: {refresh_error}")
                            conversation_history = []

                    # Sistema inteligente de manejo de flujos basado en clasificación de intenciones
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor:
                        logger.info(f"Skipping course detection because waiting_for_advisor_data is set for {phone}")
                    
                    # Manejar flujos específicos según el tipo de intención detectado
                    # --- Nueva lógica: si la clasificación es ambigua (baja confianza) y hay señales mixtas, pedir clarificación ---
                    try:
                        ambiguous_signals = 0
                        # señales técnicas
                        if any(k in msg_lower for k in ['problema', 'error', 'instal', 'otdr', 'empalme', 'medición', 'medicion', 'no funciona']):
                            ambiguous_signals += 1
                        # señales de cursos
                        if any(k in msg_lower for k in ['curso', 'cursos', 'temario', 'aprender', 'inscripcion', 'inscribirme']):
                            ambiguous_signals += 2

                        # considerar ambigüedad si confidence baja y ambas clases aparecen o señales mixtas detectadas
                        if intent_confidence < 1.65 and ambiguous_signals >= 3:
                            # En vez de preguntar al usuario, resolvemos automáticamente basados en las
                            # señales de contexto: contamos indicadores técnicos vs indicadores de curso
                            technical_indicators = ['problema', 'error', 'instal', 'otdr', 'empalme', 'empalmes', 'medición', 'medicion', 'no funciona', 'atenuación', 'pérdida', 'loss', 'attenuation']
                            course_indicators = ['curso', 'cursos', 'temario', 'aprender', 'inscripcion', 'inscribirme', 'precio', 'fechas']

                            tech_count = sum(1 for k in technical_indicators if k in msg_lower)
                            course_count = sum(1 for k in course_indicators if k in msg_lower)

                            # Si predominan indicadores técnicos, forzamos intención técnica.
                            if tech_count > course_count and tech_count > 0:
                                user_intent_type = 'tecnica'
                                intent_confidence = max(intent_confidence, 0.75)
                                logger.info(f"Ambigüedad resuelta automáticamente como 'tecnica' para {phone} (tech={tech_count} vs course={course_count})")
                            # Si predominan indicadores de curso, forzamos intención de cursos.
                            elif course_count > tech_count and course_count > 0:
                                user_intent_type = 'cursos'
                                intent_confidence = max(intent_confidence, 0.75)
                                logger.info(f"Ambigüedad resuelta automáticamente como 'cursos' para {phone} (tech={tech_count} vs course={course_count})")
                            else:
                                # Sin predominio claro: usamos la clasificación original pero con ligera elevación
                                intent_confidence = max(intent_confidence, 0.66)
                                logger.info(f"Ambigüedad no resuelta automáticamente para {phone}, se mantiene '{user_intent_type}' con confianza {intent_confidence:.2f}")
                            # Continuar con el flujo normal sin preguntar al usuario
                    except Exception as _amb_e:
                        logger.debug(f"Error en detección de ambigüedad: {_amb_e}")

                    if user_intent_type == 'cursos' and not avoid_curso_intent and not waiting_for_advisor:
                        # Usuario específicamente interesado en cursos - procesar selección de curso
                        logger.info(f"Procesando intención de cursos para {phone} con confianza {intent_confidence:.2f}")
                    elif user_intent_type == 'asesoria' or is_advisor_request:
                        # Usuario solicita asesoría - saltar a flujo de asesor
                        logger.info(f"Redirigiendo a flujo de asesor para {phone}")
                        # El flujo de asesor se maneja más adelante en el código
                    elif user_intent_type == 'productos':
                        # Usuario pregunta por productos - buscar en base de datos de productos
                        logger.info(f"Procesando consulta de productos para {phone}")
                        # El flujo de productos se maneja en las secciones específicas más adelante
                    elif user_intent_type == 'tecnica':
                        # Usuario hace pregunta técnica - responder técnicamente y sugerir curso si es relevante
                        logger.info(f"Procesando pregunta técnica para {phone}")
                        # El flujo técnico se maneja en la sección específica más adelante
                    
                    # Solo intentar detección de cambio de curso si la intención es explícitamente de cursos
                    # y no hay conflictos con otros flujos
                    if user_intent_type == 'cursos' and not avoid_curso_intent and not waiting_for_advisor:
                        try:
                            text_lower = (message_text or '').lower()
                            # Ya no necesitamos contar palabras clave técnicas, ya se evaluó correctamente arriba
                            # Proceder con detección de cambio de curso si no es técnica y no evita cursos
                            
                            # If we recently listed webinars for this user, avoid interpreting
                            # words that match webinar titles as course-change requests to
                            # prevent conflicts between webinar and course flows.
                            try:
                                last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []
                                skip_course_detect = False
                                if last_listed:
                                    try:
                                        from data.db import get_collection
                                        from bson import ObjectId
                                        webinars_col = get_collection('webinars')
                                        # Load webinar titles to check for matches
                                        for e in last_listed:
                                            wid = e.get('_id')
                                            try:
                                                doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                            except Exception:
                                                doc = webinars_col.find_one({'_id': wid})
                                            if doc:
                                                title = (doc.get('title') or doc.get('name') or '')
                                                if title and title.lower() in text_lower:
                                                    skip_course_detect = True
                                                    break
                                                # also check keywords/description
                                                desc = (doc.get('description') or doc.get('desc') or '')
                                                if desc and any(tok in text_lower for tok in desc.lower().split()[:8]):
                                                    skip_course_detect = True
                                                    break
                                    except Exception:
                                        skip_course_detect = False

                                if not skip_course_detect:
                                    course_changed, new_course_name = detect_and_update_course_selection(phone, message_text)
                                else:
                                    logger.info(f"Skipping course-change detection because message appears to reference a recently listed webinar: {message_text}")
                                    course_changed, new_course_name = False, None
                            except Exception as _e:
                                logger.debug(f"Error in webinar/course conflict guard: {_e}")
                                course_changed, new_course_name = detect_and_update_course_selection(phone, message_text)
                            
                            if course_changed:
                                send_text_message(phone, f"Perfecto, cambiamos al curso '{new_course_name}'. ¿Qué quieres saber sobre este curso?")
                                # We sent a course-change confirmation; stop processing this webhook message
                                # to avoid sending an additional reply in the same request.
                                try:
                                    globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = None
                                except Exception:
                                    pass
                                continue
                        except Exception as _e:
                            logger.debug(f"Error running detect_and_update_course_selection: {_e}")
                    
                    # --- Webinar follow-up handler: 'fechas N', 'costos N', 'inscripcion N', 'temario N', 'asesor N', 'detalle N' ---
                    try:
                        import re
                        from bson import ObjectId
                        from data.db import get_collection

                        # Quick handlers: list webinars or courses when user asks, before follow-up parsing
                        tlower = (message_text or '').lower().strip()
                        # Quick patterns
                        webinar_triggers = ['webinar', 'webinars', 'seminario', 'seminarios', 'opciones en linea', 'opciones en línea', 'opciones en línea', 'opciones online']

                        # Direct info requests like 'dame info del seminario de centro de datos' -> try to resolve directly
                        try:
                            direct_info_match = re.search(r"(?:dame\s+info(?:rmaci[oó]n)?|dame\s+detalle|info\s+del|informaci[oó]n\s+del|info\s+sobre|informaci[oó]n\s+sobre)\s*(?:el|la|los|las)?\s*(?:seminario|webinar|curso)?\s*(.+)", tlower)
                        except Exception:
                            direct_info_match = None

                        if direct_info_match:
                            frag = direct_info_match.group(1).strip()
                            if frag:
                                # normalize fragment and strip accents to improve matching
                                frag = re.sub(r"\?$", "", frag).strip()
                                def norm(s):
                                    if not s:
                                        return ''
                                    s = s.lower()
                                    s = unicodedata.normalize('NFKD', s)
                                    s = ''.join([c for c in s if not unicodedata.combining(c)])
                                    return s

                                frag_norm = norm(frag)
                                matches = []
                                try:
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        cursor = webinars_col.find({}).limit(50)
                                        for d in cursor:
                                            title = (d.get('title') or d.get('name') or '')
                                            desc = (d.get('description') or d.get('desc') or '')
                                            tags = ' '.join([str(x) for x in (d.get('tags') or d.get('keywords') or [])])
                                            hay = ' '.join([title, desc, tags])
                                            hay_norm = norm(hay)
                                            # direct containment or all words present
                                            if frag_norm in hay_norm or all(word in hay_norm for word in frag_norm.split() if len(word) > 2):
                                                d['_id'] = str(d.get('_id'))
                                                matches.append(d)
                                except Exception as _e:
                                    logger.debug(f"Error buscando webinar por solicitud directa: {_e}")

                                if len(matches) == 1:
                                    wd = matches[0]
                                    title = wd.get('title') or wd.get('name') or 'Sin título'
                                    date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                    desc = wd.get('description') or wd.get('details') or ''
                                    reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                    price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                    parts = [f"🔎 Información: {title}"]
                                    parts.append(f"📅 Fecha: {date}")
                                    if price:
                                        parts.append(f"💰 Precio: {price}")
                                    if reg_link:
                                        parts.append(f"📝 Inscripción: {reg_link}")
                                    if desc:
                                        parts.append(f"📄 Descripción: {desc}")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': wd.get('_id'), 'title': title}])
                                    send_text_message(phone, "\n\n".join(parts))
                                    continue
                                elif len(matches) > 1:
                                    reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                    for i, m in enumerate(matches, start=1):
                                        reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                    reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in matches])
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue
                        else:
                            # No direct 'dame info' pattern — try to match webinar titles mentioned in the message
                            try:
                                title_matches = []
                                try:
                                    last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []
                                except Exception:
                                    last_listed = []

                                # Check memory-listed webinars first
                                for e in last_listed:
                                    t = (e.get('title') or '').lower()
                                    if not t:
                                        continue
                                    # Direct containment (full title or short phrase)
                                    if t in tlower:
                                        title_matches.append({'_id': e.get('_id'), 'title': e.get('title')})
                                        continue
                                    # Check for common 2-word phrases from the title (bigram match)
                                    parts = [p for p in t.split() if len(p) > 2]
                                    for i in range(len(parts)-1):
                                        big = f"{parts[i]} {parts[i+1]}"
                                        if big in tlower:
                                            title_matches.append({'_id': e.get('_id'), 'title': e.get('title')})
                                            break

                                # If no memory matches, search DB titles
                                if not title_matches:
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        try:
                                            cursor = webinars_col.find({}).limit(50)
                                            for d in cursor:
                                                title = (d.get('title') or d.get('name') or '').lower()
                                                if not title:
                                                    continue
                                                if title in tlower:
                                                    d['_id'] = str(d.get('_id'))
                                                    title_matches.append(d)
                                                    continue
                                                parts = [p for p in title.split() if len(p) > 2]
                                                for i in range(len(parts)-1):
                                                    big = f"{parts[i]} {parts[i+1]}"
                                                    if big in tlower:
                                                        d['_id'] = str(d.get('_id'))
                                                        title_matches.append(d)
                                                        break
                                        except Exception as _e:
                                            logger.debug(f"Error buscando webinars por títulos en DB: {_e}")

                                if len(title_matches) == 1:
                                    wd = title_matches[0]
                                    try:
                                        webinars_col = get_collection('webinars')
                                        if webinars_col and wd.get('_id'):
                                            try:
                                                doc = webinars_col.find_one({'_id': ObjectId(wd.get('_id'))})
                                            except Exception:
                                                doc = webinars_col.find_one({'_id': wd.get('_id')})
                                            if doc:
                                                wd = doc
                                    except Exception:
                                        pass

                                    title = wd.get('title') or wd.get('name') or 'Sin título'
                                    date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                    desc = wd.get('description') or wd.get('details') or ''
                                    reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                    price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                    parts = [f"🔎 Información: {title}"]
                                    parts.append(f"📅 Fecha: {date}")
                                    if price:
                                        parts.append(f"💰 Precio: {price}")
                                    if reg_link:
                                        parts.append(f"📝 Inscripción: {reg_link}")
                                    if desc:
                                        parts.append(f"📄 Descripción: {desc}")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(wd.get('_id')), 'title': title}])
                                    send_text_message(phone, "\n\n".join(parts))
                                    continue
                                elif len(title_matches) > 1:
                                    reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                    for i, m in enumerate(title_matches, start=1):
                                        reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                    reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in title_matches])
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue
                            except Exception as _e:
                                logger.debug(f"Error en matching por título: {_e}")
                        course_triggers = ['cursos online', 'cursos en linea', 'cursos en línea', 'opciones en linea', 'opciones en línea', 'cursos online', 'cursos']

                        # If user explicitly asks for webinars or online options, try to resolve a direct target first
                        if any(k in tlower for k in webinar_triggers) and not any(k in tlower for k in ['precio', 'costos', 'temario', 'fechas', 'inscripcion']):
                            try:
                                # Detect if the user included a fragment (e.g. 'seminario de centro de datos') to directly select
                                frag_match = re.search(r"(?:webinar|webinars|seminario|seminarios)\b(?:\s*(?:de|del|sobre|sobre el|sobre la|en))?\s*(.+)$", tlower)
                                fragment = None
                                if frag_match:
                                    fragment = frag_match.group(1).strip()
                                    # Clean trailing question words
                                    fragment = re.sub(r"\?$", "", fragment).strip()

                                webinars_col = get_collection('webinars')

                                # If we have a fragment, attempt to find matching webinar(s) and respond directly
                                if fragment and webinars_col:
                                    matches = []
                                    try:
                                        # Load a reasonable set and filter client-side for fuzzy containment
                                        cursor = webinars_col.find({}).limit(50)
                                        for d in cursor:
                                            title = (d.get('title') or d.get('name') or '')
                                            desc = (d.get('description') or d.get('desc') or '')
                                            tags = ' '.join([str(x) for x in (d.get('tags') or d.get('keywords') or [])])
                                            hay = ' '.join([title, desc, tags]).lower()
                                            if fragment.lower() in hay:
                                                d['_id'] = str(d.get('_id'))
                                                matches.append(d)
                                    except Exception as _e:
                                        logger.debug(f"Error buscando webinars por fragmento: {_e}")

                                    if len(matches) == 1:
                                        # Directly send the detailed info for the matched webinar
                                        wd = matches[0]
                                        title = wd.get('title') or wd.get('name') or 'Sin título'
                                        date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                        desc = wd.get('description') or wd.get('details') or ''
                                        reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                        price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                        parts = [f"🔎 Información: {title}"]
                                        parts.append(f"📅 Fecha: {date}")
                                        if price:
                                            parts.append(f"💰 Precio: {price}")
                                        if reg_link:
                                            parts.append(f"📝 Inscripción: {reg_link}")
                                        if desc:
                                            parts.append(f"📄 Descripción: {desc}")
                                        # Save the single match into memory so follow-ups like 'temario' work
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': wd.get('_id'), 'title': title}])
                                        send_text_message(phone, "\n\n".join(parts))
                                        continue
                                    elif len(matches) > 1:
                                        # Multiple possible matches: ask to clarify by listing the matching titles
                                        reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                        for i, m in enumerate(matches, start=1):
                                            reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                        reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                        # Save these matches for follow-up selection
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in matches])
                                        send_text_message(phone, "\n".join(reply_parts))
                                        continue

                                # Fallback: list webinars (no fragment or no match)
                                cursor = webinars_col.find({}).limit(10) if webinars_col else []
                                webinar_docs = []
                                reply_lines = ["Estos son los webinars disponibles:"]
                                idx = 0
                                for d in cursor:
                                    idx += 1
                                    title = d.get('title') or d.get('name') or f"Webinar {idx}"
                                    date = d.get('date') or d.get('start_date') or d.get('fecha') or 'Fecha por definir'
                                    webinar_docs.append({'_id': str(d.get('_id')), 'title': title, 'date': date})
                                    reply_lines.append(f"{idx}. {title} — {date}")

                                if webinar_docs:
                                    send_text_message(phone, "\n".join(reply_lines) + "\n\nResponde por ejemplo: 'detalle 1' o 'temario 2' para ver más información.")
                                    # Save the listed webinars for follow-up selection
                                    save_conversation_memory(phone, 'last_listed_webinars', webinar_docs)
                                    continue
                            except Exception as _e:
                                logger.debug(f"Error listando webinars: {_e}")

                        # If user asks about online courses/options, prefer to show webinars (online events)
                        if any(k in tlower for k in ['cursos online', 'cursos en linea', 'cursos en línea', 'opciones en linea', 'opciones en línea']) and not any(k in tlower for k in ['precio', 'costos', 'temario', 'fechas']):
                            try:
                                # delegate to the webinar list handler so users asking for online courses
                                # receive the list of webinars (online options)
                                try:
                                    from routes.webinar_handlers import handle_webinar_list_request
                                except Exception:
                                    # fallback import path
                                    from .webinar_handlers import handle_webinar_list_request
                                handle_webinar_list_request(phone)
                            except Exception as _e:
                                logger.debug(f"Error delegating to webinar list handler: {_e}")
                            continue

                                # Fixed catalog (fallback / complement)
                                fixed_catalog = [
                                    'Cableado estructurado para redes de fibra y cobre',
                                    'Redes de fibra óptica planta externa',
                                    'Redes de fibra óptica FTTH para WISP e ISP',
                                    'PON/LAN redes pasivas para entornos enterprise',
                                    'Empalmes y mediciones con OTDR'
                                ]

                                for ft in fixed_catalog:
                                    key = ft.lower().strip()
                                    if key in seen_titles:
                                        continue
                                    seen_titles.add(key)
                                    idx += 1
                                    combined_list.append({'index': idx, 'title': ft, 'source': 'fixed', 'fixed_id': f'fixed-{idx}'})

                                if not combined_list:
                                    send_text_message(phone, "Lo siento, ahora mismo no tengo cursos disponibles. Intenta más tarde.")
                                    continue

                                # Build reply lines
                                reply_lines = ["Sí, tenemos cursos en línea. Aquí están las opciones:"]
                                for item in combined_list:
                                    reply_lines.append(f"{item['index']}. {item['title']}")

                                reply_lines.append("\nResponde con el número o escribe 'temario 2' para recibir el temario del curso 2.")
                                send_text_message(phone, "\n".join(reply_lines))

                                # Save last listed courses in conversation memory for selection mapping
                                # Save minimal info needed to later respond (index, title, source, id)
                                save_conversation_memory(phone, 'last_listed_courses', combined_list)
                                continue
                            except Exception as _e:
                                logger.debug(f"Error listando cursos online: {_e}")

                        # Match intent keyword and an optional word-based fragment (title keyword or short phrase)
                        follow_match = re.match(r"^(fechas|fecha|costos|precio|precios|inscripcion|inscripción|temario|asesor|detalle|completo)\s*(.*)$", tlower)
                        if follow_match:
                            intent_kw = follow_match.group(1)
                            fragment = (follow_match.group(2) or '').strip()
                            last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []

                            # If no recent webinar listing exists, attempt to load webinars from DB
                            if not last_listed:
                                try:
                                    # load recent or all webinars as a fallback
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        cursor = webinars_col.find({}).limit(10)
                                        webinar_docs = []
                                        for d in cursor:
                                            d['_id'] = str(d.get('_id'))
                                            webinar_docs.append(d)
                                        # store the loaded list in memory for follow-up matching
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': w.get('_id')} for w in webinar_docs])
                                except Exception as _e:
                                    logger.debug(f"Fallback load webinars failed: {_e}")
                                # refresh last_listed after fallback
                                last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []

                            # Load all webinar docs referenced in last_listed to match by words
                            webinars_col = get_collection('webinars')
                            webinar_docs = []
                            for e in last_listed:
                                wid = e.get('_id')
                                try:
                                    doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                except Exception:
                                    doc = webinars_col.find_one({'_id': wid})
                                if doc:
                                    # normalize id to string for local matching
                                    doc['_id'] = str(doc.get('_id'))
                                    webinar_docs.append(doc)

                            # If no docs loaded, ask user to retry listing
                            if not webinar_docs:
                                # Try loading local JSON fallback
                                local_webinars = _load_local_webinars()
                                if local_webinars:
                                    webinar_docs = local_webinars
                                else:
                                    send_text_message(phone, "No pude recuperar los webinars listados anteriormente. Por favor pide 'opciones en línea' para verlos de nuevo.")
                                    continue

                            # If the user provided a fragment: support numeric selection (e.g. 'detalle 2') or text fragment
                            selected_doc = None
                            # compute idx mapping if we have last_listed
                            try:
                                webinar_docs = []
                                webinars_col = get_collection('webinars')
                                for e in last_listed:
                                    wid = e.get('_id')
                                    try:
                                        doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                    except Exception:
                                        doc = webinars_col.find_one({'_id': wid})
                                    if doc:
                                        doc['_id'] = str(doc.get('_id'))
                                        webinar_docs.append(doc)
                            except Exception:
                                webinar_docs = []

                            if fragment:
                                # If fragment is a number, select by index
                                if fragment.isdigit():
                                    try:
                                        sel_idx = int(fragment)
                                        if 1 <= sel_idx <= len(webinar_docs):
                                            selected_doc = webinar_docs[sel_idx-1]
                                    except Exception:
                                        selected_doc = None
                                else:
                                    # text fragment search
                                    frag = fragment.lower()
                                    matches = []
                                    for doc in webinar_docs:
                                        title = (doc.get('title') or doc.get('name') or '').lower()
                                        desc = (doc.get('description') or doc.get('desc') or '').lower()
                                        keywords = ' '.join([str(x).lower() for x in (doc.get('tags') or doc.get('keywords') or [])])
                                        if frag in title or frag in desc or frag in keywords:
                                            matches.append(doc)

                                    if len(matches) == 1:
                                        selected_doc = matches[0]
                                    elif len(matches) > 1:
                                        # Ambiguous: list the candidate titles and ask the user to clarify by number
                                        reply_parts = ["Encontré varios webinars que coinciden con tu palabra:"]
                                        for i, m in enumerate(matches, start=1):
                                            reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                        reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                        send_text_message(phone, "\n".join(reply_parts))
                                        continue
                                    else:
                                        # No match found — ask to rephrase or show the list again
                                        send_text_message(phone, "No encontré un webinar que coincida con esa palabra. Responde 'webinars' para ver la lista completa o usa otra palabra clave del título.")
                                        continue
                            # If no fragment provided: if only one webinar was listed, pick it; otherwise ask for a number
                            else:
                                if len(webinar_docs) == 1:
                                    selected_doc = webinar_docs[0]
                                else:
                                    # Provide quick guidance showing the titles and ask to reply with a number
                                    reply_parts = ["Para darte la información, responde con el número del webinar que te interesa:"]
                                    for i, d in enumerate(webinar_docs, start=1):
                                        reply_parts.append(f"{i}. {d.get('title') or d.get('name')}")
                                    reply_parts.append("Por ejemplo: 'detalle 2' o 'temario 1'.")
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue

                            # At this point we have a selected_doc
                            webinar_doc = selected_doc

                            # Compute index of the selected_doc within the last_listed for reference in replies
                            try:
                                idx = None
                                for i, d in enumerate(webinar_docs, start=1):
                                    if str(d.get('_id')) == str(webinar_doc.get('_id')):
                                        idx = i
                                        break
                            except Exception:
                                idx = None

                            # Handle requested info types
                            if intent_kw in ('fechas', 'fecha'):
                                dates = webinar_doc.get('date') or webinar_doc.get('start_date') or webinar_doc.get('fecha') or 'Fecha por definir'
                                send_text_message(phone, f"Fechas del webinar '{webinar_doc.get('title') or webinar_doc.get('name') or ''}': {dates}")
                                continue

                            if intent_kw in ('costos', 'precio', 'precios'):
                                # Per product owner: webinars and online courses are free and held online every Tuesday
                                send_text_message(phone, "Gratis — se imparte en línea todos los martes.")
                                continue

                            if intent_kw in ('inscripcion', 'inscripción'):
                                enroll = webinar_doc.get('enroll_link') or webinar_doc.get('registration') or webinar_doc.get('inscripcion') or webinar_doc.get('signup')
                                fallback_webinars_link = "https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online"
                                if enroll:
                                    send_text_message(phone, f"Inscripción al webinar '{webinar_doc.get('title') or webinar_doc.get('name') or ''}': {enroll}")
                                else:
                                    # Inform user of the global webinars page when a specific registration link is missing
                                    send_text_message(phone, f"No tenemos un enlace directo de inscripción para este webinar. Puedes consultar el calendario y registrarte aquí: {fallback_webinars_link}\n\nSi quieres, dime y te contacto con un asesor para ayudarte con la inscripción.")
                                continue

                            if intent_kw == 'asesor':
                                advisor = webinar_doc.get('advisor') or webinar_doc.get('asesor')
                                if advisor:
                                    send_text_message(phone, f"Asesor/ponente: {advisor}")
                                else:
                                    send_text_message(phone, "No hay información de asesor registrada para ese webinar.")
                                continue

                            if intent_kw in ('temario', 'completo', 'detalle'):
                                # Use existing temario send logic: temario might be a url, a local file path, or plain text
                                temario = webinar_doc.get('temario') or webinar_doc.get('syllabus') or webinar_doc.get('content')
                                if not temario:
                                    # fallback to sending the full document/description text
                                    desc = webinar_doc.get('description') or webinar_doc.get('details') or 'No hay temario disponible.'
                                    send_text_message(phone, desc)
                                    continue

                                # If temario is a dict that includes path or url
                                if isinstance(temario, dict):
                                    tpath = temario.get('path') or temario.get('file') or temario.get('url')
                                else:
                                    tpath = temario

                                # If it's a URL, download and send as document; if local path, send directly; else send as text/link
                                if isinstance(tpath, str) and (tpath.startswith('http://') or tpath.startswith('https://')):
                                    # download to temp and send
                                    tmpdir = tempfile.gettempdir()
                                    local_tmp = os.path.join(tmpdir, f"temario_{phone}_{int(time.time())}.pdf")
                                    try:
                                        r = requests.get(tpath, stream=True, timeout=10)
                                        if r.status_code == 200:
                                            with open(local_tmp, 'wb') as f:
                                                for chunk in r.iter_content(8192):
                                                    f.write(chunk)
                                            send_document_message(phone, local_tmp, caption=f"Temario: {webinar_doc.get('title') or webinar_doc.get('name')}")
                                        else:
                                            # send the link as fallback
                                            send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                    except Exception as e:
                                        logger.debug(f"Error descargando temario url: {e}")
                                        send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                    finally:
                                        try:
                                            if os.path.exists(local_tmp):
                                                os.remove(local_tmp)
                                        except Exception:
                                            pass
                                    continue

                                # Local path
                                if isinstance(tpath, str) and os.path.exists(tpath):
                                    try:
                                        send_document_message(phone, tpath, caption=f"Temario: {webinar_doc.get('title') or webinar_doc.get('name')}")
                                    except Exception as e:
                                        logger.debug(f"Error enviando temario local: {e}")
                                        send_text_message(phone, "Hubo un error enviando el temario. Intenta de nuevo más tarde.")
                                    continue

                                # Otherwise, send as a text or link
                                send_text_message(phone, str(tpath))
                                continue

                        # ALSO: support course follow-ups when user replies like 'temario 2' or 'detalle 3'
                        course_follow_match = re.match(r"^(fechas|fecha|costos|precio|precios|inscripcion|inscripción|temario|detalle)\s*(.*)$", tlower)
                        if course_follow_match:
                            c_kw = course_follow_match.group(1)
                            c_frag = (course_follow_match.group(2) or '').strip()
                            last_courses = get_conversation_memory(phone, 'last_listed_courses') or []

                            if not last_courses:
                                # No recent list: prompt user to ask for courses list
                                send_text_message(phone, "Responde 'cursos' o 'cursos online' para ver las opciones disponibles.")
                                # fallthrough
                            else:
                                sel = None
                                # if numeric, select by index
                                if c_frag.isdigit():
                                    n = int(c_frag)
                                    for it in last_courses:
                                        if int(it.get('index')) == n:
                                            sel = it
                                            break
                                else:
                                    # try to match by title fragment
                                    frag = c_frag.lower()
                                    for it in last_courses:
                                        if frag in (it.get('title') or '').lower():
                                            sel = it
                                            break

                                if not sel:
                                    # Usar IA para responder en lugar de mensaje hardcodeado
                                    try:
                                        from services.chat_ai import chat_with_gemini
                                        ai_response = chat_with_gemini(
                                            phone=phone,
                                            message=message_text,
                                            system_prompt="El usuario pidió información sobre un curso pero no identifiqué cuál específicamente. Ayúdalo de manera amigable a especificar cuál de los 5 cursos de fibra óptica le interesa."
                                        )
                                        send_text_message(phone, ai_response if ai_response else "¿Podrías especificar cuál curso te interesa? Puedo ayudarte con información específica.")
                                    except Exception:
                                        send_text_message(phone, "¿Podrías especificar cuál curso te interesa? Puedo ayudarte con información específica.")
                                else:
                                    # If source is db, fetch full doc
                                    if sel.get('source') == 'db':
                                        courses_col = get_collection('courses')
                                        try:
                                            doc = courses_col.find_one({'_id': ObjectId(sel.get('_id'))})
                                        except Exception:
                                            doc = courses_col.find_one({'_id': sel.get('_id')})
                                        if doc:
                                            course_doc = doc
                                        else:
                                            course_doc = {'title': sel.get('title')}
                                    else:
                                        # fixed source: try to map to local asset pdf by title keywords
                                        course_doc = {'title': sel.get('title')}

                                        # Handle requested field
                                        if c_kw in ('costos', 'precio', 'precios'):
                                            send_text_message(phone, "Gratis — se imparte en línea todos los martes.")
                                            continue

                                        if c_kw in ('fechas', 'fecha'):
                                            dates = course_doc.get('date') or course_doc.get('start_date') or 'Fechas por definir'
                                            send_text_message(phone, f"Fechas del curso '{course_doc.get('title')}': {dates}")
                                            continue

                                        if c_kw in ('inscripcion', 'inscripción'):
                                            enroll = course_doc.get('enroll_link') or course_doc.get('registration') or course_doc.get('signup')
                                            fallback_webinars_link = "https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online"
                                            if enroll:
                                                send_text_message(phone, f"Inscripción: {enroll}")
                                            else:
                                                send_text_message(phone, f"No encontré un enlace de inscripción específico. Puedes revisar las opciones y fechas aquí: {fallback_webinars_link} \nSi quieres que te ayude con la inscripción, responde 'sí'.")
                                            continue

                                        # temario / detalle
                                        if c_kw in ('temario', 'detalle', 'completo'):
                                            tem = None
                                            if sel.get('source') == 'db' and course_doc.get('temario'):
                                                tem = course_doc.get('temario')
                                            else:
                                                # try known local asset mapping by simple filename convention
                                                # e.g., look for PDFs in ../assets matching keywords from title
                                                title_key = (sel.get('title') or '').lower()
                                                # try to match one of known assets by filename
                                                found = None
                                                assets_dir = os.path.join(os.path.dirname(__file__), '..', 'assets')
                                                try:
                                                    for fname in os.listdir(assets_dir):
                                                            if fname.lower().endswith('.pdf'):
                                                                # normalize both strings and check if most significant words match
                                                                norm_fname = re.sub(r'^\d+[\._\-\s]*', '', os.path.splitext(fname)[0]).lower()
                                                                # count matching tokens
                                                                title_tokens = [t for t in title_key.split() if len(t) > 3]
                                                                matches = sum(1 for t in title_tokens if t in norm_fname)
                                                                if matches >= max(1, min(3, len(title_tokens))):
                                                                    found = os.path.join(assets_dir, fname)
                                                                    break
                                                except Exception:
                                                    found = None
                                                tem = found

                                            if not tem:
                                                # fallback: send description or simple message
                                                desc = course_doc.get('description') or course_doc.get('details') or 'No hay temario disponible.'
                                                send_text_message(phone, desc)
                                                continue

                                            # If tem is dict or url or local path: reuse temario send logic
                                            if isinstance(tem, dict):
                                                tpath = tem.get('path') or tem.get('file') or tem.get('url')
                                            else:
                                                tpath = tem

                                            if isinstance(tpath, str) and (tpath.startswith('http://') or tpath.startswith('https://')):
                                                tmpdir = tempfile.gettempdir()
                                                local_tmp = os.path.join(tmpdir, f"temario_course_{phone}_{int(time.time())}.pdf")
                                                try:
                                                    r = requests.get(tpath, stream=True, timeout=10)
                                                    if r.status_code == 200:
                                                        with open(local_tmp, 'wb') as f:
                                                            for chunk in r.iter_content(8192):
                                                                f.write(chunk)
                                                        send_document_message(phone, local_tmp, caption=f"Temario: {course_doc.get('title')}")
                                                    else:
                                                        send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                                except Exception as e:
                                                    logger.debug(f"Error descargando temario curso url: {e}")
                                                    send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                                finally:
                                                    try:
                                                        if os.path.exists(local_tmp):
                                                            os.remove(local_tmp)
                                                    except Exception:
                                                        pass
                                                continue

                                            if isinstance(tpath, str) and os.path.exists(tpath):
                                                try:
                                                    send_document_message(phone, tpath, caption=f"Temario: {course_doc.get('title')}")
                                                except Exception as e:
                                                    logger.debug(f"Error enviando temario local curso: {e}")
                                                    send_text_message(phone, "Hubo un error enviando el temario. Intenta de nuevo más tarde.")
                                                continue

                                            send_text_message(phone, str(tpath))
                                            continue

                            # Build partial/full responses
                            title = webinar_doc.get('title') or webinar_doc.get('name') or 'Sin título'
                            desc = webinar_doc.get('description') or webinar_doc.get('desc') or ''
                            date = webinar_doc.get('date') or webinar_doc.get('start_date') or webinar_doc.get('fecha') or 'Fecha por definir'
                            price = webinar_doc.get('price') or webinar_doc.get('cost') or webinar_doc.get('costo') or 'Consultar'
                            reg_link = webinar_doc.get('registration_link') or webinar_doc.get('link') or ''
                            temario = webinar_doc.get('temario') or webinar_doc.get('pdf') or webinar_doc.get('materials')
                            # Normalize modality: if the webinar is online, present fixed phrasing
                            raw_mod = (webinar_doc.get('modalidad') or webinar_doc.get('modality') or webinar_doc.get('format') or '').lower()
                            if 'online' in raw_mod or 'línea' in raw_mod or 'en linea' in raw_mod or 'en línea' in raw_mod or raw_mod == '':
                                modality_display = 'en línea (cada martes)'
                            else:
                                modality_display = webinar_doc.get('modalidad') or webinar_doc.get('modality') or 'Presencial'

                            if intent_kw in ['fechas', 'fecha']:
                                resp = f"📅 Fechas del webinar '{title}':\n{date}\n\nSi quieres más, responde 'detalle {idx}' para ver la información completa."
                                send_text_message(phone, resp)
                                continue

                            if intent_kw in ['costos', 'precio', 'precios']:
                                # If price is not provided, offer advisor contact
                                if not price or str(price).lower() in ['consultar', 'n/a', '']:
                                    send_text_message(phone, f"No se encontró precio para '{title}'. ¿Quieres que un asesor te contacte para una cotización? Responde 'sí' o 'no'.")
                                    # Save pending advisor confirmation for this webinar
                                    save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', {'webinar_id': webinar_doc.get('_id'), 'title': title})
                                else:
                                    resp = f"💰 Precio del webinar '{title}':\n{price}\n\nPara detalles completos responde 'detalle {idx}'."
                                    send_text_message(phone, resp)
                                continue

                            if intent_kw in ['inscripcion', 'inscripción']:
                                fallback_webinars_link = "https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online"
                                if reg_link:
                                    resp = f"📝 Inscripción para '{title}':\nRegístrate aquí: {reg_link}\n\nSi necesitas ayuda para inscribirte, responde 'asesor {idx}'."
                                else:
                                    resp = (f"📝 Inscripción para '{title}':\nNo hay enlace directo en el registro. "
                                            f"Puedes ver el calendario y registrarte aquí: {fallback_webinars_link}\n\n"
                                            f"Responde 'detalle {idx}' para más información o pide que un asesor te contacte escribiendo 'asesor {idx}'.")
                                send_text_message(phone, resp)
                                continue

                            if intent_kw in ['temario']:
                                import os
                                import tempfile
                                import requests

                                if temario:
                                    # temario can be: a local path, an http(s) url, a plain text, or a dict with url/path
                                    # Normalize if dict
                                    if isinstance(temario, dict):
                                        temario_url = temario.get('url') or temario.get('path') or temario.get('pdf')
                                    else:
                                        temario_url = temario

                                    # If it's a string and ends with .pdf, try to send as document
                                    if isinstance(temario_url, str) and temario_url.lower().endswith('.pdf'):
                                        # Local file path
                                        try:
                                            if os.path.exists(temario_url):
                                                send_document_message(phone, temario_url, caption=f"Temario: {title}")
                                                send_text_message(phone, f"Te envié el temario de '{title}'. ¿Deseas también fechas, precio o inscripción?")
                                                continue
                                        except Exception:
                                            # proceed to try as URL
                                            pass

                                        # If it's a URL (http/https), try to download to a temp file and send
                                        try:
                                            if isinstance(temario_url, str) and temario_url.lower().startswith(('http://', 'https://')):
                                                r = requests.get(temario_url, timeout=15)
                                                if r.status_code == 200 and r.content:
                                                    tf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
                                                    tf.write(r.content)
                                                    tf.flush()
                                                    tf.close()
                                                    send_document_message(phone, tf.name, caption=f"Temario: {title}")
                                                    send_text_message(phone, f"Te envié el temario de '{title}'. ¿Deseas también fechas, precio o inscripción?")
                                                    try:
                                                        os.unlink(tf.name)
                                                    except Exception:
                                                        pass
                                                    continue
                                                # if download failed, fallthrough to send link/text
                                        except Exception as _dl_e:
                                            logger.debug(f"No se pudo descargar temario desde URL: {_dl_e}")

                                    # If not a PDF or we couldn't send as document, send as text/link
                                    # If it's a URL, include it; otherwise send the temario text
                                    if isinstance(temario, str) and temario.lower().startswith(('http://','https://')):
                                        send_text_message(phone, f"Puedes ver/descargar el temario de '{title}' aquí: {temario}\n\n¿Deseas también fechas, precio o inscripción?")
                                    else:
                                        send_text_message(phone, f"Temario de '{title}':\n{temario}\n\nResponde 'detalle' para la información completa.")
                                else:
                                    send_text_message(phone, f"No hay temario disponible para '{title}'. Puedes pedir 'detalle' o solicitar un asesor con 'asesor'.")
                                continue

                            if intent_kw in ['asesor']:
                                # Save advisor request and include webinar id
                                save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                save_conversation_memory(phone, 'advisor_course_id', wid)
                                send_text_message(phone, f"Perfecto, un asesor puede contactarte para el webinar '{title}'. Por favor envía: Nombre completo, correo y breve descripción de tu solicitud.")
                                continue

                            if intent_kw in ['detalle', 'completo', 'completo']:
                                parts = [f"🔎 Detalle completo: {title}"]
                                if date:
                                    parts.append(f"📅 Fechas: {date}")
                                if price:
                                    parts.append(f"💰 Precio: {price}")
                                if reg_link:
                                    parts.append(f"📝 Inscripción: {reg_link}")
                                if desc:
                                    parts.append(f"📄 Descripción: {desc}")
                                if temario:
                                    parts.append("📚 Temario disponible. Pide 'temario {idx}' para recibirlo.")
                                parts.append("\nSi quieres que te contacte un asesor escribe 'asesor {idx}'.")
                                send_text_message(phone, "\n\n".join(parts))
                                continue
                    except Exception as follow_e:
                        logger.debug(f"Error handling webinar follow-up: {follow_e}")

                    # If user was asked whether they want an advisor for a webinar, handle simple yes/no replies first
                    try:
                        pending_adv = get_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar')
                        if pending_adv and isinstance(pending_adv, dict):
                            # Normalize simple affirmative/negative
                            txt = (message_text or '').strip().lower()
                            if txt in ['si', 'sí', 's', 'yes']:
                                # User accepts advisor contact — ask for contact details
                                wid = pending_adv.get('webinar_id')
                                title = pending_adv.get('title')
                                send_text_message(phone, f"Perfecto, un asesor puede contactarte para '{title}'. Por favor envía: Nombre completo, correo y breve descripción de tu solicitud.")
                                save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                save_conversation_memory(phone, 'advisor_course_id', wid)
                                # clear the pending confirmation
                                save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', None)
                                continue
                            elif txt in ['no', 'n', 'nope']:
                                send_text_message(phone, "Entendido, no contactaré a un asesor por ahora. Si cambias de opinión, escribe 'asesor' o 'asesor {id}'.")
                                save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', None)
                                continue
                    except Exception as _e:
                        logger.debug(f"Error handling webinar advisor yes/no: {_e}")

                    # Prioritize deterministic course selection from explicit natural messages
                    try:
                        selected, sel_name = detect_and_update_course_selection(phone, message_text)
                        if selected:
                            logger.info(f"Course selection handled deterministically: {sel_name}")
                            # We already responded inside detect_and_update_course_selection
                            continue
                    except Exception as det_err:
                        logger.debug(f"deterministic course selection check failed: {det_err}")

                    # Procesar el mensaje con nuestro adaptador ML que maneja PDFs y notificaciones
                    try:
                        ml_adapter_result = process_message(
                            phone=phone, 
                            message_text=message_text, 
                            conversation_history=conversation_history,
                            whatsapp_profile=whatsapp_profile,
                            skip_course_processing=is_technical_question
                        )
                        logger.info(f"Procesamiento ML completado para {phone}")
                    except Exception as ml_error:
                        logger.error(f"Error en procesamiento ML: {ml_error}", exc_info=True)
                        # Crear un resultado predeterminado para continuar
                        ml_adapter_result = {
                            'pdf_sent': False,
                            'notification_sent': False,
                            'system_prompt': None
                        }
                        logger.warning("Usando resultado ML predeterminado debido a error")
                    
                    # Si se envió un PDF, posiblemente continuemos con respuesta adicional
                    pdf_sent = ml_adapter_result.get('pdf_sent', False)
                    if pdf_sent:
                        logger.info(f"PDF encontrado para envío: {ml_adapter_result.get('pdf_path')}")
                        course_name = ml_adapter_result.get('course_name', 'del curso')
                        course_id = ml_adapter_result.get('course_id', 0)
                        pdf_path = ml_adapter_result.get('pdf_path')
                        # Intentar enviar el documento inmediatamente
                        try:
                            send_result = send_document_message(phone, pdf_path, caption=f"Temario {course_name}")
                            if send_result:
                                logger.info(f"Documento enviado correctamente a {phone}: {pdf_path}")
                            else:
                                logger.warning(f"Fallo al enviar documento a {phone}. Se enviará confirmación sin archivo.")
                        except Exception as e:
                            logger.error(f"Error al enviar documento a {phone}: {e}", exc_info=True)
                        
                        # Guardar información del curso seleccionado en la memoria de conversación
                        if course_id and course_name:
                            # Obtener detalles adicionales del curso si están disponibles
                            course_details = {
                                "pdf_path": ml_adapter_result.get('pdf_path', ''),
                                "sent_at": datetime.now().isoformat()
                            }
                            
                            # Guardar el curso seleccionado en la memoria persistente
                            save_selected_course(phone, course_id, course_name, course_details)
                            logger.info(f"Curso seleccionado guardado para {phone}: {course_id} - {course_name}")
                            
                        send_text_message(phone, f"Te envié el temario en PDF {course_name}. ¿Deseas que también te comparta fechas, precio y ubicación del curso?")
                        # Continuar al siguiente mensaje, ya respondimos a este
                        continue

                    # --- Manejo específico de cotizaciones / inscripción / opciones online / ubicación ---
                    # MEJORA: Detectar intención de cotización / precio / factura con prioridad sobre clasificación técnica
                    # Ensure text_lower is defined (some earlier branches may skip its assignment)
                    text_lower = (message_text or '').lower()
                    cotizacion_keywords = ['cotizacion', 'cotizaci', 'precio', 'precio del curso', 'factura', 'facturación', 'facturacion']
                    # Detectar solicitudes de cotización que incluyan contexto de proyecto/ubicación
                    cotizacion_con_proyecto = any(k in (message_text or '').lower() for k in cotizacion_keywords) and any(p in (message_text or '').lower() for p in ['instalacion', 'proyecto', 'zona', 'rural', 'urbana', 'empresa', 'edificio'])
                    inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 'proceso de inscripcion', 'cómo me inscribo', 'como me inscribo']
                    online_keywords = ['online', 'en linea', 'en línea', 'webinar', 'webinars', 'seminario', 'seminarios']

                    # Priorizar manejo de cotizaciones: si detectamos intención de cotización, pedir datos o notificar a asesor
                    text_lower_local = (message_text or '').lower()
                    if any(k in text_lower_local for k in cotizacion_keywords) or cotizacion_con_proyecto:
                        # Si ML ya extrajo datos completos, enviar notificación al asesor
                        client_data = ml_adapter_result.get('ml_results', {}).get('client_data', {})
                        has_contact = bool(client_data.get('nombre') and client_data.get('correo'))

                        # Mensaje para solicitar datos (usando el formato definido en AdvisorRequestManager)
                        request_client_info = advisor_request_prompt()

                        # MEJORA: Si es cotización con proyecto, priorizar asesor sobre respuesta técnica
                        if is_technical_question and not cotizacion_con_proyecto:
                            # Solo para preguntas puramente técnicas sin contexto de cotización
                            send_text_message(phone, "Te respondí la parte técnica. Si quieres que un asesor te contacte, por favor escribe 'asesor' o confirma y te lo gestiono.")
                            # continue to next webhook
                            continue

                        # Si ya tenemos datos suficientes, procesar la notificación
                        if has_contact:
                            try:
                                from services.notification_service import notification_service
                                notify_result = notification_service.process_client_notification(phone, ml_adapter_result.get('ml_results', {}), conversation_history)
                                if notify_result.get('notification_sent'):
                                    send_text_message(phone, "Gracias — ya envié tu solicitud a un asesor. Te contactarán pronto para dar seguimiento.")
                                else:
                                    send_text_message(phone, "Recibí tu solicitud. Por favor comparte tus datos para que podamos derivarla a un asesor: \n" + request_client_info)
                            except Exception as e:
                                logger.error(f"Error enviando notificación al asesor: {e}")
                                send_text_message(phone, "Estamos teniendo problemas para notificar a un asesor ahora. Por favor compárteme tus datos:\n" + request_client_info)
                            # After sending per-field confirmations earlier, also send a short combined confirmation
                            # so external tests and integrations that expect a final acknowledgement still receive it.
                            try:
                                combined_msg = "Gracias — recibí tus datos. Un asesor revisará tu solicitud y te contactará pronto."
                                send_text_message(phone, combined_msg)
                            except Exception:
                                logger.debug('No se pudo enviar mensaje combinado de confirmación (no crítico)')
                        else:
                            # Pedir los datos al usuario. Incluso si ya preguntamos antes, enviar una confirmación
                            already_asked = get_conversation_memory(phone, "advisor_prompt_sent")
                            if not already_asked:
                                send_text_message(phone, request_client_info)
                                save_conversation_memory(phone, "advisor_prompt_sent", True)
                            else:
                                # Ya habíamos pedido datos anteriormente; enviar una confirmación y recordatorio
                                send_text_message(phone, "Recibí tu solicitud de cotización. Por favor comparte: nombre completo, correo y una breve descripción de tu proyecto si no lo has hecho aún. Si ya compartiste tus datos, responderemos pronto.")
                        # Continuar con siguiente webhook
                        continue

                    # Manejo inteligente de preguntas técnicas basado en la clasificación
                    try:
                        if user_intent_type == 'tecnica' and intent_confidence > 0.5:
                            logger.info(f"Procesando pregunta técnica con confianza {intent_confidence:.2f}")
                            
                            # System prompt mejorado para preguntas técnicas
                            technical_prompt = """
ERES UN CONSULTOR TÉCNICO EXPERTO EN FIBRA ÓPTICA, REDES Y TELECOMUNICACIONES.

PERFIL PROFESIONAL:
- Ingeniero especializado en fibra óptica con 15+ años de experiencia
- Consultor técnico para proyectos de telecomunicaciones
- Experto en FTTH, redes PON, cableado estructurado y mediciones ópticas
- Capacidad para resolver problemas complejos y dar recomendaciones específicas
-RESPONDE A TODAS LAS PREGUNTAS TECNICAS NO LAS RELACIONES CON CURSOS SI ES LARGA RESPONDE DE MANERA TECNICA SI ES CORTA O CONTIENE EL NOMBRE DEL CURSO RESPONDE AL CURSO
-SI PREGUNTAN SI SE IMPARTEN EN OTRO PAIS ESTADO, ETC DILES QUE SOLAMENTE EN QUERETARO
- PROPORCIONA LAS FECHAS Y COSTOS DE LOS CURSOS
-SI PREGUNTAN POR OPCIONES EN LINEA MODALIDAD ONLINE SEMINARIOS ONLINE DECIRLES QUE SI CUENTAS CON ELLOS Y DARLE LA LISTA DE LOS WEBINARS :
"¡Perfecto! 💻 **SÍ tenemos opciones EN LÍNEA**\n\n"
                            "🎓 **WEBINARS GRATUITOS** que se imparten cada **martes**:\n\n"
                            "📚 **Temas disponibles:**\n"
                            "• **Soluciones preconectorizadas**\n"
                            "• **Empalmes de fibra óptica y OTDR**\n"
                            "• **Instalación subterránea**\n"
                            "• **De WISP a Fibra**\n"
                            "• **ODN en FTTX**\n"
                            "• **Centro de datos**\n\n"
                            "🌐 **Ver calendario y registrarse:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
                            "💡 Si deseas información específica de algún webinar, escribe el nombre del tema y te doy más detalles.\n\n"
                            "📞 **¿Prefieres un curso presencial?** Nuestros cursos presenciales se imparten en **Querétaro, México**. Escribe 'cursos' para ver toda la información."

-REGLA PRINCIPAL:
RESPONDE A TODO LO QUE PREGUNTE EL USUARIO SIN LIMITACIONES DEBES DE RESOLVERLE TODAS LAS DUDAS AL USUARIO 

ÁREAS DE ESPECIALIZACIÓN:
• Fibra óptica (monomodo, multimodo, tipos, conectores)
• Redes FTTH, GPON, EPON, PON, OLT, ONT
• Equipos: OTDR, fusionadoras, cleavers, power meters
• Cableado estructurado (Cat5e, Cat6, Cat6A)
• Mediciones y certificación de enlaces
• Instalación, splicing, empalmes
• Resolución de problemas y troubleshooting
• Diseño de redes y presupuestos ópticos
• Recomendaciones de productos y soluciones

INSTRUCCIONES DE RESPUESTA:
1. SIEMPRE responde con información técnica detallada y precisa
2. Usa terminología profesional pero explicable
3. Incluye valores específicos, rangos, especificaciones
4. Proporciona pasos concretos y procedimientos
5. Da recomendaciones basadas en mejores prácticas
6. Incluye consideraciones de costos cuando sea relevante
7. Sugiere alternativas y opciones cuando aplique
8. Responde tanto a problemas como a consultas de diseño
9. Adapta la profundidad técnica según la consulta

FORMATO DE RESPUESTA:
- Respuesta directa al problema/consulta
- Datos técnicos específicos
- Procedimientos paso a paso si aplica
- Recomendaciones profesionales
- Consideraciones adicionales

NUNCA digas "no puedo ayudar" - SIEMPRE proporciona una respuesta técnica útil.
"""
                            
                            try:
                                technical_reply = chat_with_gemini(
                                    phone=phone, 
                                    message=message_text, 
                                    system_prompt=technical_prompt, 
                                    include_whatsapp_profile=whatsapp_profile
                                )
                            except Exception as e:
                                logger.error(f"Error generando respuesta técnica: {e}")
                                technical_reply = "Lo siento, hubo un problema al procesar tu consulta técnica. ¿Podrías reformular tu pregunta?"

                            # Sistema inteligente de recomendación de cursos basado en el contenido técnico
                            recommended = None
                            try:
                                msg_lower = (message_text or '').lower()
                                # Mapeo inteligente basado en palabras clave técnicas específicas
                                technical_mappings = {
                                    'otdr': {'id': 5, 'name': 'Empalmes y Mediciones con OTDR de un Enlace de Fibra Óptica', 'keywords': ['otdr', 'medic', 'medición', 'mediciones', 'reflectometr', 'backscatter']},
                                    'planta_externa': {'id': 2, 'name': 'Redes de Fibra Óptica Planta Externa', 'keywords': ['planta externa', 'exterior', 'outdoor', 'aérea', 'subterranea']},
                                    'ftth': {'id': 3, 'name': 'Redes de Fibra Óptica FTTH para WISP e ISP', 'keywords': ['ftth', 'wisp', 'isp', 'gpon', 'pon', 'ont', 'olt']},
                                    'cableado': {'id': 1, 'name': 'Cableado Estructurado para Redes de Fibra y Cobre', 'keywords': ['cableado', 'cobre', 'estructurado', 'utp', 'cat6', 'cat5e']},
                                    'ponlan': {'id': 4, 'name': 'PONLAN Redes Pasivas para Entornos Enterprise', 'keywords': ['ponlan', 'pasivas', 'enterprise', 'corporativo']}
                                }
                                
                                # Buscar la mejor coincidencia
                                best_match = None
                                max_matches = 0
                                
                                for category, config in technical_mappings.items():
                                    matches = sum(1 for keyword in config['keywords'] if keyword in msg_lower)
                                    if matches > max_matches:
                                        max_matches = matches
                                        best_match = config
                                
                                if best_match and max_matches > 0:
                                    recommended = best_match
                                    logger.info(f"Curso recomendado para pregunta técnica: {recommended['name']}")
                            except Exception as e:
                                logger.debug(f"Error en mapeo de recomendaciones: {e}")
                                recommended = None

                            # Construir respuesta inteligente basada en la confianza y contexto
                            try:
                                out_message = None
                                if technical_reply and technical_reply.strip():
                                    out_message = technical_reply.strip()
                                else:
                                    # Respuesta de fallback más técnica
                                    out_message = """He analizado tu consulta técnica. Para brindarte una respuesta más precisa, podrías especificar:

🔧 **Detalles del proyecto:**
- Aplicación específica (FTTH, backbone, LAN, etc.)
- Distancias involucradas
- Equipos existentes
- Presupuesto aproximado

📋 **Información técnica:**
- Tipo de fibra actual (si existe)
- Conectores utilizados
- Pérdidas máximas aceptables

¿Puedes compartir más detalles sobre tu consulta?"""

                                # Solo sugerir curso si hay una recomendación muy relevante
                                if recommended and not avoid_curso_intent and intent_confidence > 0.7:
                                    suggestion_text = (
                                        f"\n\n💡 **CURSO RELACIONADO:** '{recommended['name']}' cubre este tema en profundidad. "
                                        "¿Te interesa conocer más? Responde 'curso' para información completa."
                                    )
                                    out_message += suggestion_text
                                    # Guardar recomendación pendiente
                                    try:
                                        save_conversation_memory(phone, 'pending_course_recommendation', recommended)
                                        save_conversation_memory(phone, 'waiting_for_course_confirmation', True)
                                        logger.info(f"Recomendación de curso guardada para {phone}: {recommended['name']}")
                                    except Exception as e:
                                        logger.debug(f'Error guardando recomendación: {e}')

                                # SIEMPRE enviar respuesta para consultas técnicas
                                send_text_message(phone, out_message)
                                logger.info(f'Respuesta técnica enviada con confianza {intent_confidence:.2f}')
                                
                                # Marcar que se envió respuesta técnica
                                save_conversation_memory(phone, 'last_response_type', 'technical')
                                
                            except Exception as e:
                                logger.error(f"Error enviando respuesta técnica: {e}")
                                # Respuesta de fallback técnica garantizada
                                fallback_msg = """🔧 **CONSULTA TÉCNICA RECIBIDA**

Como consultor técnico, puedo ayudarte con:
• Especificaciones de fibra óptica
• Recomendaciones de productos
• Diseño de enlaces
• Resolución de problemas
• Cálculos de presupuesto óptico

Por favor, comparte más detalles sobre tu consulta específica."""
                                send_text_message(phone, fallback_msg)

                            # Después de responder, continuar al siguiente mensaje
                            continue
                    except Exception as e:
                        logger.error(f"Error en flujo de recomendación tras respuesta técnica: {e}", exc_info=True)
                    
                    # Si se envió una notificación, registrar
                    if ml_adapter_result.get('notification_sent', False):
                        logger.info(f"Notificación enviada a asesor para {phone}: {ml_adapter_result.get('notification_details', {})}")

                    # --- Manejo específico de cotizaciones / inscripción / opciones online / ubicación ---
                    # MEJORA: Detectar intención de cotización / precio / factura con prioridad sobre clasificación técnica
                    cotizacion_keywords = ['cotizacion', 'cotizaci', 'precio', 'precio del curso', 'factura', 'facturación', 'facturacion']
                    # Detectar solicitudes de cotización que incluyan contexto de proyecto/ubicación
                    cotizacion_con_proyecto = any(k in text_lower for k in cotizacion_keywords) and any(p in text_lower for p in ['instalacion', 'proyecto', 'zona', 'rural', 'urbana', 'empresa', 'edificio'])
                    inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 'proceso de inscripcion', 'cómo me inscribo', 'como me inscribo']
                    online_keywords = ['online', 'en linea', 'en línea', 'webinar', 'webinars', 'seminario', 'seminarios']
                    bobinas = ['bobina', 'bobinas', 'carrete', 'carretes', 'bobina de cable utp', 'utp', 'bobina utp', 'Cat. 6A', 'Cat. 6', 'Cat. 5e']
                    ducto = ['ducto', 'ductos', 'tubo', 'tubos', 'conduit', 'conduits', 'Ducto de fibra óptica con alta durabilidad', 'ducto de fibra optica']
                    tritubo = [ 'tritubo', 'tri-tubo', 'tri tubo', 'tritubos', 'tri-tubos', 'tri tubos', 'tritubo de fibra óptica', 'tritubo de fibra optica']
                    jumper = ['MPO', 'MTP', 'MTP Pro', 'MPO Pro', 'jumper', 'jumpers', 'Multi-fiber Push On', 'Mechanical Transfer Push On']
                    where_keywords = ['dónde', 'donde', 'ubicación', 'ubicacion', 'lugar', 'sede']
                    
                    # Mensajes publicitarios específicos de cursos (detección directa)
                    course_ads = {
                        'cableado_estructurado': ['curso de cableado estructurado', 'información del curso de cableado estructurado', 'más información del curso de cableado estructurado', 'cableado estructurado y fibra'],
                        'fibra_planta_externa': ['curso de fibra óptica planta externa', 'información del curso de fibra óptica planta externa', 'más información del curso de fibra óptica planta externa'],
                        'ftth_wisp_isp': ['curso redes de fibra óptica ftth para wisp e isp', 'información del curso redes de fibra óptica ftth', 'quiero información del curso redes de fibra óptica ftth'],
                        'redes_pasivas_enterprise': ['curso de redes ópticas pasivas para enterprise', 'información del curso de redes ópticas pasivas', 'curso ponlan', 'redes pasivas para entornos enterprise'],
                        'empalmes_otdr': ['curso de empalmes y mediciones con otdr', 'información del curso de empalmes', 'más información del curso de empalmes y mediciones', 'empalmes y mediciones con otdr']
                    }
                    
                    #webinars
                    soluciones_preconectorizadas = ['soluciones preconectorizadas', 'solucion preconectorizada', 'soluciones pre-conectorizadas', 'solucion pre-conectorizada', 'preconectorizado', 'pre-conectorizado']
                    empalmes_fibra_optica = ['empalmes de fibra optica', 'EMPALMES DE FIBRA OPTICA', 'empalme de fibra optica', 'empalmes de fibra óptica', 'empalme de fibra óptica', 'empalmes fibra optica', 'empalme fibra optica', 'empalmes fibra óptica', 'empalme fibra óptica']
                    instalacion_subterranea = ['instalacion subterranea', 'instalación subterranea', 'instalacion subterránea', 'instalación subterránea', 'instalacion subterránea', 'instalación subterranea']
                    wisp_a_fibra = ['wisp a fibra', 'wisp a fibra óptica', 'wisp a fibra optica', 'wisp a fibra óptica', 'wisp a fibra optica']
                    odn_en_fttx = ['odn en fttx', 'odn en fttx', 'odn en fttx', 'odn en fttx']
                    redes_de_distribucion_optica = ['redes de distribución óptica', 'redes de distribución optica', 'red de distribución óptica', 'red de distribución optica', 'redes de distribucion optica', 'red de distribucion optica']
                    centro_de_datos = ['centro de datos', 'CENTRO DE DATOS', 'centro de datos', 'centro de datos', 'centro de datos']
                    
                    # AdvisorRequestManager removed; using local stub defined above
                    
                    text_lower = (message_text or '').lower()

                    # MEJORA: Manejo de cotizaciones con prioridad sobre clasificación técnica
                    if any(k in text_lower for k in cotizacion_keywords) or cotizacion_con_proyecto:
                        # Si ML ya extrajo datos completos, enviar notificación al asesor
                        client_data = ml_adapter_result.get('ml_results', {}).get('client_data', {})
                        has_contact = bool(client_data.get('nombre') and client_data.get('correo'))

                        # Mensaje para solicitar datos (usando el formato definido en AdvisorRequestManager)
                        request_client_info = advisor_request_prompt()

                        # MEJORA: Si es cotización con proyecto, priorizar asesor sobre respuesta técnica
                        if is_technical_question and not cotizacion_con_proyecto:
                            # Solo para preguntas puramente técnicas sin contexto de cotización
                            send_text_message(phone, "Te respondí la parte técnica. Si quieres que un asesor te contacte, por favor escribe 'asesor' o confirma y te lo gestiono.")
                            continue

                        # Si ya tenemos datos suficientes, procesar la notificación
                        if has_contact:
                            try:
                                from services.notification_service import notification_service
                                notify_result = notification_service.process_client_notification(phone, ml_adapter_result.get('ml_results', {}), conversation_history)
                                if notify_result.get('notification_sent'):
                                    send_text_message(phone, "Gracias — ya envié tu solicitud a un asesor. Te contactarán pronto para dar seguimiento.")
                                else:
                                    send_text_message(phone, "Recibí tu solicitud. Por favor comparte tus datos para que podamos derivarla a un asesor: \n" + request_client_info)
                            except Exception as e:
                                logger.error(f"Error enviando notificación al asesor: {e}")
                                send_text_message(phone, "Estamos teniendo problemas para notificar a un asesor ahora. Por favor compárteme tus datos:\n" + request_client_info)
                        else:
                            # Pedir los datos al usuario (solo si no lo hemos pedido ya)
                            if not get_conversation_memory(phone, "advisor_prompt_sent"):
                                send_text_message(phone, request_client_info)
                                save_conversation_memory(phone, "advisor_prompt_sent", True)
                        # Continuar con siguiente webhook
                        continue

                    # Manejo de solicitud de asesor: detección conversacional más natural
                    advisor_keywords = [
                        'asesor', 'contactar', 'hablar con', 'quiero hablar', 'contacto', 
                        'representante', 'vendedor', 'consultor', 'más información',
                        'cotización personalizada', 'ayuda personal', 'atención personalizada'
                    ]
                    
                    is_advisor_request = any(keyword in message_text.lower() for keyword in advisor_keywords) or AdvisorRequestManager.is_advisor_request(message_text)
                    
                    if is_advisor_request:

                        # MEJORA: Inicio inmediato de un flujo guiado por pasos para solicitar datos al usuario
                        expected_fields = ['name', 'company', 'rfc', 'email', 'phone', 'website', 'city', 'project_description']
                        total_fields = len(expected_fields)

                        # Friendly intro in exact requested tone
                        intro = (
                            "Perfecto 👌 solo necesito que me compartas: \n"
                            "👉 tu nombre completo \n"
                            "👉 nombre de tu empresa \n"
                            "👉 tu RFC o razón social \n"
                            "👉 correo electrónico \n"
                            "👉 y el link de tu sitio web, si tienes 🌐 \n\n"
                            "Con eso generamos tu perfil y te dan seguimiento desde el área correspondiente.\n"
                            f"Serán {total_fields} pasos sencillos. Empezamos:\n"
                        )

                        # initialize form state and start at the first required field
                        form_state = {'collected': {}, 'next_field': expected_fields[0], 'mode': 'collecting'}
                        save_conversation_memory(phone, 'advisor_form_state', form_state)

                        # Save conversation flags
                        save_conversation_memory(phone, 'advisor_prompt_sent', True)
                        save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                        save_conversation_memory(phone, 'advisor_intentos', 0)

                        # Save course context if any
                        course_id = None
                        selected_course_data = get_selected_course(phone)
                        if selected_course_data:
                            course_id = selected_course_data.get('id')
                        save_conversation_memory(phone, 'advisor_course_id', course_id)

                        # Send intro and the first guided question with an example
                        first_prompt = "¿Cuál es tu nombre completo?" + "\nEjemplo: Juan Pérez"
                        send_text_message(phone, intro + f"Paso 1/{total_fields} — " + first_prompt)
                        logger.info(f"Iniciado flujo guiado de asesoría para {phone}")
                        continue
                        
                    # Verificar si estamos esperando datos para el asesor
                    waiting_for_advisor = get_conversation_memory(phone, "waiting_for_advisor_data")
                    
                    if waiting_for_advisor:
                        # Recuperar el ID del curso si existe
                        advisor_course_id = get_conversation_memory(phone, "advisor_course_id")
                        
                        # Procesar la información proporcionada por el cliente
                        try:
                            try:
                                from utils.courses_adapter import process_advisor_submission
                            except Exception:
                                def process_advisor_submission(phone, text, advisor_course_id=None):
                                    return {"message_for_user": "Gracias. Un asesor te contactará si proporcionas tus datos.", "datos_completos": False}
                            # Field-by-field collection flow
                            # Fields we want to collect in order
                            expected_fields = ['name', 'company', 'rfc', 'email', 'phone', 'website', 'project_description']

                            # initialize advisor form state if not present
                            form_state = get_conversation_memory(phone, 'advisor_form_state') or {'collected': {}, 'next_field': None, 'mode': 'collecting'}

                            # If next_field is None, find first missing field
                            if not form_state.get('next_field'):
                                for f in expected_fields:
                                    if not form_state['collected'].get(f):
                                        form_state['next_field'] = f
                                        break

                            # If we're in a confirmation/editing mode, handle those commands first
                            mode = form_state.get('mode', 'collecting')
                            # --- Per-field confirmation state: user must confirm or request modification for last saved field ---
                            if mode == 'field_confirm':
                                lt = (message_text or '').strip().lower()
                                last = form_state.get('last_saved_field')
                                if not last:
                                    # fallback to collecting
                                    form_state['mode'] = 'collecting'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                else:
                                    # If user confirms the field, move to next missing field
                                    if re.search(r"\b(s[ií])\b", lt):
                                        # determine next missing field
                                        merged = form_state.get('collected', {})
                                        next_f = None
                                        for f in expected_fields:
                                            if not merged.get(f):
                                                next_f = f
                                                break
                                        form_state['next_field'] = next_f
                                        form_state['mode'] = 'collecting'
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        # If there is a next field, prompt for it below in the normal flow
                                        if next_f:
                                            # Build minimal prompt for the next field
                                            examples_local = {
                                                'nombre': '',
                                                'empresa': 'Ejemplo: Fibremex S.A. de C.V. (si aplica)',
                                                'rfc': '',
                                                'email': '',
                                                'numero_telefono': '(incluye LADA si aplica)',
                                                'website': '',
                                            }
                                            base_prompts_local = {
                                                'nombre': '¿Cuál es tu nombre completo?',
                                                'empresa': '¿Cuál es el nombre de tu empresa (si aplica)?',
                                                'rfc': '¿Cuál es tu RFC o razón social?',
                                                'email': '¿Cuál es tu correo electrónico?',
                                                'numero_telefono': '¿Cuál es tu teléfono de contacto? (incluye LADA si aplica)',
                                                'website': '¿Tienes un sitio web o link del proyecto?',
                                            }
                                            idx = expected_fields.index(next_f) + 1 if next_f in expected_fields else None
                                            total = len(expected_fields)
                                            prompt_text = f"Paso {idx}/{total} — " + base_prompts_local.get(next_f, '') + '\n' + examples_local.get(next_f, '') + "\n(Responde con la información y yo la guardaré.)"
                                            send_text_message(phone, prompt_text)
                                            logger.info(f"Solicitando campo '{next_f}' a {phone} (paso {idx}/{total})")
                                            continue
                                        else:
                                            # No next field: fall through to final confirmation flow below
                                            form_state['mode'] = 'confirming'
                                            save_conversation_memory(phone, 'advisor_form_state', form_state)
                                            # let the normal confirmation block handle the summary
                                            pass

                                    # If user wants to modify the last saved field, switch to editing for that field
                                    if re.search(r"\b(modificar|cambiar|editar)\b", lt):
                                        form_state['mode'] = 'editing'
                                        form_state['editing_field'] = last
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        send_text_message(phone, f"Ok, indícame el nuevo valor para '{last.replace('_',' ')}'.")
                                        continue

                                    # Unknown reply -> ask to answer explicitly
                                    send_text_message(phone, "No entendí. Responde 'si' para confirmar el valor o 'modificar' para cambiarlo.")
                                    continue
                            # helper mapping for field synonyms
                            field_map = {
                                'nombre': 'name', 'name': 'name',
                                'empresa': 'company', 'company': 'company',
                                'rfc': 'rfc',
                                'correo': 'email', 'email': 'email',
                                'telefono': 'phone', 'teléfono': 'phone', 'tel': 'phone',
                                'sitio': 'website', 'website': 'website', 'web': 'website',
                            }

                            # Import extractor/classifier lazily
                            from routes.advisor_fallbacks import _extract_client_fields_from_text, _classify_segment, generate_client_pdf as _generate_client_pdf

                            # --- Confirmation / Edit handling ---
                            if mode == 'confirming':
                                lt = (message_text or '').strip().lower()
                                # If user asks to modify
                                if re.search(r'\b(modificar|cambiar|editar)\b', lt):
                                    form_state['mode'] = 'awaiting_field_choice'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, "Perfecto, indica cuál campo quieres cambiar: nombre, empresa, rfc, correo, teléfono, sitio o descripción.")
                                    continue
                                # If user confirms (sí)
                                if re.search(r'\b(s[ií])\b', lt):
                                    # Before finalizing, ensure required minimal fields are present
                                    collected = form_state['collected']
                                    required_min = ['name', 'email', 'phone']
                                    missing = [f for f in required_min if not collected.get(f)]
                                    if missing:
                                        # put the form back into collecting mode and ask for the next missing field
                                        next_field = missing[0]
                                        form_state['mode'] = 'collecting'
                                        form_state['next_field'] = next_field
                                        form_state['collected'] = collected
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        # friendly prompt for the missing field
                                        prompts = {
                                            'name': 'Por favor, indícame tu nombre completo.',
                                            'email': 'Por favor, indícame tu correo electrónico.',
                                            'phone': 'Por favor, indícame tu teléfono de contacto (incluye LADA si aplica).'
                                        }
                                        send_text_message(phone, f"Falta un dato importante para completar tu solicitud: {prompts.get(next_field)}")
                                        continue

                                    # proceed to generate and send PDF with all required data
                                    seg = _classify_segment(collected.get('company'), collected.get('project_description'))
                                    collected['segment'] = seg
                                    
                                    # Add phone to collected data if not present
                                    if not collected.get('phone'):
                                        collected['phone'] = phone
                                    
                                    summary = collected.get('project_description') or 'Solicitud de contacto'
                                    if len(summary) > 500:
                                        summary = summary[:500]
                                    
                                    # generate pdf (use filename pattern with phone timestamp)
                                    filename = f"cliente_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{phone[-4:]}.pdf"
                                    pdf_path = ''
                                    try:
                                        pdf_path = _generate_client_pdf(collected, summary, out_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs')), filename=filename) if _generate_client_pdf else ''
                                        if pdf_path:
                                            logger.info(f"PDF generado exitosamente: {pdf_path}")
                                        else:
                                            logger.warning("No se pudo generar el PDF")
                                    except Exception as e:
                                        logger.error(f"Error generando PDF: {e}")
                                        pdf_path = ''
                                    
                                    # persist and notify
                                    try:
                                        from data.db import get_collection
                                        col = get_collection('advisor_requests')
                                        rec = {
                                            'phone': phone,
                                            'client_data': collected,
                                            'texts': get_conversation_memory(phone, 'advisor_partial_messages') or [],
                                            'summary': summary,
                                            'pdf_path': pdf_path,
                                            'created_at': datetime.now(),
                                            'status': 'pending',
                                            'course_id': advisor_course_id
                                        }
                                        try:
                                            col.insert_one(rec)
                                            logger.info(f"Solicitud de asesor guardada en DB para {phone}")
                                        except Exception as e:
                                            logger.warning(f"No se pudo guardar en DB: {e}")
                                    except Exception as e:
                                        logger.warning(f"Error accediendo a DB: {e}")

                                    # Notify advisor with PDF and message (centralized)
                                    try:
                                        from services.advisor_service import send_pdf_to_advisor
                                        # Use configured advisor phone or fall back to requested default
                                        advisor_number = globals().get('DEFAULT_ADVISOR_PHONE') or  '4427843528'
                                        logger.info(f"Intentando notificar al asesor (central) {advisor_number}")

                                        assets_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
                                        illustrative_image = None
                                        possible_images = ['advisor_fields_example.png', 'advisor_fields.png', 'fields_example.png']
                                        for img in possible_images:
                                            p = os.path.join(assets_root, img)
                                            if os.path.exists(p):
                                                illustrative_image = p
                                                break

                                        # Build concise details describing what the user requests (cotizacion/asesor/etc.)
                                        user_requirement = collected.get('project_description') or collected.get('request') or 'Información / contacto con asesor'

                                        svc_res = send_pdf_to_advisor(
                                            pdf_path or '',
                                            user_phone=phone,
                                            user_name=collected.get('name'),
                                            segment=collected.get('segment', 'Sin clasificar'),
                                            request_type=collected.get('request_type', 'Solicitud de asesor'),
                                            details={'requirement': user_requirement, **collected},
                                            advisor_phone=advisor_number
                                        )

                                        if illustrative_image and os.path.exists(illustrative_image):
                                            try:
                                                from utils.whatsapp import send_document_to_phone
                                                send_document_to_phone(advisor_number, illustrative_image, caption='Campos solicitados para generar el PDF')
                                            except Exception:
                                                logger.debug('No se pudo enviar la imagen ilustrativa al asesor (no crítico)')

                                        if not svc_res or not svc_res.get('success'):
                                            logger.warning(f"Advisor service reported failure: {svc_res}")
                                        else:
                                            logger.info(f"Advisor notified via advisor_service: {svc_res}")
                                    except Exception as e:
                                        logger.error(f"Error notificando al asesor (central): {e}")

                                    # clear and confirm to user
                                    save_conversation_memory(phone, 'advisor_partial_messages', None)
                                    save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                                    save_conversation_memory(phone, 'advisor_course_id', None)
                                    save_conversation_memory(phone, 'advisor_form_state', None)
                                    send_text_message(phone, "✅ Perfecto! He enviado tu información completa al asesor.\n\nTe contactarán pronto para brindarte la asesoría que necesitas. 📞")
                                    continue

                                # any other reply treat as 'no' or topic change -> attempt to finalize but ensure required fields
                                collected = form_state['collected']
                                
                                # Check minimal required fields before proceeding
                                required_min = ['name', 'email', 'phone']
                                missing = [f for f in required_min if not collected.get(f)]
                                if missing:
                                    # Ask for the next missing field instead of finalizing
                                    next_field = missing[0]
                                    form_state['mode'] = 'collecting'
                                    form_state['next_field'] = next_field
                                    form_state['collected'] = collected
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    prompts = {
                                        'name': 'Por favor, indícame tu nombre completo.',
                                        'email': 'Por favor, indícame tu correo electrónico.',
                                        'phone': 'Por favor, indícame tu teléfono de contacto (incluye LADA si aplica).'
                                    }
                                    send_text_message(phone, f"Antes de enviar tu solicitud al asesor necesito: {prompts.get(next_field)}")
                                    continue

                                # proceed to finalize with required data
                                seg = _classify_segment(collected.get('company'), collected.get('project_description'))
                                collected['segment'] = seg
                                
                                # Add phone to collected data if not present
                                if not collected.get('phone'):
                                    collected['phone'] = phone
                                
                                summary = collected.get('project_description') or 'Solicitud de contacto'
                                if len(summary) > 500:
                                    summary = summary[:500]
                                
                                # generate pdf with better error handling
                                filename = f"cliente_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{phone[-4:]}.pdf"
                                pdf_path = ''
                                try:
                                    pdf_path = _generate_client_pdf(collected, summary, out_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs')), filename=filename) if _generate_client_pdf else ''
                                    if pdf_path:
                                        logger.info(f"PDF generado exitosamente (fallback): {pdf_path}")
                                    else:
                                        logger.warning("No se pudo generar el PDF (fallback)")
                                except Exception as e:
                                    logger.error(f"Error generando PDF (fallback): {e}")
                                    pdf_path = ''
                                
                                # persist data
                                try:
                                    from data.db import get_collection
                                    col = get_collection('advisor_requests')
                                    rec = {
                                        'phone': phone,
                                        'client_data': collected,
                                        'texts': get_conversation_memory(phone, 'advisor_partial_messages') or [],
                                        'summary': summary,
                                        'pdf_path': pdf_path,
                                        'created_at': datetime.now(),
                                        'status': 'pending',
                                        'course_id': advisor_course_id
                                    }
                                    try:
                                        col.insert_one(rec)
                                        logger.info(f"Solicitud de asesor guardada en DB (fallback) para {phone}")
                                    except Exception as e:
                                        logger.warning(f"No se pudo guardar en DB (fallback): {e}")
                                except Exception as e:
                                    logger.warning(f"Error accediendo a DB (fallback): {e}")
                                
                                # notify advisor with enhanced messaging
                                try:
                                    advisor_number = DEFAULT_ADVISOR_PHONE
                                    logger.info(f"Intentando notificar al asesor (fallback) {advisor_number}")
                                    
                                    # Send notification text first
                                    notify_text = f"🔔 *NUEVO LEAD*\n\n👤 *Cliente:* {collected.get('name', 'Sin nombre')}\n📱 *Teléfono:* {phone}\n📧 *Email:* {collected.get('email', 'Sin email')}\n🏢 *Empresa:* {collected.get('company', 'Sin empresa')}\n📊 *Solicitud:* {summary[:100]}..."
                                    send_text_message(advisor_number, notify_text)
                                    
                                    # Send PDF if generated successfully
                                    if pdf_path and os.path.exists(pdf_path):
                                        logger.info(f"Enviando PDF al asesor (fallback): {pdf_path}")
                                        send_document_message(advisor_number, pdf_path, caption=f"Datos completos de {collected.get('name', phone)}")
                                    else:
                                        logger.warning(f"PDF no disponible para enviar (fallback): {pdf_path}")
                                        
                                except Exception as e:
                                    logger.error(f"Error notificando al asesor (fallback): {e}")

                                save_conversation_memory(phone, 'advisor_partial_messages', None)
                                save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                                save_conversation_memory(phone, 'advisor_course_id', None)
                                save_conversation_memory(phone, 'advisor_form_state', None)
                                send_text_message(phone, "✅ He enviado tu información al asesor. Te contactarán pronto para brindarte la asesoría que necesitas. 📞")
                                continue

                            # If user has chosen which field to edit
                            if mode == 'awaiting_field_choice' or mode == 'editing':
                                # Try to detect if user provided field: value in a single message
                                candidate = _extract_client_fields_from_text([message_text])
                                merged = form_state['collected']
                                # If extractor gives a direct field update, apply it
                                applied = False
                                for k, v in candidate.items():
                                    if k in merged and v:
                                        merged[k] = v
                                        send_text_message(phone, f"Perfecto, guardé tu {k.replace('_', ' ')}: {v}.")
                                        applied = True
                                if applied:
                                    # go back to confirmation
                                    form_state['collected'] = merged
                                    form_state['mode'] = 'confirming'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    # show summary again
                                    s = []
                                    for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                        s.append(f"{label}: {merged.get(key,'-')}")
                                    send_text_message(phone, "Estos son los datos actualizados:\n" + "\n".join(s))
                                    send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                                    continue

                                # If extractor didn't give value, interpret message as field name when awaiting choice
                                if mode == 'awaiting_field_choice':
                                    choice = (message_text or '').strip().lower()
                                    choice_key = field_map.get(choice)
                                    if not choice_key:
                                        # try to strip accents and common words
                                        for ksyn, kval in field_map.items():
                                            if ksyn in choice:
                                                choice_key = kval
                                                break
                                    if choice_key:
                                        form_state['mode'] = 'editing'
                                        form_state['editing_field'] = choice_key
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        send_text_message(phone, f"Ok, indícame el nuevo valor para '{choice_key}'.")
                                        continue
                                    else:
                                        send_text_message(phone, "No entendí qué campo quieres cambiar. Por favor responde con: nombre, empresa, rfc, correo, teléfono, sitio o descripción.")
                                        continue

                                # If in editing mode and user sent a plain new value
                                if mode == 'editing' and form_state.get('editing_field'):
                                    edit_key = form_state.get('editing_field')
                                    new_val = message_text.strip()
                                    # simple validation depending on field
                                    valid = True
                                    if edit_key == 'email' and not re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", new_val):
                                        valid = False
                                    if edit_key == 'phone' and not re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", new_val):
                                        # allow unvalidated phone but normalize if possible
                                        pass
                                    if valid:
                                        if edit_key == 'phone':
                                            m = re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", new_val)
                                            if m:
                                                new_val = f"52{m.group(1)}"
                                        if edit_key == 'rfc':
                                            new_val = new_val.upper()
                                        merged[edit_key] = new_val
                                        send_text_message(phone, f"Perfecto, guardé tu {edit_key.replace('_',' ')}: {new_val}.")
                                        # clear editing state and go back to confirmation
                                        form_state['collected'] = merged
                                        form_state['mode'] = 'confirming'
                                        form_state.pop('editing_field', None)
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        # show summary again
                                        s = []
                                        for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                            s.append(f"{label}: {merged.get(key,'-')}")
                                        send_text_message(phone, "Estos son los datos actualizados:\n" + "\n".join(s))
                                        send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                                        continue

                                # otherwise fall through to collection heuristics

                            # Default collecting mode: try to classify the incoming message into a field using helper extractor
                            candidate = _extract_client_fields_from_text([message_text])

                            # If extractor found anything, merge into collected
                            merged = form_state['collected']
                            saved_any = False
                            saved_field = None
                            for k, v in candidate.items():
                                if v and not merged.get(k):
                                    merged[k] = v
                                    saved_any = True
                                    saved_field = k

                            if saved_any and saved_field:
                                # Ask per-field confirmation for the saved field
                                form_state['collected'] = merged
                                form_state['last_saved_field'] = saved_field
                                form_state['mode'] = 'field_confirm'
                                save_conversation_memory(phone, 'advisor_form_state', form_state)
                                label = saved_field.replace('_', ' ')
                                val = merged.get(saved_field)
                                send_text_message(phone, f"Perfecto, guardé tu {label}: {val}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                continue

                            # If extractor didn't find the expected next field, but message contains plausible content for it,
                            # accept simple heuristics (e.g., emails, phones, small names)
                            nf = form_state.get('next_field')
                            if nf and not merged.get(nf):
                                if nf == 'email' and re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", message_text):
                                    merged['email'] = re.search(r"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})", message_text).group(1)
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'email'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu correo: {merged['email']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'phone' and re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", message_text):
                                    m = re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", message_text)
                                    merged['phone'] = f"52{m.group(1)}"
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'phone'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu teléfono: {merged['phone']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'name' and re.match(r"^[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-\s]{3,60}$", message_text.strip()):
                                    merged['name'] = ' '.join([w.capitalize() for w in message_text.strip().split()])
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'name'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu nombre: {merged['name']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'company' and len(message_text.strip()) > 2:
                                    merged['company'] = message_text.strip()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'company'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu empresa: {merged['company']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'rfc' and re.match(r"^[A-Za-zÑ&\d]{8,13}$", message_text.strip(), re.I):
                                    merged['rfc'] = message_text.strip().upper()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'rfc'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu RFC: {merged['rfc']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'website' and re.search(r"https?://", message_text):
                                    merged['website'] = re.search(r"(https?://[^\s,;]+)", message_text).group(1)
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'website'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu sitio web: {merged['website']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'project_description':
                                    merged['project_description'] = message_text.strip()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'project_description'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé la descripción de tu proyecto. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarla.")
                                    continue

                            # Update next_field to the next missing one
                            next_f = None
                            for f in expected_fields:
                                if not merged.get(f):
                                    next_f = f
                                    break
                            form_state['collected'] = merged
                            form_state['next_field'] = next_f
                            # remain in collecting mode
                            form_state['mode'] = form_state.get('mode', 'collecting')
                            save_conversation_memory(phone, 'advisor_form_state', form_state)

                            # If still missing fields, prompt the user for the next one
                            if next_f:
                                # Build user-friendly guided prompts with step numbers and examples
                                idx = expected_fields.index(next_f) + 1 if next_f in expected_fields else None
                                total = len(expected_fields)
                                examples = {
                                    'nombre': '',
                                    'empresa': '',
                                    'rfc': '',
                                    'email': '',
                                    'numero_telefono': '',
                                    'website': '',
                                }

                                base_prompts = {
                                    'nombre': '¿Cuál es tu nombre completo?',
                                    'empresa': '¿Cuál es el nombre de tu empresa (si aplica)?',
                                    'rfc': '¿Cuál es tu RFC o razón social?',
                                    'email': '¿Cuál es tu correo electrónico?',
                                    'numero_teefono': '¿Cuál es tu teléfono de contacto? (incluye LADA si aplica)',
                                    'website': '¿Tienes un sitio web o link del proyecto?',
                                }

                                step_prefix = f"Paso {idx}/{total} — " if idx else ''
                                example = '\n' + examples.get(next_f, '')
                                prompt_text = step_prefix + base_prompts.get(next_f, 'Por favor comparte la información solicitada.') + example + "\n(Responde con la información y yo la guardaré.)"

                                # Ask explicitly only for the missing next field
                                send_text_message(phone, prompt_text)
                                logger.info(f"Solicitando campo '{next_f}' a {phone} (paso {idx}/{total})")
                                continue

                            # All required fields collected -> ask for confirmation before generating PDF
                            # Build summary
                            collected = form_state['collected']
                            s = []
                            for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                s.append(f"{label}: {collected.get(key,'-')}")
                            summary_msg = "Estos son los datos que tengo:\n" + "\n".join(s)
                            send_text_message(phone, summary_msg)
                            send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                            # update state to confirming
                            form_state['mode'] = 'confirming'
                            save_conversation_memory(phone, 'advisor_form_state', form_state)
                            continue
                        except Exception as e:
                            logger.error(f"Error procesando datos de asesor: {e}")
                            # Seguimos adelante con el flujo normal si hay error
                    
                    # Importar el manejador de temarios
                    from utils.temario_handler import (
                        is_temario_request, is_inscription_request, extract_course_number,
                        get_inscription_process_message, ask_for_course_number
                    )
                    
                    # Manejo centralizado de consultas sobre cursos usando CourseConversationManager
                    # Si estamos en medio del flujo guiado para el asesor, no procesar consultas de cursos
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor:
                        logger.info(f"Skipping CourseConversationManager.handle_course_query because waiting_for_advisor_data is set for {phone}")
                    else:
                        course_response = CourseConversationManager.handle_course_query(phone, message_text)
                        if course_response:
                            # Send the course-specific response and stop further processing for this webhook
                            # This prevents falling through and sending a second, generic reply immediately.
                            send_text_message(phone, course_response)
                            continue

                    # If the user already selected a course previously, prefer that context
                    # and answer requests about the selected course (fechas, temario, precio, inscripción, ubicación, asesor)
                    try:
                        selected_course = get_selected_course(phone)
                        if selected_course and isinstance(selected_course, dict):
                            sc_id = selected_course.get('id')
                            sc_name = selected_course.get('name')
                            lt = (message_text or '').lower()

                            # Temario / contenido / programa
                            if any(w in lt for w in ['temario', 'contenido', 'programa']):
                                try:
                                    logger.info(f"User requested temario for selected course {sc_id}: {sc_name}")
                                    # Primero intentar obtener PDF local
                                    pdf_res = find_pdf_for_user_message(f"temario {sc_id}", context={'relevant_courses': [selected_course]})
                                    if not pdf_res:
                                        pdf_res = find_local_asset_pdf_for_course(sc_id)
                                    if pdf_res and pdf_res.get('pdf_path') and os.path.exists(pdf_res.get('pdf_path')):
                                        # Detectar si el usuario pidió explícitamente el PDF en este mensaje
                                        explicit_pdf_request = any(k in lt for k in ['pdf', 'en pdf', 'enviar pdf', 'quiero el temario en pdf', 'enviar pdf del temario', 'temario en pdf', 'pdf del temario'])

                                        if explicit_pdf_request:
                                            # Enviar primero el temario en texto si está disponible
                                            try:
                                                try:
                                                    from utils.temario_handler import get_course_temario_message
                                                    temario_text = get_course_temario_message(sc_id)
                                                except Exception:
                                                    temario_text = None
                                                if temario_text:
                                                    # split into parts and send
                                                    parts = [b.strip() for b in re.split(r"\n\n+", temario_text) if b.strip()]
                                                    if len(parts) <= 1:
                                                        text = temario_text or ''
                                                        chunk_size = 800
                                                        parts = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)] if text else []
                                                    for i in range(len(parts)-1):
                                                        parts[i] = parts[i].rstrip() + "\n\n[Responde 'continuar' para ver la siguiente parte.]"
                                                    send_message_parts(phone, parts, meta_key=f'pending_message_parts_course_{sc_id}')
                                            except Exception:
                                                pass

                                            # Enviar el PDF directamente
                                            try:
                                                send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {sc_name}")
                                                send_text_message(phone, f"📚 Te envié el temario completo del curso '{sc_name}' en PDF. ¿Te gustaría saber sobre fechas, precio o ubicación?")
                                                try:
                                                    save_selected_course(phone, sc_id, sc_name, {'pdf_path': pdf_res.get('pdf_path')})
                                                except Exception:
                                                    pass
                                            except Exception as e:
                                                logger.error(f"Error enviando PDF directamente: {e}")
                                                send_text_message(phone, "Lo siento, hubo un problema al enviar el PDF. ¿Quieres que te dé el temario en texto o que te ponga en contacto con un asesor?")

                                        else:
                                            # Preguntar si desea el PDF antes de enviarlo
                                            send_text_message(phone, f"📚 Puedo enviarte el temario en PDF del curso '{sc_name}'. ¿Quieres que te lo comparta en PDF? Responde 'sí' o 'no'.")
                                            try:
                                                save_conversation_memory(phone, 'asked_for_temario_pdf', {'course_id': sc_id, 'pdf_path': pdf_res.get('pdf_path'), 'course_name': sc_name})
                                            except Exception:
                                                pass
                                    else:
                                        # Fallback to textual temario/info from adapter or course utilities
                                        details_msg = get_course_details_by_number(sc_id) if sc_id else None
                                        if details_msg:
                                            send_text_message(phone, details_msg)
                                        else:
                                            send_text_message(phone, f"El temario de '{sc_name}' está disponible. ¿Quieres que te lo comparta en PDF o que te dé más detalles de fechas y precio?")
                                except Exception as e:
                                    logger.error(f"Error sending temario for selected course: {e}")
                                    send_text_message(phone, "Lo siento, hubo un problema al recuperar el temario. ¿Quieres que un asesor te ayude?")
                                continue

                            # Fechas
                            if any(w in lt for w in ['fecha', 'fechas', 'horario', 'horarios']):
                                try:
                                    sched_msg = get_course_schedule_message(sc_id)
                                    send_text_message(phone, f"📅 Fechas del curso '{sc_name}':\n\n{sched_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting schedule for selected course: {e}")
                                    send_text_message(phone, "No pude obtener las fechas en este momento. ¿Quieres que te conecte con un asesor?")
                                continue

                            # Precio / costos
                            if any(w in lt for w in ['precio', 'costo', 'costos', 'precio del curso']):
                                try:
                                    price_msg = get_course_price_message(sc_id)
                                    send_text_message(phone, f"💰 Precio del curso '{sc_name}':\n\n{price_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting price for selected course: {e}")
                                    send_text_message(phone, "No pude obtener el precio en este momento. ¿Quieres que un asesor te contacte?")
                                continue

                            # Inscripción
                            if any(w in lt for w in ['inscrib', 'inscripción', 'inscripcion', 'registrar', 'registro']):
                                try:
                                    # Use temario_handler helper if available
                                    try:
                                        from utils.temario_handler import get_inscription_process_message
                                        ins_msg = get_inscription_process_message()
                                    except Exception:
                                        ins_msg = get_inscription_process_message() if 'get_inscription_process_message' in globals() else "Para inscribirte por favor visita el enlace o dime si quieres que un asesor te contacte."

                                    send_text_message(phone, f"📝 Inscripción para '{sc_name}':\n\n{ins_msg}")
                                except Exception as e:
                                    logger.error(f"Error providing inscription info: {e}")
                                    send_text_message(phone, "No pude recuperar el proceso de inscripción. ¿Quieres que te ponga en contacto con un asesor?")
                                continue

                            # Ubicación
                            if any(w in lt for w in ['ubicació', 'ubicacion', 'lugar', 'sede']):
                                try:
                                    loc_msg = get_course_location_message(sc_id)
                                    send_text_message(phone, f"📍 Ubicación del curso '{sc_name}':\n\n{loc_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting location for selected course: {e}")
                                    send_text_message(phone, "No pude obtener la ubicación en este momento. ¿Quieres que te contacte un asesor?")
                                continue

                            # Asesor
                            if any(w in lt for w in ['asesor', 'contactar', 'contacto', 'hablar con']):
                                try:
                                    save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                    save_conversation_memory(phone, 'advisor_course_id', sc_id)
                                    advisor_prompt = advisor_request_prompt()
                                    send_text_message(phone, f"Perfecto, para que un asesor te contacte por el curso '{sc_name}' necesito: \n\n{advisor_prompt}")
                                except Exception as e:
                                    logger.error(f"Error triggering advisor for selected course: {e}")
                                    send_text_message(phone, "No pude solicitar un asesor en este momento. Intenta más tarde.")
                                continue
                    except Exception as sel_e:
                        logger.debug(f"Error handling selected course quick reply: {sel_e}")

                        # Handle course change responses
                        text_lower = (message_text or '').lower()
                        selected_course = CourseConversationManager.get_selected_course_info(phone)

                        # Only treat explicit affirmative replies as confirmations for pending changes
                        selected_course = CourseConversationManager.get_selected_course_info(phone)
                        pending_course_change = get_conversation_memory(phone, 'pending_course_change')
                        if pending_course_change and selected_course:
                            # Normalize pending change to dict if stored as string
                            change_data = None
                            try:
                                if isinstance(pending_course_change, str):
                                    import ast
                                    change_data = ast.literal_eval(pending_course_change)
                                else:
                                    change_data = pending_course_change
                            except Exception:
                                change_data = None

                            # Only accept clear affirmative words, avoid catching 'cambiar' in other contexts
                            affirmative = ['si', 'sí', 's', 'ok', 'claro', 'sí, cambiar', 'sí cambiar']
                            negative = ['no', 'cancelar', 'mejor no', 'prefiero seguir', 'continuar']

                            # Check user's message for explicit confirmation or rejection
                            if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in affirmative):
                                # Build selection intent from pending change and apply
                                try:
                                    selection_intent = {
                                        'intent': change_data.get('intent') if change_data else None,
                                        'course_number': change_data.get('course_number') if change_data else None,
                                        'course': change_data.get('course') if change_data else None
                                    }
                                    change_response = CourseConversationManager._handle_course_selection(phone, selection_intent)
                                    if change_response:
                                        send_text_message(phone, change_response)
                                except Exception as e:
                                    logger.error(f"Error processing course change: {e}")
                                finally:
                                    # Clear pending change in any case
                                    save_conversation_memory(phone, 'pending_course_change', None)
                                continue  # Skip further processing

                            if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in negative):
                                # User explicitly rejected the change
                                save_conversation_memory(phone, 'pending_course_change', None)
                                send_text_message(phone, f"Perfecto, continuamos con el curso '{selected_course.get('name')}'. ¿Qué más te gustaría saber?")
                                continue

                            # --- Handle explicit response to 'send temario PDF' question ---
                            try:
                                asked = get_conversation_memory(phone, 'asked_for_temario_pdf')
                            except Exception:
                                asked = None

                            if asked and isinstance(asked, dict):
                                # If user replied yes, send the PDF stored in memory
                                if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in affirmative):
                                    pdf_path = asked.get('pdf_path')
                                    course_name = asked.get('course_name')
                                    try:
                                        if pdf_path and os.path.exists(pdf_path):
                                            send_document_message(phone, pdf_path, caption=f"Temario completo: {course_name}")
                                            send_text_message(phone, f"📚 Te envié el temario completo del curso '{course_name}' en PDF. ¿Te gustaría saber sobre fechas, precio o ubicación?")
                                        else:
                                            send_text_message(phone, "Lo siento, no pude encontrar el PDF del temario. ¿Quieres que te dé más detalles sobre el temario o que te ponga en contacto con un asesor?")
                                    except Exception as e:
                                        logger.error(f"Error enviando PDF solicitado por usuario: {e}")
                                        send_text_message(phone, "Hubo un problema enviando el PDF. ¿Quieres que un asesor te ayude?")
                                    finally:
                                        try:
                                            save_conversation_memory(phone, 'asked_for_temario_pdf', None)
                                        except Exception:
                                            pass
                                    continue

                                if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in negative):
                                    # User declined PDF
                                    send_text_message(phone, "Perfecto, no enviaré el PDF. ¿Quieres que te dé un resumen del temario o que te ponga en contacto con un asesor?")
                                    try:
                                        save_conversation_memory(phone, 'asked_for_temario_pdf', None)
                                    except Exception:
                                        pass
                                    continue

                        elif 'info' in text_lower:
                            # User wants info without changing - this is already handled by the course_response
                            continue

                        elif 'continuar' in text_lower and selected_course:
                            # User wants to continue with current course
                            continue_response = f"Perfecto, continuamos con el curso '{selected_course.get('name')}'. ¿Qué más te gustaría saber?"
                            send_text_message(phone, continue_response)
                            continue

                        # Handle PDF sending for temario requests
                        if selected_course and any(w in (message_text or '').lower() for w in ['temario', 'contenido', 'programa']):
                            try:
                                logger.info(f"Attempting to send PDF for course {selected_course['id']}: {selected_course['name']}")
                                pdf_res = find_pdf_for_user_message(f"temario {selected_course['id']}", context={'relevant_courses': [selected_course]})
                                if not pdf_res:
                                    pdf_res = find_local_asset_pdf_for_course(selected_course['id'])
                                if pdf_res and pdf_res.get('pdf_path'):
                                    logger.info(f"Found PDF: {pdf_res['pdf_path']}")
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {selected_course['name']}")
                                    if send_result:
                                        logger.info(f"PDF sent successfully to {phone}")
                                    else:
                                        logger.error(f"Failed to send PDF to {phone}")
                                else:
                                    logger.warning(f"No PDF found for course {selected_course['id']}")
                            except Exception as e:
                                logger.error(f"Error sending PDF for course temario: {e}")

                        # Handle advisor requests
                        if any(w in (message_text or '').lower() for w in ['asesor', 'contactar', 'asesoría', 'asesoria']):
                            save_conversation_memory(phone, "advisor_prompt_sent", True)
                            save_conversation_memory(phone, "waiting_for_advisor_data", True)
                            if selected_course:
                                save_conversation_memory(phone, "advisor_course_id", selected_course['id'])

                        continue

                    # Manejo de inscripción: explicar proceso y enviar link
                    if is_inscription_request(message_text):
                        inscription_msg = get_inscription_process_message()
                        send_text_message(phone, inscription_msg)
                        continue

                    # DETECCIÓN DE MENSAJES PUBLICITARIOS ESPECÍFICOS DE CURSOS
                    course_detected = None
                    for course_type, keywords in course_ads.items():
                        if any(keyword in text_lower for keyword in keywords):
                            course_detected = course_type
                            break
                    
                    if course_detected:
                        # Mapeo de tipos de curso a IDs del JSON
                        course_mapping = {
                            'cableado_estructurado': 1,  # "Cableado estructurado para redes de fibra y cobre"
                            'fibra_planta_externa': 2,   # "Redes de fibra óptica planta externa"
                            'ftth_wisp_isp': 3,          # "Redes de fibra óptica FTTH para WISP e ISP"
                            'redes_pasivas_enterprise': 4, # "PONLAN redes pasivas para entornos enterprise"
                            'empalmes_otdr': 5           # "Empalmes y mediciones con OTDR de un enlace de fibra óptica"
                        }
                        
                        course_id = course_mapping.get(course_detected)
                        if course_id:
                            try:
                                # Obtener información completa del curso específico
                                course_info = get_course_complete_info(course_id)
                                if course_info:
                                    # Avoid redundant greeting when collecting advisor data
                                    try:
                                        waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                                    except Exception:
                                        waiting_for_advisor = False

                                    greeting = ""
                                    response_msg = f"{greeting}Perfecto, te comparto la información completa del curso:\n\n{course_info}"
                                    
                                    # Agregar información de modalidad online si no están en Querétaro
                                    response_msg += "\n\n📍 **MODALIDAD PRESENCIAL:** Querétaro, México"
                                    response_msg += "\n\n💻 **¿No te encuentras en Querétaro?**"
                                    response_msg += "\nTenemos **webinars GRATUITOS** en línea que se imparten cada **martes**."
                                    response_msg += "\n\n📚 **Webinars disponibles:**"
                                    response_msg += "\n• Soluciones preconectorizadas"
                                    response_msg += "\n• Empalmes de fibra óptica y OTDR"
                                    response_msg += "\n• Instalación subterránea"
                                    response_msg += "\n• De WISP a Fibra"
                                    response_msg += "\n• ODN en FTTX"
                                    response_msg += "\n• Centro de datos"
                                    response_msg += "\n\n🌐 **Ver calendario de webinars:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online"
                                    
                                    send_text_message(phone, response_msg)
                                else:
                                    # Fallback si no se encuentra el curso
                                    # Send a shorter, non-greeting prompt if we're already collecting advisor data
                                    try:
                                        waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                                    except Exception:
                                        waiting_for_advisor = False

                                    send_text_message(phone, "Te ayudo con información de nuestros cursos. ¿Podrías ser más específico sobre qué curso te interesa?")
                            except Exception as e:
                                logger.error(f"Error procesando mensaje publicitario de curso {course_detected}: {e}")
                                try:
                                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                                except Exception:
                                    waiting_for_advisor = False

                                send_text_message(phone, "Te ayudo con información de nuestros cursos. Escribe 'cursos' para ver todas las opciones disponibles.")
                        continue

                    # Manejo de opciones online / webinars / modalidad online / no ubicado en Querétaro
                    if any(k in text_lower for k in online_keywords) or any(loc in text_lower for loc in ['no me encuentro en querétaro', 'no estoy en querétaro', 'modalidad online', 'curso online', 'seminario en línea']):
                        # Respuesta mejorada para opciones online
                        online_msg = (
                            "¡Perfecto! 💻 **SÍ tenemos opciones EN LÍNEA**\n\n"
                            "🎓 **WEBINARS GRATUITOS** que se imparten cada **martes**:\n\n"
                            "📚 **Temas disponibles:**\n"
                            "• **Soluciones preconectorizadas**\n"
                            "• **Empalmes de fibra óptica y OTDR**\n"
                            "• **Instalación subterránea**\n"
                            "• **De WISP a Fibra**\n"
                            "• **ODN en FTTX**\n"
                            "• **Centro de datos**\n\n"
                            "🌐 **Ver calendario y registrarse:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
                            "💡 Si deseas información específica de algún webinar, escribe el nombre del tema y te doy más detalles.\n\n"
                            "📞 **¿Prefieres un curso presencial?** Nuestros cursos presenciales se imparten en **Querétaro, México**. Escribe 'cursos' para ver toda la información."
                        )
                        send_text_message(phone, online_msg)
                        continue

                    # Manejo de bobinas UTP
                    if any(k in text_lower for k in bobinas): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            bobinas_msg = ( 
                                "Las **bobinas** de cable UTP de la marca **Optronics®.** son una excelente opción para instalaciones de redes de datos y telecomunicaciones.\n\n"
                                "La información más relevante es que estos cables son 100% de cobre, ideales para redes de telecomunicaciones y LAN, y están disponibles en las categorías Cat. 6A, Cat. 6 y Cat. 5e.\n\n"
                                "El contenido destaca varias características clave del producto:\n\n"
                                "Tipos de Estructura: Se ofrecen en estructuras U/UTP, S/FTP y F/UTP. Rendimiento:\n\n"
                                "Garantizan alta fidelidad y rendimiento eléctrico y mecánico.\n\n"
                                "Aplicaciones: Son adecuados para redes LAN, cuartos de telecomunicaciones, PoE (Power over Ethernet), voz, datos, video y centros de datos.\n\n"
                                "Calidad y Certificación: La marca cumple con estándares nacionales e internacionales de seguridad y eficiencia.\n\n"
                                "¿Te gustaría saber más sobre la diferencia entre las categorías de cable (Cat. 6A, Cat. 6, Cat. 5e) o sobre las estructuras UTP (U/UTP, S/FTP, F/UTP)?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/bobinas-de-cable-utp"
                            )
                            send_text_message(phone, bobinas_msg)
                        else:
                            # Prefer DB-backed product info; fallback to LLM dynamic response if DB not available
                            try:
                                bobinas_fallback = (
                                    "Las **bobinas** de cable UTP de la marca **Optronics®.** son una excelente opción para instalaciones de redes de datos y telecomunicaciones.\n\n"
                                    "La información más relevante es que estos cables son 100% de cobre, ideales para redes de telecomunicaciones y LAN, y están disponibles en las categorías Cat. 6A, Cat. 6 y Cat. 5e.\n\n"
                                    "El contenido destaca varias características clave del producto:\n\n"
                                    "Tipos de Estructura: Se ofrecen en estructuras U/UTP, S/FTP y F/UTP. Rendimiento:\n\n"
                                    "Garantizan alta fidelidad y rendimiento eléctrico y mecánico.\n\n"
                                    "Aplicaciones: Son adecuados para redes LAN, cuartos de telecomunicaciones, PoE (Power over Ethernet), voz, datos, video y centros de datos.\n\n"
                                    "Calidad y Certificación: La marca cumple con estándares nacionales e internacionales de seguridad y eficiencia.\n\n"
                                    "¿Te gustaría saber más sobre la diferencia entre las categorías de cable (Cat. 6A, Cat. 6, Cat. 5e) o sobre las estructuras UTP (U/UTP, S/FTP, F/UTP)?"
                                )
                                send_db_or_fallback_message(phone, ['bobina', 'bobinas', 'utp', 'cable utp', 'cat 6a'], bobinas_fallback, fallback_link='https://contenido.fibremex.com/bobinas-de-cable-utp')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Eres un asistente técnico comercial que responde preguntas sobre productos. El usuario mencionó bobinas de cable UTP. "
                                        "Responde de forma conversacional y adaptada al historial, sin usar un texto predefinido. Si el usuario lo solicita, ofrece el enlace al producto. Mantén la respuesta breve y clara."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo darte información sobre las bobinas UTP y diferencias entre Cat. 6A/6/5e. ¿Qué te interesa saber exactamente?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para bobinas: {e}")
                                    send_text_message(phone, "Puedo darte información sobre las bobinas UTP. ¿Qué aspecto te interesa (categoría, estructura, aplicaciones)?")
                        continue

                    # Manejo de ducto para fibra óptica
                    if any(k in text_lower for k in ducto): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            ducto_msg = (
                                "Los **ductos de polietileno de alta densidad (HDPE/PEAD) de Optronics®** están diseñados para proteger la fibra óptica en instalaciones subterráneas.\n\n"
                                "Lo más relevante del producto es:\n\n"
                                "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental.\n\n"
                                "Facilidad de instalación: Viene prelubricado, lo que reduce el tiempo y el esfuerzo necesarios para instalar el cableado en su interior.\n\n"
                                "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                "Aplicaciones: Su uso principal es la protección de cables de fibra óptica contra daños mecánicos y ambientales en campus, zonas urbanas o torres de telecomunicaciones.\n\n"
                                "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/ductos-de-fibra-optica"
                            )
                            send_text_message(phone, ducto_msg)
                        else:
                            try:
                                ducto_fallback = (
                                    "Los **ductos de polietileno de alta densidad (HDPE/PEAD) de Optronics®** están diseñados para proteger la fibra óptica en instalaciones subterráneas.\n\n"
                                    "Lo más relevante del producto es:\n\n"
                                    "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental.\n\n"
                                    "Facilidad de instalación: Viene prelubricado, lo que reduce el tiempo y el esfuerzo necesarios para instalar el cableado en su interior.\n\n"
                                    "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                    "Aplicaciones: Su uso principal es la protección de cables de fibra óptica contra daños mecánicos y ambientales en campus, zonas urbanas o torres de telecomunicaciones.\n\n"
                                    "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['ducto', 'ductos', 'hdpe', 'ducto fibra'], ducto_fallback, fallback_link='https://contenido.fibremex.com/ductos-de-fibra-optica')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma contextual sobre ductos de fibra óptica. No utilices mensajes prefabricados; adapta la respuesta al usuario y ofrece preguntar por especificaciones de tamaño, resistencia y aplicaciones."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo darte especificaciones de ductos HDPE y opciones de tamaño. ¿Qué necesitas saber?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para ducto: {e}")
                                    send_text_message(phone, "Puedo darte especificaciones de ductos HDPE y opciones de tamaño. ¿Qué necesitas saber?")
                        continue

                    # Manejo de tritubo para fibra óptica
                    if any(k in text_lower for k in tritubo): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            tritubo_msg = ( 
                                "El **tritubo de polietileno de alta densidad (HDPE/PEAD) de Optronics®** es una solución avanzada para la protección y organización de cables de fibra óptica en instalaciones subterráneas.\n\n"
                                "Lo más relevante del producto es:\n\n"
                                "Diseño innovador: Cuenta con tres conductos independientes dentro de un solo tubo, lo que permite la instalación de múltiples cables de fibra óptica sin interferencias.\n\n"
                                "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental, asegurando la protección a largo plazo de los cables.\n\n"
                                "Facilidad de instalación: Viene prelubricado, lo que facilita el proceso de instalación y reduce el tiempo y esfuerzo necesarios.\n\n"
                                "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                "Aplicaciones: Ideal para proyectos que requieren la instalación de varios cables de fibra óptica en un espacio reducido, como en zonas urbanas o campus empresariales.\n\n"
                                "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/tritubo-proteccion-para-fibra-optica"
                            )
                            send_text_message(phone, tritubo_msg)
                        else:
                            try:
                                tritubo_fallback = (
                                    "El **tritubo de polietileno de alta densidad (HDPE/PEAD) de Optronics®** es una solución avanzada para la protección y organización de cables de fibra óptica en instalaciones subterráneas.\n\n"
                                    "Lo más relevante del producto es:\n\n"
                                    "Diseño innovador: Cuenta con tres conductos independientes dentro de un solo tubo, lo que permite la instalación de múltiples cables de fibra óptica sin interferencias.\n\n"
                                    "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental, asegurando la protección a largo plazo de los cables.\n\n"
                                    "Facilidad de instalación: Viene prelubricado, lo que facilita el proceso de instalación y reduce el tiempo y esfuerzo necesarios.\n\n"
                                    "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                    "Aplicaciones: Ideal para proyectos que requieren la instalación de varios cables de fibra óptica en un espacio reducido, como en zonas urbanas o campus empresariales.\n\n"
                                    "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['tritubo', 'tri-tubo', 'tri tubo', 'tritubos'], tritubo_fallback, fallback_link='https://contenido.fibremex.com/tritubo-proteccion-para-fibra-optica')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma conversacional sobre tritubos HDPE: explica ventajas, aplicaciones y preguntas que ayudarán a determinar la mejor opción. Evita respuestas prefabricadas."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo explicar ventajas y aplicaciones del tritubo. ¿Qué te gustaría saber?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para tritubo: {e}")
                                    send_text_message(phone, "Puedo explicar ventajas y aplicaciones del tritubo. ¿Qué te gustaría saber?")
                        continue

                    if any(k in text_lower for k in jumper): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            jumper_msg = (
                                "Los **jumperes de fibra óptica MPO/MTP de la marca Optronics®** son esenciales para la interconexión de equipos y enlaces de fibra óptica. Lo más relevante es que estos cables se caracterizan por su alta densidad de fibra y se utilizan principalmente para interconexiones rápidas y eficientes en centros de datos, redes de telecomunicaciones y entornos de alta densidad.\n\n"
                                "Las características principales que se mencionan son:\n\n"
                                "Tipos de conectores: Se enfocan en los conectores MPO, MTP y MTPpro, que permiten la transmisión de múltiples fibras en un solo conector.\n\n"
                                "Alta densidad: Facilitan un gran número de conexiones en espacios reducidos, lo que es crucial para la eficiencia en data centers.\n\n"
                                "Velocidad: Soportan conexiones de alta velocidad como 40G y 100G.\n\n"
                                "Diseño: Tienen un diseño Push-Pull que facilita la conexión y desconexión sin necesidad de herramientas.\n\n"
                                "Aplicaciones: Son ideales para interconexiones en racks, paneles de parcheo y equipos de red.\n\n"
                                "¿Quieres saber más sobre las diferencias entre los conectores MPO, MTP y MTPpro, o sobre las especificaciones técnicas y opciones disponibles?\n\n"
                                "Si lo deseas, puedo comparar las diferencias y ventajas de los conectores MPO, MTP y MTPpro para que comprendas mejor cuál podría ser el más adecuado para un proyecto específico.\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/jumper-fibra-optica-mpo-mtp-mtppro"
                            )
                            send_text_message(phone, jumper_msg)
                        else:
                            try:
                                jumper_fallback = (
                                    "Los **jumperes de fibra óptica MPO/MTP de la marca Optronics®** son esenciales para la interconexión de equipos y enlaces de fibra óptica. Lo más relevante es que estos cables se caracterizan por su alta densidad de fibra y se utilizan principalmente para interconexiones rápidas y eficientes en centros de datos, redes de telecomunicaciones y entornos de alta densidad.\n\n"
                                    "Las características principales que se mencionan son:\n\n"
                                    "Tipos de conectores: Se enfocan en los conectores MPO, MTP y MTPpro, que permiten la transmisión de múltiples fibras en un solo conector.\n\n"
                                    "Alta densidad: Facilitan un gran número de conexiones en espacios reducidos, lo que es crucial para la eficiencia en data centers.\n\n"
                                    "Velocidad: Soportan conexiones de alta velocidad como 40G y 100G.\n\n"
                                    "Diseño: Tienen un diseño Push-Pull que facilita la conexión y desconexión sin necesidad de herramientas.\n\n"
                                    "Aplicaciones: Son ideales para interconexiones en racks, paneles de parcheo y equipos de red.\n\n"
                                    "¿Quieres saber más sobre las diferencias entre los conectores MPO, MTP y MTPpro, o sobre las especificaciones técnicas y opciones disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['mpo', 'mtp', 'jumper', 'jumperes', 'multi-fiber push on'], jumper_fallback, fallback_link='https://contenido.fibremex.com/jumper-fibra-optica-mpo-mtp-mtppro')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma conversacional sobre jumpers MPO/MTP: explica aplicaciones, diferencias y guía de selección. No uses un texto prefabricado."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo comparar conectores MPO, MTP y MTPpro para tu caso. ¿Qué necesitas conectar?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para jumper: {e}")
                                    send_text_message(phone, "Puedo comparar conectores MPO, MTP y MTPpro para tu caso. ¿Qué necesitas conectar?")
                        continue

                

                    if any(k in text_lower for k in soluciones_preconectorizadas):
                        try:
                            webinar_info = get_specific_webinar_info(0)
                            send_text_message(phone, webinar_info)
                        except Exception as e:
                            logger.error(f"Error obteniendo info de webinar soluciones_preconectorizadas desde JSON: {e}")
                            send_text_message(phone, "No pude obtener la información del webinar de soluciones preconectorizadas. Intenta de nuevo más tarde.")
                        continue

                    if any(k in text_lower for k in empalmes_fibra_optica):
                        # Buscar el webinar correspondiente en el JSON y responder con su info
                        try:
                            # El webinar de empalmes de fibra óptica es el segundo en el JSON (índice 1)
                            webinar_info = get_specific_webinar_info(1)
                            send_text_message(phone, webinar_info)
                        except Exception as e:
                            logger.error(f"Error obteniendo info de webinar empalmes_fibra_optica desde JSON: {e}")
                            send_text_message(phone, "No pude obtener la información del webinar de empalmes de fibra óptica. Intenta de nuevo más tarde.")
                        continue

                    if any(k in text_lower for k in instalacion_subterranea):
                        try:
                            webinar_info = get_specific_webinar_info(2)
                            send_text_message(phone, webinar_info)
                        except Exception as e:
                            logger.error(f"Error obteniendo info de webinar instalacion_subterranea desde JSON: {e}")
                            send_text_message(phone, "No pude obtener la información del webinar de instalación subterránea. Intenta de nuevo más tarde.")
                        continue

                    if any(k in text_lower for k in wisp_a_fibra):
                        try:
                            webinar_info = get_specific_webinar_info(3)
                            send_text_message(phone, webinar_info)
                        except Exception as e:
                            logger.error(f"Error obteniendo info de webinar wisp_a_fibra desde JSON: {e}")
                            send_text_message(phone, "No pude obtener la información del webinar de WISP a Fibra. Intenta de nuevo más tarde.")
                        continue

                    if any(k in text_lower for k in odn_en_fttx):
                        try:
                            webinar_info = get_specific_webinar_info(4)
                            send_text_message(phone, webinar_info)
                        except Exception as e:
                            logger.error(f"Error obteniendo info de webinar odn_en_fttx desde JSON: {e}")
                            send_text_message(phone, "No pude obtener la información del webinar de ODN en FTTX. Intenta de nuevo más tarde.")
                        continue

                    if any(k in text_lower for k in centro_de_datos):
                        centro_de_datos_msg = (
                            "Descubre cómo diseñar, gestionar y optimizar un centro de datos, abordando desde sus componentes esenciales hasta las tendencias más actuales en cableado y ensambles multifibra.\n\n"
                            "Mediante un enfoque técnico y práctico, conocerás las mejores prácticas de diseño, tipos de data centers, configuración de cableado, y cómo las nuevas tecnologías están transformando la eficiencia y seguridad de estos entornos.\n\n"
                            "**¿Qué aprenderás?:**\n\n"
                            "✅  Definiciones y componentes de centro de datos\n\n"
                            "✅  Tipos de data centers\n\n"
                            "✅  Topología de la infraestructura de red\n\n"
                            "✅  Cableado de comunicaciones para DC\n\n"
                            "✅  Ensambles multifibra, configuraciones y arreglos\n\n"
                            "✅  Tendencias en los ensambles multifibra\n\n"
                            "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/ciclo5-seminario6-centro-de-datos"
                        )
                        send_text_message(phone, centro_de_datos_msg)
                        continue

                    # Manejo de ubicación / dónde es el curso
                    if any(k in text_lower for k in where_keywords):
                        # Si ya hay un curso seleccionado, responder con la ubicación desde la DB
                        try:
                            selected_course = get_selected_course(phone)
                            if selected_course and selected_course.get('id'):
                                from utils.courses_adapter import get_course_location_message
                                send_text_message(phone, get_course_location_message(selected_course.get('id')))
                                continue
                            else:
                                # No hay curso seleccionado, pedir al usuario el nombre o sugerir cursos
                                send_text_message(phone, "¿De qué curso quieres saber la ubicación? Dime el nombre del curso o pide que te recomiende según lo que quieras aprender.")
                                continue
                        except Exception:
                            # Fallback: mantener la respuesta genérica si ocurre un error
                            send_text_message(phone, "Dime el nombre del curso para indicarte la ubicación o si prefieres te recomiendo cursos según tu objetivo.")
                            continue
                    
                    # Detectar si el usuario está pidiendo información sobre un curso específico
                    course_selection_keywords = [
                        "quiero información sobre el curso", "me interesa el curso",
                        "dime más sobre el curso", "información del curso",
                        "detalles del curso", "más información del curso",
                        "me puedes dar información del curso", "sobre el curso de",
                        "curso de", "certificación en", "capacitación en",
                        "temario de", "precio del curso", "fechas del curso"
                    ]

                    # Si el mensaje parece referirse a un curso, intentar resolverlo mediante ML+DB
                    is_course_selection = any(keyword in (message_text or '').lower() for keyword in course_selection_keywords)
                    # Guard: si estamos en el flujo guiado del asesor, no intentar seleccionar cursos por nombre
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor and is_course_selection:
                        logger.info(f"Skipping select_course_by_name because waiting_for_advisor_data is set for {phone}")
                    elif is_course_selection:
                        try:
                            # Usar el adaptador conversacional para identificar el curso (sin mappings predefinidos)
                            try:
                                from utils.courses_adapter import select_course_by_name
                            except Exception:
                                def select_course_by_name(phone, text):
                                    return {'selected': False, 'candidates': [], 'message': 'Funcionalidad de cursos deshabilitada.'}
                            sel = select_course_by_name(phone, message_text)
                            logger.info(f"Resultado select_course_by_name: {sel}")
                            if sel.get('selected') and sel.get('course'):
                                course = sel['course']
                                # Si es pregunta técnica, guardar como recomendación pendiente en memoria
                                if is_technical_question:
                                    try:
                                        save_conversation_memory(phone, 'pending_course_recommendation', {
                                            'id': getattr(course, 'id', None),
                                            'name': getattr(course, 'nombre', ''),
                                            'reason': 'detected_in_technical_query'
                                        })
                                        logger.info(f"Guardada recomendación pendiente para {phone}: {getattr(course,'nombre','')}")
                                    except Exception:
                                        logger.debug("No se pudo guardar pending_course_recommendation en memoria")
                                else:
                                    # Guardar selección formalmente
                                    try:
                                        save_selected_course(phone, getattr(course, 'id', None), getattr(course, 'nombre', ''), {"detected_from_message": message_text})
                                    except Exception:
                                        logger.debug("No se pudo guardar selected_course pero se continuará")
                        except Exception as e:
                            logger.debug(f"Error identificando curso mediante select_course_by_name: {e}")
                    
                    # Obtener información sobre el curso seleccionado anteriormente (si existe)
                    selected_course = get_selected_course(phone)

                    # Manejar respuestas afirmativas cortas (ej. "si", "sí", "ok")
                    try:
                        affirmative_regex = r"^\s*(si|sí|s|claro|ok|vale|por favor|porfa)\b.*$"
                        if isinstance(message_text, str) and re.match(affirmative_regex, message_text.lower()):
                            logger.info(f"Respuesta afirmativa detectada para {phone}: '{message_text}'")
                            # Check if we are specifically waiting for a course confirmation
                            waiting_confirmation = False
                            try:
                                waiting_confirmation = bool(get_conversation_memory(phone, "waiting_for_course_confirmation"))
                            except Exception:
                                waiting_confirmation = False

                            # Intentar enviar el temario si ya hay un curso seleccionado en la memoria
                            if waiting_confirmation and selected_course and not avoid_curso_intent and not is_technical_question:
                                try:
                                    # Buscar el PDF preferentemente por ID/nombre del curso en el contexto
                                    query_for_pdf = f"temario {selected_course.get('name', '')}"
                                    pdf_result = find_pdf_for_user_message(query_for_pdf, context={'relevant_courses': [selected_course]})
                                    if not pdf_result and selected_course and selected_course.get('id'):
                                        pdf_result = find_local_asset_pdf_for_course(selected_course.get('id'))
                                    if pdf_result and pdf_result.get('pdf_path'):
                                        pdf_path = pdf_result.get('pdf_path')
                                        caption = f"Temario {selected_course.get('name')}"
                                        logger.info(f"Enviando temario {pdf_path} a {phone} (confirmación del usuario)")
                                        send_document_message(phone, pdf_path, caption=caption)
                                        send_text_message(phone, f"Te envié el temario {selected_course.get('name')}. ¿Deseas que también te comparta fechas, precio y ubicación del curso?")
                                        # Limpiar la bandera de confirmación y continuar
                                        try:
                                            save_conversation_memory(phone, "waiting_for_course_confirmation", False)
                                        except Exception:
                                            logger.debug("No se pudo limpiar waiting_for_course_confirmation en memoria")
                                        continue
                                except Exception as e:
                                    logger.error(f"Error buscando/enviando PDF por confirmación: {e}", exc_info=True)
                            # Si no hay curso seleccionado, no hay PDF o no estábamos esperando confirmación, pedir clarificación
                            try:
                                # limpiar la bandera si existe para evitar confusión
                                save_conversation_memory(phone, "waiting_for_course_confirmation", False)
                            except Exception:
                                pass
                            send_text_message(phone, "¿A qué curso te refieres? Indícanos el nombre del curso (por ejemplo: 'Cableado estructurado') para enviarte el temario en PDF.")
                            continue
                    except Exception:
                        logger.debug("No se pudo procesar la posible respuesta afirmativa (continuando normalmente)")

                    # Detectar intención explícita de 'cursos' y enviar lista automáticamente
                    try:
                        if re.search(r"\bcurso(s)?\b", (message_text or '').lower()):
                            # Evitar spam si el usuario ya tiene un curso seleccionado
                            selected_course = get_selected_course(phone)
                            # Solo enviar la lista automáticamente si NO estamos evitando cursos
                            # y si no parece una pregunta técnica.
                            if not selected_course and not avoid_curso_intent and not is_technical_question:
                                logger.info(f"Enviando lista de cursos automáticamente a {phone} por intención detectada")
                                send_text_message(phone, list_courses_message())
                                continue

                    except Exception as e:
                        logger.error(f"Error al enviar lista de cursos automáticamente: {e}")

                    # --- Manejo de selección conversacional inteligente (sin números) ---
                    # Esta lógica ya no utiliza números, se basa en detección de intención natural
                    # La selección se maneja através de smart_course_selection_by_intent() más arriba
                    try:
                        # Mantener compatibilidad con números solo si el usuario los usa explícitamente
                        # pero preferir siempre la detección conversacional
                        from utils.courses_adapter import parse_course_number_from_text
                        num = parse_course_number_from_text(message_text or '')
                        if num and 1 <= num <= 5 and not avoid_curso_intent and not is_technical_question:
                            # Solo usar números si no se detectó por conversación natural antes
                            logger.info(f"Usuario seleccionó curso por número (fallback): {num} (phone={phone})")
                            try:
                                _CourseManager = CourseManager
                                course_obj = _CourseManager.get_course_by_id(num)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                save_selected_course(phone, num, course_name, {"selected_at": datetime.now().isoformat(), "method": "number_fallback"})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # Enviar detalles formateados
                            details = get_course_details_by_number(num)
                            send_text_message(phone, details)

                            # Si el usuario pidió explícitamente 'temario' en este mensaje, enviarlo
                            pdf_res = None
                            try:
                                if 'temario' in (message_text or '').lower():
                                    pdf_res = find_pdf_for_user_message(f"temario {num}")
                                    if not pdf_res:
                                        pdf_res = find_local_asset_pdf_for_course(num)
                                else:
                                    # Pedir confirmación para enviar el temario
                                    send_text_message(phone, f"¿Te refieres al curso {course_name}? Responde 'sí' o escribe 'temario' para que te envíe el temario en PDF.")
                                    # Marcar en memoria que esperamos confirmación explícita del usuario
                                    try:
                                        save_conversation_memory(phone, "waiting_for_course_confirmation", True)
                                    except Exception:
                                        logger.debug("No se pudo guardar waiting_for_course_confirmation en memoria")
                            except Exception:
                                logger.debug("Skipping PDF search due to context/guard or error")

                            if pdf_res and pdf_res.get('pdf_path'):
                                try:
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario {pdf_res.get('course_name','')}")
                                    if send_result:
                                        logger.info(f"PDF enviado correctamente a {phone} para curso {num}: {pdf_res.get('pdf_path')}")
                                    else:
                                        logger.warning(f"Intento de envío de PDF devolvió resultado vacío/None para {phone} (curso {num})")
                                except Exception as e:
                                    logger.error(f"Error al enviar PDF del curso {num} a {phone}: {e}")
                            else:
                                # Fallback: intentar buscar y enviar directamente desde carpetas locales
                                try:
                                    from utils import whatsapp as whatsapp_utils
                                    # Prepare several candidate queries: prefer the course name when available
                                    course_name_candidate = course_name if 'course_name' in locals() and course_name else None
                                    candidates = []
                                    if course_name_candidate:
                                        candidates.append(course_name_candidate)
                                        # try shorter variants
                                        candidates.append(course_name_candidate.split(' - ')[0])
                                    candidates.extend([str(num), f"{num}", f"{num}.", f"curso {num}", f"temario {num}"])
                                    sent = False
                                    logger.info(f"No se encontró PDF via adapter; intentando búsqueda directa en assets/pdfs con queries: {candidates}")
                                    if hasattr(whatsapp_utils, 'find_and_send_pdf'):
                                        for q in candidates:
                                            if not q:
                                                continue
                                            send_result = whatsapp_utils.find_and_send_pdf(phone, q, caption=f"Temario {num}")
                                            if send_result:
                                                logger.info(f"PDF enviado correctamente (fallback directo) a {phone} para curso {num} usando query '{q}'")
                                                sent = True
                                                try:
                                                    send_text_message(phone, "Te envié el temario en PDF desde nuestros recursos. ¿Te gustaría saber sobre fechas, precio o ubicación del curso?")
                                                except Exception:
                                                    pass
                                                break
                                        if not sent:
                                            logger.info(f"No se encontró o no se pudo enviar PDF desde assets/pdfs para ninguna de las queries: {candidates}")
                                    else:
                                        logger.debug('whatsapp_utils.find_and_send_pdf no disponible')
                                except Exception as e:
                                    logger.debug(f"Fallback directo para enviar PDF falló: {e}")

                            # Ya respondimos a la selección, continuar con siguiente webhook
                            continue
                    except Exception as e:
                        logger.error(f"Error procesando selección numérica de curso: {e}", exc_info=True)
                    
                    # --- Manejo de selección por palabras clave específicas de cursos ---
                    try:
                        message_lower = (message_text or '').lower()
                        detected_course_id = None
                        
                        # Mapeo de palabras clave a IDs de curso con prioridades
                        course_keywords = {
                            1: ['cableado', 'estructurado', 'cobre'],
                            2: ['planta externa', 'exterior', 'outdoor'],
                            3: ['ftth', 'wisp', 'isp', 'gpon'],
                            4: ['ponlan', 'enterprise', 'empresarial', 'corporativo', 'pasivas'],
                            5: ['empalmes', 'otdr', 'mediciones', 'fusion']
                        }
                        
                        # Palabras clave únicas que identifican cursos específicos
                        unique_keywords = {
                            3: ['ftth'],
                            4: ['ponlan'],
                            5: ['otdr', 'empalmes'],
                            2: ['planta externa', 'fibra óptica externa'],
                            1: ['cableado estructurado']
                        }
                        
                        detected_course_id = None
                        
                        # Primero buscar términos únicos (prioridad alta)
                        for course_id, keywords in unique_keywords.items():
                            if any(keyword in message_lower for keyword in keywords):
                                detected_course_id = course_id
                                logger.info(f"Curso detectado por término único: {course_id} (palabras: {keywords})")
                                break
                        
                        # Si no hay términos únicos, buscar por palabras clave con mejor lógica
                        if not detected_course_id:
                            course_keywords = {
                                1: ['cableado', 'estructurado', 'cobre'],
                                2: ['planta externa', 'fibra óptica', 'exterior', 'outdoor', 'externa'],
                                3: ['ftth', 'wisp', 'isp', 'gpon'],
                                4: ['ponlan', 'enterprise', 'empresarial', 'corporativo', 'pasivas'],
                                5: ['empalmes', 'otdr', 'mediciones', 'fusion']
                            }
                            
                            course_scores = {}
                            
                            for course_id, keywords in course_keywords.items():
                                score = 0
                                for keyword in keywords:
                                    if keyword in message_lower:
                                        # Dar más peso a palabras más largas/menos comunes
                                        score += len(keyword) * 2
                                        # Bonus por palabras completas
                                        if f" {keyword} " in f" {message_lower} ":
                                            score += 10
                                        # Bonus por frases completas
                                        if keyword.replace(' ', '') in message_lower.replace(' ', ''):
                                            score += 5
                                
                                if score > 0:
                                    course_scores[course_id] = score
                            
                            # Seleccionar el curso con mayor puntuación
                            if course_scores:
                                detected_course_id = max(course_scores, key=course_scores.get)
                                logger.info(f"Curso detectado por puntuación: {detected_course_id} (scores: {course_scores})")
                            
                            # Seleccionar el curso con mayor puntuación
                            if course_scores:
                                detected_course_id = max(course_scores, key=course_scores.get)
                                logger.info(f"Curso detectado por puntuación: {detected_course_id} (scores: {course_scores})")
                        
                        # Si se detectó un curso por palabra clave, enviarlo (salvo que sea pregunta técnica)
                        if detected_course_id and not avoid_curso_intent:
                            if is_technical_question:
                                # Guardar como recomendación pendiente, no enviar ni seleccionar automáticamente
                                try:
                                    _CourseManager = CourseManager
                                    course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                    course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                    save_conversation_memory(phone, 'pending_course_recommendation', {'id': detected_course_id, 'name': course_name, 'reason': 'keyword_in_technical_query'})
                                    logger.info(f"Guardada recomendación pendiente (keyword) para {phone}: {course_name}")
                                except Exception:
                                    logger.debug("No se pudo guardar pending_course_recommendation (keyword) en memoria")
                                # Do not proceed with the normal course-details flow for technical queries
                                continue

                        if detected_course_id and not avoid_curso_intent and not is_technical_question:
                            logger.info(f"Usuario seleccionó curso por palabra clave: {detected_course_id} (phone={phone})")
                            # Guardar selección en memoria primero
                            try:
                                _CourseManager = CourseManager
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                _save_selected_course(phone, detected_course_id, course_name, {"selected_at": datetime.now().isoformat(), "suppress_llm": True})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # Enviar detalles formateados
                            details = get_course_details_by_number(detected_course_id)
                            send_text_message(phone, details)

                            # Cuando el usuario pide información específica de un curso (detectado por palabras clave),
                            # enviar el temario automáticamente sin pedir confirmación
                            pdf_res = None
                            try:
                                pdf_res = find_pdf_for_user_message(f"temario {detected_course_id}")
                                if not pdf_res:
                                    pdf_res = find_local_asset_pdf_for_course(detected_course_id)
                            except Exception:
                                logger.debug("No se pudo buscar PDF del temario")

                            if pdf_res and pdf_res.get('pdf_path'):
                                try:
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {course_name}")
                                    if send_result:
                                        logger.info(f"PDF enviado correctamente a {phone} para curso {detected_course_id}: {pdf_res.get('pdf_path')}")
                                        send_text_message(phone, "Te envié el temario en PDF. ¿Te gustaría saber sobre fechas, precio o ubicación del curso?")
                                    else:
                                        logger.warning(f"Intento de envío de PDF devolvió resultado vacío/None para {phone} (curso {detected_course_id})")
                                        send_text_message(phone, "El temario está disponible. ¿Te gustaría que te enviara más información sobre fechas, precio o ubicación?")
                                except Exception as e:
                                    logger.error(f"Error al enviar PDF del curso {detected_course_id} a {phone}: {e}")
                                    send_text_message(phone, "El temario está disponible. ¿Te gustaría que te enviara más información sobre fechas, precio o ubicación?")
                            else:
                                # Fallback: intentar enviar directamente desde assets/pdfs usando utils.whatsapp
                                try:
                                    from utils import whatsapp as whatsapp_utils
                                    course_name_candidate = course_name if 'course_name' in locals() and course_name else None
                                    candidates = []
                                    if course_name_candidate:
                                        candidates.append(course_name_candidate)
                                        candidates.append(course_name_candidate.split(' - ')[0])
                                    candidates.extend([str(detected_course_id), f"{detected_course_id}", f"{detected_course_id}.", f"curso {detected_course_id}", f"temario {detected_course_id}"])
                                    sent = False
                                    logger.info(f"No se encontró PDF via adapter; intentando búsqueda directa en assets/pdfs con queries: {candidates}")
                                    if hasattr(whatsapp_utils, 'find_and_send_pdf'):
                                        for q in candidates:
                                            if not q:
                                                continue
                                            send_result = whatsapp_utils.find_and_send_pdf(phone, q, caption=f"Temario completo: {course_name}")
                                            if send_result:
                                                logger.info(f"PDF enviado correctamente (fallback directo) a {phone} para curso {detected_course_id} usando query '{q}'")
                                                sent = True
                                                try:
                                                    send_text_message(phone, "Te envié el temario en PDF desde nuestros recursos. ¿Te gustaría saber sobre fechas, precio o ubicación del curso?")
                                                except Exception:
                                                    pass
                                                break
                                        if not sent:
                                            logger.info(f"No se encontró o no se pudo enviar PDF desde assets/pdfs para ninguna de las queries: {candidates}")
                                    else:
                                        logger.debug('whatsapp_utils.find_and_send_pdf no disponible')
                                except Exception as e:
                                    logger.debug(f"Fallback directo para enviar PDF falló: {e}")

                            # Guardar selección en la memoria de conversación
                            try:
                                _CourseManager = CourseManager
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                # Guardar selección y suprimir la generación inmediata del LLM
                                _save_selected_course(phone, detected_course_id, course_name, {"selected_at": datetime.now().isoformat(), "suppress_llm": True})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # No enviar mensaje adicional - ya está incluido en get_course_details_by_number()
                            # Ya respondimos a la selección, continuar con siguiente webhook
                            continue
                    except Exception as e:
                        logger.error(f"Error procesando selección por palabra clave: {e}", exc_info=True)
                    
                    # Generar respuesta con memoria y contexto adicional (curso)
                    # El system_prompt_override toma precedencia sobre el system_prompt del adaptador ML
                    system_prompt = system_prompt_override or ml_adapter_result.get('system_prompt')
                    
                    # Incorporar información del curso seleccionado en el system prompt si está disponible
                    if selected_course and not system_prompt_override and not avoid_curso_intent:
                        # Crear contexto enriquecido con información del curso seleccionado
                        course_context = (
                            f"\nINFORMACIÓN IMPORTANTE: El usuario ha seleccionado o mostrado interés en el "
                            f"curso '{selected_course['name']}' previamente. "
                            f"Puedes referirte a este curso específicamente cuando sea relevante para la conversación. "
                            f"Si la consulta actual del usuario está relacionada con este curso, proporciona información detallada y relevante. "
                            f"Si la consulta no está relacionada con este curso, responde adecuadamente pero mantén en cuenta este interés previo."
                        )
                        
                        # Añadir el contexto al system prompt
                        if system_prompt:
                            system_prompt = system_prompt + course_context
                        else:
                            system_prompt = (
                                "Eres un asistente experto en fibra óptica y telecomunicaciones. "
                                "Responde de manera clara, precisa y profesional a las consultas de los usuarios. "
                                + course_context
                            )
                        
                        logger.info(f"System prompt enriquecido con contexto de curso seleccionado para {phone}")
                    
                    # Si tenemos una anulación del system_prompt, registrarlo
                    if system_prompt_override:
                        logger.info(f"Usando system_prompt_override: {system_prompt_override[:50]}...")

                    # Si el curso seleccionado indica que debemos suprimir la generación LLM
                    try:
                        selected_course = get_selected_course(phone)
                        if selected_course and isinstance(selected_course.get('details', {}), dict) and selected_course.get('details', {}).get('suppress_llm'):
                            # Limpiar la bandera para que en la siguiente interacción sí pueda generarse LLM normalmente
                            selected_course['details'].pop('suppress_llm', None)
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            # Guardar la memoria actualizada sin la bandera
                            try:
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                _save_selected_course(phone, selected_course.get('id'), selected_course.get('name', ''), selected_course.get('details', {}))
                            except Exception:
                                logger.debug("No se pudo actualizar la marca suppress_llm en memoria")
                            # Saltar la generación LLM para esta petición (ya respondimos con la info del curso)
                            logger.info(f"Supressing LLM generation for phone={phone} due to recent course info send")
                            continue
                    except Exception:
                        # En caso de cualquier fallo, no bloquear la generación normal
                        logger.debug("No se pudo verificar la bandera suppress_llm (continuando)")
                    
                    # Medir tiempo de generación de respuesta
                    start_response_time = datetime.now()

                    # Detectar explícitamente si la intención del usuario es sobre CURSOS
                    # y responder directamente desde la fuente canónica (constants.js / DB)
                    # para evitar que el LLM invente fechas, precios o duraciones.
                    skip_gemini = False
                    try:
                        def _detect_course_intent(text: str):
                            t = (text or '').lower()
                            # Palabras clave que indican interés en cursos
                            course_kw = [
                                'curso', 'cursos', 'temario', 'capacitación', 'capacitacion', 'formacion', 'formación',
                                'inscribirme', 'inscripción', 'inscripcion', 'precio', 'precio del curso', 'costo', 'fechas',
                                'duración', 'duracion', 'modalidad', 'temario', 'programa', 'contenido', 'inscripción',
                                'dónde se imparte', 'donde se imparte', 'fecha del curso', 'próximo curso', 'proximo curso',
                                'recomien', 'sugier', 'estudiar', 'aprender', 'certificar', 'entrenar', 'capacitar',
                                'cursos tienes', 'cursos disponibles', 'opciones de curso', 'que me recomiendas',
                                'cual me conviene', 'que curso', 'interesado en curso', 'busco curso'
                            ]

                            # Indicadores técnicos que deben anular intención de curso
                            technical_kw = [
                                'cómo', 'como', 'cuál', 'cual', 'qué', 'que', 'instalación', 'instalacion', 'configuración',
                                'configuracion', 'problema', 'error', 'empalme', 'otdr', 'mediciones', 'atenuación', 'atenuacion',
                                'conector', 'fusión', 'fusion', 'falla', 'no funciona', 'diagnóstico', 'diagnostico'
                            ]

                            course_score = sum(1 for k in course_kw if k in t)
                            technical_score = sum(1 for k in technical_kw if k in t)

                            # Dar más peso a frases claras
                            clear_course = ['quiero inscribirme', 'información sobre el curso', 'quiero tomar el curso', 'fechas del curso', 'precio del curso']
                            clear_tech = ['cómo funciona', 'cómo se hace', 'como funciona', 'como se hace', 'ayúdame con', 'ayudame con']
                            for phrase in clear_course:
                                if phrase in t:
                                    course_score += 3
                            for phrase in clear_tech:
                                if phrase in t:
                                    technical_score += 3

                            # Decisión
                            user_asks_courses = course_score > 0 and course_score >= technical_score
                            if technical_score > course_score + 1:
                                user_asks_courses = False

                            is_tech = technical_score > course_score
                            return user_asks_courses, is_tech

                        user_asking_about_courses, is_technical_question = _detect_course_intent(message_text)

                        # Use ML result to override/confirm intent detection (prefer ML when available)
                        try:
                            # Get recent conversation history to help ML
                            conv_hist = get_conversation_history(phone) or []
                            ml_result_local = ml_service.process_message(message_text, conversation_history=conv_hist, phone=phone)
                            classification = ml_result_local.get('classification', {}) or {}
                            ml_category = classification.get('category')
                            ml_conf = float(classification.get('confidence') or 0)

                            # If ML strongly indicates technical, prioritize technical
                            if ml_category in ('soporte_tecnico', 'soporte', 'soporte-técnico') and ml_conf >= 0.45:
                                is_technical_question = True
                                user_asking_about_courses = False

                            # If ML strongly indicates courses/webinars, push toward course intent
                            if ml_category in ('cursos', 'webinars') and ml_conf >= 0.45:
                                user_asking_about_courses = True
                                # only mark as non-technical if confidence is reasonably high
                                if ml_conf >= 0.6:
                                    is_technical_question = False
                        except Exception as e:
                            logger.debug(f"ML override failed: {e}")

                        # Solo enviar información de cursos si el usuario hace una petición explícita
                        explicit_course_request = False
                        try:
                            tlower = (message_text or '').lower()
                            explicit_course_request = bool(re.search(r"\b(curso|cursos|temario|inscribirme|inscripción|inscripcion|precio|fechas|dónde se imparte|donde se imparte|quiero inscribirme|quiero tomar el curso|recomien|sugier|capacitación|capacitacion|entrenam|aprend|estudi)\b", tlower))
                        except Exception:
                            explicit_course_request = False

                        # If ML or keywords indicate explicit course intent, prepare to include official course info
                        # Require stronger ML confidence to return canonical course details directly.
                        ml_allows_course = False
                        try:
                            ml_allows_course = (ml_category in ('cursos', 'webinars') and float(ml_conf) >= 0.6)
                        except Exception:
                            ml_allows_course = False

                        if user_asking_about_courses and not is_technical_question and explicit_course_request and ml_allows_course:
                            logger.info(f"Usuario preguntando explícitamente sobre cursos detectado. Usando datos oficiales para {phone}.")

                            # Detectar si es una consulta general de recomendación o curso específico
                            is_general_inquiry = any(word in message_text.lower() for word in [
                                'recomien', 'sugier', 'cual me conviene', 'que curso', 'cursos tienes', 
                                'cursos disponibles', 'opciones de curso', 'que me recomiendas'
                            ])

                            if selected_course and not is_general_inquiry:
                                # Responder sobre el curso seleccionado (datos oficiales)
                                from utils.courses_adapter import compose_course_suggestion_via_ai, get_course_full_details_message
                                # Use AI to polish the suggestion but keep official details intact
                                respuesta = compose_course_suggestion_via_ai(selected_course, user_query=message_text, phone=phone)
                            elif is_general_inquiry or not selected_course:
                                # Responder con recomendaciones generales (datos oficiales)
                                from utils.courses_adapter import get_courses_recommendation_message, compose_course_suggestion_via_ai
                                # Get recommendations (candidates) and produce an AI-polished suggestion
                                candidates = get_courses_recommendation_message(message_text)
                                # If the recommendation helper already returns a formatted string, use it.
                                if isinstance(candidates, str):
                                    respuesta = candidates
                                else:
                                    # Compose short suggestions for top candidates
                                    snippets = []
                                    for c in (candidates or [])[:3]:
                                        snippets.append(compose_course_suggestion_via_ai(c, user_query=message_text, phone=phone))
                                    respuesta = "\n\n".join(snippets) if snippets else get_courses_recommendation_message(message_text)

                            # Additionally, always let the AI provide a short, non-inventive explanation or follow-up
                            try:
                                # Ask the model to provide a short answer but not invent exact course details
                                followup_prompt = (
                                    "Responde brevemente a la consulta del usuario y sugiere cursos relacionados sin inventar fechas ni precios. "
                                    "Indica que los detalles concretos (fechas/precios) están disponibles y ofrece conectar con un asesor."
                                )
                                ai_followup = chat_with_gemini(phone=phone, message=message_text, system_prompt=followup_prompt)
                                if ai_followup:
                                    respuesta = respuesta + "\n\nSugerencia AI:\n" + ai_followup
                            except Exception:
                                logger.debug("LLM followup for course suggestion failed, continuing with official data")

                            # Ensure we have a fallback if respuesta is empty
                            if not respuesta or not isinstance(respuesta, str):
                                respuesta = format_course_for_whatsapp(selected_course.get('details') if selected_course else None)

                            # Enviar la respuesta basada en JSON/DB y evitar llamar al LLM
                            send_text_message(phone, respuesta)
                            # Continuar con el siguiente mensaje del webhook (ya respondimos)
                            continue
                    except Exception as e:
                        logger.error(f"Error preparando respuesta basada en JSON de cursos: {e}", exc_info=True)

                    try:
                        # --- Sistema mejorado de contexto de cursos ---
                        enhanced_response = None
                        if 'contextual_response' in ml_adapter_result and ml_adapter_result.get('contextual_response', {}).get('enhanced_response'):
                            contextual_data = ml_adapter_result['contextual_response']
                            logger.info(f"Usando respuesta contextual mejorada para {phone} con intención: {contextual_data.get('intent', 'unknown')}")
                            
                            # Usar la respuesta contextual mejorada
                            enhanced_response = contextual_data.get('message', '')
                            
                            # Agregar preguntas de seguimiento si están disponibles
                            if contextual_data.get('follow_up_questions'):
                                enhanced_response += "\n\n¿Te gustaría saber más sobre:\n"
                                for i, question in enumerate(contextual_data['follow_up_questions'], 1):
                                    enhanced_response += f"• {question}\n"
                            
                            # Agregar acciones sugeridas si están disponibles
                            if contextual_data.get('suggested_actions'):
                                # Only append suggested actions when the user explicitly asked for options
                                # (words like 'ayuda', 'menu', 'opciones', 'qué puedes') or when the
                                # main enhanced_response is very short (so suggestions are helpful).
                                low_msg = (message_text or '').lower()
                                wants_menu = any(k in low_msg for k in ['ayuda', 'menú', 'menu', 'opciones', 'qué puedes', 'que puedes', 'qué haces', 'que haces', 'qué puedes hacer', 'que puedes hacer', 'qué ofreces', 'que ofreces'])
                                if wants_menu or (isinstance(enhanced_response, str) and len(enhanced_response.strip()) < 80):
                                    enhanced_response += "\n\nTambién puedo ayudarte con:\n"
                                    for action in contextual_data['suggested_actions'][:3]:  # Max 3 acciones
                                        enhanced_response += f"📌 {action}\n"
                        
                        # Usar respuesta mejorada si está disponible, sino usar Gemini
                        if enhanced_response and len(enhanced_response.strip()) > 20:
                            respuesta = enhanced_response
                            logger.info(f"Usando respuesta contextual mejorada ({len(respuesta)} chars)")
                        elif not skip_gemini:
                            # 🤖 Usar chat con contexto enriquecido ML-first
                            if 'contextual_prompt' in locals() and contextual_prompt:
                                selected_prompt = contextual_prompt
                                logger.info(f"🎯 Usando prompt contextual generado por ML para intent: {user_intent_type}")
                            elif system_prompt_override:
                                selected_prompt = system_prompt_override
                            elif user_intent_type in intent_prompts:
                                selected_prompt = intent_prompts[user_intent_type]
                                logger.info(f"Usando prompt específico para intent: {user_intent_type}")
                            else:
                                selected_prompt = system_prompt  # Fallback al prompt original
                            
                            # Usar chat con contexto enriquecido
                            respuesta = enhanced_chat_with_context(phone, message_text, selected_prompt)
                        
                        # Medir tiempo de respuesta para monitoreo
                        response_time = (datetime.now() - start_response_time).total_seconds()
                        logger.info(f"Respuesta generada en {response_time:.2f} segundos")
                        
                        # Verificar si la respuesta es válida
                        if not respuesta or len(respuesta.strip()) < 10:
                            logger.warning(f"Respuesta inválida o muy corta: '{respuesta}'")
                            respuesta = "Lo siento, estoy teniendo dificultades para procesar tu consulta en este momento. ¿Podrías reformular tu pregunta?"

                        # Verificar si venimos de una solicitud de asesor completada recientemente
                        last_action = get_conversation_memory(phone, "last_action")
                        if last_action == "advisor_request_completed":
                            # Limpiar este estado para futuras interacciones
                            save_conversation_memory(phone, "last_action", None)
                            # Limpiar también cualquier contexto adicional que pudiera causar mensajes repetidos
                            save_conversation_memory(phone, "waiting_for_advisor_data", False)
                            save_conversation_memory(phone, "advisor_data", None)
                            logger.info(f"Detectado mensaje después de solicitud de asesor para {phone}")
                        
                        # Re-evaluar específicamente si el usuario pedía información sobre CURSOS
                        # (esto captura casos donde la detección previa falló). Si es así, forzamos
                        # la respuesta desde la fuente canónica (constants.js / DB) para evitar
                        # que la IA invente fechas, precios o duraciones.
                        try:
                            try:
                                user_asks_courses, is_tech_q = _detect_course_intent(message_text)
                            except Exception:
                                # Fallback simple
                                t = (message_text or '').lower()
                                user_asks_courses = any(k in t for k in ['curso', 'temario', 'fechas', 'precio', 'inscrib'])
                                is_tech_q = False

                            if user_asks_courses and not is_technical_question and explicit_course_request and ml_allows_course:
                                logger.info(f"Post-check: Usuario preguntando sobre cursos. Respondiendo desde fuente canónica para {phone}.")
                                
                                # Detectar si es una consulta general de recomendación o curso específico
                                is_general_inquiry = any(word in message_text.lower() for word in [
                                    'recomien', 'sugier', 'cual me conviene', 'que curso', 'cursos tienes', 
                                    'cursos disponibles', 'opciones de curso', 'que me recomiendas'
                                ])
                                
                                if selected_course and not is_general_inquiry:
                                    # Responder sobre el curso seleccionado
                                    from utils.courses_adapter import get_course_full_details_message
                                    respuesta = f"Información del curso seleccionado '{selected_course.get('name', '')}':\n\n"
                                    respuesta += get_course_full_details_message(selected_course.get('id'))
                                elif is_general_inquiry or not selected_course:
                                    # Responder con recomendaciones generales
                                    from utils.courses_adapter import get_courses_recommendation_message
                                    respuesta = get_courses_recommendation_message(message_text)
                                else:
                                    # Fallback a formato básico
                                    respuesta = format_course_for_whatsapp(selected_course.get('details') if selected_course else None)
                                
                                # Enviar la respuesta basada en JSON/DB y evitar llamar al LLM
                                send_text_message(phone, respuesta)
                                # Continuar con el siguiente mensaje del webhook (ya respondimos)
                                continue
                        except Exception as e:
                            logger.error(f"Error re-evaluando intención de cursos: {e}", exc_info=True)
                    except Exception as gemini_error:
                        logger.error(f"Error generando respuesta con Gemini: {gemini_error}", exc_info=True)
                        # Proporcionar una respuesta genérica en caso de error
                        respuesta = "Disculpa, estoy experimentando problemas técnicos en este momento. Por favor, intenta nuevamente en unos minutos."
                    
                    # Evitar reenviar exactamente el mismo texto que envió el usuario
                    try:
                        if respuesta and isinstance(respuesta, str) and respuesta.strip() == message_text.strip():
                            logger.warning('La IA devolvió el mismo texto que el usuario; usar mensaje de aclaración en su lugar')
                            respuesta = 'Perdona, no entendí del todo. ¿Puedes dar más detalles o reformular tu pregunta?'
                            
                        # Detectar si estamos atascados en cursos cuando el usuario no está preguntando sobre ellos
                        # Usamos una detección más sofisticada para distinguir entre preguntas técnicas y solicitudes de cursos
                        
                        # Palabras que indican específicamente interés en CURSOS (no en temas técnicos de fibra)
                        curso_keywords_in_user = [
                            'curso', 'cursos', 'temario', 'capacitación', 'quiero aprender', 
                            'formación', 'certificación', 'inscribirme', 'costo del curso',
                            'cuándo inicia el curso', 'próximo curso', 'proximo curso',
                            'inscribir', 'inscripción', 'estudiar', 'tomar el curso', 
                            'asistir al curso', 'matricularme', 'modalidad del curso',
                            'precio del curso', 'duración del curso', 'horario del curso'
                        ]
                        
                        # Patrones que indican consultas TÉCNICAS (no sobre cursos)
                        technical_question_patterns = [
                            # Términos de pregunta técnica
                            'cómo', 'cuál es', 'qué tipo', 'diferencia entre', 'recomiendas', 'problema con',
                            'instalación', 'configuración', 'mejor', 'ventajas', 'desventajas', 'comparación',
                            
                            # Términos técnicos específicos de fibra y telecomunicaciones
                            'backbone', 'vertical', 'hotel', 'loose tube', 'tight buffer', 'tipo de fibra',
                            'fibra monomodo', 'fibra multimodo', 'atenuación', 'conector', 'empalme', 'fusión',
                            'otdr', 'power meter', 'presupuesto óptico', 'pérdida', 'banda', 'longitud de onda',
                            'single mode', 'multimode', 'patch cord', 'pigtail', 'roseta', 'caja de empalme',
                            'splitter', 'divisor', 'rack', 'odf', 'distribuidor', 'pon', 'gpon', 'ftth', 'fttb',
                            'fttx', 'bandwidth', 'ancho de banda', 'latencia', 'distancia máxima', 'transmisión',
                            'switch', 'router', 'gateway', 'olt', 'onu', 'ont', 'cable', 'ducto', 'canalización',
                            'poste', 'aérea', 'subterránea', 'cableado', 'networking', 'red', 'diagrama',
                            'arquitectura', 'topología', 'escalabilidad', 'rendimiento', 'velocidad', 'gigabit',
                            'terabit', 'potencia', 'dbm', 'especificaciones', 'estándar', 'protocolos',
                            
                            # Palabras que indican problemas o consultas técnicas
                            'error', 'falla', 'problema', 'no funciona', 'cómo resolver', 'cómo arreglar',
                            'solución para', 'diagnóstico', 'mantenimiento', 'reparación', 'optimización',
                            'mejora', 'recomendación', 'consejo técnico', 'sugerencia', 'mejor práctica',
                            'cuál recomiendas', 'cómo puedo', 'cómo debo', 'necesito ayuda con', 'duda sobre'
                        ]
                        
                        # Palabras que indican que el bot está hablando de CURSOS
                        curso_keywords_in_response = [
                            'curso', 'temario', 'certificación', 'capacitación', 
                            'clases', 'formación', 'aprender', 'modalidad presencial',
                            'fechas', 'próximas fechas', 'precio del curso', 'inscripción',
                            'instructor', 'material didáctico', 'programa', 'contenido del curso',
                            'modalidad', 'presencial', 'online', 'virtual', 'híbrido',
                            'calendario de cursos', 'próxima edición', 'curso disponible',
                            'horarios', 'días de clase', 'aprenderás', 'te capacitarás',
                            'inscribirte', 'registrarte', 'cupo limitado', 'participantes'
                        ]
                        
                        # Verificar si el usuario está haciendo una pregunta técnica específica
                        # Utilizamos una puntuación para determinar qué tan técnica es la pregunta
                        technical_score = 0
                        course_score = 0
                        
                        # Analizar patrones técnicos (cada coincidencia suma 1 punto)
                        for pattern in technical_question_patterns:
                            if pattern in message_text.lower():
                                technical_score += 1
                        
                        # Analizar patrones de curso (cada coincidencia suma 1 punto)
                        for keyword in curso_keywords_in_user:
                            if keyword in message_lower:
                                course_score += 1
                                
                        # Análisis semántico mejorado
                        message_lower = message_text.lower()
                        
                        # Frases específicas que indican claramente que es una pregunta técnica
                        clear_technical_indicators = [
                            "cómo funciona", "cómo se hace", "explícame", "problema técnico", 
                            "error en", "no está funcionando", "ayúdame con", "duda técnica",
                            "cómo puedo resolver", "cómo solucionar"
                        ]
                        
                        # Frases específicas que indican claramente interés en cursos
                        clear_course_indicators = [
                            "quiero inscribirme", "información sobre el curso", "quiero tomar el curso", "fechas del curso", "precio del curso"
                        ]
                        
                        # Dar mayor peso a indicadores claros
                        for indicator in clear_technical_indicators:
                            if indicator in message_lower:
                                technical_score += 3  # Mayor peso para indicadores claros
                        
                        for indicator in clear_course_indicators:
                            if indicator in message_lower:
                                course_score += 3  # Mayor peso para indicadores claros
                        
                        # Determinar el tipo de pregunta basado en las puntuaciones
                        # Mayor umbral para considerar que está preguntando sobre cursos
                        is_technical_question = technical_score > course_score
                        # Requerir al menos 2 puntos de curso y una diferencia positiva respecto a técnico
                        user_asking_about_courses = course_score >= 2 and course_score > technical_score

                        # Si es una pregunta técnica, generar la respuesta técnica (ya generada en `respuesta`) y
                        # añadir sugerencias de cursos al final como propuesta (no reemplazar la respuesta técnica).
                        try:
                            if is_technical_question:
                                try:
                                    # Buscar cursos relevantes con palabras clave extraídas del mensaje
                                    from routes.course_handlers import CourseManager
                                    from utils.courses_adapter import compose_course_suggestion_via_ai
                                    # Build simple keywords list from message (top nouns/words)
                                    keywords = [w for w in re.findall(r"\w+", message_text.lower()) if len(w) > 3][:6]
                                    candidates = CourseManager.search_courses_by_keywords(keywords, limit=2)
                                    suggestions = []
                                    for c in candidates:
                                        try:
                                            suggestions.append(compose_course_suggestion_via_ai(c, user_query=message_text, phone=phone))
                                        except Exception:
                                            try:
                                                suggestions.append(format_course_for_whatsapp(c))
                                            except Exception:
                                                pass
                                    if suggestions:
                                        respuesta = respuesta.strip() + "\n\nSi te interesa, también te puedo recomendar estos cursos relacionados:\n\n" + "\n\n".join(suggestions)
                                except Exception as e:
                                    logger.debug(f"No se pudieron obtener sugerencias de cursos: {e}")
                        except Exception:
                            pass
                        
                        # Depuración de la detección
                        logger.info(f"Detección de tema - Técnico: {technical_score}, Cursos: {course_score}")
                        logger.info(f"Resultado: Técnico={is_technical_question}, Curso={user_asking_about_courses}")
                        
                        # Si la pregunta es claramente técnica, no considerarla como pregunta sobre cursos
                        # incluso si tiene algunas menciones de cursos
                        if technical_score > course_score:  # Si hay cualquier diferencia a favor de técnico
                            user_asking_about_courses = False
                            logger.info("Pregunta técnica detectada, ignorando menciones de cursos")
                            
                        # Verificar si el bot está hablando de cursos en su respuesta
                        # Contamos la frecuencia de palabras relacionadas con cursos para evaluar qué tan centrada
                        # está la respuesta en cursos
                        course_keyword_count = sum(1 for keyword in curso_keywords_in_response if keyword in respuesta.lower())
                        bot_talking_about_courses = course_keyword_count >= 2  # Necesitamos al menos 2 menciones para considerarlo "hablando de cursos"
                        
                        # Detección mejorada de casos problemáticos:
                        # 1. Usuario NO pregunta sobre cursos pero el bot SÍ habla de ellos (error más común)
                        # 2. Usuario hace una pregunta TÉCNICA pero el bot responde con cursos (el caso del ejemplo)
                        # 3. Detectar también cuando hablamos demasiado de cursos en la respuesta
                        
                        # Análisis más detallado del contenido de la respuesta
                        is_course_fixated = False
                        
                        # Verificar si hay una alta concentración de palabras sobre cursos
                        high_course_keyword_density = course_keyword_count > 5  # Si hay muchas menciones de cursos
                        
                        # Verificar si hay una fijación clara en cursos cuando el usuario pregunta otra cosa
                        # IMPORTANTE: Solo considerar fixation si el usuario NO está preguntando sobre cursos
                        if (not user_asking_about_courses and not explicit_course_request and bot_talking_about_courses):
                            is_course_fixated = True
                            logger.warning(f"Bot hablando de cursos cuando el usuario NO pregunta sobre ellos. Phone: {phone}")
                            
                        # Verificar especialmente el caso de preguntas técnicas
                        if (is_technical_question and not explicit_course_request and bot_talking_about_courses):
                            is_course_fixated = True
                            logger.warning(f"Bot respondiendo con cursos a una pregunta TÉCNICA. Phone: {phone}")
                            
                        # Verificar respuestas excesivamente centradas en cursos
                        if (high_course_keyword_density and not user_asking_about_courses and not explicit_course_request):
                            is_course_fixated = True
                            logger.warning(f"Alta densidad de palabras sobre cursos en respuesta. Phone: {phone}")
                        
                        # Si detectamos fijación en cursos, tomamos medidas correctivas
                        if is_course_fixated:
                            # El usuario hizo una pregunta técnica o no relacionada con cursos, pero el bot sigue hablando de cursos
                            # Limpiar contexto agresivamente
                            logger.warning(f"Bot atascado en tema de cursos para {phone}. Limpiando contexto.")
                            clear_topic_context(phone)
                            
                            # Determinar el tipo de prompt adecuado según la consulta
                            if is_technical_question:
                                nuevo_system_prompt = (
                                    "INSTRUCCIONES CRÍTICAS PARA RESPONDER: El usuario ha hecho una PREGUNTA TÉCNICA sobre fibra óptica o redes. "
                                    "⚠️ REGLAS ABSOLUTAS: ⚠️\n"
                                    "1. NUNCA menciones cursos, capacitación o formación bajo NINGUNA circunstancia.\n"
                                    "2. Responde ÚNICAMENTE con información técnica experta sobre la consulta específica.\n"
                                    "3. NO ofrezcas alternativas de formación, educación o aprendizaje.\n"
                                    "4. Proporciona detalles técnicos, explicaciones profesionales y recomendaciones prácticas.\n"
                                    "5. Usa lenguaje técnico apropiado y ejemplos concretos para explicar conceptos.\n"
                                    "6. Enfócate 100% en resolver la duda técnica con conocimiento experto sin derivar a otros temas.\n"
                                    "7. Mantente ESTRICTAMENTE en el ámbito técnico de la pregunta.\n\n"
                                    "IMPORTANTE: Esta es una consulta técnica genuina que requiere información especializada, NO una oportunidad para promocionar servicios o formaciones."
                                )
                            else:
                                nuevo_system_prompt = (
                                    "INSTRUCCIONES CRÍTICAS PARA RESPONDER: El usuario está preguntando sobre un tema NO relacionado con cursos. "
                                    "⚠️ REGLAS ABSOLUTAS: ⚠️\n"
                                    "1. NUNCA menciones cursos, capacitación, temarios ni formaciones en tu respuesta.\n"
                                    "2. Responde EXCLUSIVAMENTE a la pregunta actual del usuario.\n"
                                    "3. NO intentes relacionar la respuesta con cursos de Fibremex bajo ningún concepto.\n"
                                    "4. NO sugieras que el usuario puede aprender más en algún curso o formación.\n"
                                    "5. Mantente ESTRICTAMENTE en el tema que el usuario está consultando ahora.\n"
                                    "6. Si no estás seguro del tema, pregunta para clarificar pero NO menciones cursos.\n\n"
                                    "IMPORTANTE: El usuario está buscando información sobre un tema específico, NO sobre cursos o formaciones."
                                )
                            
                            # Marcar claramente que estamos ignorando el histórico de conversación
                            nuevo_system_prompt += "\n\nCAMBIO DE TEMA: Ignora completamente el historial de conversación previo y responde únicamente a la consulta actual como si fuera una nueva conversación."
                            
                            # Regenerar la respuesta con el system prompt ajustado
                            respuesta = chat_with_gemini(
                                phone=phone,
                                message=message_text,
                                system_prompt=nuevo_system_prompt,
                                include_whatsapp_profile=whatsapp_profile
                            )
                            
                            # Verificar que la nueva respuesta no siga hablando de cursos
                            new_course_mentions = sum(1 for keyword in curso_keywords_in_response if keyword in respuesta.lower())
                            if new_course_mentions > 1:
                                logger.warning(f"La respuesta regenerada SIGUE hablando de cursos. Haciendo un segundo intento más agresivo.")
                                
                                # Segundo intento aún más agresivo
                                ultimo_system_prompt = (
                                    "⚠️⚠️ ATENCIÓN CRÍTICA ⚠️⚠️\n"
                                    "NO MENCIONES CURSOS, CLASES, CAPACITACIONES, FORMACIONES O CUALQUIER SERVICIO EDUCATIVO.\n"
                                    "El usuario NO está preguntando sobre cursos. Responde directamente a su consulta sin ninguna referencia a educación o formación.\n\n"
                                    "RESPONDE ÚNICAMENTE SOBRE: " + message_text + "\n\n"
                                    "NO INCLUYAS NINGUNA PALABRA RELACIONADA CON EDUCACIÓN, APRENDIZAJE O FORMACIÓN EN TU RESPUESTA."
                                )
                                
                                respuesta = chat_with_gemini(
                                    phone=phone,
                                    message=message_text,
                                    system_prompt=ultimo_system_prompt,
                                    include_whatsapp_profile=False  # Omitir el perfil para evitar contexto adicional
                                )
                            
                            # Agregar un mensaje de transición adecuado al inicio
                            mensaje_transicion = "Permíteme responder directamente a tu consulta:\n\n"
                            respuesta = mensaje_transicion + respuesta
                            
                    except Exception as e:
                        # En caso de problemas de comparación, simplemente continuar
                        logger.error(f"Error verificando respuesta repetitiva: {e}")

                    logger.info(f"Respuesta generada: {respuesta[:50]}...")
                    
                    # Enviar respuesta y registrar la acción con manejo de errores
                    logger.info(f"Enviando respuesta a {f'PHONE_XXXXX{str(phone)[-4:]}'}, longitud={len(respuesta)}")
                    
                    # Usar el número real (sin sanitizar) para el envío
                    send_result = send_text_message(phone, respuesta)
                    
                    if send_result:
                        logger.info(f"Respuesta enviada exitosamente a {f'PHONE_XXXXX{str(phone)[-4:]}'}")
                        
                        # Registrar estadísticas del mensaje para monitoreo
                        log_webhook_event("message_sent", {
                            "phone": f"PHONE_XXXXX{str(phone)[-4:]}",  # Sanitizado
                            "response_length": len(respuesta),
                            "processing_time_ms": int((datetime.now() - processing_start_time).total_seconds() * 1000),
                            "message_id": message_id
                        })
                    else:
                        logger.error(f"FALLÓ el envío del mensaje a {f'PHONE_XXXXX{str(phone)[-4:]}'}")
                        # Si falla el envío, registrar el error
                        log_webhook_event("message_send_failed", {
                            "phone": f"PHONE_XXXXX{str(phone)[-4:]}",  # Sanitizado
                            "error": "Error de envío - revisar logs anteriores",
                            "message_id": message_id
                        }, level="error")
        
        return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        # Registro detallado de errores para facilitar la depuración
        logger.error(f"Error procesando webhook: {e}", exc_info=True)
        
        # Registrar evento de error de forma estructurada
        error_details = {
            "error_type": type(e).__name__,
            "error_message": str(e),
            "traceback": traceback.format_exc(),
            "request_headers": {k: v for k, v in request.headers.items()},
            "request_method": request.method,
            "request_path": request.path,
            "request_remote_addr": request.remote_addr
        }
        
        log_webhook_event("webhook_error", error_details, level="error")
        
        # Evitar exponer detalles internos en la respuesta al cliente
        return jsonify({"status": "error", "message": "Error interno al procesar el webhook"}), 500
    finally:
        # Clear current webhook message id guard (in case it was set)
        try:
            globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = None
        except Exception:
            pass

