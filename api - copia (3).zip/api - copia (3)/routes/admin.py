from flask import Blueprint, jsonify
import os
from models.courses import CourseManager

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/admin/pdfs', methods=['GET'])
def list_pdfs():
    assets_dir = os.path.join(os.path.dirname(__file__), '..', 'assets')
    try:
        files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.pdf')]
    except Exception:
        files = []

    mappings = []
    try:
        courses = CourseManager.get_all_courses()
    except Exception:
        courses = []

    for c in courses:
        cname = getattr(c, 'nombre', '')
        matches = [f for f in files if cname and cname.lower().split()[0] in f.lower()]
        mappings.append({'course_id': getattr(c, 'id', None), 'course_name': cname, 'matches': matches})

    return jsonify({'pdf_files': files, 'mappings': mappings})
