import json
import logging
from datetime import datetime
from flask import request

from .whatsapp import (
    classify_user_intent_ml,
    generate_contextual_system_prompt,
    update_conversation_context,
    enhanced_chat_with_context,
    log_webhook_event
)

# Configurar logger
logger = logging.getLogger(__name__)

def webhook_handler():
    """Maneja mensajes entrantes de WhatsApp utilizando el sistema de memoria de conversación y ML"""
    try:
        # Persistir el cuerpo bruto del webhook inmediatamente para capturar cualquier entrega
        # incluso si no se puede parsear como JSON (esto ayuda a depurar entregas reales desde Meta/ngrok)
        try:
            import os
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== RAW WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END RAW WEBHOOK ===\n")
            logger.debug("Raw webhook persisted to logs/webhook_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST recibido")
        
        # Registrar información estructurada del webhook para depuración avanzada
        try:
            # Analizar el payload para determinar su tipo
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)
            
            # Registrar evento de forma estructurada
            log_webhook_event(
                event_type="webhook_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
            
            # Registrar una versión sanitizada del payload (sin información sensible)
            # Omitir información potencialmente sensible - HACER COPIA PROFUNDA
            import copy
            sanitized_payload = {}
            if isinstance(payload, dict):
                sanitized_payload = copy.deepcopy(payload)  # Copia profunda para no afectar el original
                # Ocultar números de teléfono completos SOLO en la copia
                if 'entry' in sanitized_payload and isinstance(sanitized_payload['entry'], list):
                    for entry in sanitized_payload['entry']:
                        if 'changes' in entry and isinstance(entry['changes'], list):
                            for change in entry['changes']:
                                if 'value' in change and isinstance(change['value'], dict):
                                    value = change['value']
                                    # Sanitizar mensajes SOLO en la copia
                                    if 'messages' in value and isinstance(value['messages'], list):
                                        for msg in value['messages']:
                                            if 'from' in msg:
                                                msg['from'] = f"PHONE_XXXXX{str(msg['from'])[-4:]}"
            
            logger.debug(f"Payload sanitizado: {json.dumps(sanitized_payload, default=str)[:1000]}")
        except Exception as e:
            logger.error(f"Error al procesar información de webhook: {e}")
            logger.error(traceback.format_exc())
        
        if not payload:
            logger.warning("Payload vacío recibido")
            return jsonify({"status": "error", "message": "Payload vacío"}), 400
        
        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload")
            return jsonify({"status": "ok"}), 200  # No es un error, podría ser otro tipo de notificación
        
        # Importaciones necesarias para el procesamiento de ML
        from services.chat_ai import query_mongodb, chat_with_gemini
        from utils.ml_adapter import process_message
        from services.conversation_memory import get_conversation_history, clear_topic_context, ConversationMemory, save_selected_course, get_selected_course
        
        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                
                # LOG: Inicio de procesamiento del payload
                logger.info("📨 Iniciando procesamiento de payload WhatsApp")
                
                # Clasificar y procesar correctamente según el tipo de evento de WhatsApp
                # Identificar el tipo de payload basado en su estructura
                payload_type = "unknown"
                if 'statuses' in value and not 'messages' in value:
                    payload_type = "status_update"
                elif 'messages' in value:
                    payload_type = "message"
                elif 'errors' in value:
                    payload_type = "error"
                elif 'metadata' in value:
                    payload_type = "metadata"                # Registrar el tipo de evento para monitoreo
                logger.info(f"Evento de WhatsApp detectado: {payload_type}")
                
                # Manejar cada tipo de evento adecuadamente
                if payload_type == "status_update":
                    # Procesar notificaciones de estado sin generar respuestas
                    logger.info("Recibida notificación de estado, procesando sin respuesta")
                    statuses = value.get('statuses', [])
                    for status in statuses:
                        status_id = status.get('id')
                        status_status = status.get('status')  # sent, delivered, read, failed
                        recipient_id = status.get('recipient_id')
                        logger.info(f"Status de mensaje: ID={status_id}, Status={status_status}, Recipient={recipient_id}")
                        
                        # TODO: Aquí se podría implementar seguimiento de entrega de mensajes si es necesario
                    continue
                elif payload_type == "error":
                    # Registrar errores para investigación
                    errors = value.get('errors', [])
                    for error in errors:
                        logger.error(f"Error de WhatsApp: {error}")
                    continue
                elif payload_type != "message":
                    # Ignorar cualquier otro tipo de evento que no sea un mensaje
                    logger.info(f"Tipo de evento {payload_type} no procesable, ignorando")
                    continue
                    
                # Solo procesar si hay mensajes reales del usuario
                messages = value.get('messages', [])
                if not messages:
                    logger.info("No hay mensajes reales del usuario en este webhook, ignorando")
                    continue
                    
                for message in messages:
                    # Verificar que sea un mensaje válido
                    if not message:
                        logger.warning("Objeto de mensaje vacío, ignorando")
                        continue

                    # Determinar tipo (puede faltar en algunos payloads)
                    msg_type = message.get('type')
                    if not msg_type:
                        logger.warning("Mensaje recibido sin campo 'type' definido, continuando para registro")

                    # Extraer texto disponible según el tipo
                    if msg_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                    else:
                        # Para otros tipos intentamos obtener captions/fields comunes
                        if message.get('text') and isinstance(message.get('text'), dict):
                            message_text = message.get('text', {}).get('body', '')
                        else:
                            message_text = message.get('caption') or message.get('body') or ''

                    # Si falta timestamp, lo registramos pero no descartamos el mensaje automáticamente
                    if 'timestamp' not in message:
                        logger.warning("Mensaje sin timestamp; se registrará para inspección pero se procesará")

                    # Ignorar explícitamente mensajes de sistema o notificaciones
                    if message.get('system') or 'notification' in str(message).lower():
                        logger.warning("Mensaje de sistema o notificación detectado, ignorando")
                        continue

                    # Si no hay texto extraíble, lo registramos y seguimos (algunos attachments no tienen body)
                    if not message_text or not str(message_text).strip():
                        logger.warning("Mensaje sin texto extraíble; posible media/attachment - registrando y continuando")

                    # Extraer información del mensaje
                    phone = message.get('from')
                    message_id = message.get('id')
                    timestamp = message.get('timestamp')

                    # Mark current incoming message id for duplicate-send guarding
                    try:
                        globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = message_id
                    except Exception:
                        pass

                    logger.info(f"📨 Mensaje recibido: phone={phone}, text={str(message_text)[:60]}..., timestamp={timestamp}")

                    # Validaciones básicas
                    if not phone or not message_id:
                        logger.warning(f"❌ Mensaje incompleto: phone={phone}, id={message_id}")
                        continue

                    # Evitar reprocesar mensajes
                    if ConversationMemory.is_message_processed(message_id):
                        logger.info(f"Mensaje {message_id} ya fue procesado anteriormente, ignorando")
                        continue

                    # Verificación de timestamp: si existe lo validamos, si no existe no bloqueamos
                    try:
                        if timestamp:
                            message_time = datetime.fromtimestamp(int(timestamp))
                            current_time = datetime.now()
                            time_diff = current_time - message_time
                            time_diff_seconds = time_diff.total_seconds()

                            # Mensaje demasiado antiguo (más de 5 minutos)
                            if time_diff_seconds > 300:
                                logger.warning(f"Mensaje {message_id} es antiguo ({time_diff_seconds} segundos), ignorando")
                                continue

                            # Mensaje con timestamp futuro (más de 10 segundos en el futuro)
                            if time_diff_seconds < -10:
                                logger.warning(f"Mensaje {message_id} tiene timestamp futuro ({-time_diff_seconds} segundos), ignorando")
                                continue

                            if time_diff_seconds > 60:
                                logger.info(f"Mensaje con retraso significativo: {time_diff_seconds} segundos")
                        else:
                            logger.debug(f"Mensaje {message_id} no tiene timestamp; omitiendo validación temporal")
                    except Exception as e:
                        logger.error(f"Error verificando timestamp del mensaje: {e}")
                        # En caso de error, verificamos si el formato del timestamp parece válido
                        if not str(timestamp).isdigit() or len(str(timestamp)) != 10:
                            logger.warning(f"Timestamp con formato inválido: {timestamp} - ignorando mensaje")
                            continue
                        
                    # Marcar este mensaje como procesado
                    ConversationMemory.mark_message_as_processed(message_id)
                    
                    # Registrar inicio del tiempo de procesamiento
                    processing_start_time = datetime.now()
                    
                    # NUEVO: Función que procesa TODOS los mensajes con IA PRIMERO
                    def process_message_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, ml_adapter_result, is_technical_question=False):
                        """
                        Esta función procesa TODOS los mensajes con IA sin excepción.
                        Garantiza que ningún mensaje se quede sin respuesta de IA.
                        """
                        logger.info(f"🚀 AI block entry: Procesando mensaje con IA para {phone}")
                        
                        try:
                            # System prompt mejorado que responde a TODO
                            system_prompt = """
ERES UN ASISTENTE EXPERTO DE FIBREMEX, ESPECIALIZADO EN FIBRA ÓPTICA Y TELECOMUNICACIONES.

REGLA PRINCIPAL: DEBES RESPONDER A TODAS LAS CONSULTAS SIN EXCEPCIÓN.

ESPECIALIDADES:
• Fibra óptica (tipos, conectores, instalación)
• Productos: Bobinas UTP, Ductos, Tritubo, Jumpers MPO/MTP
• Redes FTTH, GPON, PON, cableado estructurado  
• Equipos: OTDR, fusionadoras, cleavers
• Cursos de capacitación en Querétaro

CURSOS DISPONIBLES (solo en Querétaro, México):
1. Cableado Estructurado - 3-4 Nov 2025 - $269 USD + IVA
2. Fibra Óptica Planta Externa - 5-6 Nov 2025 - $269 USD + IVA
3. FTTH para WISP e ISP - 10-11 Nov 2025 - $299 USD + IVA
4. PONLAN Enterprise - 12-13 Nov 2025 - Consultar precio
5. Empalmes y OTDR - 5-6 Nov 2025 - Consultar precio
Ubicación: Parque Industrial Tecnológico Innovación, Querétaro, Qro.

PRODUCTOS PRINCIPALES:
• Bobinas UTP 100% cobre (Cat 5e, 6, 6A) - Para cableado estructurado
• Ductos fibra óptica (HDPE, corrugado) - Protección de instalaciones
• Tritubo - Optimización de espacio en ductos
• Jumpers MPO/MTP - Para centros de datos

WEBINARS GRATUITOS (martes online):
• Soluciones preconectorizadas
• Empalmes de fibra óptica y OTDR  
• Instalación subterránea
• De WISP a Fibra
• ODN en FTTX
• Centro de datos

INSTRUCCIONES:
1. RESPONDE SIEMPRE con información útil y precisa
2. Para consultas técnicas: da soluciones prácticas y detalladas
3. Para productos: incluye especificaciones y aplicaciones
4. Para cursos: menciona solo cuando sean relevantes o se pregunten específicamente
5. Para webinars: Si preguntan por opciones online, menciona los webinars gratuitos
6. Sé profesional pero amigable
7. Ofrece información adicional relevante

NUNCA digas "no puedo ayudar" - SIEMPRE encuentra una forma de ser útil.
"""
                            
                            # Asegurar que chat_with_gemini esté disponible en este scope
                            try:
                                from services.chat_ai import chat_with_gemini as _local_chat
                            except Exception:
                                _local_chat = None

                            # Generar respuesta con IA
                            if _local_chat:
                                respuesta = _local_chat(
                                    phone=phone,
                                    message=message_text,
                                    system_prompt=system_prompt,
                                    include_whatsapp_profile=whatsapp_profile
                                )
                            else:
                                # Fallback si no está disponible
                                respuesta = None
                            
                            logger.info(f"🤖 AI processing: Respuesta generada para {phone}: {respuesta[:50]}...")
                            
                            # Verificar que la respuesta sea válida
                            if not respuesta or len(respuesta.strip()) < 5:
                                respuesta = "Recibí tu mensaje. ¿Podrías darme más detalles sobre lo que necesitas? Puedo ayudarte con información técnica, productos o cursos de fibra óptica."
                            
                            # Enviar respuesta
                            logger.info(f"📤 Enviando respuesta: {len(respuesta)} caracteres")
                            send_result = send_text_message(phone, respuesta)
                            
                            if send_result:
                                logger.info(f"✅ Respuesta enviada exitosamente a {phone}")
                                return True
                            else:
                                logger.error(f"❌ Error enviando respuesta a {phone}")
                                return False
                                
                        except Exception as e:
                            logger.error(f"❌ Error en process_message_with_ai_always: {e}", exc_info=True)
                            # Respuesta de emergencia
                            try:
                                emergency_response = "Disculpa, tuve un problema procesando tu mensaje. ¿Puedes intentar de nuevo? Estoy aquí para ayudarte con consultas técnicas, productos o cursos de fibra óptica."
                                send_text_message(phone, emergency_response)
                                return True
                            except Exception as e2:
                                logger.error(f"❌ Error crítico enviando respuesta de emergencia: {e2}")
                                return False
                    
                    # Obtener datos del perfil de WhatsApp si están disponibles
                    whatsapp_profile = None
                    if 'contacts' in value and value['contacts']:
                        contact = value['contacts'][0]
                        whatsapp_profile = {
                            "name": contact.get('profile', {}).get('name')
                        }
                        logger.info(f"Perfil de WhatsApp obtenido: {whatsapp_profile}")
                    
                    # Obtener el historial de conversación para el procesamiento ML
                    try:
                        conversation_history = get_conversation_history(phone)
                        logger.info(f"Historial recuperado para {phone}: {len(conversation_history)} mensajes")
                    except Exception as history_error:
                        logger.error(f"Error al obtener historial: {history_error}")
                        # Si falla, inicializar un historial vacío para continuar
                        conversation_history = []
                    
                    # **PROCESAMIENTO CON IA PRIMERO - GARANTIZA RESPUESTA PARA TODOS LOS MENSAJES**
                    # Pero priorizamos respuestas determinísticas para PETICIONES EXPLÍCITAS de cursos/webinars/productos
                    import re
                    explicit_course_or_ad_request = False
                    if not is_technical_question:
                        if re.search(r"\b(curso|cursos|temario|inscripci[oó]n|inscripcion|webinar|webinars|fechas|precio|costo|cotizar|cotización)\b", (message_text or '').lower()):
                            explicit_course_or_ad_request = True
                            logger.info(f"🔎 Petición explícita de cursos/webinars/productos detectada para {phone}, se priorizará respuesta determinística")

                    if not explicit_course_or_ad_request:
                        logger.info(f"🚀 AI block entry: Iniciando procesamiento con IA para {phone}")
                        try:
                            # Llamar a la función que garantiza respuesta con IA para TODOS los mensajes
                            respuesta = process_message_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, {}, is_technical_question=is_technical_question)
                            if respuesta:
                                logger.info(f"✅ Mensaje procesado exitosamente con IA para {phone}")
                                # El mensaje ya fue procesado y enviado, continuar con el siguiente
                                continue
                            else:
                                logger.warning(f"⚠️ AI processing failed, continuando con lógica compleja para {phone}")
                        except Exception as ai_error:
                            logger.error(f"❌ Error en procesamiento con IA: {ai_error}")
                            # Si falla la IA, continuar con la lógica compleja como fallback
                    else:
                        logger.info(f"⏭️ Saltando bloque IA para {phone} porque la solicitud es explícita de cursos/productos/webinars")
                    
                    # Sistema inteligente de clasificación de requerimientos del usuario
                    def classify_user_intent(message_text, conversation_history=None):
                        """
                        Clasifica la intención del usuario en: técnica, general, cursos, productos, o asesoría
                        """
                        if not message_text:
                            return {'type': 'general', 'confidence': 0.5, 'details': 'Mensaje vacío'}
                        msg_lower = message_text.lower().strip()

                        # Patrones de detección por categoría (pesos ajustados)
                        patterns = {
                            'tecnica': {
                                'keywords': ['problema', 'problemas', 'error', 'falla', 'no funciona', 'cómo solucionar', 'cómo arreglar',
                                             'diagnóstico', 'calibrar', 'configurar', 'instalar', 'conectar', 'instalación',
                                             'fusionadora', 'cleaver', 'otdr', 'pérdida de señal', 'atenuación', 'dbm', 'reflectometr',
                                             'backscatter', 'splice', 'empalme', 'empalmes', 'fibra rota', 'medición', 'troubleshoot', 'reparar',
                                             'conector', 'conectores', 'conectorización', 'conectorizacion', 'conectorizar', 'fusionar',
                                             'dificultad', 'ayuda con', 'cómo hacer', 'procedimiento', 'técnica', 'método', 'pasos para',
                                             'fibra', 'multimodo', 'monomodo', 'enlace', 'extender', 'metros', 'distancia', 'pigtal', 'pigtail',
                                             'om1', 'om2', 'om3', 'om4', 'om5', 'g652', 'g657', 'conectar', 'unir', 'proyecto', 'red',
                                             'implementar', 'diseñar', 'recomendar', 'recomendación', 'mejor opción', 'alternativa',
                                             'especificación', 'característica', 'ventaja', 'diferencia', 'comparar', 'qué usar'],
                                'phrases': ['ayuda técnica', 'necesito ayuda', 'no se enciende', 'no arranca', 'no pasa señal', 'cómo reparar',
                                           'tengo problema', 'hay problema', 'necesito resolver', 'cómo funciona', 'qué recomiendan',
                                           'cuál usar', 'mejor opción', 'cómo extender', 'cómo conectar', 'qué necesito',
                                           'es posible', 'se puede', 'puedo usar', 'funciona con', 'compatible con'],
                                'weight': 2.2
                            },
                            'general': {
                                'keywords': ['hola', 'quién', 'quien', 'horario', 'dónde', 'donde', 'contacto', 'información', 'informacion',
                                             'servicios', 'empresa', 'ubicación', 'horarios', 'buenos días', 'buenas tardes', 'buenas noches'],
                                'phrases': ['qué hacen', 'quiénes son', 'dónde están ubicados', 'cómo puedo contactarlos', 'información general'],
                                'weight': 1.0
                            },
                            'cursos': {
                                'keywords': ['curso', 'cursos', 'temario', 'certificación', 'capacitación', 'formación', 'formacion', 'inscripcion', 
                                           'inscribirme', 'recomiendan', 'recomienda', 'webinar', 'webinars', 'seminario', 'seminarios', 
                                           'online', 'on-line', 'en línea', 'en linea', 'fechas', 'costo', 'precio del curso', 'cuánto cuesta'],
                                'phrases': ['quiero aprender', 'me interesa el curso', 'información del curso', 'cuánto cuesta el curso', 
                                           'cuando empieza', 'qué curso recomiendan', 'próximas fechas', 'fechas disponibles'],
                                'weight': 1.5
                            },
                            'productos': {
                                'keywords': ['bobina', 'ducto', 'tritubo', 'jumper', 'cable', 'cotización', 'comprar', 'adquirir', 
                                           'disponibilidad', 'stock', 'mpo', 'mtp', 'utp', 'par trenzado', 'cobre'],
                                'phrases': ['qué productos tienen', 'dónde comprar', 'necesito cotización', 'quiero información de',
                                           'me gustaría cotizar', 'quiero cotizar', 'más información del'],
                                'weight': 1.8
                            },
                            'asesoria': {
                                'keywords': ['asesor', 'asesoría', 'asesoria', 'contactar', 'hablar con', 'consultor', 'vendedor', 'representante'],
                                'phrases': ['quiero hablar con', 'necesito que me contacten', 'consulta personalizada', 'ayuda especializada'],
                                'weight': 1.3
                            }
                        }

                        # Calcular puntuación para cada categoría
                        scores = {}
                        for category, config in patterns.items():
                            score = 0
                            matched_items = []

                            # Verificar keywords
                            for keyword in config.get('keywords', []):
                                if keyword in msg_lower:
                                    score += config.get('weight', 1.0)
                                    matched_items.append(keyword)

                            # Verificar phrases (mayor peso)
                            for phrase in config.get('phrases', []):
                                if phrase in msg_lower:
                                    score += config.get('weight', 1.0) * 1.5
                                    matched_items.append(phrase)

                            scores[category] = {
                                'score': score,
                                'matches': matched_items
                            }

                        # Encontrar la categoría con mayor puntuación
                        best_category = max(scores.keys(), key=lambda k: scores[k]['score'])
                        best_score = scores[best_category]['score']

                        # Reglas de desempate y priorización
                        has_course_keyword = any(k in msg_lower for k in ['curso', 'cursos', 'temario', 'inscripcion', 'inscribirme'])
                        recommend_phrases = ['qué curso', 'que curso', 'curso recomiendan', 'qué curso recomiendan', 'recomiendan curso', 'qué curso recomiendas', 'recomiendan para']
                        has_recommend_phrase = any(p in msg_lower for p in recommend_phrases)

                        tech_priority_phrases = ['problema', 'problemas', 'ayuda técnica', 'necesito ayuda', 'instalación', 'problema con', 'error en', 'no funciona']
                        has_tech_priority = any(p in msg_lower for p in tech_priority_phrases)

                        tecnica_score = scores.get('tecnica', {}).get('score', 0)
                        general_score = scores.get('general', {}).get('score', 0)
                        cursos_score = scores.get('cursos', {}).get('score', 0)

                        # Si el usuario pregunta explícitamente por qué curso, preferir 'cursos'
                        if has_recommend_phrase and has_course_keyword:
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si el usuario expresa interés en aprender y menciona curso (ej. 'Me interesa aprender', 'tienen algún curso'),
                        # preferir 'cursos' incluso si también aparecen términos técnicos.
                        course_interest_phrases = ['me interesa aprender', 'me interesa', 'tienen algún curso', 'tienen algun curso', 'tienen curso', 'tienen algún', 'tienen']
                        has_course_interest = any(p in msg_lower for p in course_interest_phrases)
                        if has_course_interest and has_course_keyword:
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si el usuario utiliza verbos/ofertas (tienen, ofrecen, hay) junto a 'curso'/'webinar', forzar 'cursos'
                        offer_verbs = ['tienen', 'tienen algun', 'tienen algún', 'ofrecen', 'ofrece', 'hay', 'ofrecemos', 'ofrecer']
                        has_offer_verb = any(v in msg_lower for v in offer_verbs)
                        if has_offer_verb and any(k in msg_lower for k in ['curso', 'cursos', 'webinar', 'webinars', 'seminario', 'seminarios', 'opciones online']):
                            best_category = 'cursos'
                            best_score = max(best_score, cursos_score)

                        # Si hay señales técnicas claras y también aparece 'curso', preferir 'tecnica' SOLO si no hay interés explícito en cursos
                        if has_tech_priority and has_course_keyword and not has_course_interest:
                            best_category = 'tecnica'
                            best_score = max(best_score, tecnica_score)

                        # Si cursos tiene la mejor puntuación pero tecnica está muy cerca (>=75%), preferir tecnica
                        if best_category == 'cursos' and tecnica_score >= 0.75 * max(1.0, best_score):
                            best_category = 'tecnica'
                            best_score = tecnica_score

                        # Si cursos y general están muy parejos y no hay señales técnicas, preferir general
                        if best_category == 'cursos' and general_score >= 0.9 * max(1.0, best_score) and not has_tech_priority:
                            best_category = 'general'
                            best_score = general_score

                        # Si no hay puntuación significativa, clasificar como general
                        if best_score == 0:
                            return {
                                'type': 'general',
                                'confidence': 0.45,
                                'details': 'No se encontraron patrones específicos',
                                'scores': scores
                            }

                        # Calcular confianza basada en la diferencia con la segunda opción
                        sorted_scores = sorted(scores.values(), key=lambda x: x['score'], reverse=True)
                        if len(sorted_scores) > 1:
                            second_score = sorted_scores[1]['score']
                            if best_score + second_score > 0:
                                confidence = min(0.95, float(best_score) / float(best_score + second_score))
                            else:
                                confidence = 0.95
                        else:
                            confidence = 0.95

                        return {
                            'type': best_category,
                            'confidence': confidence,
                            'details': f"Matches: {scores[best_category]['matches']}",
                            'scores': scores
                        }
                    
                    # Función para manejar mensajes de publicidad específicos
                    def handle_advertising_messages(message_text):
                        """Maneja mensajes específicos de publicidad y los redirige a información relevante"""
                        text_lower = message_text.lower().strip()
                        
                        # Patrones de mensajes de publicidad por productos
                        advertising_patterns = {
                            'bobinas_utp': {
                                'patterns': ['bobina', 'par trenzado', '100% cobre', 'utp', 'cable utp', 'bobinas utp'],
                                'response': '''🔧 **Bobinas UTP - Cable Par Trenzado 100% Cobre**

¡Excelente elección! Nuestras bobinas UTP ofrecen:
✅ Cobre 100% puro para máxima conductividad
✅ Disponibles en Cat. 5e, Cat. 6 y Cat. 6A
✅ Longitudes estándar de 305m
✅ Certificación internacional TIA/EIA

**Especificaciones técnicas:**
• Impedancia: 100 ohms ± 15%
• Capacitancia: < 56 pF/m
• Resistencia DC: < 9.38 ohms/100m
• Temperatura operativa: -20°C a +60°C

Para cotización personalizada, compárteme:
- Categoría requerida (5e, 6, 6A)
- Cantidad de bobinas
- Ubicación de entrega

**CURSO RELACIONADO:**
📚 "Cableado Estructurado para Redes de Fibra y Cobre"
📅 Próxima fecha: 3-4 Noviembre 2025
💰 $269 USD + IVA
⏱️ 16 horas (2 días)

¿Te interesa el curso? ¡Responde "curso 1" para más información!'''
                            },
                            'ductos': {
                                'patterns': ['ducto', 'ductos', 'tubo', 'conduit', 'cotizar ductos'],
                                'response': '''🏗️ **Ductos para Fibra Óptica**

Nuestros ductos ofrecen la mejor protección para tus instalaciones:
✅ Alta resistencia UV y química
✅ Flexibilidad para instalaciones complejas
✅ Disponibles en múltiples diámetros
✅ Cumple normas internacionales

**Tipos disponibles:**
• Ducto corrugado para enterrado
• Ducto liso para interior
• Ducto de alta densidad (HDPE)
• Microductos para fibra

**Aplicaciones:**
- Redes FTTH
- Planta externa
- Campus universitarios
- Edificios corporativos

Para cotización, necesito:
- Tipo de ducto requerido
- Diámetro y longitud
- Aplicación específica

**CURSO RELACIONADO:**
📚 "Redes de Fibra Óptica Planta Externa"
📅 Próxima fecha: 5-6 Noviembre 2025
💰 $269 USD + IVA
⏱️ 16 horas (2 días)

¿Quieres capacitarte en instalación de ductos? ¡Responde "curso 2" para más información!'''
                            },
                            'tritubo': {
                                'patterns': ['tritubo', 'tri-tubo', 'tri tubo', 'más información del tritubo'],
                                'response': '''🌐 **Tritubo para Fibra Óptica**

Solución innovadora para máxima densidad de fibra:
✅ Tres tubos en una sola estructura
✅ Optimiza espacio en ductos
✅ Fácil identificación por colores
✅ Reducción de costos de instalación

**Características técnicas:**
• Material: HDPE de alta calidad
• Colores estándar: Azul, Rojo, Verde
• Diámetros: 7mm, 10mm, 12mm
• Longitudes: 2000m por carrete

**Ventajas:**
- 50% menos espacio que tubos individuales
- Instalación más rápida
- Mejor organización de la red
- Menor costo por metro

Para cotización personalizada, compárteme:
- Diámetro requerido
- Longitud total
- Proyecto específico

**CURSO RELACIONADO:**
📚 "Redes de Fibra Óptica FTTH para WISP e ISP"
📅 Próxima fecha: 10-11 Noviembre 2025
💰 $299 USD + IVA
⏱️ 16 horas (2 días)

¿Te interesa aprender sobre FTTH? ¡Responde "curso 3" para más información!'''
                            },
                            'mpo_mtp': {
                                'patterns': ['mpo', 'mtp', 'mtp pro', 'jumper mpo', 'jumper mtp', 'cotizar jumper'],
                                'response': '''🔗 **Jumpers MPO/MTP y MTP Pro**

Conectividad de alta densidad para centros de datos:
✅ MPO/MTP estándar y MTP Pro disponibles
✅ Conectores de precisión
✅ Baja pérdida de inserción (<0.5dB)
✅ Alta durabilidad (>1000 ciclos)

**Configuraciones disponibles:**
• 8, 12, 24 fibras
• Singlemode y Multimode
• Polaridad A, B, C
• Longitudes: 1m a 100m

**Tipos de conectores:**
- MPO: Multi-fiber Push On
- MTP: Mechanical Transfer Push On
- MTP Pro: Versión premium con mejor rendimiento

**Aplicaciones:**
- Data centers
- Redes empresariales
- Backbone de alta velocidad
- Conexiones 40G/100G/400G

Para cotización, especifica:
- Tipo de conector (MPO/MTP/MTP Pro)
- Número de fibras
- Tipo de fibra (SM/MM)
- Longitudes requeridas

**CURSO RELACIONADO:**
📚 "PONLAN Redes Pasivas para Entornos Enterprise"
📅 Próxima fecha: 12-13 Noviembre 2025
💰 Consultar con asesor
⏱️ 16 horas (2 días)

¿Quieres especializarte en redes enterprise? ¡Responde "curso 4" para más información!'''
                            },
                            'cursos_generales': {
                                'patterns': ['curso de cableado estructurado', 'curso de fibra óptica planta externa', 
                                           'curso redes de fibra óptica ftth', 'curso de redes ópticas pasivas', 
                                           'curso de empalmes y mediciones'],
                                'response': '''📚 **NUESTROS CURSOS ESPECIALIZADOS**

Tenemos 5 cursos profesionales disponibles:

**1. Cableado Estructurado para Redes de Fibra y Cobre** 🔧
📅 3-4 Noviembre 2025 | ⏱️ 16 horas | 💰 $269 USD + IVA

**2. Redes de Fibra Óptica Planta Externa** 🏗️
📅 5-6 Noviembre 2025 | ⏱️ 16 horas | 💰 $269 USD + IVA

**3. Redes de Fibra Óptica FTTH para WISP e ISP** 🌐
📅 10-11 Noviembre 2025 | ⏱️ 16 horas | 💰 $299 USD + IVA

**4. PONLAN Redes Pasivas para Entornos Enterprise** 🏢
📅 12-13 Noviembre 2025 | ⏱️ 16 horas | 💰 Consultar con asesor

**5. Empalmes y Mediciones con OTDR** 🎯
📅 5-6 Noviembre 2025 | ⏱️ 16 horas | 💰 Consultar con asesor

📍 Ubicación: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
🕘 Horario: 9:00 a 19:00 hrs

¿Cuál te interesa? Responde con el número o nombre del curso para ver el temario completo.'''
                            }
                        }
                        
                        # Buscar coincidencias con patrones de publicidad (orden de prioridad)
                        
                        # Mensajes específicos de publicidad de cursos
                        curso_patterns = {
                            'información del curso de cableado estructurado': '📚 **CURSO: Cableado Estructurado para Redes de Fibra y Cobre**\n\n✅ **Temario completo:**\n• Fundamentos de cableado estructurado\n• Instalación de fibra y cobre\n• Normativas TIA/EIA\n• Certificación de enlaces\n• Práticas con equipos profesionales\n\n📅 **Fecha:** 3-4 Noviembre 2025\n💰 **Precio:** $269 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de fibra óptica planta externa': '📚 **CURSO: Redes de Fibra Óptica Planta Externa**\n\n✅ **Temario completo:**\n• Diseño de redes exteriores\n• Instalación aérea y subterránea\n• Tipos de fibra para exterior\n• Presupuestos ópticos\n• Mediciones con OTDR\n\n📅 **Fecha:** 5-6 Noviembre 2025\n💰 **Precio:** $269 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso redes de fibra óptica ftth': '📚 **CURSO: Redes de Fibra Óptica FTTH para WISP e ISP**\n\n✅ **Temario completo:**\n• Arquitectura FTTH/GPON\n• Equipos OLT y ONT\n• Splitters y divisores\n• Instalación residencial\n• Gestión de red FTTH\n\n📅 **Fecha:** 10-11 Noviembre 2025\n💰 **Precio:** $299 USD + IVA\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de redes ópticas pasivas': '📚 **CURSO: PONLAN Redes Pasivas para Entornos Enterprise**\n\n✅ **Temario completo:**\n• Redes PON para empresas\n• Arquitectura PONLAN\n• Equipos especializados\n• Diseño corporativo\n• Certificación empresarial\n\n📅 **Fecha:** 12-13 Noviembre 2025\n💰 **Precio:** Consultar con asesor\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!',
                            'información del curso de empalmes y mediciones': '📚 **CURSO: Empalmes y Mediciones con OTDR**\n\n✅ **Temario completo:**\n• Técnicas de empalme\n• Uso profesional de OTDR\n• Interpretación de trazas\n• Certificación de enlaces\n• Resolución de problemas\n\n📅 **Fecha:** 5-6 Noviembre 2025\n💰 **Precio:** Consultar con asesor\n⏱️ **Duración:** 16 horas (2 días)\n📍 **Ubicación:** Querétaro, Qro.\n\n¿Te interesa inscribirte? ¡Responde "sí" para más información!'
                        }
                        
                        for curso_pattern, response in curso_patterns.items():
                            if curso_pattern in text_lower:
                                return response
                        
                        # Mensajes específicos de productos (más específicos primero)
                        specific_messages = {
                            'información de bobina de par trenzado 100% cobre': 'bobinas_utp',
                            'quiero información de bobina de par trenzado 100% cobre': 'bobinas_utp',
                            'me gustaría cotizar ductos': 'ductos',
                            'quiero cotizar ductos': 'ductos',
                            'más información del tritubo': 'tritubo',
                            'quiero más información del tritubo': 'tritubo',
                            'cotizar jumper mpo y mtp': 'mpo_mtp',
                            'quiero cotizar jumper mpo y mtp': 'mpo_mtp'
                        }
                        
                        for specific_msg, product_type in specific_messages.items():
                            if specific_msg in text_lower:
                                return advertising_patterns[product_type]['response']
                        
                        # Patrones generales por categoría
                        for product_type, config in advertising_patterns.items():
                            if product_type == 'cursos_generales':
                                continue  # Ya manejado arriba
                            for pattern in config['patterns']:
                                if pattern in text_lower:
                                    # Verificar contexto para evitar falsos positivos
                                    if any(context_word in text_lower for context_word in ['quiero', 'información', 'cotizar', 'más información']):
                                        return config['response']
                        
                        return None
                    
                    # Detectar cambios de tema intencionales
                    topic_shift_keywords = ['cambio de tema', 'otra pregunta', 'nuevo tema', 'diferente', 'otra cosa', 
                                           'hablemos de', 'cuéntame sobre', 'donde esta', 'donde se encuentra',
                                           'no quiero', 'quiero saber', 'quiero hablar', 'pregunta', 'dime sobre']
                    
                    # Detectar comandos para finalizar la conversación enfocada en cursos
                    clear_course_commands = ['finalizar curso', 'terminar curso', 'salir del curso', 'salir curso', 
                                           'cancelar curso', 'no más cursos', 'no mas cursos']
                    
                    # 🤖 Usar el sistema ML-first mejorado
                    intent_classification = classify_user_intent_ml(message_text, phone, conversation_history)
                    user_intent_type = intent_classification['type']
                    intent_confidence = intent_classification['confidence']
                    ml_details = intent_classification['details']

                    logger.info(f"� ML Classification: {user_intent_type} (confidence: {intent_confidence:.2f})")
                    
                    # Actualizar contexto de conversación con información ML
                    ml_result = ml_details.get('full_ml_result', {})
                    update_conversation_context(phone, ml_result, user_intent_type)

                    # Generar system prompt contextual basado en ML
                    contextual_prompt = generate_contextual_system_prompt(ml_result, user_intent_type, message_text)
                    
                    # Manejar leads calientes automáticamente
                    client_data = ml_result.get('client_data', {})
                    lead_prediction = ml_result.get('lead_prediction', {})
                    
                    # Si es lead caliente con datos completos, generar PDF para asesor
                    if (lead_prediction.get('lead_type') == 'caliente' and 
                        client_data.get('nombre') and (client_data.get('correo') or client_data.get('empresa'))):
                        try:
                            from services.ml_service import ml_service
                            pdf_path = ml_service.generate_client_pdf(client_data, ml_result.get('classification', {}))
                            logger.info(f"🔥 PDF generado para lead caliente: {pdf_path}")
                        except Exception as e:
                            logger.error(f"Error generando PDF: {e}")

                    # Si requiere atención humana, marcar para seguimiento
                    if ml_result.get('requires_human_attention'):
                        from services.conversation_memory import ConversationMemory
                        ConversationMemory.add_entity_to_memory(phone, 'needs_human_followup', True)
                        logger.warning(f"⚠️ Cliente {phone} requiere atención humana")

                    # Función para detectar consultas técnicas específicas (movida arriba para prioridad)
                    def is_technical_consultation(message_text):
                        """Detecta si es una consulta técnica que debe procesarse inmediatamente"""
                        text_lower = (message_text or '').lower().strip()
                        # Patrones de consultas técnicas claras (ampliados para cubrir preguntas cortas y términos generales)
                        technical_indicators = [
                            # Términos generales
                            'fibra', 'fibra óptica', 'fibra optica', 'dispers', 'dispersión', 'dispercion', 'dispersión cromática', 'dispercion cromatica',
                            # Productos y especificaciones
                            'fibra multimodo', 'fibra monomodo', 'om1', 'om2', 'om3', 'om4', 'om5',
                            'g652', 'g657', 'pigtail', 'pigtal', 'conector sc', 'conector fc', 'conector lc', 'conector',
                            # Consultas de implementación
                            'extender', 'conectar', 'unir', 'enlace', 'distancia', 'metros', 'ducto', 'ductos', 'empalme', 'empalmes', 'fusion', 'fusión',
                            'otdr', 'reflectómetro', 'reflectometro',
                            'es posible', 'se puede', 'puedo usar', 'funciona con', 'compatible', 'cómo', 'como', 'qué es', 'que es', 'para qué sirve',
                            # Recomendaciones técnicas
                            'qué recomiendan', 'cuál usar', 'mejor opción', 'alternativa', 'recomiendan', 'recomend',
                            # Especificaciones
                            'características', 'especificaciones', 'diferencia entre', 'atenuación', 'pérdida', 'loss', 'attenuation',
                            # Proyectos y diseño
                            'proyecto', 'implementar', 'diseñar', 'instalar', 'presupuesto', 'presupuesto óptico', 'presupuesto optico'
                        ]

                        # Short question heuristic: if user asks "qué es X" or "para que sirve X" where X matches a technical term
                        short_question_patterns = ['qué es', 'que es', 'para que sirve', 'para qué sirve', 'qué es la', 'que es la']

                        if any(s in text_lower for s in short_question_patterns) and any(k in text_lower for k in ['fibra', 'otdr', 'pigtail', 'dispersion', 'dispersión', 'conector']):
                            return True

                        return any(indicator in text_lower for indicator in technical_indicators)

                    # Priorizar consultas técnicas: si detectamos indicadores técnicos, marcamos la intención y
                    # evitamos que los detectores de publicidad/curso la sobreescriban o la cortocircuiten.
                    is_technical_question = False
                    if is_technical_consultation(message_text):
                        user_intent_type = 'tecnica'
                        intent_confidence = max(intent_confidence, 0.9)
                        is_technical_question = True
                        logger.info(f"🔧 Consulta técnica específica detectada para {phone}: {message_text[:50]}...")

                    # === PROCESAMIENTO AI-FIRST: TODAS LAS CONSULTAS PASAN POR IA ===
                    logger.info(f"🚀 PROCESANDO CON IA PRIMERO - Teléfono: {phone}")
                    
                    def process_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, user_intent_type, is_technical_question=False):
                        """Procesa TODOS los mensajes con IA sin excepción"""
                        try:
                            # System prompt mejorado para responder a TODO
                            ai_system_prompt = """
ERES UN CONSULTOR EXPERTO EN FIBRA ÓPTICA Y TELECOMUNICACIONES DE FIBREMEX.

INSTRUCCIONES PRINCIPALES:
1. RESPONDE A TODAS LAS CONSULTAS SIN EXCEPCIÓN
2. Si preguntan sobre productos (bobinas, ductos, tritubo, jumpers MPO/MTP): proporciona información técnica detallada
3. Si preguntan sobre cursos: proporciona información completa de fechas, precios y temarios
4. Si preguntan consultas técnicas: responde como experto con detalles específicos
5. Si preguntan por opciones online: menciona los webinars gratuitos cada martes
6. NUNCA digas que no puedes ayudar - SIEMPRE da una respuesta útil

INFORMACIÓN DE PRODUCTOS:
• Bobinas UTP: Cat 5e, 6, 6A - 100% cobre, 305m, certificación TIA/EIA
• Ductos: HDPE alta densidad, corrugado/liso, múltiples diámetros
• Tritubo: 3 tubos en una estructura, optimiza espacio, colores estándar
• Jumpers MPO/MTP: 8-24 fibras, SM/MM, polaridades A/B/C

INFORMACIÓN DE CURSOS:
1. Cableado Estructurado - 3-4 Nov 2025 - $269 USD + IVA
2. Fibra Óptica Planta Externa - 5-6 Nov 2025 - $269 USD + IVA  
3. FTTH para WISP e ISP - 10-11 Nov 2025 - $299 USD + IVA
4. PONLAN Enterprise - 12-13 Nov 2025 - Consultar precio
5. Empalmes y OTDR - 5-6 Nov 2025 - Consultar precio

UBICACIÓN: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
WEBINARS: Gratuitos cada martes en línea

REGLA DORADA: RESPONDE SIEMPRE CON INFORMACIÓN ÚTIL Y ESPECÍFICA
"""
                            
                            # Asegurar chat_with_gemini disponible localmente
                            try:
                                from services.chat_ai import chat_with_gemini as _local_chat
                            except Exception:
                                _local_chat = None

                            # Generar respuesta con IA
                            if _local_chat:
                                ai_response = _local_chat(
                                    phone=phone,
                                    message=message_text,
                                    system_prompt=ai_system_prompt,
                                    include_whatsapp_profile=whatsapp_profile
                                )
                            else:
                                ai_response = None

                            # If this was a technical question, ensure the AI does NOT proactively push course
                            # suggestions. If the AI reply mentions courses, regenerate with a stricter prompt.
                            if is_technical_question and ai_response:
                                low = ai_response.lower()
                                if any(k in low for k in ['curso', 'cursos', 'temario', 'inscripción', 'inscripcion', 'fechas']):
                                    logger.info(f"🔒 Sanitizing AI response to remove course suggestions for technical query for {phone}")
                                    strict_prompt = ai_system_prompt + "\n\nINSTRUCCIÓN ADICIONAL: El usuario hizo una consulta TÉCNICA. NO menciones cursos, fechas, precios ni ofrezcas inscripciones. Concéntrate exclusivamente en la solución técnica."
                                    try:
                                        if _local_chat:
                                            ai_response_strict = _local_chat(
                                                phone=phone,
                                                message=message_text,
                                                system_prompt=strict_prompt,
                                                include_whatsapp_profile=whatsapp_profile
                                            )
                                        else:
                                            ai_response_strict = None
                                        if ai_response_strict and len(ai_response_strict.strip()) > 10:
                                            ai_response = ai_response_strict
                                    except Exception as _re:
                                        logger.debug(f"Error regenerating strict AI response: {_re}")
                            
                            logger.info(f"✅ IA procesó exitosamente para {phone}: {len(ai_response)} caracteres")
                            return ai_response
                            
                        except Exception as e:
                            logger.error(f"❌ Error en procesamiento IA: {e}")
                            return f"He analizado tu consulta. Para brindarte información específica sobre {message_text[:50]}..., ¿podrías darme más detalles sobre tu proyecto o necesidad específica?"
                    
                    # PROCESAR CON IA INMEDIATAMENTE
                    try:
                        ai_response = process_with_ai_always(phone, message_text, conversation_history, whatsapp_profile, user_intent_type, is_technical_question=is_technical_question)
                        
                        # ENVIAR RESPUESTA IA INMEDIATAMENTE
                        if ai_response and len(ai_response.strip()) > 10:
                            logger.info(f"📤 Enviando respuesta IA a {phone}")
                            send_text_message(phone, ai_response.strip())
                            
                            # Marcar como procesado y continuar al siguiente webhook
                            save_conversation_memory(phone, 'last_response_type', 'ai_processed')
                            logger.info(f"✅ Mensaje procesado con IA para {phone} - COMPLETADO")
                            continue
                        else:
                            logger.warning(f"⚠️ Respuesta IA vacía o muy corta para {phone}")
                    except Exception as e:
                        logger.error(f"❌ Fallo crítico en procesamiento IA para {phone}: {e}")
                    
                    # Verificar si es un mensaje de publicidad específico (SOLO como fallback)
                    advertising_response = None
                    if not is_technical_question:
                        advertising_response = handle_advertising_messages(message_text)
                        if advertising_response:
                            logger.info(f"Mensaje de publicidad detectado para {phone} (fallback)")
                            send_text_message(phone, advertising_response)
                            continue
                    
                    # Manejar solicitudes específicas de información de cursos
                    def handle_course_info_requests(message_text):
                        """Maneja solicitudes específicas de información de cursos"""
                        text_lower = message_text.lower().strip()
                        
                        # Lista general de cursos
                        if any(pattern in text_lower for pattern in ['cursos', 'qué cursos', 'que cursos', 'lista de cursos', 'cursos disponibles']):
                            if not any(specific in text_lower for specific in ['temario', 'fechas', 'precio', 'información de']):
                                return get_all_courses_summary()
                        
                        # Mapeo de palabras clave a IDs de curso (orden de especificidad)
                        course_keywords = {
                            4: ['ponlan', 'enterprise', 'pol', 'pasivas', 'corporativo', 'empresarial'],  # Más específico primero
                            5: ['otdr', 'empalmes', 'fusión', 'fusion', 'mediciones', 'reflectómetro', 'reflectometro'],
                            3: ['ftth', 'wisp', 'isp', 'gpon', 'fiber to the home'],  # 'pon' removido para evitar conflicto con ponlan
                            1: ['cableado', 'estructurado', 'cobre', 'cat6', 'cat5e', 'utp'],
                            2: ['planta externa', 'exterior', 'outdoor', 'fibra óptica planta', 'fibra optica planta']
                        }
                        
                        # Patrones para diferentes tipos de solicitud
                        import re
                        
                        # Solicitud por número específico
                        number_match = re.search(r'(?:curso\s+|información\s+curso\s+|temario\s+|fechas?\s+curso\s+|precio\s+curso\s+)(\d+)', text_lower)
                        if number_match:
                            course_id = int(number_match.group(1))
                            return get_course_complete_info(course_id=course_id)
                        
                        # Solicitud de información específica (fechas, precios, temario)
                        info_patterns = [
                            (r'(?:fechas?|cuando|cuándo)\s+(.+)', 'fechas'),
                            (r'(?:precio|costo|cuánto cuesta|cuanto cuesta)\s+(.+)', 'precio'),
                            (r'(?:temario|contenido|programa)\s+(.+)', 'temario'),
                            (r'(?:información|info)\s+(?:del\s+|sobre\s+)?(.+)', 'completa')
                        ]
                        
                        for pattern, info_type in info_patterns:
                            match = re.search(pattern, text_lower)
                            if match:
                                course_text = match.group(1).strip()
                                
                                # Si es un número directo
                                if course_text.isdigit():
                                    course_id = int(course_text)
                                    return get_course_specific_info(course_id, info_type)
                                
                                # Buscar por palabras clave
                                for course_id, keywords in course_keywords.items():
                                    if any(keyword in course_text for keyword in keywords):
                                        return get_course_specific_info(course_id, info_type)
                        
                        # Solicitud general por palabras clave
                        for course_id, keywords in course_keywords.items():
                            if any(keyword in text_lower for keyword in keywords):
                                # Si menciona información específica
                                if any(word in text_lower for word in ['información', 'info', 'temario', 'fechas', 'precio', 'costo']):
                                    return get_course_complete_info(course_id=course_id)
                        
                        return None
                    
                    # Verificar si es una solicitud de información de cursos (sólo si no es técnica)
                    course_info_response = None
                    if not is_technical_question:
                        course_info_response = handle_course_info_requests(message_text)
                        if course_info_response:
                            logger.info(f"Solicitud de información de curso detectada para {phone}")
                            send_text_message(phone, course_info_response)
                            continue

                    # Si el usuario es nuevo y no sabe qué curso elegir, iniciar flujo de descubrimiento
                    # Detectar frases tipo: "no se que curso tomar", "no se que elegir", "que me recomiendas"
                    try:
                        newbie_phrases = ['no se que curso', 'no sé que curso', 'no se que elegir', 'no sé que elegir', 'que me recomiendas', 'qué me recomiendas', 'no se que tomar']
                        if any(p in (message_text or '').lower() for p in newbie_phrases) and not is_technical_question:
                            # Preguntar 2-3 preguntas abiertas para recomendar curso
                            discovery_q = (
                                "Perfecto — para recomendarte el mejor curso, cuéntame brevemente:\n"
                                "1) ¿Qué tema te interesa aprender o qué quieres mejorar? (ej. empalmes, FTTH, cableado estructurado)\n"
                                "2) ¿Trabajas en campo o en proyecto/planificación?\n"
                                "3) ¿Tienes experiencia previa en fibra o redes? (principiante/intermedio/avanzado)"
                            )
                            send_text_message(phone, discovery_q)
                            try:
                                save_conversation_memory(phone, 'awaiting_discovery_answers', True)
                            except Exception:
                                logger.debug('No se pudo guardar awaiting_discovery_answers')
                            continue
                    except Exception as _disc_e:
                        logger.debug(f"Error iniciando flujo de descubrimiento: {_disc_e}")
                    
                    # La detección de consultas técnicas se maneja arriba y prioriza ese flujo.
                    # Evitamos redefinir la función o re-evaluar aquí para mantener la prioridad aplicada.
                    
                    # Variables para el flujo posterior
                    avoid_curso_intent = False
                    is_technical_question = (user_intent_type == 'tecnica')
                    is_course_question = (user_intent_type == 'cursos')
                    is_product_question = (user_intent_type == 'productos')
                    is_advisor_request = (user_intent_type == 'asesoria')
                    system_prompt_override = None
                    
                    # Crear system prompts específicos según el tipo de intent
                    intent_prompts = {
                        'tecnica': """
ERES UN EXPERTO TÉCNICO EN FIBRA ÓPTICA Y REDES DE TELECOMUNICACIONES.

ESPECIALIDADES:
- Fibra óptica y sus aplicaciones
- Redes FTTH, GPON, PON, PONLAN
- Equipos: OTDR, fusionadoras, cleavers, power meters
- Cableado estructurado UTP/STP
- Mediciones y pruebas de fibra
- Instalación y mantenimiento
- Diagnóstico y resolución de problemas

INSTRUCCIONES:
1. Responde con información técnica precisa y detallada
2. Usa terminología profesional apropiada
3. Incluye valores específicos, procedimientos paso a paso
4. Menciona herramientas y equipos necesarios
5. Proporciona soluciones prácticas
6. NO ofrezcas cursos a menos que sea estrictamente relevante
7. Enfócate en resolver la consulta técnica específica

Responde de manera profesional y técnica a la consulta del usuario.
""",
                        'cursos': """
ERES UN CONSULTOR EDUCATIVO ESPECIALIZADO EN CURSOS DE FIBRA ÓPTICA Y TELECOMUNICACIONES.

INFORMACIÓN DE CURSOS:
1. Cableado Estructurado - 3-4 Nov 2025 - Precio: Consultar
2. Fibra Óptica Planta Externa - 5-6 Nov 2025 - Precio: Consultar  
3. FTTH para WISP e ISP - 10-11 Sep 2025 - Precio: $299 USD + IVA
4. PONLAN Enterprise - 12-13 Nov 2025 - Precio: Consultar
5. Empalmes y OTDR - 7 Nov 2025 - Precio: Consultar

UBICACIÓN: Parque Industrial Tecnológico Innovación, Querétaro, Qro.
HORARIO: 9:00 a 19:00 hrs
DURACIÓN: 16 horas (2 días)

INSTRUCCIONES:
1. Proporciona información completa de fechas, precios y temarios
2. Recomienda el curso más adecuado según la consulta
3. Incluye detalles de ubicación y modalidad
4. Menciona certificación DC3 cuando aplique
5. Ofrece temarios detallados si se solicitan

Ayuda al usuario a encontrar el curso perfecto para sus necesidades.
""",
                        'productos': """
ERES UN ESPECIALISTA EN PRODUCTOS DE FIBRA ÓPTICA Y CABLEADO.

PRODUCTOS PRINCIPALES:
- Bobinas UTP (Cat. 5e, 6, 6A) - 100% cobre
- Ductos para fibra óptica (HDPE, corrugado, liso)
- Tritubo para optimización de espacio
- Jumpers MPO/MTP/MTP Pro para data centers

INSTRUCCIONES:
1. Proporciona especificaciones técnicas detalladas
2. Explica aplicaciones y ventajas
3. Solicita información específica para cotización
4. Relaciona con cursos relevantes cuando sea apropiado
5. Incluye datos de rendimiento y certificaciones

Ayuda al usuario a encontrar el producto adecuado para su proyecto.
""",
                        'general': """
ERES UN ASISTENTE ESPECIALIZADO DE FIBREMEX, EMPRESA LÍDER EN FIBRA ÓPTICA.

INFORMACIÓN EMPRESA:
- Especialistas en fibra óptica y telecomunicaciones
- Cursos presenciales en Querétaro
- Productos de alta calidad
- Ubicación: Parque Industrial Tecnológico Innovación, Qro.

INSTRUCCIONES:
1. Responde consultas generales sobre la empresa
2. Proporciona información de contacto y ubicación
3. Explica servicios y productos disponibles
4. Mantén un tono profesional y amigable
5. Deriva a especialistas cuando sea necesario

Ayuda al usuario con información general sobre Fibremex.
"""
                    }
                    
                    msg_lower = message_text.lower()

                    # Helper: detectar peticiones explícitas de cursos/webinars (evitar false-positives)
                    def is_explicit_course_or_webinar_request(text: str) -> bool:
                        t = (text or '').lower()
                        # casos claros: menciona 'webinar' o 'webinars' o 'seminario'
                        if any(k in t for k in ['webinar', 'webinars', 'seminario', 'seminarios']):
                            return True
                        # peticiones directas de curso: 'quiero información sobre el curso', 'tienen curso', 'qué cursos', 'cuentas con cursos', 'cuentas con opciones online'
                        direct_phrases = ['quiero información sobre el curso', 'quiero informacion sobre el curso', 'qué cursos', 'que cursos', 'tienen curso', 'tienen cursos', 'cuentas con', 'cuentas con opciones', 'me interesa el curso', 'me interesa aprender', 'qué curso recomiendan', 'curso recomiendan', 'curso recomiendas']
                        if any(p in t for p in direct_phrases):
                            return True
                        # también si pregunta con palabras clave 'temario' o 'inscripcion' de forma directa
                        if any(k in t for k in ['temario', 'inscripción', 'inscripcion', 'fechas del curso', 'fecha del curso', 'fechas']):
                            # asegúrate de que no está dentro de una frase claramente técnica
                            if not any(k in t for k in ['problema', 'error', 'no funciona', 'fallo', 'instal']):
                                return True
                        return False
                    
                    # Detectar si el usuario explícitamente no quiere hablar de cursos
                    if ('no quiero' in msg_lower and 
                        any(curso_word in msg_lower for curso_word in ['curso', 'cursos', 'hablar de eso'])):
                        avoid_curso_intent = True
                        logger.warning(f"Usuario explícitamente no quiere hablar de cursos: {message_text}")
                    
                    # Log detallado de la clasificación
                    if intent_confidence > 0.7:
                        logger.info(f"Alta confianza en clasificación: {user_intent_type}")
                    else:
                        logger.warning(f"Baja confianza en clasificación: {user_intent_type} ({intent_confidence:.2f})")
                        # En caso de baja confianza, usar contexto adicional
                        if conversation_history and len(conversation_history) > 0:
                            # Analizar el contexto previo PARA MEJORAR LA CLASIFICACIÓN
                            # IMPORTANT: use only prior USER messages (user_message) and avoid
                            # using bot responses or previously generated AI content because
                            # that can create false positives for course/product detection.
                            recent_user_messages = ' '.join([
                                turn.get('user_message', '') for turn in conversation_history[-3:]
                            ])
                            context_classification = classify_user_intent(recent_user_messages + ' ' + message_text)
                            if context_classification['confidence'] > intent_confidence:
                                logger.info(f"Mejorando clasificación con contexto: {context_classification['type']}")
                                user_intent_type = context_classification['type']
                                intent_confidence = context_classification['confidence']

                    # Manejo si previamente pedimos una aclaración: NO pedir al usuario, sino
                    # re-clasificar automáticamente usando el texto completo y limpiar la bandera.
                    pending_clarify = get_conversation_memory(phone, 'awaiting_intent_clarification')
                    if pending_clarify:
                        try:
                            reclass = classify_user_intent(message_text, conversation_history)
                            user_intent_type = reclass.get('type') or user_intent_type
                            intent_confidence = reclass.get('confidence', intent_confidence)
                            is_technical_question = (user_intent_type == 'tecnica')
                            is_course_question = (user_intent_type == 'cursos')
                            is_product_question = (user_intent_type == 'productos')
                            is_advisor_request = (user_intent_type == 'asesoria')
                            try:
                                save_conversation_memory(phone, 'awaiting_intent_clarification', False)
                                save_conversation_memory(phone, 'intent_clarified', user_intent_type)
                            except Exception:
                                logger.debug('No se pudo limpiar awaiting_intent_clarification')
                            logger.info(f"Intención automáticamente reclasificada para {phone}: {user_intent_type} (conf {intent_confidence:.2f})")
                        except Exception as e:
                            # Si hay error, simplemente limpiar la bandera y continuar con la clasificación actual
                            try:
                                save_conversation_memory(phone, 'awaiting_intent_clarification', False)
                            except Exception:
                                logger.debug('No se pudo limpiar awaiting_intent_clarification tras error')
                            logger.debug(f"Error reclasificando durante awaiting_intent_clarification: {e}")

                    # Si el usuario pide terminar el flujo de curso, limpiar la selección

                    # Si el usuario pide terminar el flujo de curso, limpiar la selección
                    if any(cmd in message_text.lower() for cmd in clear_course_commands):
                        try:
                            clear_selected_course(phone)
                            send_text_message(phone, "He finalizado la selección de curso. ¿En qué más puedo ayudarte?")
                            logger.info(f"Curso seleccionado limpiado para {phone} por comando del usuario")
                            # Continue to next webhook processing (no course-specific behavior)
                            continue
                        except Exception:
                            logger.debug("No se pudo limpiar la selección de curso (o no existía)")
                    
                    # Verificar si el usuario explícitamente no quiere hablar de cursos
                    if ('no quiero' in message_text.lower() and 
                        any(curso_word in message_text.lower() for curso_word in ['curso', 'cursos', 'hablar de eso'])):
                        avoid_curso_intent = True
                        logger.warning(f"Usuario explícitamente no quiere hablar de cursos: {message_text}")
                    
                    is_topic_shift = any(keyword in message_text.lower() for keyword in topic_shift_keywords)
                    
                    # Sistema inteligente de manejo de contexto basado en la clasificación
                    should_reset_context = False
                    context_reset_reason = ""
                    
                    # Definir system prompts específicos por tipo de intención
                    intent_prompts = {
                        'tecnica': (
                            "El usuario ha hecho una PREGUNTA TÉCNICA sobre fibra óptica, redes o telecomunicaciones. "
                            "Responde como un experto técnico proporcionando información técnica precisa, paso a paso. "
                            "Al final, OPCIONALMENTE puedes sugerir un curso relacionado si es relevante, pero la prioridad "
                            "es resolver su problema técnico actual."
                        ),
                        'cursos': (
                            "El usuario está interesado en CURSOS y CAPACITACIONES. Proporciona información detallada "
                            "sobre los cursos disponibles, incluyendo temarios, fechas, precios, modalidades y beneficios. "
                            "Ayúdalo a seleccionar el curso más adecuado para sus necesidades."
                        ),
                        'productos': (
                            "El usuario está consultando sobre PRODUCTOS (bobinas, ductos, cables, etc.). "
                            "Proporciona información técnica de los productos, características, disponibilidad y precios. "
                            "Si necesita cotización personalizada, ofrece conectarlo con un asesor."
                        ),
                        'asesoria': (
                            "El usuario solicita ASESORÍA PERSONALIZADA. Recopila sus datos de contacto y información "
                            "sobre su proyecto o necesidades específicas para conectarlo con un asesor especializado."
                        ),
                        'general': (
                            "El usuario hace una consulta GENERAL sobre la empresa, servicios o información básica. "
                            "Proporciona información útil y oriéntalo hacia los servicios más relevantes según su consulta."
                        )
                    }
                    
                    # Determinar si necesitamos resetear el contexto
                    if avoid_curso_intent:
                        should_reset_context = True
                        context_reset_reason = "Usuario rechaza explícitamente cursos"
                        system_prompt_override = "El usuario explícitamente NO quiere hablar de cursos. Responde a su pregunta actual sin mencionar cursos ni formaciones."
                    elif is_topic_shift and len(conversation_history) > 3:
                        should_reset_context = True
                        context_reset_reason = "Cambio de tema detectado"
                        system_prompt_override = intent_prompts.get(user_intent_type, intent_prompts['general'])
                    elif user_intent_type != 'general' and intent_confidence > 0.6:
                        # Si tenemos alta confianza en una intención específica, usar su prompt
                        system_prompt_override = intent_prompts[user_intent_type]
                        # Solo resetear contexto si es muy diferente del tema anterior
                        if len(conversation_history) > 2:
                            should_reset_context = True
                            context_reset_reason = f"Cambio a intención específica: {user_intent_type}"
                    
                    # Aplicar reset de contexto si es necesario
                    if should_reset_context:
                        logger.info(f"Reseteando contexto para {phone}. Razón: {context_reset_reason}")
                        clear_topic_context(phone)
                        # Refrescar el historial después de limpiar
                        try:
                            conversation_history = get_conversation_history(phone)
                        except Exception as refresh_error:
                            logger.error(f"Error al refrescar historial: {refresh_error}")
                            conversation_history = []

                    # Sistema inteligente de manejo de flujos basado en clasificación de intenciones
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor:
                        logger.info(f"Skipping course detection because waiting_for_advisor_data is set for {phone}")
                    
                    # Manejar flujos específicos según el tipo de intención detectado
                    # --- Nueva lógica: si la clasificación es ambigua (baja confianza) y hay señales mixtas, pedir clarificación ---
                    try:
                        ambiguous_signals = 0
                        # señales técnicas
                        if any(k in msg_lower for k in ['problema', 'error', 'instal', 'otdr', 'empalme', 'medición', 'medicion', 'no funciona']):
                            ambiguous_signals += 1
                        # señales de cursos
                        if any(k in msg_lower for k in ['curso', 'cursos', 'temario', 'aprender', 'inscripcion', 'inscribirme']):
                            ambiguous_signals += 2

                        # considerar ambigüedad si confidence baja y ambas clases aparecen o señales mixtas detectadas
                        if intent_confidence < 1.65 and ambiguous_signals >= 3:
                            # En vez de preguntar al usuario, resolvemos automáticamente basados en las
                            # señales de contexto: contamos indicadores técnicos vs indicadores de curso
                            technical_indicators = ['problema', 'error', 'instal', 'otdr', 'empalme', 'empalmes', 'medición', 'medicion', 'no funciona', 'atenuación', 'pérdida', 'loss', 'attenuation']
                            course_indicators = ['curso', 'cursos', 'temario', 'aprender', 'inscripcion', 'inscribirme', 'precio', 'fechas']

                            tech_count = sum(1 for k in technical_indicators if k in msg_lower)
                            course_count = sum(1 for k in course_indicators if k in msg_lower)

                            # Si predominan indicadores técnicos, forzamos intención técnica.
                            if tech_count > course_count and tech_count > 0:
                                user_intent_type = 'tecnica'
                                intent_confidence = max(intent_confidence, 0.75)
                                logger.info(f"Ambigüedad resuelta automáticamente como 'tecnica' para {phone} (tech={tech_count} vs course={course_count})")
                            # Si predominan indicadores de curso, forzamos intención de cursos.
                            elif course_count > tech_count and course_count > 0:
                                user_intent_type = 'cursos'
                                intent_confidence = max(intent_confidence, 0.75)
                                logger.info(f"Ambigüedad resuelta automáticamente como 'cursos' para {phone} (tech={tech_count} vs course={course_count})")
                            else:
                                # Sin predominio claro: usamos la clasificación original pero con ligera elevación
                                intent_confidence = max(intent_confidence, 0.66)
                                logger.info(f"Ambigüedad no resuelta automáticamente para {phone}, se mantiene '{user_intent_type}' con confianza {intent_confidence:.2f}")
                            # Continuar con el flujo normal sin preguntar al usuario
                    except Exception as _amb_e:
                        logger.debug(f"Error en detección de ambigüedad: {_amb_e}")

                    if user_intent_type == 'cursos' and not avoid_curso_intent and not waiting_for_advisor:
                        # Usuario específicamente interesado en cursos - procesar selección de curso
                        logger.info(f"Procesando intención de cursos para {phone} con confianza {intent_confidence:.2f}")
                    elif user_intent_type == 'asesoria' or is_advisor_request:
                        # Usuario solicita asesoría - saltar a flujo de asesor
                        logger.info(f"Redirigiendo a flujo de asesor para {phone}")
                        # El flujo de asesor se maneja más adelante en el código
                    elif user_intent_type == 'productos':
                        # Usuario pregunta por productos - buscar en base de datos de productos
                        logger.info(f"Procesando consulta de productos para {phone}")
                        # El flujo de productos se maneja en las secciones específicas más adelante
                    elif user_intent_type == 'tecnica':
                        # Usuario hace pregunta técnica - responder técnicamente y sugerir curso si es relevante
                        logger.info(f"Procesando pregunta técnica para {phone}")
                        # El flujo técnico se maneja en la sección específica más adelante
                    
                    # Solo intentar detección de cambio de curso si la intención es explícitamente de cursos
                    # y no hay conflictos con otros flujos
                    if user_intent_type == 'cursos' and not avoid_curso_intent and not waiting_for_advisor:
                        try:
                            text_lower = (message_text or '').lower()
                            # Ya no necesitamos contar palabras clave técnicas, ya se evaluó correctamente arriba
                            # Proceder con detección de cambio de curso si no es técnica y no evita cursos
                            
                            # If we recently listed webinars for this user, avoid interpreting
                            # words that match webinar titles as course-change requests to
                            # prevent conflicts between webinar and course flows.
                            try:
                                last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []
                                skip_course_detect = False
                                if last_listed:
                                    try:
                                        from data.db import get_collection
                                        from bson import ObjectId
                                        webinars_col = get_collection('webinars')
                                        # Load webinar titles to check for matches
                                        for e in last_listed:
                                            wid = e.get('_id')
                                            try:
                                                doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                            except Exception:
                                                doc = webinars_col.find_one({'_id': wid})
                                            if doc:
                                                title = (doc.get('title') or doc.get('name') or '')
                                                if title and title.lower() in text_lower:
                                                    skip_course_detect = True
                                                    break
                                                # also check keywords/description
                                                desc = (doc.get('description') or doc.get('desc') or '')
                                                if desc and any(tok in text_lower for tok in desc.lower().split()[:8]):
                                                    skip_course_detect = True
                                                    break
                                    except Exception:
                                        skip_course_detect = False

                                if not skip_course_detect:
                                    course_changed, new_course_name = detect_and_update_course_selection(phone, message_text)
                                else:
                                    logger.info(f"Skipping course-change detection because message appears to reference a recently listed webinar: {message_text}")
                                    course_changed, new_course_name = False, None
                            except Exception as _e:
                                logger.debug(f"Error in webinar/course conflict guard: {_e}")
                                course_changed, new_course_name = detect_and_update_course_selection(phone, message_text)
                            
                            if course_changed:
                                send_text_message(phone, f"Perfecto, cambiamos al curso '{new_course_name}'. ¿Qué quieres saber sobre este curso?")
                                # We sent a course-change confirmation; stop processing this webhook message
                                # to avoid sending an additional reply in the same request.
                                try:
                                    globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = None
                                except Exception:
                                    pass
                                continue
                        except Exception as _e:
                            logger.debug(f"Error running detect_and_update_course_selection: {_e}")
                    
                    # --- Webinar follow-up handler: 'fechas N', 'costos N', 'inscripcion N', 'temario N', 'asesor N', 'detalle N' ---
                    try:
                        import re
                        from bson import ObjectId
                        from data.db import get_collection

                        # Quick handlers: list webinars or courses when user asks, before follow-up parsing
                        tlower = (message_text or '').lower().strip()
                        # Quick patterns
                        webinar_triggers = ['webinar', 'webinars', 'seminario', 'seminarios', 'opciones en linea', 'opciones en línea', 'opciones en línea', 'opciones online']

                        # Direct info requests like 'dame info del seminario de centro de datos' -> try to resolve directly
                        try:
                            direct_info_match = re.search(r"(?:dame\s+info(?:rmaci[oó]n)?|dame\s+detalle|info\s+del|informaci[oó]n\s+del|info\s+sobre|informaci[oó]n\s+sobre)\s*(?:el|la|los|las)?\s*(?:seminario|webinar|curso)?\s*(.+)", tlower)
                        except Exception:
                            direct_info_match = None

                        if direct_info_match:
                            frag = direct_info_match.group(1).strip()
                            if frag:
                                # normalize fragment and strip accents to improve matching
                                frag = re.sub(r"\?$", "", frag).strip()
                                def norm(s):
                                    if not s:
                                        return ''
                                    s = s.lower()
                                    s = unicodedata.normalize('NFKD', s)
                                    s = ''.join([c for c in s if not unicodedata.combining(c)])
                                    return s

                                frag_norm = norm(frag)
                                matches = []
                                try:
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        cursor = webinars_col.find({}).limit(50)
                                        for d in cursor:
                                            title = (d.get('title') or d.get('name') or '')
                                            desc = (d.get('description') or d.get('desc') or '')
                                            tags = ' '.join([str(x) for x in (d.get('tags') or d.get('keywords') or [])])
                                            hay = ' '.join([title, desc, tags])
                                            hay_norm = norm(hay)
                                            # direct containment or all words present
                                            if frag_norm in hay_norm or all(word in hay_norm for word in frag_norm.split() if len(word) > 2):
                                                d['_id'] = str(d.get('_id'))
                                                matches.append(d)
                                except Exception as _e:
                                    logger.debug(f"Error buscando webinar por solicitud directa: {_e}")

                                if len(matches) == 1:
                                    wd = matches[0]
                                    title = wd.get('title') or wd.get('name') or 'Sin título'
                                    date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                    desc = wd.get('description') or wd.get('details') or ''
                                    reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                    price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                    parts = [f"🔎 Información: {title}"]
                                    parts.append(f"📅 Fecha: {date}")
                                    if price:
                                        parts.append(f"💰 Precio: {price}")
                                    if reg_link:
                                        parts.append(f"📝 Inscripción: {reg_link}")
                                    if desc:
                                        parts.append(f"📄 Descripción: {desc}")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': wd.get('_id'), 'title': title}])
                                    send_text_message(phone, "\n\n".join(parts))
                                    continue
                                elif len(matches) > 1:
                                    reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                    for i, m in enumerate(matches, start=1):
                                        reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                    reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in matches])
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue
                        else:
                            # No direct 'dame info' pattern — try to match webinar titles mentioned in the message
                            try:
                                title_matches = []
                                try:
                                    last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []
                                except Exception:
                                    last_listed = []

                                # Check memory-listed webinars first
                                for e in last_listed:
                                    t = (e.get('title') or '').lower()
                                    if not t:
                                        continue
                                    # Direct containment (full title or short phrase)
                                    if t in tlower:
                                        title_matches.append({'_id': e.get('_id'), 'title': e.get('title')})
                                        continue
                                    # Check for common 2-word phrases from the title (bigram match)
                                    parts = [p for p in t.split() if len(p) > 2]
                                    for i in range(len(parts)-1):
                                        big = f"{parts[i]} {parts[i+1]}"
                                        if big in tlower:
                                            title_matches.append({'_id': e.get('_id'), 'title': e.get('title')})
                                            break

                                # If no memory matches, search DB titles
                                if not title_matches:
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        try:
                                            cursor = webinars_col.find({}).limit(50)
                                            for d in cursor:
                                                title = (d.get('title') or d.get('name') or '').lower()
                                                if not title:
                                                    continue
                                                if title in tlower:
                                                    d['_id'] = str(d.get('_id'))
                                                    title_matches.append(d)
                                                    continue
                                                parts = [p for p in title.split() if len(p) > 2]
                                                for i in range(len(parts)-1):
                                                    big = f"{parts[i]} {parts[i+1]}"
                                                    if big in tlower:
                                                        d['_id'] = str(d.get('_id'))
                                                        title_matches.append(d)
                                                        break
                                        except Exception as _e:
                                            logger.debug(f"Error buscando webinars por títulos en DB: {_e}")

                                if len(title_matches) == 1:
                                    wd = title_matches[0]
                                    try:
                                        webinars_col = get_collection('webinars')
                                        if webinars_col and wd.get('_id'):
                                            try:
                                                doc = webinars_col.find_one({'_id': ObjectId(wd.get('_id'))})
                                            except Exception:
                                                doc = webinars_col.find_one({'_id': wd.get('_id')})
                                            if doc:
                                                wd = doc
                                    except Exception:
                                        pass

                                    title = wd.get('title') or wd.get('name') or 'Sin título'
                                    date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                    desc = wd.get('description') or wd.get('details') or ''
                                    reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                    price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                    parts = [f"🔎 Información: {title}"]
                                    parts.append(f"📅 Fecha: {date}")
                                    if price:
                                        parts.append(f"💰 Precio: {price}")
                                    if reg_link:
                                        parts.append(f"📝 Inscripción: {reg_link}")
                                    if desc:
                                        parts.append(f"📄 Descripción: {desc}")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(wd.get('_id')), 'title': title}])
                                    send_text_message(phone, "\n\n".join(parts))
                                    continue
                                elif len(title_matches) > 1:
                                    reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                    for i, m in enumerate(title_matches, start=1):
                                        reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                    reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                    save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in title_matches])
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue
                            except Exception as _e:
                                logger.debug(f"Error en matching por título: {_e}")
                        course_triggers = ['cursos online', 'cursos en linea', 'cursos en línea', 'opciones en linea', 'opciones en línea', 'cursos online', 'cursos']

                        # If user explicitly asks for webinars or online options, try to resolve a direct target first
                        if any(k in tlower for k in webinar_triggers) and not any(k in tlower for k in ['precio', 'costos', 'temario', 'fechas', 'inscripcion']):
                            try:
                                # Detect if the user included a fragment (e.g. 'seminario de centro de datos') to directly select
                                frag_match = re.search(r"(?:webinar|webinars|seminario|seminarios)\b(?:\s*(?:de|del|sobre|sobre el|sobre la|en))?\s*(.+)$", tlower)
                                fragment = None
                                if frag_match:
                                    fragment = frag_match.group(1).strip()
                                    # Clean trailing question words
                                    fragment = re.sub(r"\?$", "", fragment).strip()

                                webinars_col = get_collection('webinars')

                                # If we have a fragment, attempt to find matching webinar(s) and respond directly
                                if fragment and webinars_col:
                                    matches = []
                                    try:
                                        # Load a reasonable set and filter client-side for fuzzy containment
                                        cursor = webinars_col.find({}).limit(50)
                                        for d in cursor:
                                            title = (d.get('title') or d.get('name') or '')
                                            desc = (d.get('description') or d.get('desc') or '')
                                            tags = ' '.join([str(x) for x in (d.get('tags') or d.get('keywords') or [])])
                                            hay = ' '.join([title, desc, tags]).lower()
                                            if fragment.lower() in hay:
                                                d['_id'] = str(d.get('_id'))
                                                matches.append(d)
                                    except Exception as _e:
                                        logger.debug(f"Error buscando webinars por fragmento: {_e}")

                                    if len(matches) == 1:
                                        # Directly send the detailed info for the matched webinar
                                        wd = matches[0]
                                        title = wd.get('title') or wd.get('name') or 'Sin título'
                                        date = wd.get('date') or wd.get('start_date') or wd.get('fecha') or 'Fecha por definir'
                                        desc = wd.get('description') or wd.get('details') or ''
                                        reg_link = wd.get('registration') or wd.get('registration_link') or wd.get('link') or ''
                                        price = wd.get('price') or wd.get('cost') or wd.get('costo') or 'Consultar'
                                        parts = [f"🔎 Información: {title}"]
                                        parts.append(f"📅 Fecha: {date}")
                                        if price:
                                            parts.append(f"💰 Precio: {price}")
                                        if reg_link:
                                            parts.append(f"📝 Inscripción: {reg_link}")
                                        if desc:
                                            parts.append(f"📄 Descripción: {desc}")
                                        # Save the single match into memory so follow-ups like 'temario' work
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': wd.get('_id'), 'title': title}])
                                        send_text_message(phone, "\n\n".join(parts))
                                        continue
                                    elif len(matches) > 1:
                                        # Multiple possible matches: ask to clarify by listing the matching titles
                                        reply_parts = ["Encontré varios webinars que coinciden con esa búsqueda:"]
                                        for i, m in enumerate(matches, start=1):
                                            reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                        reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                        # Save these matches for follow-up selection
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': str(m.get('_id')), 'title': m.get('title') or m.get('name')} for m in matches])
                                        send_text_message(phone, "\n".join(reply_parts))
                                        continue

                                # Fallback: list webinars (no fragment or no match)
                                cursor = webinars_col.find({}).limit(10) if webinars_col else []
                                webinar_docs = []
                                reply_lines = ["Estos son los webinars disponibles:"]
                                idx = 0
                                for d in cursor:
                                    idx += 1
                                    title = d.get('title') or d.get('name') or f"Webinar {idx}"
                                    date = d.get('date') or d.get('start_date') or d.get('fecha') or 'Fecha por definir'
                                    webinar_docs.append({'_id': str(d.get('_id')), 'title': title, 'date': date})
                                    reply_lines.append(f"{idx}. {title} — {date}")

                                if webinar_docs:
                                    send_text_message(phone, "\n".join(reply_lines) + "\n\nResponde por ejemplo: 'detalle 1' o 'temario 2' para ver más información.")
                                    # Save the listed webinars for follow-up selection
                                    save_conversation_memory(phone, 'last_listed_webinars', webinar_docs)
                                    continue
                            except Exception as _e:
                                logger.debug(f"Error listando webinars: {_e}")

                        # If user asks about online courses/options, list the courses combining DB + fixed catalog
                        if any(k in tlower for k in ['cursos online', 'cursos en linea', 'cursos en línea', 'opciones en linea', 'opciones en línea']) and not any(k in tlower for k in ['precio', 'costos', 'temario', 'fechas']):
                            try:
                                combined_list = []
                                seen_titles = set()
                                idx = 0

                                # First, try to load courses from DB collection 'courses'
                                try:
                                    courses_col = get_collection('courses')
                                    cursor = courses_col.find({}).limit(10)
                                    for d in cursor:
                                        title = (d.get('title') or d.get('name') or '').strip()
                                        if not title:
                                            continue
                                        key = title.lower()
                                        if key in seen_titles:
                                            continue
                                        seen_titles.add(key)
                                        idx += 1
                                        combined_list.append({'index': idx, 'title': title, 'source': 'db', '_id': str(d.get('_id'))})
                                except Exception:
                                    # If collection doesn't exist or query fails, just continue with fixed list
                                    pass

                                # Fixed catalog (fallback / complement)
                                fixed_catalog = [
                                    'Cableado estructurado para redes de fibra y cobre',
                                    'Redes de fibra óptica planta externa',
                                    'Redes de fibra óptica FTTH para WISP e ISP',
                                    'PON/LAN redes pasivas para entornos enterprise',
                                    'Empalmes y mediciones con OTDR'
                                ]

                                for ft in fixed_catalog:
                                    key = ft.lower().strip()
                                    if key in seen_titles:
                                        continue
                                    seen_titles.add(key)
                                    idx += 1
                                    combined_list.append({'index': idx, 'title': ft, 'source': 'fixed', 'fixed_id': f'fixed-{idx}'})

                                if not combined_list:
                                    send_text_message(phone, "Lo siento, ahora mismo no tengo cursos disponibles. Intenta más tarde.")
                                    continue

                                # Build reply lines
                                reply_lines = ["Sí, tenemos cursos en línea. Aquí están las opciones:"]
                                for item in combined_list:
                                    reply_lines.append(f"{item['index']}. {item['title']}")

                                reply_lines.append("\nResponde con el número o escribe 'temario 2' para recibir el temario del curso 2.")
                                send_text_message(phone, "\n".join(reply_lines))

                                # Save last listed courses in conversation memory for selection mapping
                                # Save minimal info needed to later respond (index, title, source, id)
                                save_conversation_memory(phone, 'last_listed_courses', combined_list)
                                continue
                            except Exception as _e:
                                logger.debug(f"Error listando cursos online: {_e}")

                        # Match intent keyword and an optional word-based fragment (title keyword or short phrase)
                        follow_match = re.match(r"^(fechas|fecha|costos|precio|precios|inscripcion|inscripción|temario|asesor|detalle|completo)\s*(.*)$", tlower)
                        if follow_match:
                            intent_kw = follow_match.group(1)
                            fragment = (follow_match.group(2) or '').strip()
                            last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []

                            # If no recent webinar listing exists, attempt to load webinars from DB
                            if not last_listed:
                                try:
                                    # load recent or all webinars as a fallback
                                    webinars_col = get_collection('webinars')
                                    if webinars_col:
                                        cursor = webinars_col.find({}).limit(10)
                                        webinar_docs = []
                                        for d in cursor:
                                            d['_id'] = str(d.get('_id'))
                                            webinar_docs.append(d)
                                        # store the loaded list in memory for follow-up matching
                                        save_conversation_memory(phone, 'last_listed_webinars', [{'_id': w.get('_id')} for w in webinar_docs])
                                except Exception as _e:
                                    logger.debug(f"Fallback load webinars failed: {_e}")
                                # refresh last_listed after fallback
                                last_listed = get_conversation_memory(phone, 'last_listed_webinars') or []

                            # Load all webinar docs referenced in last_listed to match by words
                            webinars_col = get_collection('webinars')
                            webinar_docs = []
                            for e in last_listed:
                                wid = e.get('_id')
                                try:
                                    doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                except Exception:
                                    doc = webinars_col.find_one({'_id': wid})
                                if doc:
                                    # normalize id to string for local matching
                                    doc['_id'] = str(doc.get('_id'))
                                    webinar_docs.append(doc)

                            # If no docs loaded, ask user to retry listing
                            if not webinar_docs:
                                send_text_message(phone, "No pude recuperar los webinars listados anteriormente. Por favor pide 'opciones en línea' para verlos de nuevo.")
                                continue

                            # If the user provided a fragment: support numeric selection (e.g. 'detalle 2') or text fragment
                            selected_doc = None
                            # compute idx mapping if we have last_listed
                            try:
                                webinar_docs = []
                                webinars_col = get_collection('webinars')
                                for e in last_listed:
                                    wid = e.get('_id')
                                    try:
                                        doc = webinars_col.find_one({'_id': ObjectId(wid)})
                                    except Exception:
                                        doc = webinars_col.find_one({'_id': wid})
                                    if doc:
                                        doc['_id'] = str(doc.get('_id'))
                                        webinar_docs.append(doc)
                            except Exception:
                                webinar_docs = []

                            if fragment:
                                # If fragment is a number, select by index
                                if fragment.isdigit():
                                    try:
                                        sel_idx = int(fragment)
                                        if 1 <= sel_idx <= len(webinar_docs):
                                            selected_doc = webinar_docs[sel_idx-1]
                                    except Exception:
                                        selected_doc = None
                                else:
                                    # text fragment search
                                    frag = fragment.lower()
                                    matches = []
                                    for doc in webinar_docs:
                                        title = (doc.get('title') or doc.get('name') or '').lower()
                                        desc = (doc.get('description') or doc.get('desc') or '').lower()
                                        keywords = ' '.join([str(x).lower() for x in (doc.get('tags') or doc.get('keywords') or [])])
                                        if frag in title or frag in desc or frag in keywords:
                                            matches.append(doc)

                                    if len(matches) == 1:
                                        selected_doc = matches[0]
                                    elif len(matches) > 1:
                                        # Ambiguous: list the candidate titles and ask the user to clarify by number
                                        reply_parts = ["Encontré varios webinars que coinciden con tu palabra:"]
                                        for i, m in enumerate(matches, start=1):
                                            reply_parts.append(f"{i}. {m.get('title') or m.get('name')}")
                                        reply_parts.append("Responde por ejemplo: 'detalle 2' para ver el segundo resultado.")
                                        send_text_message(phone, "\n".join(reply_parts))
                                        continue
                                    else:
                                        # No match found — ask to rephrase or show the list again
                                        send_text_message(phone, "No encontré un webinar que coincida con esa palabra. Responde 'webinars' para ver la lista completa o usa otra palabra clave del título.")
                                        continue
                            # If no fragment provided: if only one webinar was listed, pick it; otherwise ask for a number
                            else:
                                if len(webinar_docs) == 1:
                                    selected_doc = webinar_docs[0]
                                else:
                                    # Provide quick guidance showing the titles and ask to reply with a number
                                    reply_parts = ["Para darte la información, responde con el número del webinar que te interesa:"]
                                    for i, d in enumerate(webinar_docs, start=1):
                                        reply_parts.append(f"{i}. {d.get('title') or d.get('name')}")
                                    reply_parts.append("Por ejemplo: 'detalle 2' o 'temario 1'.")
                                    send_text_message(phone, "\n".join(reply_parts))
                                    continue

                            # At this point we have a selected_doc
                            webinar_doc = selected_doc

                            # Compute index of the selected_doc within the last_listed for reference in replies
                            try:
                                idx = None
                                for i, d in enumerate(webinar_docs, start=1):
                                    if str(d.get('_id')) == str(webinar_doc.get('_id')):
                                        idx = i
                                        break
                            except Exception:
                                idx = None

                            # Handle requested info types
                            if intent_kw in ('fechas', 'fecha'):
                                dates = webinar_doc.get('date') or webinar_doc.get('start_date') or webinar_doc.get('fecha') or 'Fecha por definir'
                                send_text_message(phone, f"Fechas del webinar '{webinar_doc.get('title') or webinar_doc.get('name') or ''}': {dates}")
                                continue

                            if intent_kw in ('costos', 'precio', 'precios'):
                                # Per product owner: webinars and online courses are free and held online every Tuesday
                                send_text_message(phone, "Gratis — se imparte en línea todos los martes.")
                                continue

                            if intent_kw in ('inscripcion', 'inscripción'):
                                enroll = webinar_doc.get('enroll_link') or webinar_doc.get('registration') or webinar_doc.get('inscripcion') or webinar_doc.get('signup')
                                if enroll:
                                    send_text_message(phone, f"Inscripción al webinar '{webinar_doc.get('title') or webinar_doc.get('name') or ''}': {enroll}")
                                else:
                                    send_text_message(phone, "Puedes inscribirte en la página del evento o contestarme y te doy el enlace si lo deseas.")
                                continue

                            if intent_kw == 'asesor':
                                advisor = webinar_doc.get('advisor') or webinar_doc.get('asesor')
                                if advisor:
                                    send_text_message(phone, f"Asesor/ponente: {advisor}")
                                else:
                                    send_text_message(phone, "No hay información de asesor registrada para ese webinar.")
                                continue

                            if intent_kw in ('temario', 'completo', 'detalle'):
                                # Use existing temario send logic: temario might be a url, a local file path, or plain text
                                temario = webinar_doc.get('temario') or webinar_doc.get('syllabus') or webinar_doc.get('content')
                                if not temario:
                                    # fallback to sending the full document/description text
                                    desc = webinar_doc.get('description') or webinar_doc.get('details') or 'No hay temario disponible.'
                                    send_text_message(phone, desc)
                                    continue

                                # If temario is a dict that includes path or url
                                if isinstance(temario, dict):
                                    tpath = temario.get('path') or temario.get('file') or temario.get('url')
                                else:
                                    tpath = temario

                                # If it's a URL, download and send as document; if local path, send directly; else send as text/link
                                if isinstance(tpath, str) and (tpath.startswith('http://') or tpath.startswith('https://')):
                                    # download to temp and send
                                    tmpdir = tempfile.gettempdir()
                                    local_tmp = os.path.join(tmpdir, f"temario_{phone}_{int(time.time())}.pdf")
                                    try:
                                        r = requests.get(tpath, stream=True, timeout=10)
                                        if r.status_code == 200:
                                            with open(local_tmp, 'wb') as f:
                                                for chunk in r.iter_content(8192):
                                                    f.write(chunk)
                                            send_document_message(phone, local_tmp, caption=f"Temario: {webinar_doc.get('title') or webinar_doc.get('name')}")
                                        else:
                                            # send the link as fallback
                                            send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                    except Exception as e:
                                        logger.debug(f"Error descargando temario url: {e}")
                                        send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                    finally:
                                        try:
                                            if os.path.exists(local_tmp):
                                                os.remove(local_tmp)
                                        except Exception:
                                            pass
                                    continue

                                # Local path
                                if isinstance(tpath, str) and os.path.exists(tpath):
                                    try:
                                        send_document_message(phone, tpath, caption=f"Temario: {webinar_doc.get('title') or webinar_doc.get('name')}")
                                    except Exception as e:
                                        logger.debug(f"Error enviando temario local: {e}")
                                        send_text_message(phone, "Hubo un error enviando el temario. Intenta de nuevo más tarde.")
                                    continue

                                # Otherwise, send as a text or link
                                send_text_message(phone, str(tpath))
                                continue

                        # ALSO: support course follow-ups when user replies like 'temario 2' or 'detalle 3'
                        course_follow_match = re.match(r"^(fechas|fecha|costos|precio|precios|inscripcion|inscripción|temario|detalle)\s*(.*)$", tlower)
                        if course_follow_match:
                            c_kw = course_follow_match.group(1)
                            c_frag = (course_follow_match.group(2) or '').strip()
                            last_courses = get_conversation_memory(phone, 'last_listed_courses') or []

                            if not last_courses:
                                # No recent list: prompt user to ask for courses list
                                send_text_message(phone, "Responde 'cursos' o 'cursos online' para ver las opciones disponibles.")
                                # fallthrough
                            else:
                                sel = None
                                # if numeric, select by index
                                if c_frag.isdigit():
                                    n = int(c_frag)
                                    for it in last_courses:
                                        if int(it.get('index')) == n:
                                            sel = it
                                            break
                                else:
                                    # try to match by title fragment
                                    frag = c_frag.lower()
                                    for it in last_courses:
                                        if frag in (it.get('title') or '').lower():
                                            sel = it
                                            break

                                if not sel:
                                    # Usar IA para responder en lugar de mensaje hardcodeado
                                    try:
                                        from services.chat_ai import chat_with_gemini
                                        ai_response = chat_with_gemini(
                                            phone=phone,
                                            message=message_text,
                                            system_prompt="El usuario pidió información sobre un curso pero no identifiqué cuál específicamente. Ayúdalo de manera amigable a especificar cuál de los 5 cursos de fibra óptica le interesa."
                                        )
                                        send_text_message(phone, ai_response if ai_response else "¿Podrías especificar cuál curso te interesa? Puedo ayudarte con información específica.")
                                    except Exception:
                                        send_text_message(phone, "¿Podrías especificar cuál curso te interesa? Puedo ayudarte con información específica.")
                                else:
                                    # If source is db, fetch full doc
                                    if sel.get('source') == 'db':
                                        courses_col = get_collection('courses')
                                        try:
                                            doc = courses_col.find_one({'_id': ObjectId(sel.get('_id'))})
                                        except Exception:
                                            doc = courses_col.find_one({'_id': sel.get('_id')})
                                        if doc:
                                            course_doc = doc
                                        else:
                                            course_doc = {'title': sel.get('title')}
                                    else:
                                        # fixed source: try to map to local asset pdf by title keywords
                                        course_doc = {'title': sel.get('title')}

                                        # Handle requested field
                                        if c_kw in ('costos', 'precio', 'precios'):
                                            send_text_message(phone, "Gratis — se imparte en línea todos los martes.")
                                            continue

                                        if c_kw in ('fechas', 'fecha'):
                                            dates = course_doc.get('date') or course_doc.get('start_date') or 'Fechas por definir'
                                            send_text_message(phone, f"Fechas del curso '{course_doc.get('title')}': {dates}")
                                            continue

                                        if c_kw in ('inscripcion', 'inscripción'):
                                            enroll = course_doc.get('enroll_link') or course_doc.get('registration') or course_doc.get('signup')
                                            if enroll:
                                                send_text_message(phone, f"Inscripción: {enroll}")
                                            else:
                                                send_text_message(phone, "Puedo enviarte el enlace de inscripción si lo deseas. Responde 'sí' para que lo busque.")
                                            continue

                                        # temario / detalle
                                        if c_kw in ('temario', 'detalle', 'completo'):
                                            tem = None
                                            if sel.get('source') == 'db' and course_doc.get('temario'):
                                                tem = course_doc.get('temario')
                                            else:
                                                # try known local asset mapping by simple filename convention
                                                # e.g., look for PDFs in ../assets matching keywords from title
                                                title_key = (sel.get('title') or '').lower()
                                                # try to match one of known assets by filename
                                                found = None
                                                assets_dir = os.path.join(os.path.dirname(__file__), '..', 'assets')
                                                try:
                                                    for fname in os.listdir(assets_dir):
                                                        if fname.lower().endswith('.pdf') and all(part in title_key for part in title_key.split()[:3]):
                                                            found = os.path.join(assets_dir, fname)
                                                            break
                                                except Exception:
                                                    found = None
                                                tem = found

                                            if not tem:
                                                # fallback: send description or simple message
                                                desc = course_doc.get('description') or course_doc.get('details') or 'No hay temario disponible.'
                                                send_text_message(phone, desc)
                                                continue

                                            # If tem is dict or url or local path: reuse temario send logic
                                            if isinstance(tem, dict):
                                                tpath = tem.get('path') or tem.get('file') or tem.get('url')
                                            else:
                                                tpath = tem

                                            if isinstance(tpath, str) and (tpath.startswith('http://') or tpath.startswith('https://')):
                                                tmpdir = tempfile.gettempdir()
                                                local_tmp = os.path.join(tmpdir, f"temario_course_{phone}_{int(time.time())}.pdf")
                                                try:
                                                    r = requests.get(tpath, stream=True, timeout=10)
                                                    if r.status_code == 200:
                                                        with open(local_tmp, 'wb') as f:
                                                            for chunk in r.iter_content(8192):
                                                                f.write(chunk)
                                                        send_document_message(phone, local_tmp, caption=f"Temario: {course_doc.get('title')}")
                                                    else:
                                                        send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                                except Exception as e:
                                                    logger.debug(f"Error descargando temario curso url: {e}")
                                                    send_text_message(phone, f"Puedes ver el temario aquí: {tpath}")
                                                finally:
                                                    try:
                                                        if os.path.exists(local_tmp):
                                                            os.remove(local_tmp)
                                                    except Exception:
                                                        pass
                                                continue

                                            if isinstance(tpath, str) and os.path.exists(tpath):
                                                try:
                                                    send_document_message(phone, tpath, caption=f"Temario: {course_doc.get('title')}")
                                                except Exception as e:
                                                    logger.debug(f"Error enviando temario local curso: {e}")
                                                    send_text_message(phone, "Hubo un error enviando el temario. Intenta de nuevo más tarde.")
                                                continue

                                            send_text_message(phone, str(tpath))
                                            continue

                            # Build partial/full responses
                            title = webinar_doc.get('title') or webinar_doc.get('name') or 'Sin título'
                            desc = webinar_doc.get('description') or webinar_doc.get('desc') or ''
                            date = webinar_doc.get('date') or webinar_doc.get('start_date') or webinar_doc.get('fecha') or 'Fecha por definir'
                            price = webinar_doc.get('price') or webinar_doc.get('cost') or webinar_doc.get('costo') or 'Consultar'
                            reg_link = webinar_doc.get('registration_link') or webinar_doc.get('link') or ''
                            temario = webinar_doc.get('temario') or webinar_doc.get('pdf') or webinar_doc.get('materials')
                            # Normalize modality: if the webinar is online, present fixed phrasing
                            raw_mod = (webinar_doc.get('modalidad') or webinar_doc.get('modality') or webinar_doc.get('format') or '').lower()
                            if 'online' in raw_mod or 'línea' in raw_mod or 'en linea' in raw_mod or 'en línea' in raw_mod or raw_mod == '':
                                modality_display = 'en línea (cada martes)'
                            else:
                                modality_display = webinar_doc.get('modalidad') or webinar_doc.get('modality') or 'Presencial'

                            if intent_kw in ['fechas', 'fecha']:
                                resp = f"📅 Fechas del webinar '{title}':\n{date}\n\nSi quieres más, responde 'detalle {idx}' para ver la información completa."
                                send_text_message(phone, resp)
                                continue

                            if intent_kw in ['costos', 'precio', 'precios']:
                                # If price is not provided, offer advisor contact
                                if not price or str(price).lower() in ['consultar', 'n/a', '']:
                                    send_text_message(phone, f"No se encontró precio para '{title}'. ¿Quieres que un asesor te contacte para una cotización? Responde 'sí' o 'no'.")
                                    # Save pending advisor confirmation for this webinar
                                    save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', {'webinar_id': webinar_doc.get('_id'), 'title': title})
                                else:
                                    resp = f"💰 Precio del webinar '{title}':\n{price}\n\nPara detalles completos responde 'detalle {idx}'."
                                    send_text_message(phone, resp)
                                continue

                            if intent_kw in ['inscripcion', 'inscripción']:
                                if reg_link:
                                    resp = f"📝 Inscripción para '{title}':\nRegístrate aquí: {reg_link}\n\nSi necesitas ayuda para inscribirte, responde 'asesor {idx}'."
                                else:
                                    resp = f"📝 Inscripción para '{title}':\nNo hay enlace directo en el registro. Responde 'detalle {idx}' para más información o pide que un asesor te contacte escribiendo 'asesor {idx}'."
                                send_text_message(phone, resp)
                                continue

                            if intent_kw in ['temario']:
                                import os
                                import tempfile
                                import requests

                                if temario:
                                    # temario can be: a local path, an http(s) url, a plain text, or a dict with url/path
                                    # Normalize if dict
                                    if isinstance(temario, dict):
                                        temario_url = temario.get('url') or temario.get('path') or temario.get('pdf')
                                    else:
                                        temario_url = temario

                                    # If it's a string and ends with .pdf, try to send as document
                                    if isinstance(temario_url, str) and temario_url.lower().endswith('.pdf'):
                                        # Local file path
                                        try:
                                            if os.path.exists(temario_url):
                                                send_document_message(phone, temario_url, caption=f"Temario: {title}")
                                                send_text_message(phone, f"Te envié el temario de '{title}'. ¿Deseas también fechas, precio o inscripción?")
                                                continue
                                        except Exception:
                                            # proceed to try as URL
                                            pass

                                        # If it's a URL (http/https), try to download to a temp file and send
                                        try:
                                            if isinstance(temario_url, str) and temario_url.lower().startswith(('http://', 'https://')):
                                                r = requests.get(temario_url, timeout=15)
                                                if r.status_code == 200 and r.content:
                                                    tf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
                                                    tf.write(r.content)
                                                    tf.flush()
                                                    tf.close()
                                                    send_document_message(phone, tf.name, caption=f"Temario: {title}")
                                                    send_text_message(phone, f"Te envié el temario de '{title}'. ¿Deseas también fechas, precio o inscripción?")
                                                    try:
                                                        os.unlink(tf.name)
                                                    except Exception:
                                                        pass
                                                    continue
                                                # if download failed, fallthrough to send link/text
                                        except Exception as _dl_e:
                                            logger.debug(f"No se pudo descargar temario desde URL: {_dl_e}")

                                    # If not a PDF or we couldn't send as document, send as text/link
                                    # If it's a URL, include it; otherwise send the temario text
                                    if isinstance(temario, str) and temario.lower().startswith(('http://','https://')):
                                        send_text_message(phone, f"Puedes ver/descargar el temario de '{title}' aquí: {temario}\n\n¿Deseas también fechas, precio o inscripción?")
                                    else:
                                        send_text_message(phone, f"Temario de '{title}':\n{temario}\n\nResponde 'detalle' para la información completa.")
                                else:
                                    send_text_message(phone, f"No hay temario disponible para '{title}'. Puedes pedir 'detalle' o solicitar un asesor con 'asesor'.")
                                continue

                            if intent_kw in ['asesor']:
                                # Save advisor request and include webinar id
                                save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                save_conversation_memory(phone, 'advisor_course_id', wid)
                                send_text_message(phone, f"Perfecto, un asesor puede contactarte para el webinar '{title}'. Por favor envía: Nombre completo, correo y breve descripción de tu solicitud.")
                                continue

                            if intent_kw in ['detalle', 'completo', 'completo']:
                                parts = [f"🔎 Detalle completo: {title}"]
                                if date:
                                    parts.append(f"📅 Fechas: {date}")
                                if price:
                                    parts.append(f"💰 Precio: {price}")
                                if reg_link:
                                    parts.append(f"📝 Inscripción: {reg_link}")
                                if desc:
                                    parts.append(f"📄 Descripción: {desc}")
                                if temario:
                                    parts.append("📚 Temario disponible. Pide 'temario {idx}' para recibirlo.")
                                parts.append("\nSi quieres que te contacte un asesor escribe 'asesor {idx}'.")
                                send_text_message(phone, "\n\n".join(parts))
                                continue
                    except Exception as follow_e:
                        logger.debug(f"Error handling webinar follow-up: {follow_e}")

                    # If user was asked whether they want an advisor for a webinar, handle simple yes/no replies first
                    try:
                        pending_adv = get_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar')
                        if pending_adv and isinstance(pending_adv, dict):
                            # Normalize simple affirmative/negative
                            txt = (message_text or '').strip().lower()
                            if txt in ['si', 'sí', 's', 'yes']:
                                # User accepts advisor contact — ask for contact details
                                wid = pending_adv.get('webinar_id')
                                title = pending_adv.get('title')
                                send_text_message(phone, f"Perfecto, un asesor puede contactarte para '{title}'. Por favor envía: Nombre completo, correo y breve descripción de tu solicitud.")
                                save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                save_conversation_memory(phone, 'advisor_course_id', wid)
                                # clear the pending confirmation
                                save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', None)
                                continue
                            elif txt in ['no', 'n', 'nope']:
                                send_text_message(phone, "Entendido, no contactaré a un asesor por ahora. Si cambias de opinión, escribe 'asesor' o 'asesor {id}'.")
                                save_conversation_memory(phone, 'awaiting_advisor_confirmation_for_webinar', None)
                                continue
                    except Exception as _e:
                        logger.debug(f"Error handling webinar advisor yes/no: {_e}")

                    # Prioritize deterministic course selection from explicit natural messages
                    try:
                        selected, sel_name = detect_and_update_course_selection(phone, message_text)
                        if selected:
                            logger.info(f"Course selection handled deterministically: {sel_name}")
                            # We already responded inside detect_and_update_course_selection
                            continue
                    except Exception as det_err:
                        logger.debug(f"deterministic course selection check failed: {det_err}")

                    # Procesar el mensaje con nuestro adaptador ML que maneja PDFs y notificaciones
                    try:
                        ml_adapter_result = process_message(
                            phone=phone, 
                            message_text=message_text, 
                            conversation_history=conversation_history,
                            whatsapp_profile=whatsapp_profile,
                            skip_course_processing=is_technical_question
                        )
                        logger.info(f"Procesamiento ML completado para {phone}")
                    except Exception as ml_error:
                        logger.error(f"Error en procesamiento ML: {ml_error}", exc_info=True)
                        # Crear un resultado predeterminado para continuar
                        ml_adapter_result = {
                            'pdf_sent': False,
                            'notification_sent': False,
                            'system_prompt': None
                        }
                        logger.warning("Usando resultado ML predeterminado debido a error")
                    
                    # Si se envió un PDF, posiblemente continuemos con respuesta adicional
                    pdf_sent = ml_adapter_result.get('pdf_sent', False)
                    if pdf_sent:
                        logger.info(f"PDF encontrado para envío: {ml_adapter_result.get('pdf_path')}")
                        course_name = ml_adapter_result.get('course_name', 'del curso')
                        course_id = ml_adapter_result.get('course_id', 0)
                        pdf_path = ml_adapter_result.get('pdf_path')
                        # Intentar enviar el documento inmediatamente
                        try:
                            send_result = send_document_message(phone, pdf_path, caption=f"Temario {course_name}")
                            if send_result:
                                logger.info(f"Documento enviado correctamente a {phone}: {pdf_path}")
                            else:
                                logger.warning(f"Fallo al enviar documento a {phone}. Se enviará confirmación sin archivo.")
                        except Exception as e:
                            logger.error(f"Error al enviar documento a {phone}: {e}", exc_info=True)
                        
                        # Guardar información del curso seleccionado en la memoria de conversación
                        if course_id and course_name:
                            # Obtener detalles adicionales del curso si están disponibles
                            course_details = {
                                "pdf_path": ml_adapter_result.get('pdf_path', ''),
                                "sent_at": datetime.now().isoformat()
                            }
                            
                            # Guardar el curso seleccionado en la memoria persistente
                            save_selected_course(phone, course_id, course_name, course_details)
                            logger.info(f"Curso seleccionado guardado para {phone}: {course_id} - {course_name}")
                            
                        send_text_message(phone, f"Te envié el temario en PDF {course_name}. ¿Deseas que también te comparta fechas, precio y ubicación del curso?")
                        # Continuar al siguiente mensaje, ya respondimos a este
                        continue

                    # --- Manejo específico de cotizaciones / inscripción / opciones online / ubicación ---
                    # MEJORA: Detectar intención de cotización / precio / factura con prioridad sobre clasificación técnica
                    # Ensure text_lower is defined (some earlier branches may skip its assignment)
                    text_lower = (message_text or '').lower()
                    cotizacion_keywords = ['cotizacion', 'cotizaci', 'precio', 'precio del curso', 'factura', 'facturación', 'facturacion']
                    # Detectar solicitudes de cotización que incluyan contexto de proyecto/ubicación
                    cotizacion_con_proyecto = any(k in (message_text or '').lower() for k in cotizacion_keywords) and any(p in (message_text or '').lower() for p in ['instalacion', 'proyecto', 'zona', 'rural', 'urbana', 'empresa', 'edificio'])
                    inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 'proceso de inscripcion', 'cómo me inscribo', 'como me inscribo']
                    online_keywords = ['online', 'en linea', 'en línea', 'webinar', 'webinars', 'seminario', 'seminarios']

                    # Priorizar manejo de cotizaciones: si detectamos intención de cotización, pedir datos o notificar a asesor
                    text_lower_local = (message_text or '').lower()
                    if any(k in text_lower_local for k in cotizacion_keywords) or cotizacion_con_proyecto:
                        # Si ML ya extrajo datos completos, enviar notificación al asesor
                        client_data = ml_adapter_result.get('ml_results', {}).get('client_data', {})
                        has_contact = bool(client_data.get('nombre') and client_data.get('correo'))

                        # Mensaje para solicitar datos (usando el formato definido en AdvisorRequestManager)
                        request_client_info = advisor_request_prompt()

                        # MEJORA: Si es cotización con proyecto, priorizar asesor sobre respuesta técnica
                        if is_technical_question and not cotizacion_con_proyecto:
                            # Solo para preguntas puramente técnicas sin contexto de cotización
                            send_text_message(phone, "Te respondí la parte técnica. Si quieres que un asesor te contacte, por favor escribe 'asesor' o confirma y te lo gestiono.")
                            # continue to next webhook
                            continue

                        # Si ya tenemos datos suficientes, procesar la notificación
                        if has_contact:
                            try:
                                from services.notification_service import notification_service
                                notify_result = notification_service.process_client_notification(phone, ml_adapter_result.get('ml_results', {}), conversation_history)
                                if notify_result.get('notification_sent'):
                                    send_text_message(phone, "Gracias — ya envié tu solicitud a un asesor. Te contactarán pronto para dar seguimiento.")
                                else:
                                    send_text_message(phone, "Recibí tu solicitud. Por favor comparte tus datos para que podamos derivarla a un asesor: \n" + request_client_info)
                            except Exception as e:
                                logger.error(f"Error enviando notificación al asesor: {e}")
                                send_text_message(phone, "Estamos teniendo problemas para notificar a un asesor ahora. Por favor compárteme tus datos:\n" + request_client_info)
                            # After sending per-field confirmations earlier, also send a short combined confirmation
                            # so external tests and integrations that expect a final acknowledgement still receive it.
                            try:
                                combined_msg = "Gracias — recibí tus datos. Un asesor revisará tu solicitud y te contactará pronto."
                                send_text_message(phone, combined_msg)
                            except Exception:
                                logger.debug('No se pudo enviar mensaje combinado de confirmación (no crítico)')
                        else:
                            # Pedir los datos al usuario. Incluso si ya preguntamos antes, enviar una confirmación
                            already_asked = get_conversation_memory(phone, "advisor_prompt_sent")
                            if not already_asked:
                                send_text_message(phone, request_client_info)
                                save_conversation_memory(phone, "advisor_prompt_sent", True)
                            else:
                                # Ya habíamos pedido datos anteriormente; enviar una confirmación y recordatorio
                                send_text_message(phone, "Recibí tu solicitud de cotización. Por favor comparte: nombre completo, correo y una breve descripción de tu proyecto si no lo has hecho aún. Si ya compartiste tus datos, responderemos pronto.")
                        # Continuar con siguiente webhook
                        continue

                    # Manejo inteligente de preguntas técnicas basado en la clasificación
                    try:
                        if user_intent_type == 'tecnica' and intent_confidence > 0.5:
                            logger.info(f"Procesando pregunta técnica con confianza {intent_confidence:.2f}")
                            
                            # System prompt mejorado para preguntas técnicas
                            technical_prompt = """
ERES UN CONSULTOR TÉCNICO EXPERTO EN FIBRA ÓPTICA, REDES Y TELECOMUNICACIONES.

PERFIL PROFESIONAL:
- Ingeniero especializado en fibra óptica con 15+ años de experiencia
- Consultor técnico para proyectos de telecomunicaciones
- Experto en FTTH, redes PON, cableado estructurado y mediciones ópticas
- Capacidad para resolver problemas complejos y dar recomendaciones específicas
-RESPONDE A TODAS LAS PREGUNTAS TECNICAS NO LAS RELACIONES CON CURSOS SI ES LARGA RESPONDE DE MANERA TECNICA SI ES CORTA O CONTIENE EL NOMBRE DEL CURSO RESPONDE AL CURSO
-SI PREGUNTAN SI SE IMPARTEN EN OTRO PAIS ESTADO, ETC DILES QUE SOLAMENTE EN QUERETARO
- PROPORCIONA LAS FECHAS Y COSTOS DE LOS CURSOS
-SI PREGUNTAN POR OPCIONES EN LINEA MODALIDAD ONLINE SEMINARIOS ONLINE DECIRLES QUE SI CUENTAS CON ELLOS Y DARLE LA LISTA DE LOS WEBINARS :
"¡Perfecto! 💻 **SÍ tenemos opciones EN LÍNEA**\n\n"
                            "🎓 **WEBINARS GRATUITOS** que se imparten cada **martes**:\n\n"
                            "📚 **Temas disponibles:**\n"
                            "• **Soluciones preconectorizadas**\n"
                            "• **Empalmes de fibra óptica y OTDR**\n"
                            "• **Instalación subterránea**\n"
                            "• **De WISP a Fibra**\n"
                            "• **ODN en FTTX**\n"
                            "• **Centro de datos**\n\n"
                            "🌐 **Ver calendario y registrarse:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
                            "💡 Si deseas información específica de algún webinar, escribe el nombre del tema y te doy más detalles.\n\n"
                            "📞 **¿Prefieres un curso presencial?** Nuestros cursos presenciales se imparten en **Querétaro, México**. Escribe 'cursos' para ver toda la información."

-REGLA PRINCIPAL:
RESPONDE A TODO LO QUE PREGUNTE EL USUARIO SIN LIMITACIONES DEBES DE RESOLVERLE TODAS LAS DUDAS AL USUARIO 

ÁREAS DE ESPECIALIZACIÓN:
• Fibra óptica (monomodo, multimodo, tipos, conectores)
• Redes FTTH, GPON, EPON, PON, OLT, ONT
• Equipos: OTDR, fusionadoras, cleavers, power meters
• Cableado estructurado (Cat5e, Cat6, Cat6A)
• Mediciones y certificación de enlaces
• Instalación, splicing, empalmes
• Resolución de problemas y troubleshooting
• Diseño de redes y presupuestos ópticos
• Recomendaciones de productos y soluciones

INSTRUCCIONES DE RESPUESTA:
1. SIEMPRE responde con información técnica detallada y precisa
2. Usa terminología profesional pero explicable
3. Incluye valores específicos, rangos, especificaciones
4. Proporciona pasos concretos y procedimientos
5. Da recomendaciones basadas en mejores prácticas
6. Incluye consideraciones de costos cuando sea relevante
7. Sugiere alternativas y opciones cuando aplique
8. Responde tanto a problemas como a consultas de diseño
9. Adapta la profundidad técnica según la consulta

FORMATO DE RESPUESTA:
- Respuesta directa al problema/consulta
- Datos técnicos específicos
- Procedimientos paso a paso si aplica
- Recomendaciones profesionales
- Consideraciones adicionales

NUNCA digas "no puedo ayudar" - SIEMPRE proporciona una respuesta técnica útil.
"""
                            
                            try:
                                technical_reply = chat_with_gemini(
                                    phone=phone, 
                                    message=message_text, 
                                    system_prompt=technical_prompt, 
                                    include_whatsapp_profile=whatsapp_profile
                                )
                            except Exception as e:
                                logger.error(f"Error generando respuesta técnica: {e}")
                                technical_reply = "Lo siento, hubo un problema al procesar tu consulta técnica. ¿Podrías reformular tu pregunta?"

                            # Sistema inteligente de recomendación de cursos basado en el contenido técnico
                            recommended = None
                            try:
                                msg_lower = (message_text or '').lower()
                                # Mapeo inteligente basado en palabras clave técnicas específicas
                                technical_mappings = {
                                    'otdr': {'id': 5, 'name': 'Empalmes y Mediciones con OTDR de un Enlace de Fibra Óptica', 'keywords': ['otdr', 'medic', 'medición', 'mediciones', 'reflectometr', 'backscatter']},
                                    'planta_externa': {'id': 2, 'name': 'Redes de Fibra Óptica Planta Externa', 'keywords': ['planta externa', 'exterior', 'outdoor', 'aérea', 'subterranea']},
                                    'ftth': {'id': 3, 'name': 'Redes de Fibra Óptica FTTH para WISP e ISP', 'keywords': ['ftth', 'wisp', 'isp', 'gpon', 'pon', 'ont', 'olt']},
                                    'cableado': {'id': 1, 'name': 'Cableado Estructurado para Redes de Fibra y Cobre', 'keywords': ['cableado', 'cobre', 'estructurado', 'utp', 'cat6', 'cat5e']},
                                    'ponlan': {'id': 4, 'name': 'PONLAN Redes Pasivas para Entornos Enterprise', 'keywords': ['ponlan', 'pasivas', 'enterprise', 'corporativo']}
                                }
                                
                                # Buscar la mejor coincidencia
                                best_match = None
                                max_matches = 0
                                
                                for category, config in technical_mappings.items():
                                    matches = sum(1 for keyword in config['keywords'] if keyword in msg_lower)
                                    if matches > max_matches:
                                        max_matches = matches
                                        best_match = config
                                
                                if best_match and max_matches > 0:
                                    recommended = best_match
                                    logger.info(f"Curso recomendado para pregunta técnica: {recommended['name']}")
                            except Exception as e:
                                logger.debug(f"Error en mapeo de recomendaciones: {e}")
                                recommended = None

                            # Construir respuesta inteligente basada en la confianza y contexto
                            try:
                                out_message = None
                                if technical_reply and technical_reply.strip():
                                    out_message = technical_reply.strip()
                                else:
                                    # Respuesta de fallback más técnica
                                    out_message = """He analizado tu consulta técnica. Para brindarte una respuesta más precisa, podrías especificar:

🔧 **Detalles del proyecto:**
- Aplicación específica (FTTH, backbone, LAN, etc.)
- Distancias involucradas
- Equipos existentes
- Presupuesto aproximado

📋 **Información técnica:**
- Tipo de fibra actual (si existe)
- Conectores utilizados
- Pérdidas máximas aceptables

¿Puedes compartir más detalles sobre tu consulta?"""

                                # Solo sugerir curso si hay una recomendación muy relevante
                                if recommended and not avoid_curso_intent and intent_confidence > 0.7:
                                    suggestion_text = (
                                        f"\n\n💡 **CURSO RELACIONADO:** '{recommended['name']}' cubre este tema en profundidad. "
                                        "¿Te interesa conocer más? Responde 'curso' para información completa."
                                    )
                                    out_message += suggestion_text
                                    # Guardar recomendación pendiente
                                    try:
                                        save_conversation_memory(phone, 'pending_course_recommendation', recommended)
                                        save_conversation_memory(phone, 'waiting_for_course_confirmation', True)
                                        logger.info(f"Recomendación de curso guardada para {phone}: {recommended['name']}")
                                    except Exception as e:
                                        logger.debug(f'Error guardando recomendación: {e}')

                                # SIEMPRE enviar respuesta para consultas técnicas
                                send_text_message(phone, out_message)
                                logger.info(f'Respuesta técnica enviada con confianza {intent_confidence:.2f}')
                                
                                # Marcar que se envió respuesta técnica
                                save_conversation_memory(phone, 'last_response_type', 'technical')
                                
                            except Exception as e:
                                logger.error(f"Error enviando respuesta técnica: {e}")
                                # Respuesta de fallback técnica garantizada
                                fallback_msg = """🔧 **CONSULTA TÉCNICA RECIBIDA**

Como consultor técnico, puedo ayudarte con:
• Especificaciones de fibra óptica
• Recomendaciones de productos
• Diseño de enlaces
• Resolución de problemas
• Cálculos de presupuesto óptico

Por favor, comparte más detalles sobre tu consulta específica."""
                                send_text_message(phone, fallback_msg)

                            # Después de responder, continuar al siguiente mensaje
                            continue
                    except Exception as e:
                        logger.error(f"Error en flujo de recomendación tras respuesta técnica: {e}", exc_info=True)
                    
                    # Si se envió una notificación, registrar
                    if ml_adapter_result.get('notification_sent', False):
                        logger.info(f"Notificación enviada a asesor para {phone}: {ml_adapter_result.get('notification_details', {})}")

                    # --- Manejo específico de cotizaciones / inscripción / opciones online / ubicación ---
                    # MEJORA: Detectar intención de cotización / precio / factura con prioridad sobre clasificación técnica
                    cotizacion_keywords = ['cotizacion', 'cotizaci', 'precio', 'precio del curso', 'factura', 'facturación', 'facturacion']
                    # Detectar solicitudes de cotización que incluyan contexto de proyecto/ubicación
                    cotizacion_con_proyecto = any(k in text_lower for k in cotizacion_keywords) and any(p in text_lower for p in ['instalacion', 'proyecto', 'zona', 'rural', 'urbana', 'empresa', 'edificio'])
                    inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 'proceso de inscripcion', 'cómo me inscribo', 'como me inscribo']
                    online_keywords = ['online', 'en linea', 'en línea', 'webinar', 'webinars', 'seminario', 'seminarios']
                    bobinas = ['bobina', 'bobinas', 'carrete', 'carretes', 'bobina de cable utp', 'utp', 'bobina utp', 'Cat. 6A', 'Cat. 6', 'Cat. 5e']
                    ducto = ['ducto', 'ductos', 'tubo', 'tubos', 'conduit', 'conduits', 'Ducto de fibra óptica con alta durabilidad', 'ducto de fibra optica']
                    tritubo = [ 'tritubo', 'tri-tubo', 'tri tubo', 'tritubos', 'tri-tubos', 'tri tubos', 'tritubo de fibra óptica', 'tritubo de fibra optica']
                    jumper = ['MPO', 'MTP', 'MTP Pro', 'MPO Pro', 'jumper', 'jumpers', 'Multi-fiber Push On', 'Mechanical Transfer Push On']
                    where_keywords = ['dónde', 'donde', 'ubicación', 'ubicacion', 'lugar', 'sede']
                    
                    # Mensajes publicitarios específicos de cursos (detección directa)
                    course_ads = {
                        'cableado_estructurado': ['curso de cableado estructurado', 'información del curso de cableado estructurado', 'más información del curso de cableado estructurado', 'cableado estructurado y fibra'],
                        'fibra_planta_externa': ['curso de fibra óptica planta externa', 'información del curso de fibra óptica planta externa', 'más información del curso de fibra óptica planta externa'],
                        'ftth_wisp_isp': ['curso redes de fibra óptica ftth para wisp e isp', 'información del curso redes de fibra óptica ftth', 'quiero información del curso redes de fibra óptica ftth'],
                        'redes_pasivas_enterprise': ['curso de redes ópticas pasivas para enterprise', 'información del curso de redes ópticas pasivas', 'curso ponlan', 'redes pasivas para entornos enterprise'],
                        'empalmes_otdr': ['curso de empalmes y mediciones con otdr', 'información del curso de empalmes', 'más información del curso de empalmes y mediciones', 'empalmes y mediciones con otdr']
                    }
                    
                    #webinars
                    soluciones_preconectorizadas = ['soluciones preconectorizadas', 'solucion preconectorizada', 'soluciones pre-conectorizadas', 'solucion pre-conectorizada', 'preconectorizado', 'pre-conectorizado']
                    empalmes_fibra_optica = ['empalmes de fibra optica', 'EMPALMES DE FIBRA OPTICA', 'empalme de fibra optica', 'empalmes de fibra óptica', 'empalme de fibra óptica', 'empalmes fibra optica', 'empalme fibra optica', 'empalmes fibra óptica', 'empalme fibra óptica']
                    instalacion_subterranea = ['instalacion subterranea', 'instalación subterranea', 'instalacion subterránea', 'instalación subterránea', 'instalacion subterránea', 'instalación subterranea']
                    wisp_a_fibra = ['wisp a fibra', 'wisp a fibra óptica', 'wisp a fibra optica', 'wisp a fibra óptica', 'wisp a fibra optica']
                    odn_en_fttx = ['odn en fttx', 'odn en fttx', 'odn en fttx', 'odn en fttx']
                    redes_de_distribucion_optica = ['redes de distribución óptica', 'redes de distribución optica', 'red de distribución óptica', 'red de distribución optica', 'redes de distribucion optica', 'red de distribucion optica']
                    centro_de_datos = ['centro de datos', 'CENTRO DE DATOS', 'centro de datos', 'centro de datos', 'centro de datos']
                    
                    # AdvisorRequestManager removed; using local stub defined above
                    
                    text_lower = (message_text or '').lower()

                    # MEJORA: Manejo de cotizaciones con prioridad sobre clasificación técnica
                    if any(k in text_lower for k in cotizacion_keywords) or cotizacion_con_proyecto:
                        # Si ML ya extrajo datos completos, enviar notificación al asesor
                        client_data = ml_adapter_result.get('ml_results', {}).get('client_data', {})
                        has_contact = bool(client_data.get('nombre') and client_data.get('correo'))

                        # Mensaje para solicitar datos (usando el formato definido en AdvisorRequestManager)
                        request_client_info = advisor_request_prompt()

                        # MEJORA: Si es cotización con proyecto, priorizar asesor sobre respuesta técnica
                        if is_technical_question and not cotizacion_con_proyecto:
                            # Solo para preguntas puramente técnicas sin contexto de cotización
                            send_text_message(phone, "Te respondí la parte técnica. Si quieres que un asesor te contacte, por favor escribe 'asesor' o confirma y te lo gestiono.")
                            continue

                        # Si ya tenemos datos suficientes, procesar la notificación
                        if has_contact:
                            try:
                                from services.notification_service import notification_service
                                notify_result = notification_service.process_client_notification(phone, ml_adapter_result.get('ml_results', {}), conversation_history)
                                if notify_result.get('notification_sent'):
                                    send_text_message(phone, "Gracias — ya envié tu solicitud a un asesor. Te contactarán pronto para dar seguimiento.")
                                else:
                                    send_text_message(phone, "Recibí tu solicitud. Por favor comparte tus datos para que podamos derivarla a un asesor: \n" + request_client_info)
                            except Exception as e:
                                logger.error(f"Error enviando notificación al asesor: {e}")
                                send_text_message(phone, "Estamos teniendo problemas para notificar a un asesor ahora. Por favor compárteme tus datos:\n" + request_client_info)
                        else:
                            # Pedir los datos al usuario (solo si no lo hemos pedido ya)
                            if not get_conversation_memory(phone, "advisor_prompt_sent"):
                                send_text_message(phone, request_client_info)
                                save_conversation_memory(phone, "advisor_prompt_sent", True)
                        # Continuar con siguiente webhook
                        continue

                    # Manejo de solicitud de asesor: detección conversacional más natural
                    advisor_keywords = [
                        'asesor', 'contactar', 'hablar con', 'quiero hablar', 'contacto', 
                        'representante', 'vendedor', 'consultor', 'más información',
                        'cotización personalizada', 'ayuda personal', 'atención personalizada'
                    ]
                    
                    is_advisor_request = any(keyword in message_text.lower() for keyword in advisor_keywords) or AdvisorRequestManager.is_advisor_request(message_text)
                    
                    if is_advisor_request:
                        # MEJORA: Inicio inmediato de un flujo guiado por pasos para solicitar datos al usuario
                        total_fields = 7
                        expected_fields = ['name', 'company', 'rfc', 'email', 'phone', 'website', 'project_description']

                        # Friendly intro plus immediate first step
                        intro = (
                            "¡Perfecto! Me alegra ayudarte a conectarte con un asesor. \n"
                            "Te guiaré paso a paso para recopilar la información necesaria.\n"
                            f"Serán {total_fields} pasos sencillos. Empezamos:\n"
                        )

                        # initialize form state and start at the first required field
                        form_state = {'collected': {}, 'next_field': expected_fields[0], 'mode': 'collecting'}
                        save_conversation_memory(phone, 'advisor_form_state', form_state)

                        # Save conversation flags
                        save_conversation_memory(phone, 'advisor_prompt_sent', True)
                        save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                        save_conversation_memory(phone, 'advisor_intentos', 0)

                        # Save course context if any
                        course_id = None
                        selected_course_data = get_selected_course(phone)
                        if selected_course_data:
                            course_id = selected_course_data.get('id')
                        save_conversation_memory(phone, 'advisor_course_id', course_id)

                        # Send intro and the first guided question with an example
                        first_prompt = "¿Cuál es tu nombre completo?" + "\nEjemplo: Juan Pérez"
                        send_text_message(phone, intro + f"Paso 1/{total_fields} — " + first_prompt)
                        logger.info(f"Iniciado flujo guiado de asesoría para {phone}")
                        continue
                        
                    # Verificar si estamos esperando datos para el asesor
                    waiting_for_advisor = get_conversation_memory(phone, "waiting_for_advisor_data")
                    
                    if waiting_for_advisor:
                        # Recuperar el ID del curso si existe
                        advisor_course_id = get_conversation_memory(phone, "advisor_course_id")
                        
                        # Procesar la información proporcionada por el cliente
                        try:
                            try:
                                from utils.courses_adapter import process_advisor_submission
                            except Exception:
                                def process_advisor_submission(phone, text, advisor_course_id=None):
                                    return {"message_for_user": "Gracias. Un asesor te contactará si proporcionas tus datos.", "datos_completos": False}
                            # Field-by-field collection flow
                            # Fields we want to collect in order
                            expected_fields = ['name', 'company', 'rfc', 'email', 'phone', 'website', 'project_description']

                            # initialize advisor form state if not present
                            form_state = get_conversation_memory(phone, 'advisor_form_state') or {'collected': {}, 'next_field': None, 'mode': 'collecting'}

                            # If next_field is None, find first missing field
                            if not form_state.get('next_field'):
                                for f in expected_fields:
                                    if not form_state['collected'].get(f):
                                        form_state['next_field'] = f
                                        break

                            # If we're in a confirmation/editing mode, handle those commands first
                            mode = form_state.get('mode', 'collecting')
                            # --- Per-field confirmation state: user must confirm or request modification for last saved field ---
                            if mode == 'field_confirm':
                                lt = (message_text or '').strip().lower()
                                last = form_state.get('last_saved_field')
                                if not last:
                                    # fallback to collecting
                                    form_state['mode'] = 'collecting'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                else:
                                    # If user confirms the field, move to next missing field
                                    if re.search(r"\b(s[ií])\b", lt):
                                        # determine next missing field
                                        merged = form_state.get('collected', {})
                                        next_f = None
                                        for f in expected_fields:
                                            if not merged.get(f):
                                                next_f = f
                                                break
                                        form_state['next_field'] = next_f
                                        form_state['mode'] = 'collecting'
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        # If there is a next field, prompt for it below in the normal flow
                                        if next_f:
                                            # Build minimal prompt for the next field
                                            examples_local = {
                                                'name': '',
                                                'company': 'Ejemplo: Fibremex S.A. de C.V. (si aplica)',
                                                'rfc': '',
                                                'email': '',
                                                'phone': '(incluye LADA si aplica)',
                                                'website': '',
                                                'project_description': 'Ejemplo: Instalación FTTH en edificio de 24 viviendas. Zona: Col. Centro.'
                                            }
                                            base_prompts_local = {
                                                'name': '¿Cuál es tu nombre completo?',
                                                'company': '¿Cuál es el nombre de tu empresa (si aplica)?',
                                                'rfc': '¿Cuál es tu RFC o razón social?',
                                                'email': '¿Cuál es tu correo electrónico?',
                                                'phone': '¿Cuál es tu teléfono de contacto? (incluye LADA si aplica)',
                                                'website': '¿Tienes un sitio web o link del proyecto?',
                                                'project_description': 'Cuéntame brevemente para qué necesitas la cotización o asesoría (zona, proyecto, objetivo).'
                                            }
                                            idx = expected_fields.index(next_f) + 1 if next_f in expected_fields else None
                                            total = len(expected_fields)
                                            prompt_text = f"Paso {idx}/{total} — " + base_prompts_local.get(next_f, '') + '\n' + examples_local.get(next_f, '') + "\n(Responde con la información y yo la guardaré.)"
                                            send_text_message(phone, prompt_text)
                                            logger.info(f"Solicitando campo '{next_f}' a {phone} (paso {idx}/{total})")
                                            continue
                                        else:
                                            # No next field: fall through to final confirmation flow below
                                            form_state['mode'] = 'confirming'
                                            save_conversation_memory(phone, 'advisor_form_state', form_state)
                                            # let the normal confirmation block handle the summary
                                            pass

                                    # If user wants to modify the last saved field, switch to editing for that field
                                    if re.search(r"\b(modificar|cambiar|editar)\b", lt):
                                        form_state['mode'] = 'editing'
                                        form_state['editing_field'] = last
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        send_text_message(phone, f"Ok, indícame el nuevo valor para '{last.replace('_',' ')}'.")
                                        continue

                                    # Unknown reply -> ask to answer explicitly
                                    send_text_message(phone, "No entendí. Responde 'si' para confirmar el valor o 'modificar' para cambiarlo.")
                                    continue
                            # helper mapping for field synonyms
                            field_map = {
                                'nombre': 'name', 'name': 'name',
                                'empresa': 'company', 'company': 'company',
                                'rfc': 'rfc',
                                'correo': 'email', 'email': 'email',
                                'telefono': 'phone', 'teléfono': 'phone', 'tel': 'phone',
                                'sitio': 'website', 'website': 'website', 'web': 'website',
                                'descripcion': 'project_description', 'descripción': 'project_description', 'descripcion proyecto': 'project_description'
                            }

                            # Import extractor/classifier lazily
                            from routes.advisor_fallbacks import _extract_client_fields_from_text, _classify_segment, generate_client_pdf as _generate_client_pdf

                            # --- Confirmation / Edit handling ---
                            if mode == 'confirming':
                                lt = (message_text or '').strip().lower()
                                # If user asks to modify
                                if re.search(r'\b(modificar|cambiar|editar)\b', lt):
                                    form_state['mode'] = 'awaiting_field_choice'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, "Perfecto, indica cuál campo quieres cambiar: nombre, empresa, rfc, correo, teléfono, sitio o descripción.")
                                    continue
                                # If user confirms (sí)
                                if re.search(r'\b(s[ií])\b', lt):
                                    # proceed to generate and send PDF
                                    collected = form_state['collected']
                                    seg = _classify_segment(collected.get('company'), collected.get('project_description'))
                                    collected['segment'] = seg
                                    summary = collected.get('project_description') or 'Solicitud de contacto'
                                    if len(summary) > 500:
                                        summary = summary[:500]
                                    # generate pdf (use filename pattern with phone timestamp)
                                    filename = f"cliente_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{phone[-4:]}.pdf"
                                    pdf_path = _generate_client_pdf(collected, summary, out_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs')), filename=filename) if _generate_client_pdf else ''
                                    # persist and notify
                                    try:
                                        from data.db import get_collection
                                        col = get_collection('advisor_requests')
                                        rec = {
                                            'phone': phone,
                                            'client_data': collected,
                                            'texts': get_conversation_memory(phone, 'advisor_partial_messages') or [],
                                            'summary': summary,
                                            'pdf_path': pdf_path,
                                            'created_at': datetime.now(),
                                            'status': 'pending',
                                            'course_id': advisor_course_id
                                        }
                                        try:
                                            col.insert_one(rec)
                                        except Exception:
                                            pass
                                    except Exception:
                                        pass

                                    try:
                                        advisor_number = DEFAULT_ADVISOR_PHONE
                                        if pdf_path:
                                            send_document_message(advisor_number, pdf_path, caption=f"Nuevo lead: {collected.get('name', phone)}")
                                        notify_text = f"Nuevo lead: {collected.get('name', phone)} - Segmento: {collected.get('segment')} - Requiere: {summary[:140]}"
                                        send_text_message(advisor_number, notify_text)
                                    except Exception:
                                        logger.debug("Failed to notify advisor during confirmation path")

                                    # clear and confirm to user
                                    save_conversation_memory(phone, 'advisor_partial_messages', None)
                                    save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                                    save_conversation_memory(phone, 'advisor_course_id', None)
                                    save_conversation_memory(phone, 'advisor_form_state', None)
                                    send_text_message(phone, "Gracias — un asesor te contactará pronto. He enviado tu información al asesor.")
                                    continue

                                # any other reply treat as 'no' or topic change -> still send to advisor
                                # proceed to generate and send PDF but inform user we forwarded the info
                                collected = form_state['collected']
                                seg = _classify_segment(collected.get('company'), collected.get('project_description'))
                                collected['segment'] = seg
                                summary = collected.get('project_description') or 'Solicitud de contacto'
                                if len(summary) > 500:
                                    summary = summary[:500]
                                filename = f"cliente_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{phone[-4:]}.pdf"
                                pdf_path = _generate_client_pdf(collected, summary, out_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs')), filename=filename) if _generate_client_pdf else ''
                                try:
                                    from data.db import get_collection
                                    col = get_collection('advisor_requests')
                                    rec = {
                                        'phone': phone,
                                        'client_data': collected,
                                        'texts': get_conversation_memory(phone, 'advisor_partial_messages') or [],
                                        'summary': summary,
                                        'pdf_path': pdf_path,
                                        'created_at': datetime.now(),
                                        'status': 'pending',
                                        'course_id': advisor_course_id
                                    }
                                    try:
                                        col.insert_one(rec)
                                    except Exception:
                                        pass
                                except Exception:
                                    pass
                                try:
                                    advisor_number = DEFAULT_ADVISOR_PHONE
                                    if pdf_path:
                                        send_document_message(advisor_number, pdf_path, caption=f"Nuevo lead: {collected.get('name', phone)}")
                                    notify_text = f"Nuevo lead: {collected.get('name', phone)} - Segmento: {collected.get('segment')} - Requiere: {summary[:140]}"
                                    send_text_message(advisor_number, notify_text)
                                except Exception:
                                    logger.debug("Failed to notify advisor during fallback path")

                                save_conversation_memory(phone, 'advisor_partial_messages', None)
                                save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                                save_conversation_memory(phone, 'advisor_course_id', None)
                                save_conversation_memory(phone, 'advisor_form_state', None)
                                send_text_message(phone, "He enviado tu información al asesor. Si quieres cambiar algo más adelante, dímelo y lo actualizo.")
                                continue

                            # If user has chosen which field to edit
                            if mode == 'awaiting_field_choice' or mode == 'editing':
                                # Try to detect if user provided field: value in a single message
                                candidate = _extract_client_fields_from_text([message_text])
                                merged = form_state['collected']
                                # If extractor gives a direct field update, apply it
                                applied = False
                                for k, v in candidate.items():
                                    if k in merged and v:
                                        merged[k] = v
                                        send_text_message(phone, f"Perfecto, guardé tu {k.replace('_', ' ')}: {v}.")
                                        applied = True
                                if applied:
                                    # go back to confirmation
                                    form_state['collected'] = merged
                                    form_state['mode'] = 'confirming'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    # show summary again
                                    s = []
                                    for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                        s.append(f"{label}: {merged.get(key,'-')}")
                                    send_text_message(phone, "Estos son los datos actualizados:\n" + "\n".join(s))
                                    send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                                    continue

                                # If extractor didn't give value, interpret message as field name when awaiting choice
                                if mode == 'awaiting_field_choice':
                                    choice = (message_text or '').strip().lower()
                                    choice_key = field_map.get(choice)
                                    if not choice_key:
                                        # try to strip accents and common words
                                        for ksyn, kval in field_map.items():
                                            if ksyn in choice:
                                                choice_key = kval
                                                break
                                    if choice_key:
                                        form_state['mode'] = 'editing'
                                        form_state['editing_field'] = choice_key
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        send_text_message(phone, f"Ok, indícame el nuevo valor para '{choice_key}'.")
                                        continue
                                    else:
                                        send_text_message(phone, "No entendí qué campo quieres cambiar. Por favor responde con: nombre, empresa, rfc, correo, teléfono, sitio o descripción.")
                                        continue

                                # If in editing mode and user sent a plain new value
                                if mode == 'editing' and form_state.get('editing_field'):
                                    edit_key = form_state.get('editing_field')
                                    new_val = message_text.strip()
                                    # simple validation depending on field
                                    valid = True
                                    if edit_key == 'email' and not re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", new_val):
                                        valid = False
                                    if edit_key == 'phone' and not re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", new_val):
                                        # allow unvalidated phone but normalize if possible
                                        pass
                                    if valid:
                                        if edit_key == 'phone':
                                            m = re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", new_val)
                                            if m:
                                                new_val = f"52{m.group(1)}"
                                        if edit_key == 'rfc':
                                            new_val = new_val.upper()
                                        merged[edit_key] = new_val
                                        send_text_message(phone, f"Perfecto, guardé tu {edit_key.replace('_',' ')}: {new_val}.")
                                        # clear editing state and go back to confirmation
                                        form_state['collected'] = merged
                                        form_state['mode'] = 'confirming'
                                        form_state.pop('editing_field', None)
                                        save_conversation_memory(phone, 'advisor_form_state', form_state)
                                        # show summary again
                                        s = []
                                        for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                            s.append(f"{label}: {merged.get(key,'-')}")
                                        send_text_message(phone, "Estos son los datos actualizados:\n" + "\n".join(s))
                                        send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                                        continue

                                # otherwise fall through to collection heuristics

                            # Default collecting mode: try to classify the incoming message into a field using helper extractor
                            candidate = _extract_client_fields_from_text([message_text])

                            # If extractor found anything, merge into collected
                            merged = form_state['collected']
                            saved_any = False
                            saved_field = None
                            for k, v in candidate.items():
                                if v and not merged.get(k):
                                    merged[k] = v
                                    saved_any = True
                                    saved_field = k

                            if saved_any and saved_field:
                                # Ask per-field confirmation for the saved field
                                form_state['collected'] = merged
                                form_state['last_saved_field'] = saved_field
                                form_state['mode'] = 'field_confirm'
                                save_conversation_memory(phone, 'advisor_form_state', form_state)
                                label = saved_field.replace('_', ' ')
                                val = merged.get(saved_field)
                                send_text_message(phone, f"Perfecto, guardé tu {label}: {val}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                continue

                            # If extractor didn't find the expected next field, but message contains plausible content for it,
                            # accept simple heuristics (e.g., emails, phones, small names)
                            nf = form_state.get('next_field')
                            if nf and not merged.get(nf):
                                if nf == 'email' and re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", message_text):
                                    merged['email'] = re.search(r"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})", message_text).group(1)
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'email'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu correo: {merged['email']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'phone' and re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", message_text):
                                    m = re.search(r"(?:\+?52\s*)?(?:1\s*)?(\d{10})", message_text)
                                    merged['phone'] = f"52{m.group(1)}"
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'phone'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu teléfono: {merged['phone']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'name' and re.match(r"^[A-Za-zÁÉÍÓÚáéíóúñÑ\'\-\s]{3,60}$", message_text.strip()):
                                    merged['name'] = ' '.join([w.capitalize() for w in message_text.strip().split()])
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'name'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu nombre: {merged['name']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'company' and len(message_text.strip()) > 2:
                                    merged['company'] = message_text.strip()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'company'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu empresa: {merged['company']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'rfc' and re.match(r"^[A-Za-zÑ&\d]{8,13}$", message_text.strip(), re.I):
                                    merged['rfc'] = message_text.strip().upper()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'rfc'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu RFC: {merged['rfc']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'website' and re.search(r"https?://", message_text):
                                    merged['website'] = re.search(r"(https?://[^\s,;]+)", message_text).group(1)
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'website'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé tu sitio web: {merged['website']}. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarlo.")
                                    continue
                                elif nf == 'project_description':
                                    merged['project_description'] = message_text.strip()
                                    form_state['collected'] = merged
                                    form_state['last_saved_field'] = 'project_description'
                                    form_state['mode'] = 'field_confirm'
                                    save_conversation_memory(phone, 'advisor_form_state', form_state)
                                    send_text_message(phone, f"Perfecto, guardé la descripción de tu proyecto. ¿Es correcto? Responde 'si' para continuar o 'modificar' para cambiarla.")
                                    continue

                            # Update next_field to the next missing one
                            next_f = None
                            for f in expected_fields:
                                if not merged.get(f):
                                    next_f = f
                                    break
                            form_state['collected'] = merged
                            form_state['next_field'] = next_f
                            # remain in collecting mode
                            form_state['mode'] = form_state.get('mode', 'collecting')
                            save_conversation_memory(phone, 'advisor_form_state', form_state)

                            # If still missing fields, prompt the user for the next one
                            if next_f:
                                # Build user-friendly guided prompts with step numbers and examples
                                idx = expected_fields.index(next_f) + 1 if next_f in expected_fields else None
                                total = len(expected_fields)
                                examples = {
                                    'name': '',
                                    'company': '',
                                    'rfc': '',
                                    'email': '',
                                    'phone': '',
                                    'website': '',
                                    'project_description': 'Ejemplo: Instalación FTTH en edificio de 24 viviendas. Zona: Col. Centro.'
                                }

                                base_prompts = {
                                    'name': '¿Cuál es tu nombre completo?',
                                    'company': '¿Cuál es el nombre de tu empresa (si aplica)?',
                                    'rfc': '¿Cuál es tu RFC o razón social?',
                                    'email': '¿Cuál es tu correo electrónico?',
                                    'phone': '¿Cuál es tu teléfono de contacto? (incluye LADA si aplica)',
                                    'website': '¿Tienes un sitio web o link del proyecto?',
                                    'project_description': 'Cuéntame brevemente para qué necesitas la cotización o asesoría (zona, proyecto, objetivo).'
                                }

                                step_prefix = f"Paso {idx}/{total} — " if idx else ''
                                example = '\n' + examples.get(next_f, '')
                                prompt_text = step_prefix + base_prompts.get(next_f, 'Por favor comparte la información solicitada.') + example + "\n(Responde con la información y yo la guardaré.)"

                                # Ask explicitly only for the missing next field
                                send_text_message(phone, prompt_text)
                                logger.info(f"Solicitando campo '{next_f}' a {phone} (paso {idx}/{total})")
                                continue

                            # All required fields collected -> ask for confirmation before generating PDF
                            # Build summary
                            collected = form_state['collected']
                            s = []
                            for label, key in [('Nombre', 'name'), ('Empresa', 'company'), ('RFC', 'rfc'), ('Correo', 'email'), ('Teléfono', 'phone'), ('Sitio', 'website'), ('Descripción', 'project_description')]:
                                s.append(f"{label}: {collected.get(key,'-')}")
                            summary_msg = "Estos son los datos que tengo:\n" + "\n".join(s)
                            send_text_message(phone, summary_msg)
                            send_text_message(phone, "¿Deseas modificar algún dato? Responde 'modificar' para cambiar o 'no' para confirmar y enviar al asesor.")
                            # update state to confirming
                            form_state['mode'] = 'confirming'
                            save_conversation_memory(phone, 'advisor_form_state', form_state)
                            continue
                        except Exception as e:
                            logger.error(f"Error procesando datos de asesor: {e}")
                            # Seguimos adelante con el flujo normal si hay error
                    
                    # Importar el manejador de temarios
                    from utils.temario_handler import (
                        is_temario_request, is_inscription_request, extract_course_number,
                        get_inscription_process_message, ask_for_course_number
                    )
                    
                    # Manejo centralizado de consultas sobre cursos usando CourseConversationManager
                    # Si estamos en medio del flujo guiado para el asesor, no procesar consultas de cursos
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor:
                        logger.info(f"Skipping CourseConversationManager.handle_course_query because waiting_for_advisor_data is set for {phone}")
                    else:
                        course_response = CourseConversationManager.handle_course_query(phone, message_text)
                        if course_response:
                            # Send the course-specific response and stop further processing for this webhook
                            # This prevents falling through and sending a second, generic reply immediately.
                            send_text_message(phone, course_response)
                            continue

                    # If the user already selected a course previously, prefer that context
                    # and answer requests about the selected course (fechas, temario, precio, inscripción, ubicación, asesor)
                    try:
                        selected_course = get_selected_course(phone)
                        if selected_course and isinstance(selected_course, dict):
                            sc_id = selected_course.get('id')
                            sc_name = selected_course.get('name')
                            lt = (message_text or '').lower()

                            # Temario / contenido / programa
                            if any(w in lt for w in ['temario', 'contenido', 'programa']):
                                try:
                                    logger.info(f"User requested temario for selected course {sc_id}: {sc_name}")
                                    pdf_res = find_pdf_for_user_message(f"temario {sc_id}", context={'relevant_courses': [selected_course]})
                                    if pdf_res and pdf_res.get('pdf_path') and os.path.exists(pdf_res.get('pdf_path')):
                                        send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {sc_name}")
                                        # MEJORA: Enviar confirmación textual junto con el PDF
                                        send_text_message(phone, f"📚 Te envié el temario completo del curso '{sc_name}' en PDF. ¿Te gustaría saber sobre fechas, precio o ubicación?")
                                        # Save selected course details if not present
                                        try:
                                            save_selected_course(phone, sc_id, sc_name, {'pdf_path': pdf_res.get('pdf_path')})
                                        except Exception:
                                            pass
                                    else:
                                        # Fallback to textual temario/info from adapter or course utilities
                                        details_msg = get_course_details_by_number(sc_id) if sc_id else None
                                        if details_msg:
                                            send_text_message(phone, details_msg)
                                        else:
                                            send_text_message(phone, f"El temario de '{sc_name}' está disponible. ¿Quieres que te lo comparta en PDF o que te dé más detalles de fechas y precio?")
                                except Exception as e:
                                    logger.error(f"Error sending temario for selected course: {e}")
                                    send_text_message(phone, "Lo siento, hubo un problema al recuperar el temario. ¿Quieres que un asesor te ayude?")
                                continue

                            # Fechas
                            if any(w in lt for w in ['fecha', 'fechas', 'horario', 'horarios']):
                                try:
                                    sched_msg = get_course_schedule_message(sc_id)
                                    send_text_message(phone, f"📅 Fechas del curso '{sc_name}':\n\n{sched_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting schedule for selected course: {e}")
                                    send_text_message(phone, "No pude obtener las fechas en este momento. ¿Quieres que te conecte con un asesor?")
                                continue

                            # Precio / costos
                            if any(w in lt for w in ['precio', 'costo', 'costos', 'precio del curso']):
                                try:
                                    price_msg = get_course_price_message(sc_id)
                                    send_text_message(phone, f"💰 Precio del curso '{sc_name}':\n\n{price_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting price for selected course: {e}")
                                    send_text_message(phone, "No pude obtener el precio en este momento. ¿Quieres que un asesor te contacte?")
                                continue

                            # Inscripción
                            if any(w in lt for w in ['inscrib', 'inscripción', 'inscripcion', 'registrar', 'registro']):
                                try:
                                    # Use temario_handler helper if available
                                    try:
                                        from utils.temario_handler import get_inscription_process_message
                                        ins_msg = get_inscription_process_message()
                                    except Exception:
                                        ins_msg = get_inscription_process_message() if 'get_inscription_process_message' in globals() else "Para inscribirte por favor visita el enlace o dime si quieres que un asesor te contacte."

                                    send_text_message(phone, f"📝 Inscripción para '{sc_name}':\n\n{ins_msg}")
                                except Exception as e:
                                    logger.error(f"Error providing inscription info: {e}")
                                    send_text_message(phone, "No pude recuperar el proceso de inscripción. ¿Quieres que te ponga en contacto con un asesor?")
                                continue

                            # Ubicación
                            if any(w in lt for w in ['ubicació', 'ubicacion', 'lugar', 'sede']):
                                try:
                                    loc_msg = get_course_location_message(sc_id)
                                    send_text_message(phone, f"📍 Ubicación del curso '{sc_name}':\n\n{loc_msg}")
                                except Exception as e:
                                    logger.error(f"Error getting location for selected course: {e}")
                                    send_text_message(phone, "No pude obtener la ubicación en este momento. ¿Quieres que te contacte un asesor?")
                                continue

                            # Asesor
                            if any(w in lt for w in ['asesor', 'contactar', 'contacto', 'hablar con']):
                                try:
                                    save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                    save_conversation_memory(phone, 'advisor_course_id', sc_id)
                                    advisor_prompt = advisor_request_prompt()
                                    send_text_message(phone, f"Perfecto, para que un asesor te contacte por el curso '{sc_name}' necesito: \n\n{advisor_prompt}")
                                except Exception as e:
                                    logger.error(f"Error triggering advisor for selected course: {e}")
                                    send_text_message(phone, "No pude solicitar un asesor en este momento. Intenta más tarde.")
                                continue
                    except Exception as sel_e:
                        logger.debug(f"Error handling selected course quick reply: {sel_e}")

                        # Handle course change responses
                        text_lower = (message_text or '').lower()
                        selected_course = CourseConversationManager.get_selected_course_info(phone)

                        # Only treat explicit affirmative replies as confirmations for pending changes
                        selected_course = CourseConversationManager.get_selected_course_info(phone)
                        pending_course_change = get_conversation_memory(phone, 'pending_course_change')
                        if pending_course_change and selected_course:
                            # Normalize pending change to dict if stored as string
                            change_data = None
                            try:
                                if isinstance(pending_course_change, str):
                                    import ast
                                    change_data = ast.literal_eval(pending_course_change)
                                else:
                                    change_data = pending_course_change
                            except Exception:
                                change_data = None

                            # Only accept clear affirmative words, avoid catching 'cambiar' in other contexts
                            affirmative = ['si', 'sí', 's', 'ok', 'claro', 'sí, cambiar', 'sí cambiar']
                            negative = ['no', 'cancelar', 'mejor no', 'prefiero seguir', 'continuar']

                            # Check user's message for explicit confirmation or rejection
                            if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in affirmative):
                                # Build selection intent from pending change and apply
                                try:
                                    selection_intent = {
                                        'intent': change_data.get('intent') if change_data else None,
                                        'course_number': change_data.get('course_number') if change_data else None,
                                        'course': change_data.get('course') if change_data else None
                                    }
                                    change_response = CourseConversationManager._handle_course_selection(phone, selection_intent)
                                    if change_response:
                                        send_text_message(phone, change_response)
                                except Exception as e:
                                    logger.error(f"Error processing course change: {e}")
                                finally:
                                    # Clear pending change in any case
                                    save_conversation_memory(phone, 'pending_course_change', None)
                                continue  # Skip further processing

                            if any(word == text_lower.strip() or text_lower.strip().startswith(word + ' ') for word in negative):
                                # User explicitly rejected the change
                                save_conversation_memory(phone, 'pending_course_change', None)
                                send_text_message(phone, f"Perfecto, continuamos con el curso '{selected_course.get('name')}'. ¿Qué más te gustaría saber?")
                                continue

                        elif 'info' in text_lower:
                            # User wants info without changing - this is already handled by the course_response
                            continue

                        elif 'continuar' in text_lower and selected_course:
                            # User wants to continue with current course
                            continue_response = f"Perfecto, continuamos con el curso '{selected_course.get('name')}'. ¿Qué más te gustaría saber?"
                            send_text_message(phone, continue_response)
                            continue

                        # Handle PDF sending for temario requests
                        if selected_course and any(w in (message_text or '').lower() for w in ['temario', 'contenido', 'programa']):
                            try:
                                logger.info(f"Attempting to send PDF for course {selected_course['id']}: {selected_course['name']}")
                                pdf_res = find_pdf_for_user_message(f"temario {selected_course['id']}", context={'relevant_courses': [selected_course]})
                                if pdf_res and pdf_res.get('pdf_path'):
                                    logger.info(f"Found PDF: {pdf_res['pdf_path']}")
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {selected_course['name']}")
                                    if send_result:
                                        logger.info(f"PDF sent successfully to {phone}")
                                    else:
                                        logger.error(f"Failed to send PDF to {phone}")
                                else:
                                    logger.warning(f"No PDF found for course {selected_course['id']}")
                            except Exception as e:
                                logger.error(f"Error sending PDF for course temario: {e}")

                        # Handle advisor requests
                        if any(w in (message_text or '').lower() for w in ['asesor', 'contactar', 'asesoría', 'asesoria']):
                            save_conversation_memory(phone, "advisor_prompt_sent", True)
                            save_conversation_memory(phone, "waiting_for_advisor_data", True)
                            if selected_course:
                                save_conversation_memory(phone, "advisor_course_id", selected_course['id'])

                        continue

                    # Manejo de inscripción: explicar proceso y enviar link
                    if is_inscription_request(message_text):
                        inscription_msg = get_inscription_process_message()
                        send_text_message(phone, inscription_msg)
                        continue

                    # DETECCIÓN DE MENSAJES PUBLICITARIOS ESPECÍFICOS DE CURSOS
                    course_detected = None
                    for course_type, keywords in course_ads.items():
                        if any(keyword in text_lower for keyword in keywords):
                            course_detected = course_type
                            break
                    
                    if course_detected:
                        # Mapeo de tipos de curso a IDs del JSON
                        course_mapping = {
                            'cableado_estructurado': 1,  # "Cableado estructurado para redes de fibra y cobre"
                            'fibra_planta_externa': 2,   # "Redes de fibra óptica planta externa"
                            'ftth_wisp_isp': 3,          # "Redes de fibra óptica FTTH para WISP e ISP"
                            'redes_pasivas_enterprise': 4, # "PONLAN redes pasivas para entornos enterprise"
                            'empalmes_otdr': 5           # "Empalmes y mediciones con OTDR de un enlace de fibra óptica"
                        }
                        
                        course_id = course_mapping.get(course_detected)
                        if course_id:
                            try:
                                # Obtener información completa del curso específico
                                course_info = get_course_complete_info(course_id)
                                if course_info:
                                    response_msg = f"¡Hola! 👋 Perfecto, te comparto la información completa del curso:\n\n{course_info}"
                                    
                                    # Agregar información de modalidad online si no están en Querétaro
                                    response_msg += "\n\n📍 **MODALIDAD PRESENCIAL:** Querétaro, México"
                                    response_msg += "\n\n💻 **¿No te encuentras en Querétaro?**"
                                    response_msg += "\nTenemos **webinars GRATUITOS** en línea que se imparten cada **martes**."
                                    response_msg += "\n\n📚 **Webinars disponibles:**"
                                    response_msg += "\n• Soluciones preconectorizadas"
                                    response_msg += "\n• Empalmes de fibra óptica y OTDR"
                                    response_msg += "\n• Instalación subterránea"
                                    response_msg += "\n• De WISP a Fibra"
                                    response_msg += "\n• ODN en FTTX"
                                    response_msg += "\n• Centro de datos"
                                    response_msg += "\n\n🌐 **Ver calendario de webinars:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online"
                                    
                                    send_text_message(phone, response_msg)
                                else:
                                    # Fallback si no se encuentra el curso
                                    send_text_message(phone, "¡Hola! 👋 Te ayudo con información de nuestros cursos. ¿Podrías ser más específico sobre qué curso te interesa?")
                            except Exception as e:
                                logger.error(f"Error procesando mensaje publicitario de curso {course_detected}: {e}")
                                send_text_message(phone, "¡Hola! 👋 Te ayudo con información de nuestros cursos. Escribe 'cursos' para ver todas las opciones disponibles.")
                        continue

                    # Manejo de opciones online / webinars / modalidad online / no ubicado en Querétaro
                    if any(k in text_lower for k in online_keywords) or any(loc in text_lower for loc in ['no me encuentro en querétaro', 'no estoy en querétaro', 'modalidad online', 'curso online', 'seminario en línea']):
                        # Respuesta mejorada para opciones online
                        online_msg = (
                            "¡Perfecto! 💻 **SÍ tenemos opciones EN LÍNEA**\n\n"
                            "🎓 **WEBINARS GRATUITOS** que se imparten cada **martes**:\n\n"
                            "📚 **Temas disponibles:**\n"
                            "• **Soluciones preconectorizadas**\n"
                            "• **Empalmes de fibra óptica y OTDR**\n"
                            "• **Instalación subterránea**\n"
                            "• **De WISP a Fibra**\n"
                            "• **ODN en FTTX**\n"
                            "• **Centro de datos**\n\n"
                            "🌐 **Ver calendario y registrarse:** https://fibremex.com/fibra-optica/views/Capacitaciones/2-seminarios-online\n\n"
                            "💡 Si deseas información específica de algún webinar, escribe el nombre del tema y te doy más detalles.\n\n"
                            "📞 **¿Prefieres un curso presencial?** Nuestros cursos presenciales se imparten en **Querétaro, México**. Escribe 'cursos' para ver toda la información."
                        )
                        send_text_message(phone, online_msg)
                        continue

                    # Manejo de bobinas UTP
                    if any(k in text_lower for k in bobinas): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            bobinas_msg = ( 
                                "Las **bobinas** de cable UTP de la marca **Optronics®.** son una excelente opción para instalaciones de redes de datos y telecomunicaciones.\n\n"
                                "La información más relevante es que estos cables son 100% de cobre, ideales para redes de telecomunicaciones y LAN, y están disponibles en las categorías Cat. 6A, Cat. 6 y Cat. 5e.\n\n"
                                "El contenido destaca varias características clave del producto:\n\n"
                                "Tipos de Estructura: Se ofrecen en estructuras U/UTP, S/FTP y F/UTP. Rendimiento:\n\n"
                                "Garantizan alta fidelidad y rendimiento eléctrico y mecánico.\n\n"
                                "Aplicaciones: Son adecuados para redes LAN, cuartos de telecomunicaciones, PoE (Power over Ethernet), voz, datos, video y centros de datos.\n\n"
                                "Calidad y Certificación: La marca cumple con estándares nacionales e internacionales de seguridad y eficiencia.\n\n"
                                "¿Te gustaría saber más sobre la diferencia entre las categorías de cable (Cat. 6A, Cat. 6, Cat. 5e) o sobre las estructuras UTP (U/UTP, S/FTP, F/UTP)?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/bobinas-de-cable-utp"
                            )
                            send_text_message(phone, bobinas_msg)
                        else:
                            # Prefer DB-backed product info; fallback to LLM dynamic response if DB not available
                            try:
                                bobinas_fallback = (
                                    "Las **bobinas** de cable UTP de la marca **Optronics®.** son una excelente opción para instalaciones de redes de datos y telecomunicaciones.\n\n"
                                    "La información más relevante es que estos cables son 100% de cobre, ideales para redes de telecomunicaciones y LAN, y están disponibles en las categorías Cat. 6A, Cat. 6 y Cat. 5e.\n\n"
                                    "El contenido destaca varias características clave del producto:\n\n"
                                    "Tipos de Estructura: Se ofrecen en estructuras U/UTP, S/FTP y F/UTP. Rendimiento:\n\n"
                                    "Garantizan alta fidelidad y rendimiento eléctrico y mecánico.\n\n"
                                    "Aplicaciones: Son adecuados para redes LAN, cuartos de telecomunicaciones, PoE (Power over Ethernet), voz, datos, video y centros de datos.\n\n"
                                    "Calidad y Certificación: La marca cumple con estándares nacionales e internacionales de seguridad y eficiencia.\n\n"
                                    "¿Te gustaría saber más sobre la diferencia entre las categorías de cable (Cat. 6A, Cat. 6, Cat. 5e) o sobre las estructuras UTP (U/UTP, S/FTP, F/UTP)?"
                                )
                                send_db_or_fallback_message(phone, ['bobina', 'bobinas', 'utp', 'cable utp', 'cat 6a'], bobinas_fallback, fallback_link='https://contenido.fibremex.com/bobinas-de-cable-utp')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Eres un asistente técnico comercial que responde preguntas sobre productos. El usuario mencionó bobinas de cable UTP. "
                                        "Responde de forma conversacional y adaptada al historial, sin usar un texto predefinido. Si el usuario lo solicita, ofrece el enlace al producto. Mantén la respuesta breve y clara."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo darte información sobre las bobinas UTP y diferencias entre Cat. 6A/6/5e. ¿Qué te interesa saber exactamente?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para bobinas: {e}")
                                    send_text_message(phone, "Puedo darte información sobre las bobinas UTP. ¿Qué aspecto te interesa (categoría, estructura, aplicaciones)?")
                        continue

                    # Manejo de ducto para fibra óptica
                    if any(k in text_lower for k in ducto): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            ducto_msg = (
                                "Los **ductos de polietileno de alta densidad (HDPE/PEAD) de Optronics®** están diseñados para proteger la fibra óptica en instalaciones subterráneas.\n\n"
                                "Lo más relevante del producto es:\n\n"
                                "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental.\n\n"
                                "Facilidad de instalación: Viene prelubricado, lo que reduce el tiempo y el esfuerzo necesarios para instalar el cableado en su interior.\n\n"
                                "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                "Aplicaciones: Su uso principal es la protección de cables de fibra óptica contra daños mecánicos y ambientales en campus, zonas urbanas o torres de telecomunicaciones.\n\n"
                                "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/ductos-de-fibra-optica"
                            )
                            send_text_message(phone, ducto_msg)
                        else:
                            try:
                                ducto_fallback = (
                                    "Los **ductos de polietileno de alta densidad (HDPE/PEAD) de Optronics®** están diseñados para proteger la fibra óptica en instalaciones subterráneas.\n\n"
                                    "Lo más relevante del producto es:\n\n"
                                    "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental.\n\n"
                                    "Facilidad de instalación: Viene prelubricado, lo que reduce el tiempo y el esfuerzo necesarios para instalar el cableado en su interior.\n\n"
                                    "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                    "Aplicaciones: Su uso principal es la protección de cables de fibra óptica contra daños mecánicos y ambientales en campus, zonas urbanas o torres de telecomunicaciones.\n\n"
                                    "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['ducto', 'ductos', 'hdpe', 'ducto fibra'], ducto_fallback, fallback_link='https://contenido.fibremex.com/ductos-de-fibra-optica')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma contextual sobre ductos de fibra óptica. No utilices mensajes prefabricados; adapta la respuesta al usuario y ofrece preguntar por especificaciones de tamaño, resistencia y aplicaciones."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo darte especificaciones de ductos HDPE y opciones de tamaño. ¿Qué necesitas saber?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para ducto: {e}")
                                    send_text_message(phone, "Puedo darte especificaciones de ductos HDPE y opciones de tamaño. ¿Qué necesitas saber?")
                        continue

                    # Manejo de tritubo para fibra óptica
                    if any(k in text_lower for k in tritubo): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            tritubo_msg = ( 
                                "El **tritubo de polietileno de alta densidad (HDPE/PEAD) de Optronics®** es una solución avanzada para la protección y organización de cables de fibra óptica en instalaciones subterráneas.\n\n"
                                "Lo más relevante del producto es:\n\n"
                                "Diseño innovador: Cuenta con tres conductos independientes dentro de un solo tubo, lo que permite la instalación de múltiples cables de fibra óptica sin interferencias.\n\n"
                                "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental, asegurando la protección a largo plazo de los cables.\n\n"
                                "Facilidad de instalación: Viene prelubricado, lo que facilita el proceso de instalación y reduce el tiempo y esfuerzo necesarios.\n\n"
                                "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                "Aplicaciones: Ideal para proyectos que requieren la instalación de varios cables de fibra óptica en un espacio reducido, como en zonas urbanas o campus empresariales.\n\n"
                                "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/tritubo-proteccion-para-fibra-optica"
                            )
                            send_text_message(phone, tritubo_msg)
                        else:
                            try:
                                tritubo_fallback = (
                                    "El **tritubo de polietileno de alta densidad (HDPE/PEAD) de Optronics®** es una solución avanzada para la protección y organización de cables de fibra óptica en instalaciones subterráneas.\n\n"
                                    "Lo más relevante del producto es:\n\n"
                                    "Diseño innovador: Cuenta con tres conductos independientes dentro de un solo tubo, lo que permite la instalación de múltiples cables de fibra óptica sin interferencias.\n\n"
                                    "Alta durabilidad: Está fabricado para resistir impactos, humedad y desgaste ambiental, asegurando la protección a largo plazo de los cables.\n\n"
                                    "Facilidad de instalación: Viene prelubricado, lo que facilita el proceso de instalación y reduce el tiempo y esfuerzo necesarios.\n\n"
                                    "Resistencia: Cumple con la norma ASTM F2160 y es resistente a los rayos UV, la corrosión y temperaturas extremas.\n\n"
                                    "Aplicaciones: Ideal para proyectos que requieren la instalación de varios cables de fibra óptica en un espacio reducido, como en zonas urbanas o campus empresariales.\n\n"
                                    "¿Quieres saber más sobre las especificaciones técnicas o las opciones de tamaño y color disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['tritubo', 'tri-tubo', 'tri tubo', 'tritubos'], tritubo_fallback, fallback_link='https://contenido.fibremex.com/tritubo-proteccion-para-fibra-optica')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma conversacional sobre tritubos HDPE: explica ventajas, aplicaciones y preguntas que ayudarán a determinar la mejor opción. Evita respuestas prefabricadas."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo explicar ventajas y aplicaciones del tritubo. ¿Qué te gustaría saber?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para tritubo: {e}")
                                    send_text_message(phone, "Puedo explicar ventajas y aplicaciones del tritubo. ¿Qué te gustaría saber?")
                        continue

                    if any(k in text_lower for k in jumper): 
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            jumper_msg = (
                                "Los **jumperes de fibra óptica MPO/MTP de la marca Optronics®** son esenciales para la interconexión de equipos y enlaces de fibra óptica. Lo más relevante es que estos cables se caracterizan por su alta densidad de fibra y se utilizan principalmente para interconexiones rápidas y eficientes en centros de datos, redes de telecomunicaciones y entornos de alta densidad.\n\n"
                                "Las características principales que se mencionan son:\n\n"
                                "Tipos de conectores: Se enfocan en los conectores MPO, MTP y MTPpro, que permiten la transmisión de múltiples fibras en un solo conector.\n\n"
                                "Alta densidad: Facilitan un gran número de conexiones en espacios reducidos, lo que es crucial para la eficiencia en data centers.\n\n"
                                "Velocidad: Soportan conexiones de alta velocidad como 40G y 100G.\n\n"
                                "Diseño: Tienen un diseño Push-Pull que facilita la conexión y desconexión sin necesidad de herramientas.\n\n"
                                "Aplicaciones: Son ideales para interconexiones en racks, paneles de parcheo y equipos de red.\n\n"
                                "¿Quieres saber más sobre las diferencias entre los conectores MPO, MTP y MTPpro, o sobre las especificaciones técnicas y opciones disponibles?\n\n"
                                "Si lo deseas, puedo comparar las diferencias y ventajas de los conectores MPO, MTP y MTPpro para que comprendas mejor cuál podría ser el más adecuado para un proyecto específico.\n\n"
                                "Te comparto el enlace directo para que veas mas sobre los productos: https://contenido.fibremex.com/jumper-fibra-optica-mpo-mtp-mtppro"
                            )
                            send_text_message(phone, jumper_msg)
                        else:
                            try:
                                jumper_fallback = (
                                    "Los **jumperes de fibra óptica MPO/MTP de la marca Optronics®** son esenciales para la interconexión de equipos y enlaces de fibra óptica. Lo más relevante es que estos cables se caracterizan por su alta densidad de fibra y se utilizan principalmente para interconexiones rápidas y eficientes en centros de datos, redes de telecomunicaciones y entornos de alta densidad.\n\n"
                                    "Las características principales que se mencionan son:\n\n"
                                    "Tipos de conectores: Se enfocan en los conectores MPO, MTP y MTPpro, que permiten la transmisión de múltiples fibras en un solo conector.\n\n"
                                    "Alta densidad: Facilitan un gran número de conexiones en espacios reducidos, lo que es crucial para la eficiencia en data centers.\n\n"
                                    "Velocidad: Soportan conexiones de alta velocidad como 40G y 100G.\n\n"
                                    "Diseño: Tienen un diseño Push-Pull que facilita la conexión y desconexión sin necesidad de herramientas.\n\n"
                                    "Aplicaciones: Son ideales para interconexiones en racks, paneles de parcheo y equipos de red.\n\n"
                                    "¿Quieres saber más sobre las diferencias entre los conectores MPO, MTP y MTPpro, o sobre las especificaciones técnicas y opciones disponibles?"
                                )
                                send_db_or_fallback_message(phone, ['mpo', 'mtp', 'jumper', 'jumperes', 'multi-fiber push on'], jumper_fallback, fallback_link='https://contenido.fibremex.com/jumper-fibra-optica-mpo-mtp-mtppro')
                            except Exception:
                                try:
                                    system_prompt = (
                                        "Responde de forma conversacional sobre jumpers MPO/MTP: explica aplicaciones, diferencias y guía de selección. No uses un texto prefabricado."
                                    )
                                    dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                    send_text_message(phone, dyn or "Puedo comparar conectores MPO, MTP y MTPpro para tu caso. ¿Qué necesitas conectar?")
                                except Exception as e:
                                    logger.error(f"Error generando respuesta dinámica para jumper: {e}")
                                    send_text_message(phone, "Puedo comparar conectores MPO, MTP y MTPpro para tu caso. ¿Qué necesitas conectar?")
                        continue

                

                    if any (k in text_lower for k in soluciones_preconectorizadas):
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            soluciones_preconectorizadas_msg = (
                                "Descubre cómo reducir tiempos, costos y errores en campo mediante el uso de soluciones preconectorizadas, desde la oficina central hasta la red de distribución y última milla.\n\n"
                                "Analizando casos reales, ventajas operativas y ejemplos de implementación eficiente con productos personalizados y de alto desempeño.\n\n"
                                "**¿Qué aprenderás?:**\n\n"
                                "✅  ¿Qué son las soluciones preconectorizadas?\n\n"
                                "✅  Ventajas de la solución preconectorizada\n\n"
                                "✅  Ensambles preconectorizados en la oficina central\n\n"
                                "✅  Ensambles preconectorizados en la red de distribución\n\n"
                                "✅  Cajas NAP preconectorizadas\n\n"
                                "✅  Solución ReadyOp Optronics\n\n"
                                "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/soluciones-preconectorizadas"
                            )
                            send_text_message(phone, soluciones_preconectorizadas_msg)
                        else:
                            try:
                                system_prompt = (
                                    "Responde de forma conversacional sobre soluciones preconectorizadas y sus ventajas. No uses texto prefabricado; adapta la respuesta al caso del usuario y sugiere preguntas para entender mejor su necesidad."
                                )
                                dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                send_text_message(phone, dyn or "Puedo explicar las ventajas de las soluciones preconectorizadas. ¿Qué necesitas resolver en campo?")
                            except Exception as e:
                                logger.error(f"Error generando respuesta dinámica para soluciones_preconectorizadas: {e}")
                                send_text_message(phone, "Puedo explicar las ventajas de las soluciones preconectorizadas. ¿Qué necesitas resolver en campo?")
                        continue

                    if any(k in text_lower for k in empalmes_fibra_optica):
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            empalmes_fibra_optica_msg = (
                                "Descubre cómo seleccionar, configurar y utilizar correctamente tu empalmadora, asegurando resultados de alta calidad, minimizando pérdidas y extendiendo la vida útil de tu equipo.\n\n"
                                "Conociendo las partes clave del equipo, configuraciones esenciales y las mejores prácticas para el cuidado, mantenimiento y operación efectiva en campo.\n\n"
                                "**¿Qué aprenderás?:**\n\n"
                                "✅  Diferencias entre empalmadoras por núcleo y por revestimiento\n\n"
                                "✅  Cómo elegir el equipo adecuado según tu proyecto\n\n"
                                "✅  Preparación correcta de la fibra antes del empalme\n\n"
                                "✅  Configuración y calibración del equipo para distintos entornos\n\n"
                                "✅  Detección y solución de fallas comunes en la zona de fusión\n\n"
                                "✅  Mantenimiento preventivo y cambio de consumibles\n\n"
                                "✅  Uso de GPS para localización y control de equipos\n\n"
                                "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/seminario-empalmes-de-fibra-optica"
                            )
                            send_text_message(phone, empalmes_fibra_optica_msg)
                        else:
                            try:
                                system_prompt = (
                                    "Responde de forma técnica y conversacional sobre empalmes de fibra óptica y uso de OTDR: adapta la respuesta al nivel del usuario y ofrece pasos prácticos. No uses un texto predefinido."
                                )
                                dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                send_text_message(phone, dyn or "Puedo explicar cómo preparar la fibra para empalmes y uso básico de OTDR. ¿Qué necesitas saber?")
                            except Exception as e:
                                logger.error(f"Error generando respuesta dinámica para empalmes_fibra_optica: {e}")
                                send_text_message(phone, "Puedo explicar cómo preparar la fibra para empalmes y uso básico de OTDR. ¿Qué necesitas saber?")
                        continue

                    if any(k in text_lower for k in instalacion_subterranea):
                        USE_PREDEFINED_RESPONSES = False
                        if USE_PREDEFINED_RESPONSES:
                            instalacion_subterranea_msg = (
                                "Descubre las ventajas, requerimientos y mejores prácticas para implementar redes ópticas subterráneas, ideales para proyectos que requieren mayor protección, menor impacto visual y máxima durabilidad.\n\n"
                                "A través de un análisis técnico de métodos de instalación, tipos de ductos, registros y condiciones del terreno, complementado con ejemplos reales y normativas clave.\n\n"
                                "**¿Qué aprenderás?:**\n\n"
                                "✅  Las tendencias en instalaciones de fibra\n\n"
                                "✅  Cuándo optar por una instalación subterránea y sus consideraciones\n\n"
                                "✅  Métodos de instalación y elementos para la correcta instalación subterránea\n\n"
                                "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/seminario-instalacion-subterranea"
                            )
                            send_text_message(phone, instalacion_subterranea_msg)
                        else:
                            try:
                                system_prompt = (
                                    "Responde de forma profesional sobre instalación subterránea de fibra: riesgos, métodos, ductos y consideraciones. No utilices texto prefabricado; adapta la respuesta al usuario."
                                )
                                dyn = chat_with_gemini(phone=phone, message=message_text, system_prompt=system_prompt, include_whatsapp_profile=whatsapp_profile)
                                send_text_message(phone, dyn or "Puedo explicar métodos y consideraciones para instalación subterránea. ¿Qué te interesa?")
                            except Exception as e:
                                logger.error(f"Error generando respuesta dinámica para instalacion_subterranea: {e}")
                                send_text_message(phone, "Puedo explicar métodos y consideraciones para instalación subterránea. ¿Qué te interesa?")
                        continue

                    if any(k in text_lower for k in wisp_a_fibra):
                        wisp_a_fibra_msg = (
                            "Descubre cómo migrar tu red a fibra óptica de manera eficiente, rentable y con las mejores tecnologías del mercado.\n\n"
                            "En este seminario exclusivo, aprenderás los beneficios y estrategias clave para evolucionar de WISP a una red de fibra óptica. Conoce las soluciones tecnológicas y buenas prácticas que te permitirán hacer esta transición de manera exitosa.\n\n"
                            "**¿Qué aprenderás?:**\n\n"
                            "✅  Ventajas y desventajas de un WISP\n\n"
                            "✅  Ventajas del uso de la fibra óptica.\n\n"
                            "✅  Consideraciones para elegir el cable de fibra óptica adecuado.\n\n"
                            "✅  Redes de fibra FTTH.\n\n"
                            "✅  ¿Cómo funciona una red PON? y sus elementos.\n\n"
                            "✅  Consideraciones para realizar la migración de WISP a Fibra\n\n"
                            "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/seminario-de-wisp-a-fibra"
                        )
                        send_text_message(phone, wisp_a_fibra_msg)
                        continue

                    if any(k in text_lower for k in odn_en_fttx):
                        odn_en_fttx_msg = (
                            "Descubre cómo implementar redes ópticas de distribución efectivas, seguras y adaptadas a las necesidades actuales de los ISP´s.\n\n"
                            "Aprenderás a identificar los elementos que integran una ODN (Optical Distribution Network) y cómo influyen en su desempeño, así como los métodos más utilizados para su instalación según el tipo de entorno y requerimientos técnicos.\n\n"
                            "Además, abordaremos las tendencias actuales en métodos de instalación y los materiales más eficientes para asegurar una red confiable y escalable.\n\n"
                            "**¿Qué aprenderás?:**\n\n"
                            "✅  Elementos que integran la ODN.\n\n"
                            "✅  Métodos de instalación, sus elementos y consideraciones.\n\n"
                            "✅  Estructura de cables exteriores de Fibra óptica, y sus elementos de sujeción.\n\n"
                            "✅  Tendencias en cuanto a métodos de instalación.\n\n"
                            "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/seminario-odn-en-fttx"
                        )
                        send_text_message(phone, odn_en_fttx_msg)
                        continue

                    if any(k in text_lower for k in centro_de_datos):
                        centro_de_datos_msg = (
                            "Descubre cómo diseñar, gestionar y optimizar un centro de datos, abordando desde sus componentes esenciales hasta las tendencias más actuales en cableado y ensambles multifibra.\n\n"
                            "Mediante un enfoque técnico y práctico, conocerás las mejores prácticas de diseño, tipos de data centers, configuración de cableado, y cómo las nuevas tecnologías están transformando la eficiencia y seguridad de estos entornos.\n\n"
                            "**¿Qué aprenderás?:**\n\n"
                            "✅  Definiciones y componentes de centro de datos\n\n"
                            "✅  Tipos de data centers\n\n"
                            "✅  Topología de la infraestructura de red\n\n"
                            "✅  Cableado de comunicaciones para DC\n\n"
                            "✅  Ensambles multifibra, configuraciones y arreglos\n\n"
                            "✅  Tendencias en los ensambles multifibra\n\n"
                            "Te comparto el enlace directo para que veas y conozcas mas sobre el webinar: https://contenido.fibremex.com/ciclo5-seminario6-centro-de-datos"
                        )
                        send_text_message(phone, centro_de_datos_msg)
                        continue

                    # Manejo de ubicación / dónde es el curso
                    if any(k in text_lower for k in where_keywords):
                        # Si ya hay un curso seleccionado, responder con la ubicación desde la DB
                        try:
                            selected_course = get_selected_course(phone)
                            if selected_course and selected_course.get('id'):
                                from utils.courses_adapter import get_course_location_message
                                send_text_message(phone, get_course_location_message(selected_course.get('id')))
                                continue
                            else:
                                # No hay curso seleccionado, pedir al usuario el nombre o sugerir cursos
                                send_text_message(phone, "¿De qué curso quieres saber la ubicación? Dime el nombre del curso o pide que te recomiende según lo que quieras aprender.")
                                continue
                        except Exception:
                            # Fallback: mantener la respuesta genérica si ocurre un error
                            send_text_message(phone, "Dime el nombre del curso para indicarte la ubicación o si prefieres te recomiendo cursos según tu objetivo.")
                            continue
                    
                    # Detectar si el usuario está pidiendo información sobre un curso específico
                    course_selection_keywords = [
                        "quiero información sobre el curso", "me interesa el curso",
                        "dime más sobre el curso", "información del curso",
                        "detalles del curso", "más información del curso",
                        "me puedes dar información del curso", "sobre el curso de",
                        "curso de", "certificación en", "capacitación en",
                        "temario de", "precio del curso", "fechas del curso"
                    ]

                    # Si el mensaje parece referirse a un curso, intentar resolverlo mediante ML+DB
                    is_course_selection = any(keyword in (message_text or '').lower() for keyword in course_selection_keywords)
                    # Guard: si estamos en el flujo guiado del asesor, no intentar seleccionar cursos por nombre
                    waiting_for_advisor = get_conversation_memory(phone, 'waiting_for_advisor_data')
                    if waiting_for_advisor and is_course_selection:
                        logger.info(f"Skipping select_course_by_name because waiting_for_advisor_data is set for {phone}")
                    elif is_course_selection:
                        try:
                            # Usar el adaptador conversacional para identificar el curso (sin mappings predefinidos)
                            try:
                                from utils.courses_adapter import select_course_by_name
                            except Exception:
                                def select_course_by_name(phone, text):
                                    return {'selected': False, 'candidates': [], 'message': 'Funcionalidad de cursos deshabilitada.'}
                            sel = select_course_by_name(phone, message_text)
                            logger.info(f"Resultado select_course_by_name: {sel}")
                            if sel.get('selected') and sel.get('course'):
                                course = sel['course']
                                # Si es pregunta técnica, guardar como recomendación pendiente en memoria
                                if is_technical_question:
                                    try:
                                        save_conversation_memory(phone, 'pending_course_recommendation', {
                                            'id': getattr(course, 'id', None),
                                            'name': getattr(course, 'nombre', ''),
                                            'reason': 'detected_in_technical_query'
                                        })
                                        logger.info(f"Guardada recomendación pendiente para {phone}: {getattr(course,'nombre','')}")
                                    except Exception:
                                        logger.debug("No se pudo guardar pending_course_recommendation en memoria")
                                else:
                                    # Guardar selección formalmente
                                    try:
                                        save_selected_course(phone, getattr(course, 'id', None), getattr(course, 'nombre', ''), {"detected_from_message": message_text})
                                    except Exception:
                                        logger.debug("No se pudo guardar selected_course pero se continuará")
                        except Exception as e:
                            logger.debug(f"Error identificando curso mediante select_course_by_name: {e}")
                    
                    # Obtener información sobre el curso seleccionado anteriormente (si existe)
                    selected_course = get_selected_course(phone)

                    # Manejar respuestas afirmativas cortas (ej. "si", "sí", "ok")
                    try:
                        affirmative_regex = r"^\s*(si|sí|s|claro|ok|vale|por favor|porfa)\b.*$"
                        if isinstance(message_text, str) and re.match(affirmative_regex, message_text.lower()):
                            logger.info(f"Respuesta afirmativa detectada para {phone}: '{message_text}'")
                            # Check if we are specifically waiting for a course confirmation
                            waiting_confirmation = False
                            try:
                                waiting_confirmation = bool(get_conversation_memory(phone, "waiting_for_course_confirmation"))
                            except Exception:
                                waiting_confirmation = False

                            # Intentar enviar el temario si ya hay un curso seleccionado en la memoria
                            if waiting_confirmation and selected_course and not avoid_curso_intent and not is_technical_question:
                                try:
                                    # Buscar el PDF preferentemente por ID/nombre del curso en el contexto
                                    query_for_pdf = f"temario {selected_course.get('name', '')}"
                                    pdf_result = find_pdf_for_user_message(query_for_pdf, context={'relevant_courses': [selected_course]})
                                    if pdf_result and pdf_result.get('pdf_path'):
                                        pdf_path = pdf_result.get('pdf_path')
                                        caption = f"Temario {selected_course.get('name')}"
                                        logger.info(f"Enviando temario {pdf_path} a {phone} (confirmación del usuario)")
                                        send_document_message(phone, pdf_path, caption=caption)
                                        send_text_message(phone, f"Te envié el temario {selected_course.get('name')}. ¿Deseas que también te comparta fechas, precio y ubicación del curso?")
                                        # Limpiar la bandera de confirmación y continuar
                                        try:
                                            save_conversation_memory(phone, "waiting_for_course_confirmation", False)
                                        except Exception:
                                            logger.debug("No se pudo limpiar waiting_for_course_confirmation en memoria")
                                        continue
                                except Exception as e:
                                    logger.error(f"Error buscando/enviando PDF por confirmación: {e}", exc_info=True)
                            # Si no hay curso seleccionado, no hay PDF o no estábamos esperando confirmación, pedir clarificación
                            try:
                                # limpiar la bandera si existe para evitar confusión
                                save_conversation_memory(phone, "waiting_for_course_confirmation", False)
                            except Exception:
                                pass
                            send_text_message(phone, "¿A qué curso te refieres? Indícanos el nombre del curso (por ejemplo: 'Cableado estructurado') para enviarte el temario en PDF.")
                            continue
                    except Exception:
                        logger.debug("No se pudo procesar la posible respuesta afirmativa (continuando normalmente)")

                    # Detectar intención explícita de 'cursos' y enviar lista automáticamente
                    try:
                        if re.search(r"\bcurso(s)?\b", (message_text or '').lower()):
                            # Evitar spam si el usuario ya tiene un curso seleccionado
                            selected_course = get_selected_course(phone)
                            # Solo enviar la lista automáticamente si NO estamos evitando cursos
                            # y si no parece una pregunta técnica.
                            if not selected_course and not avoid_curso_intent and not is_technical_question:
                                logger.info(f"Enviando lista de cursos automáticamente a {phone} por intención detectada")
                                send_text_message(phone, list_courses_message())
                                continue

                    except Exception as e:
                        logger.error(f"Error al enviar lista de cursos automáticamente: {e}")

                    # --- Manejo de selección conversacional inteligente (sin números) ---
                    # Esta lógica ya no utiliza números, se basa en detección de intención natural
                    # La selección se maneja através de smart_course_selection_by_intent() más arriba
                    try:
                        # Mantener compatibilidad con números solo si el usuario los usa explícitamente
                        # pero preferir siempre la detección conversacional
                        from utils.courses_adapter import parse_course_number_from_text
                        num = parse_course_number_from_text(message_text or '')
                        if num and 1 <= num <= 5 and not avoid_curso_intent and not is_technical_question:
                            # Solo usar números si no se detectó por conversación natural antes
                            logger.info(f"Usuario seleccionó curso por número (fallback): {num} (phone={phone})")
                            try:
                                _CourseManager = CourseManager
                                course_obj = _CourseManager.get_course_by_id(num)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                save_selected_course(phone, num, course_name, {"selected_at": datetime.now().isoformat(), "method": "number_fallback"})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # Enviar detalles formateados
                            details = get_course_details_by_number(num)
                            send_text_message(phone, details)

                            # Si el usuario pidió explícitamente 'temario' en este mensaje, enviarlo
                            pdf_res = None
                            try:
                                if 'temario' in (message_text or '').lower():
                                    pdf_res = find_pdf_for_user_message(f"temario {num}")
                                else:
                                    # Pedir confirmación para enviar el temario
                                    send_text_message(phone, f"¿Te refieres al curso {course_name}? Responde 'sí' o escribe 'temario' para que te envíe el temario en PDF.")
                                    # Marcar en memoria que esperamos confirmación explícita del usuario
                                    try:
                                        save_conversation_memory(phone, "waiting_for_course_confirmation", True)
                                    except Exception:
                                        logger.debug("No se pudo guardar waiting_for_course_confirmation en memoria")
                            except Exception:
                                logger.debug("Skipping PDF search due to context/guard or error")

                            if pdf_res and pdf_res.get('pdf_path'):
                                try:
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario {pdf_res.get('course_name','')}")
                                    if send_result:
                                        logger.info(f"PDF enviado correctamente a {phone} para curso {num}: {pdf_res.get('pdf_path')}")
                                    else:
                                        logger.warning(f"Intento de envío de PDF devolvió resultado vacío/None para {phone} (curso {num})")
                                except Exception as e:
                                    logger.error(f"Error al enviar PDF del curso {num} a {phone}: {e}")
                            else:
                                logger.info(f"No se encontró PDF para el curso {num} o no se solicitó explícitamente")

                            # Ya respondimos a la selección, continuar con siguiente webhook
                            continue
                    except Exception as e:
                        logger.error(f"Error procesando selección numérica de curso: {e}", exc_info=True)
                    
                    # --- Manejo de selección por palabras clave específicas de cursos ---
                    try:
                        message_lower = (message_text or '').lower()
                        detected_course_id = None
                        
                        # Mapeo de palabras clave a IDs de curso con prioridades
                        course_keywords = {
                            1: ['cableado', 'estructurado', 'cobre'],
                            2: ['planta externa', 'exterior', 'outdoor'],
                            3: ['ftth', 'wisp', 'isp', 'gpon'],
                            4: ['ponlan', 'enterprise', 'empresarial', 'corporativo', 'pasivas'],
                            5: ['empalmes', 'otdr', 'mediciones', 'fusion']
                        }
                        
                        # Palabras clave únicas que identifican cursos específicos
                        unique_keywords = {
                            3: ['ftth'],
                            4: ['ponlan'],
                            5: ['otdr', 'empalmes'],
                            2: ['planta externa', 'fibra óptica externa'],
                            1: ['cableado estructurado']
                        }
                        
                        detected_course_id = None
                        
                        # Primero buscar términos únicos (prioridad alta)
                        for course_id, keywords in unique_keywords.items():
                            if any(keyword in message_lower for keyword in keywords):
                                detected_course_id = course_id
                                logger.info(f"Curso detectado por término único: {course_id} (palabras: {keywords})")
                                break
                        
                        # Si no hay términos únicos, buscar por palabras clave con mejor lógica
                        if not detected_course_id:
                            course_keywords = {
                                1: ['cableado', 'estructurado', 'cobre'],
                                2: ['planta externa', 'fibra óptica', 'exterior', 'outdoor', 'externa'],
                                3: ['ftth', 'wisp', 'isp', 'gpon'],
                                4: ['ponlan', 'enterprise', 'empresarial', 'corporativo', 'pasivas'],
                                5: ['empalmes', 'otdr', 'mediciones', 'fusion']
                            }
                            
                            course_scores = {}
                            
                            for course_id, keywords in course_keywords.items():
                                score = 0
                                for keyword in keywords:
                                    if keyword in message_lower:
                                        # Dar más peso a palabras más largas/menos comunes
                                        score += len(keyword) * 2
                                        # Bonus por palabras completas
                                        if f" {keyword} " in f" {message_lower} ":
                                            score += 10
                                        # Bonus por frases completas
                                        if keyword.replace(' ', '') in message_lower.replace(' ', ''):
                                            score += 5
                                
                                if score > 0:
                                    course_scores[course_id] = score
                            
                            # Seleccionar el curso con mayor puntuación
                            if course_scores:
                                detected_course_id = max(course_scores, key=course_scores.get)
                                logger.info(f"Curso detectado por puntuación: {detected_course_id} (scores: {course_scores})")
                            
                            # Seleccionar el curso con mayor puntuación
                            if course_scores:
                                detected_course_id = max(course_scores, key=course_scores.get)
                                logger.info(f"Curso detectado por puntuación: {detected_course_id} (scores: {course_scores})")
                        
                        # Si se detectó un curso por palabra clave, enviarlo (salvo que sea pregunta técnica)
                        if detected_course_id and not avoid_curso_intent:
                            if is_technical_question:
                                # Guardar como recomendación pendiente, no enviar ni seleccionar automáticamente
                                try:
                                    _CourseManager = CourseManager
                                    course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                    course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                    save_conversation_memory(phone, 'pending_course_recommendation', {'id': detected_course_id, 'name': course_name, 'reason': 'keyword_in_technical_query'})
                                    logger.info(f"Guardada recomendación pendiente (keyword) para {phone}: {course_name}")
                                except Exception:
                                    logger.debug("No se pudo guardar pending_course_recommendation (keyword) en memoria")
                                # Do not proceed with the normal course-details flow for technical queries
                                continue

                        if detected_course_id and not avoid_curso_intent and not is_technical_question:
                            logger.info(f"Usuario seleccionó curso por palabra clave: {detected_course_id} (phone={phone})")
                            # Guardar selección en memoria primero
                            try:
                                _CourseManager = CourseManager
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                _save_selected_course(phone, detected_course_id, course_name, {"selected_at": datetime.now().isoformat(), "suppress_llm": True})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # Enviar detalles formateados
                            details = get_course_details_by_number(detected_course_id)
                            send_text_message(phone, details)

                            # Cuando el usuario pide información específica de un curso (detectado por palabras clave),
                            # enviar el temario automáticamente sin pedir confirmación
                            pdf_res = None
                            try:
                                pdf_res = find_pdf_for_user_message(f"temario {detected_course_id}")
                            except Exception:
                                logger.debug("No se pudo buscar PDF del temario")

                            if pdf_res and pdf_res.get('pdf_path'):
                                try:
                                    send_result = send_document_message(phone, pdf_res['pdf_path'], caption=f"Temario completo: {course_name}")
                                    if send_result:
                                        logger.info(f"PDF enviado correctamente a {phone} para curso {detected_course_id}: {pdf_res.get('pdf_path')}")
                                        send_text_message(phone, "Te envié el temario en PDF. ¿Te gustaría saber sobre fechas, precio o ubicación del curso?")
                                    else:
                                        logger.warning(f"Intento de envío de PDF devolvió resultado vacío/None para {phone} (curso {detected_course_id})")
                                        send_text_message(phone, "El temario está disponible. ¿Te gustaría que te enviara más información sobre fechas, precio o ubicación?")
                                except Exception as e:
                                    logger.error(f"Error al enviar PDF del curso {detected_course_id} a {phone}: {e}")
                                    send_text_message(phone, "El temario está disponible. ¿Te gustaría que te enviara más información sobre fechas, precio o ubicación?")
                            else:
                                send_text_message(phone, "El temario detallado está disponible. ¿Te gustaría que te enviara más información sobre fechas, precio o ubicación?")

                            # Guardar selección en la memoria de conversación
                            try:
                                _CourseManager = CourseManager
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                course_obj = _CourseManager.get_course_by_id(detected_course_id)
                                course_name = getattr(course_obj, 'nombre', '') if course_obj else ''
                                # Guardar selección y suprimir la generación inmediata del LLM
                                _save_selected_course(phone, detected_course_id, course_name, {"selected_at": datetime.now().isoformat(), "suppress_llm": True})
                            except Exception:
                                logger.debug("No se pudo guardar curso seleccionado en memoria")

                            # No enviar mensaje adicional - ya está incluido en get_course_details_by_number()
                            # Ya respondimos a la selección, continuar con siguiente webhook
                            continue
                    except Exception as e:
                        logger.error(f"Error procesando selección por palabra clave: {e}", exc_info=True)
                    
                    # Generar respuesta con memoria y contexto adicional (curso)
                    # El system_prompt_override toma precedencia sobre el system_prompt del adaptador ML
                    system_prompt = system_prompt_override or ml_adapter_result.get('system_prompt')
                    
                    # Incorporar información del curso seleccionado en el system prompt si está disponible
                    if selected_course and not system_prompt_override and not avoid_curso_intent:
                        # Crear contexto enriquecido con información del curso seleccionado
                        course_context = (
                            f"\nINFORMACIÓN IMPORTANTE: El usuario ha seleccionado o mostrado interés en el "
                            f"curso '{selected_course['name']}' previamente. "
                            f"Puedes referirte a este curso específicamente cuando sea relevante para la conversación. "
                            f"Si la consulta actual del usuario está relacionada con este curso, proporciona información detallada y relevante. "
                            f"Si la consulta no está relacionada con este curso, responde adecuadamente pero mantén en cuenta este interés previo."
                        )
                        
                        # Añadir el contexto al system prompt
                        if system_prompt:
                            system_prompt = system_prompt + course_context
                        else:
                            system_prompt = (
                                "Eres un asistente experto en fibra óptica y telecomunicaciones. "
                                "Responde de manera clara, precisa y profesional a las consultas de los usuarios. "
                                + course_context
                            )
                        
                        logger.info(f"System prompt enriquecido con contexto de curso seleccionado para {phone}")
                    
                    # Si tenemos una anulación del system_prompt, registrarlo
                    if system_prompt_override:
                        logger.info(f"Usando system_prompt_override: {system_prompt_override[:50]}...")

                    # Si el curso seleccionado indica que debemos suprimir la generación LLM
                    try:
                        selected_course = get_selected_course(phone)
                        if selected_course and isinstance(selected_course.get('details', {}), dict) and selected_course.get('details', {}).get('suppress_llm'):
                            # Limpiar la bandera para que en la siguiente interacción sí pueda generarse LLM normalmente
                            selected_course['details'].pop('suppress_llm', None)
                            # Guardar la memoria actualizada sin la bandera
                            try:
                                from services.conversation_memory import save_selected_course as _save_selected_course
                                _save_selected_course(phone, selected_course.get('id'), selected_course.get('name', ''), selected_course.get('details', {}))
                            except Exception:
                                logger.debug("No se pudo actualizar la marca suppress_llm en memoria")
                            # Saltar la generación LLM para esta petición (ya respondimos con la info del curso)
                            logger.info(f"Supressing LLM generation for phone={phone} due to recent course info send")
                            continue
                    except Exception:
                        # En caso de cualquier fallo, no bloquear la generación normal
                        logger.debug("No se pudo verificar la bandera suppress_llm (continuando)")
                    
                    # Medir tiempo de generación de respuesta
                    start_response_time = datetime.now()

                    # Detectar explícitamente si la intención del usuario es sobre CURSOS
                    # y responder directamente desde la fuente canónica (constants.js / DB)
                    # para evitar que el LLM invente fechas, precios o duraciones.
                    skip_gemini = False
                    try:
                        def _detect_course_intent(text: str):
                            t = (text or '').lower()
                            # Palabras clave que indican interés en cursos
                            course_kw = [
                                'curso', 'cursos', 'temario', 'capacitación', 'capacitacion', 'formacion', 'formación',
                                'inscribirme', 'inscripción', 'inscripcion', 'precio', 'precio del curso', 'costo', 'fechas',
                                'duración', 'duracion', 'modalidad', 'temario', 'programa', 'contenido', 'inscripción',
                                'dónde se imparte', 'donde se imparte', 'fecha del curso', 'próximo curso', 'proximo curso',
                                'recomien', 'sugier', 'estudiar', 'aprender', 'certificar', 'entrenar', 'capacitar',
                                'cursos tienes', 'cursos disponibles', 'opciones de curso', 'que me recomiendas',
                                'cual me conviene', 'que curso', 'interesado en curso', 'busco curso'
                            ]

                            # Indicadores técnicos que deben anular intención de curso
                            technical_kw = [
                                'cómo', 'como', 'cuál', 'cual', 'qué', 'que', 'instalación', 'instalacion', 'configuración',
                                'configuracion', 'problema', 'error', 'empalme', 'otdr', 'mediciones', 'atenuación', 'atenuacion',
                                'conector', 'fusión', 'fusion', 'falla', 'no funciona', 'diagnóstico', 'diagnostico'
                            ]

                            course_score = sum(1 for k in course_kw if k in t)
                            technical_score = sum(1 for k in technical_kw if k in t)

                            # Dar más peso a frases claras
                            clear_course = ['quiero inscribirme', 'información sobre el curso', 'quiero tomar el curso', 'fechas del curso', 'precio del curso']
                            clear_tech = ['cómo funciona', 'cómo se hace', 'como funciona', 'como se hace', 'ayúdame con', 'ayudame con']
                            for phrase in clear_course:
                                if phrase in t:
                                    course_score += 3
                            for phrase in clear_tech:
                                if phrase in t:
                                    technical_score += 3

                            # Decisión
                            user_asks_courses = course_score > 0 and course_score >= technical_score
                            if technical_score > course_score + 1:
                                user_asks_courses = False

                            is_tech = technical_score > course_score
                            return user_asks_courses, is_tech

                        user_asking_about_courses, is_technical_question = _detect_course_intent(message_text)

                        # Solo enviar información de cursos si el usuario hace una petición explícita
                        explicit_course_request = False
                        try:
                            tlower = (message_text or '').lower()
                            explicit_course_request = bool(re.search(r"\b(curso|cursos|temario|inscribirme|inscripción|inscripcion|precio|fechas|dónde se imparte|donde se imparte|quiero inscribirme|quiero tomar el curso|recomien|sugier|capacitación|capacitacion|entrenam|aprend|estudi)\b", tlower))
                        except Exception:
                            explicit_course_request = False

                        if user_asking_about_courses and not is_technical_question and explicit_course_request:
                            logger.info(f"Usuario preguntando explícitamente sobre cursos detectado. Usando datos oficiales para {phone}.")
                            
                            # Detectar si es una consulta general de recomendación o curso específico
                            is_general_inquiry = any(word in message_text.lower() for word in [
                                'recomien', 'sugier', 'cual me conviene', 'que curso', 'cursos tienes', 
                                'cursos disponibles', 'opciones de curso', 'que me recomiendas'
                            ])
                            
                            if selected_course and not is_general_inquiry:
                                # Responder sobre el curso seleccionado
                                from utils.courses_adapter import get_course_full_details_message
                                respuesta = f"Información del curso seleccionado '{selected_course.get('name', '')}':\n\n"
                                respuesta += get_course_full_details_message(selected_course.get('id'))
                            elif is_general_inquiry or not selected_course:
                                # Responder con recomendaciones generales
                                from utils.courses_adapter import get_courses_recommendation_message
                                respuesta = get_courses_recommendation_message(message_text)
                            else:
                                # Fallback a formato básico
                                respuesta = format_course_for_whatsapp(selected_course.get('details') if selected_course else None)
                            
                            # Enviar la respuesta basada en JSON/DB y evitar llamar al LLM
                            send_text_message(phone, respuesta)
                            # Continuar con el siguiente mensaje del webhook (ya respondimos)
                            continue
                    except Exception as e:
                        logger.error(f"Error preparando respuesta basada en JSON de cursos: {e}", exc_info=True)

                    try:
                        # --- Sistema mejorado de contexto de cursos ---
                        enhanced_response = None
                        if 'contextual_response' in ml_adapter_result and ml_adapter_result.get('contextual_response', {}).get('enhanced_response'):
                            contextual_data = ml_adapter_result['contextual_response']
                            logger.info(f"Usando respuesta contextual mejorada para {phone} con intención: {contextual_data.get('intent', 'unknown')}")
                            
                            # Usar la respuesta contextual mejorada
                            enhanced_response = contextual_data.get('message', '')
                            
                            # Agregar preguntas de seguimiento si están disponibles
                            if contextual_data.get('follow_up_questions'):
                                enhanced_response += "\n\n¿Te gustaría saber más sobre:\n"
                                for i, question in enumerate(contextual_data['follow_up_questions'], 1):
                                    enhanced_response += f"• {question}\n"
                            
                            # Agregar acciones sugeridas si están disponibles
                            if contextual_data.get('suggested_actions'):
                                enhanced_response += "\n\nTambién puedo ayudarte con:\n"
                                for action in contextual_data['suggested_actions'][:3]:  # Max 3 acciones
                                    enhanced_response += f"📌 {action}\n"
                        
                        # Usar respuesta mejorada si está disponible, sino usar Gemini
                        if enhanced_response and len(enhanced_response.strip()) > 20:
                            respuesta = enhanced_response
                            logger.info(f"Usando respuesta contextual mejorada ({len(respuesta)} chars)")
                        elif not skip_gemini:
                            # 🤖 Usar chat con contexto enriquecido ML-first
                            if 'contextual_prompt' in locals() and contextual_prompt:
                                selected_prompt = contextual_prompt
                                logger.info(f"🎯 Usando prompt contextual generado por ML para intent: {user_intent_type}")
                            elif system_prompt_override:
                                selected_prompt = system_prompt_override
                            elif user_intent_type in intent_prompts:
                                selected_prompt = intent_prompts[user_intent_type]
                                logger.info(f"Usando prompt específico para intent: {user_intent_type}")
                            else:
                                selected_prompt = system_prompt  # Fallback al prompt original
                            
                            # Usar chat con contexto enriquecido
                            respuesta = enhanced_chat_with_context(phone, message_text, selected_prompt)
                        
                        # Medir tiempo de respuesta para monitoreo
                        response_time = (datetime.now() - start_response_time).total_seconds()
                        logger.info(f"Respuesta generada en {response_time:.2f} segundos")
                        
                        # Verificar si la respuesta es válida
                        if not respuesta or len(respuesta.strip()) < 10:
                            logger.warning(f"Respuesta inválida o muy corta: '{respuesta}'")
                            respuesta = "Lo siento, estoy teniendo dificultades para procesar tu consulta en este momento. ¿Podrías reformular tu pregunta?"

                        # Verificar si venimos de una solicitud de asesor completada recientemente
                        last_action = get_conversation_memory(phone, "last_action")
                        if last_action == "advisor_request_completed":
                            # Limpiar este estado para futuras interacciones
                            save_conversation_memory(phone, "last_action", None)
                            # Limpiar también cualquier contexto adicional que pudiera causar mensajes repetidos
                            save_conversation_memory(phone, "waiting_for_advisor_data", False)
                            save_conversation_memory(phone, "advisor_data", None)
                            logger.info(f"Detectado mensaje después de solicitud de asesor para {phone}")
                        
                        # Re-evaluar específicamente si el usuario pedía información sobre CURSOS
                        # (esto captura casos donde la detección previa falló). Si es así, forzamos
                        # la respuesta desde la fuente canónica (constants.js / DB) para evitar
                        # que la IA invente fechas, precios o duraciones.
                        try:
                            try:
                                user_asks_courses, is_tech_q = _detect_course_intent(message_text)
                            except Exception:
                                # Fallback simple
                                t = (message_text or '').lower()
                                user_asks_courses = any(k in t for k in ['curso', 'temario', 'fechas', 'precio', 'inscrib'])
                                is_tech_q = False

                            if user_asks_courses and not is_technical_question and explicit_course_request:
                                logger.info(f"Post-check: Usuario preguntando sobre cursos. Respondiendo desde fuente canónica para {phone}.")
                                
                                # Detectar si es una consulta general de recomendación o curso específico
                                is_general_inquiry = any(word in message_text.lower() for word in [
                                    'recomien', 'sugier', 'cual me conviene', 'que curso', 'cursos tienes', 
                                    'cursos disponibles', 'opciones de curso', 'que me recomiendas'
                                ])
                                
                                if selected_course and not is_general_inquiry:
                                    # Responder sobre el curso seleccionado
                                    from utils.courses_adapter import get_course_full_details_message
                                    respuesta = f"Información del curso seleccionado '{selected_course.get('name', '')}':\n\n"
                                    respuesta += get_course_full_details_message(selected_course.get('id'))
                                elif is_general_inquiry or not selected_course:
                                    # Responder con recomendaciones generales
                                    from utils.courses_adapter import get_courses_recommendation_message
                                    respuesta = get_courses_recommendation_message(message_text)
                                else:
                                    # Fallback a formato básico
                                    respuesta = format_course_for_whatsapp(selected_course.get('details') if selected_course else None)
                                
                                # Enviar la respuesta basada en JSON/DB y evitar llamar al LLM
                                send_text_message(phone, respuesta)
                                # Continuar con el siguiente mensaje del webhook (ya respondimos)
                                continue
                        except Exception as e:
                            logger.error(f"Error re-evaluando intención de cursos: {e}", exc_info=True)
                    except Exception as gemini_error:
                        logger.error(f"Error generando respuesta con Gemini: {gemini_error}", exc_info=True)
                        # Proporcionar una respuesta genérica en caso de error
                        respuesta = "Disculpa, estoy experimentando problemas técnicos en este momento. Por favor, intenta nuevamente en unos minutos."
                    
                    # Evitar reenviar exactamente el mismo texto que envió el usuario
                    try:
                        if respuesta and isinstance(respuesta, str) and respuesta.strip() == message_text.strip():
                            logger.warning('La IA devolvió el mismo texto que el usuario; usar mensaje de aclaración en su lugar')
                            respuesta = 'Perdona, no entendí del todo. ¿Puedes dar más detalles o reformular tu pregunta?'
                            
                        # Detectar si estamos atascados en cursos cuando el usuario no está preguntando sobre ellos
                        # Usamos una detección más sofisticada para distinguir entre preguntas técnicas y solicitudes de cursos
                        
                        # Palabras que indican específicamente interés en CURSOS (no en temas técnicos de fibra)
                        curso_keywords_in_user = [
                            'curso', 'cursos', 'temario', 'capacitación', 'quiero aprender', 
                            'formación', 'certificación', 'inscribirme', 'costo del curso',
                            'cuándo inicia el curso', 'próximo curso', 'proximo curso',
                            'inscribir', 'inscripción', 'estudiar', 'tomar el curso', 
                            'asistir al curso', 'matricularme', 'modalidad del curso',
                            'precio del curso', 'duración del curso', 'horario del curso'
                        ]
                        
                        # Patrones que indican consultas TÉCNICAS (no sobre cursos)
                        technical_question_patterns = [
                            # Términos de pregunta técnica
                            'cómo', 'cuál es', 'qué tipo', 'diferencia entre', 'recomiendas', 'problema con',
                            'instalación', 'configuración', 'mejor', 'ventajas', 'desventajas', 'comparación',
                            
                            # Términos técnicos específicos de fibra y telecomunicaciones
                            'backbone', 'vertical', 'hotel', 'loose tube', 'tight buffer', 'tipo de fibra',
                            'fibra monomodo', 'fibra multimodo', 'atenuación', 'conector', 'empalme', 'fusión',
                            'otdr', 'power meter', 'presupuesto óptico', 'pérdida', 'banda', 'longitud de onda',
                            'single mode', 'multimode', 'patch cord', 'pigtail', 'roseta', 'caja de empalme',
                            'splitter', 'divisor', 'rack', 'odf', 'distribuidor', 'pon', 'gpon', 'ftth', 'fttb',
                            'fttx', 'bandwidth', 'ancho de banda', 'latencia', 'distancia máxima', 'transmisión',
                            'switch', 'router', 'gateway', 'olt', 'onu', 'ont', 'cable', 'ducto', 'canalización',
                            'poste', 'aérea', 'subterránea', 'cableado', 'networking', 'red', 'diagrama',
                            'arquitectura', 'topología', 'escalabilidad', 'rendimiento', 'velocidad', 'gigabit',
                            'terabit', 'potencia', 'dbm', 'especificaciones', 'estándar', 'protocolos',
                            
                            # Palabras que indican problemas o consultas técnicas
                            'error', 'falla', 'problema', 'no funciona', 'cómo resolver', 'cómo arreglar',
                            'solución para', 'diagnóstico', 'mantenimiento', 'reparación', 'optimización',
                            'mejora', 'recomendación', 'consejo técnico', 'sugerencia', 'mejor práctica',
                            'cuál recomiendas', 'cómo puedo', 'cómo debo', 'necesito ayuda con', 'duda sobre'
                        ]
                        
                        # Palabras que indican que el bot está hablando de CURSOS
                        curso_keywords_in_response = [
                            'curso', 'temario', 'certificación', 'capacitación', 
                            'clases', 'formación', 'aprender', 'modalidad presencial',
                            'fechas', 'próximas fechas', 'precio del curso', 'inscripción',
                            'instructor', 'material didáctico', 'programa', 'contenido del curso',
                            'modalidad', 'presencial', 'online', 'virtual', 'híbrido',
                            'calendario de cursos', 'próxima edición', 'curso disponible',
                            'horarios', 'días de clase', 'aprenderás', 'te capacitarás',
                            'inscribirte', 'registrarte', 'cupo limitado', 'participantes'
                        ]
                        
                        # Verificar si el usuario está haciendo una pregunta técnica específica
                        # Utilizamos una puntuación para determinar qué tan técnica es la pregunta
                        technical_score = 0
                        course_score = 0
                        
                        # Analizar patrones técnicos (cada coincidencia suma 1 punto)
                        for pattern in technical_question_patterns:
                            if pattern in message_text.lower():
                                technical_score += 1
                        
                        # Analizar patrones de curso (cada coincidencia suma 1 punto)
                        for keyword in curso_keywords_in_user:
                            if keyword in message_lower:
                                course_score += 1
                                
                        # Análisis semántico mejorado
                        message_lower = message_text.lower()
                        
                        # Frases específicas que indican claramente que es una pregunta técnica
                        clear_technical_indicators = [
                            "cómo funciona", "cómo se hace", "explícame", "problema técnico", 
                            "error en", "no está funcionando", "ayúdame con", "duda técnica",
                            "cómo puedo resolver", "cómo solucionar"
                        ]
                        
                        # Frases específicas que indican claramente interés en cursos
                        clear_course_indicators = [
                            "quiero inscribirme", "información sobre el curso", "quiero tomar el curso", "fechas del curso", "precio del curso"
                        ]
                        
                        # Dar mayor peso a indicadores claros
                        for indicator in clear_technical_indicators:
                            if indicator in message_lower:
                                technical_score += 3  # Mayor peso para indicadores claros
                        
                        for indicator in clear_course_indicators:
                            if indicator in message_lower:
                                course_score += 3  # Mayor peso para indicadores claros
                        
                        # Determinar el tipo de pregunta basado en las puntuaciones
                        # Mayor umbral para considerar que está preguntando sobre cursos
                        is_technical_question = technical_score > course_score
                        # Requerir al menos 2 puntos de curso y una diferencia positiva respecto a técnico
                        user_asking_about_courses = course_score >= 2 and course_score > technical_score
                        
                        # Depuración de la detección
                        logger.info(f"Detección de tema - Técnico: {technical_score}, Cursos: {course_score}")
                        logger.info(f"Resultado: Técnico={is_technical_question}, Curso={user_asking_about_courses}")
                        
                        # Si la pregunta es claramente técnica, no considerarla como pregunta sobre cursos
                        # incluso si tiene algunas menciones de cursos
                        if technical_score > course_score:  # Si hay cualquier diferencia a favor de técnico
                            user_asking_about_courses = False
                            logger.info("Pregunta técnica detectada, ignorando menciones de cursos")
                            
                        # Verificar si el bot está hablando de cursos en su respuesta
                        # Contamos la frecuencia de palabras relacionadas con cursos para evaluar qué tan centrada
                        # está la respuesta en cursos
                        course_keyword_count = sum(1 for keyword in curso_keywords_in_response if keyword in respuesta.lower())
                        bot_talking_about_courses = course_keyword_count >= 2  # Necesitamos al menos 2 menciones para considerarlo "hablando de cursos"
                        
                        # Detección mejorada de casos problemáticos:
                        # 1. Usuario NO pregunta sobre cursos pero el bot SÍ habla de ellos (error más común)
                        # 2. Usuario hace una pregunta TÉCNICA pero el bot responde con cursos (el caso del ejemplo)
                        # 3. Detectar también cuando hablamos demasiado de cursos en la respuesta
                        
                        # Análisis más detallado del contenido de la respuesta
                        is_course_fixated = False
                        
                        # Verificar si hay una alta concentración de palabras sobre cursos
                        high_course_keyword_density = course_keyword_count > 5  # Si hay muchas menciones de cursos
                        
                        # Verificar si hay una fijación clara en cursos cuando el usuario pregunta otra cosa
                        # IMPORTANTE: Solo considerar fixation si el usuario NO está preguntando sobre cursos
                        if (not user_asking_about_courses and not explicit_course_request and bot_talking_about_courses):
                            is_course_fixated = True
                            logger.warning(f"Bot hablando de cursos cuando el usuario NO pregunta sobre ellos. Phone: {phone}")
                            
                        # Verificar especialmente el caso de preguntas técnicas
                        if (is_technical_question and not explicit_course_request and bot_talking_about_courses):
                            is_course_fixated = True
                            logger.warning(f"Bot respondiendo con cursos a una pregunta TÉCNICA. Phone: {phone}")
                            
                        # Verificar respuestas excesivamente centradas en cursos
                        if (high_course_keyword_density and not user_asking_about_courses and not explicit_course_request):
                            is_course_fixated = True
                            logger.warning(f"Alta densidad de palabras sobre cursos en respuesta. Phone: {phone}")
                        
                        # Si detectamos fijación en cursos, tomamos medidas correctivas
                        if is_course_fixated:
                            # El usuario hizo una pregunta técnica o no relacionada con cursos, pero el bot sigue hablando de cursos
                            # Limpiar contexto agresivamente
                            logger.warning(f"Bot atascado en tema de cursos para {phone}. Limpiando contexto.")
                            clear_topic_context(phone)
                            
                            # Determinar el tipo de prompt adecuado según la consulta
                            if is_technical_question:
                                nuevo_system_prompt = (
                                    "INSTRUCCIONES CRÍTICAS PARA RESPONDER: El usuario ha hecho una PREGUNTA TÉCNICA sobre fibra óptica o redes. "
                                    "⚠️ REGLAS ABSOLUTAS: ⚠️\n"
                                    "1. NUNCA menciones cursos, capacitación o formación bajo NINGUNA circunstancia.\n"
                                    "2. Responde ÚNICAMENTE con información técnica experta sobre la consulta específica.\n"
                                    "3. NO ofrezcas alternativas de formación, educación o aprendizaje.\n"
                                    "4. Proporciona detalles técnicos, explicaciones profesionales y recomendaciones prácticas.\n"
                                    "5. Usa lenguaje técnico apropiado y ejemplos concretos para explicar conceptos.\n"
                                    "6. Enfócate 100% en resolver la duda técnica con conocimiento experto sin derivar a otros temas.\n"
                                    "7. Mantente ESTRICTAMENTE en el ámbito técnico de la pregunta.\n\n"
                                    "IMPORTANTE: Esta es una consulta técnica genuina que requiere información especializada, NO una oportunidad para promocionar servicios o formaciones."
                                )
                            else:
                                nuevo_system_prompt = (
                                    "INSTRUCCIONES CRÍTICAS PARA RESPONDER: El usuario está preguntando sobre un tema NO relacionado con cursos. "
                                    "⚠️ REGLAS ABSOLUTAS: ⚠️\n"
                                    "1. NUNCA menciones cursos, capacitación, temarios ni formaciones en tu respuesta.\n"
                                    "2. Responde EXCLUSIVAMENTE a la pregunta actual del usuario.\n"
                                    "3. NO intentes relacionar la respuesta con cursos de Fibremex bajo ningún concepto.\n"
                                    "4. NO sugieras que el usuario puede aprender más en algún curso o formación.\n"
                                    "5. Mantente ESTRICTAMENTE en el tema que el usuario está consultando ahora.\n"
                                    "6. Si no estás seguro del tema, pregunta para clarificar pero NO menciones cursos.\n\n"
                                    "IMPORTANTE: El usuario está buscando información sobre un tema específico, NO sobre cursos o formaciones."
                                )
                            
                            # Marcar claramente que estamos ignorando el histórico de conversación
                            nuevo_system_prompt += "\n\nCAMBIO DE TEMA: Ignora completamente el historial de conversación previo y responde únicamente a la consulta actual como si fuera una nueva conversación."
                            
                            # Regenerar la respuesta con el system prompt ajustado
                            respuesta = chat_with_gemini(
                                phone=phone,
                                message=message_text,
                                system_prompt=nuevo_system_prompt,
                                include_whatsapp_profile=whatsapp_profile
                            )
                            
                            # Verificar que la nueva respuesta no siga hablando de cursos
                            new_course_mentions = sum(1 for keyword in curso_keywords_in_response if keyword in respuesta.lower())
                            if new_course_mentions > 1:
                                logger.warning(f"La respuesta regenerada SIGUE hablando de cursos. Haciendo un segundo intento más agresivo.")
                                
                                # Segundo intento aún más agresivo
                                ultimo_system_prompt = (
                                    "⚠️⚠️ ATENCIÓN CRÍTICA ⚠️⚠️\n"
                                    "NO MENCIONES CURSOS, CLASES, CAPACITACIONES, FORMACIONES O CUALQUIER SERVICIO EDUCATIVO.\n"
                                    "El usuario NO está preguntando sobre cursos. Responde directamente a su consulta sin ninguna referencia a educación o formación.\n\n"
                                    "RESPONDE ÚNICAMENTE SOBRE: " + message_text + "\n\n"
                                    "NO INCLUYAS NINGUNA PALABRA RELACIONADA CON EDUCACIÓN, APRENDIZAJE O FORMACIÓN EN TU RESPUESTA."
                                )
                                
                                respuesta = chat_with_gemini(
                                    phone=phone,
                                    message=message_text,
                                    system_prompt=ultimo_system_prompt,
                                    include_whatsapp_profile=False  # Omitir el perfil para evitar contexto adicional
                                )
                            
                            # Agregar un mensaje de transición adecuado al inicio
                            mensaje_transicion = "Permíteme responder directamente a tu consulta:\n\n"
                            respuesta = mensaje_transicion + respuesta
                            
                    except Exception as e:
                        # En caso de problemas de comparación, simplemente continuar
                        logger.error(f"Error verificando respuesta repetitiva: {e}")

                    logger.info(f"Respuesta generada: {respuesta[:50]}...")
                    
                    # Enviar respuesta y registrar la acción con manejo de errores
                    logger.info(f"Enviando respuesta a {f'PHONE_XXXXX{str(phone)[-4:]}'}, longitud={len(respuesta)}")
                    
                    # Usar el número real (sin sanitizar) para el envío
                    send_result = send_text_message(phone, respuesta)
                    
                    if send_result:
                        logger.info(f"Respuesta enviada exitosamente a {f'PHONE_XXXXX{str(phone)[-4:]}'}")
                        
                        # Registrar estadísticas del mensaje para monitoreo
                        log_webhook_event("message_sent", {
                            "phone": f"PHONE_XXXXX{str(phone)[-4:]}",  # Sanitizado
                            "response_length": len(respuesta),
                            "processing_time_ms": int((datetime.now() - processing_start_time).total_seconds() * 1000),
                            "message_id": message_id
                        })
                    else:
                        logger.error(f"FALLÓ el envío del mensaje a {f'PHONE_XXXXX{str(phone)[-4:]}'}")
                        # Si falla el envío, registrar el error
                        log_webhook_event("message_send_failed", {
                            "phone": f"PHONE_XXXXX{str(phone)[-4:]}",  # Sanitizado
                            "error": "Error de envío - revisar logs anteriores",
                            "message_id": message_id
                        }, level="error")
        
        return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        # Registro detallado de errores para facilitar la depuración
        logger.error(f"Error procesando webhook: {e}", exc_info=True)
        
        # Registrar evento de error de forma estructurada
        error_details = {
            "error_type": type(e).__name__,
            "error_message": str(e),
            "traceback": traceback.format_exc(),
            "request_headers": {k: v for k, v in request.headers.items()},
            "request_method": request.method,
            "request_path": request.path,
            "request_remote_addr": request.remote_addr
        }
        
        log_webhook_event("webhook_error", error_details, level="error")
        
        # Evitar exponer detalles internos en la respuesta al cliente
        return jsonify({"status": "error", "message": "Error interno al procesar el webhook"}), 500
    finally:
        # Clear current webhook message id guard (in case it was set)
        try:
            globals()['_CURRENT_WEBHOOK_MESSAGE_ID'] = None
        except Exception:
            pass
