"""
Manejadores para envío de mensajes de WhatsApp
"""
import requests
import logging
import os
import mimetypes
import traceback
from typing import Optional, Dict, Any
from urllib.parse import urljoin
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE
)

logger = logging.getLogger(__name__)

# Runtime guard to avoid duplicate sends for the same incoming webhook message
# _CURRENT_WEBHOOK_MESSAGE_ID is set while processing a single incoming message
# _SENT_RESPONSES stores message_ids for which we've already sent a reply in this process
_CURRENT_WEBHOOK_MESSAGE_ID = None
_SENT_RESPONSES = set()


def send_text_message(to, text):
    """Envía un mensaje de texto a través de WhatsApp API"""
    # Prevent duplicate replies for the same incoming webhook message
    try:
        current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
        if current_id and current_id in globals().get('_SENT_RESPONSES', set()):
            logger.debug(f"Preventing duplicate reply for message {current_id}")
            return None
    except Exception:
        pass

    # Prevent unsolicited/proactive sends unless explicitly allowed via environment
    try:
        current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
        allow_proactive = os.environ.get('ALLOW_PROACTIVE_WA', '').lower() in ('1', 'true', 'yes')
        if not current_id and not allow_proactive:
            logger.warning('Blocked outbound WhatsApp send without active webhook message (set ALLOW_PROACTIVE_WA=true to override)')
            return None
    except Exception:
        # If guard fails, fall back to safe behavior (do not send)
        return None
        
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.error("Credenciales de WhatsApp no configuradas")
        return None
        
    # Check for empty or None text
    if not text:
        logger.warning(f"Attempted to send empty message to {to}")
        return None
        
    # WhatsApp has a message length limit (~4,000 characters)
    MAX_MESSAGE_LENGTH = 4000
    
    if len(text) <= MAX_MESSAGE_LENGTH:
        # Mensaje normal, enviar directamente
        result = _send_single_text_message(to, text)
        if result:
            # Mark this incoming message as replied to
            try:
                current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
                if current_id:
                    globals().setdefault('_SENT_RESPONSES', set()).add(current_id)
            except Exception:
                pass
        else:
            logger.error("Failed to send text message")
        return result
    else:
        # Mensaje largo: truncar para enviar solo UN mensaje y ofrecer continuar.
        logger.info(f"Mensaje largo detectado ({len(text)} chars), truncando para un solo envío...")
        truncated = text[:MAX_MESSAGE_LENGTH - 200].rstrip()
        truncated += "\n\n[Mensaje resumido — responde 'continuar' para que amplíe esta respuesta.]"
        result = _send_single_text_message(to, truncated)
        if result:
            # Mark as replied and save the full text for potential continuation
            try:
                current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
                if current_id:
                    globals().setdefault('_SENT_RESPONSES', set()).add(current_id)
            except Exception:
                pass
        else:
            logger.error("Failed to send truncated message")
        return result


def _send_single_text_message(to, text):
    """Envía un único mensaje de texto a través de WhatsApp API"""
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.error("Credenciales de WhatsApp no configuradas")
        return None

    # Validar formato del número mexicano
    if not isinstance(to, str) or not to.startswith('521') or len(to) != 13:
        logger.error(f"Formato de número inválido: {to}. Debe ser '521XXXXXXXXXX'")
        return None

    # Check for empty or None text
    if not text or not text.strip():
        logger.warning(f"Attempted to send empty message to {f'PHONE_XXXXX{str(to)[-4:]}'}")
        return None

    url = f"{WHATSAPP_API_BASE}{WHATSAPP_PHONE_NUMBER_ID}/messages"

    headers = {
        'Authorization': f'Bearer {WHATSAPP_TOKEN}',
        'Content-Type': 'application/json'
    }

    # Payload corregido para WhatsApp Business API México
    payload = {
        'messaging_product': 'whatsapp',
        'recipient_type': 'individual',
        'to': to,
        'type': 'text',
        'text': {
            'preview_url': False,
            'body': text.strip()
        }
    }

    try:
        import requests
        logger.info(f"Sending WhatsApp message to {f'PHONE_XXXXX{str(to)[-4:]}'}")
        logger.debug(f"Payload completo: {payload}")
        logger.debug(f"Headers (sin token): {{'Authorization': 'Bearer ***', 'Content-Type': 'application/json'}}")

        response = requests.post(url, json=payload, headers=headers, timeout=30)
        
        logger.info(f"Status Code recibido: {response.status_code}")
        logger.debug(f"Respuesta completa: {response.text}")

        if response.status_code == 200:
            logger.info(f"Mensaje enviado exitosamente a {f'PHONE_XXXXX{str(to)[-4:]}'}")
            return response.json()
        else:
            logger.error(f"Error enviando mensaje. Status: {response.status_code}, Response: {response.text}")
            return None

    except requests.exceptions.RequestException as e:
        logger.error(f"Error de conexión enviando mensaje de WhatsApp: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Error inesperado enviando mensaje de WhatsApp: {str(e)}")
        return None


def _upload_media(file_path: str) -> Optional[str]:
    """Upload a file to WhatsApp media endpoint and return media_id if successful."""
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.warning('_upload_media: WhatsApp credentials not configured; skipping upload')
        return None

    # Endpoint: /{phone-number-id}/media
    url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/media")
    headers = {'Authorization': f'Bearer {WHATSAPP_TOKEN}'}

    try:
        if not os.path.exists(file_path):
            logger.error(f'_upload_media: file does not exist: {file_path}')
            return None
            
        # Determinar el tipo MIME basado en la extensión del archivo
        file_name = os.path.basename(file_path)
        mime_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'
        
        # Para PDFs asegurar que usamos application/pdf
        if file_path.lower().endswith('.pdf'):
            mime_type = 'application/pdf'
            
        logger.info(f"Subiendo archivo {file_name} con tipo MIME {mime_type}")
        
        with open(file_path, 'rb') as f:
            files = {
                'file': (file_name, f, mime_type),
                'type': (None, mime_type),
                'messaging_product': (None, 'whatsapp')
            }
            
            response = requests.post(url, headers=headers, files=files, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            media_id = result.get('id')
            
            if media_id:
                logger.info(f'Successfully uploaded {file_name}, media_id={media_id}')
                return media_id
            else:
                logger.error(f'Upload response missing media_id: {result}')
                return None
                
    except Exception as e:
        logger.error(f"Failed to upload media {file_path}: {str(e)}")
        logger.error(traceback.format_exc())
        return None


def send_document_message(to: str, file_path: str, caption: str = None) -> Optional[dict]:
    """Send a document message (PDF) to a WhatsApp user by uploading media and sending a document message."""
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.warning('send_document_message: WhatsApp credentials not configured; skipping send')
        return None

    # Prevent unsolicited/proactive sends unless explicitly allowed via environment
    try:
        current_id = globals().get('_CURRENT_WEBHOOK_MESSAGE_ID')
        allow_proactive = os.environ.get('ALLOW_PROACTIVE_WA', '').lower() in ('1', 'true', 'yes')
        if not current_id and not allow_proactive:
            logger.warning('Blocked outbound WhatsApp document send without active webhook message (set ALLOW_PROACTIVE_WA=true to override)')
            return None
    except Exception:
        return None
        
    if not os.path.exists(file_path):
        logger.error(f'send_document_message: file does not exist: {file_path}')
        return None
        
    media_id = _upload_media(file_path)
    if not media_id:
        logger.error('send_document_message: upload failed, cannot send document')
        return None

    url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/messages")
    payload = {
        'messaging_product': 'whatsapp',
        'to': to,
        'type': 'document',
        'document': {
            'id': media_id,
            'caption': caption or ''
        }
    }
    headers = {'Authorization': f'Bearer {WHATSAPP_TOKEN}', 'Content-Type': 'application/json'}

    try:
        logger.info(f'Enviando documento con media_id={media_id} a {to}')
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        resp.raise_for_status()
        logger.info(f'Document sent to {to}, media_id={media_id}')
        return resp.json()
    except Exception as e:
        logger.error(f'Error sending document message: {str(e)}')
        logger.error(traceback.format_exc())
        return None


def log_webhook_event(event_type: str, details: Dict[str, Any], level: str = "info") -> None:
    """
    Registrar información detallada sobre eventos del webhook de manera estructurada.
    
    Args:
        event_type: Tipo de evento (mensaje, status, error, etc.)
        details: Detalles específicos del evento
        level: Nivel de log (info, warning, error)
    """
    import json
    from datetime import datetime
    
    log_data = {
        "event_type": event_type,
        "timestamp": datetime.now().isoformat(),
        "details": details
    }
    
    # Limitar la longitud de los datos para evitar logs demasiado grandes
    log_message = json.dumps(log_data, default=str)[:500]
    
    if level == "warning":
        logger.warning(f"WEBHOOK_EVENT: {log_message}")
    elif level == "error":
        logger.error(f"WEBHOOK_EVENT: {log_message}")
    else:
        logger.info(f"WEBHOOK_EVENT: {log_message}")


def set_current_webhook_message_id(message_id: str):
    """Set the current webhook message ID for duplicate prevention"""
    global _CURRENT_WEBHOOK_MESSAGE_ID
    _CURRENT_WEBHOOK_MESSAGE_ID = message_id


def clear_current_webhook_message_id():
    """Clear the current webhook message ID"""
    global _CURRENT_WEBHOOK_MESSAGE_ID
    _CURRENT_WEBHOOK_MESSAGE_ID = None


def send_read_receipt(message_id: str) -> Optional[dict]:
    """
    Envía un 'read receipt' a la API de WhatsApp para el message_id dado.
    Retorna la respuesta JSON o None si falla.
    """
    if not WHATSAPP_TOKEN or not WHATSAPP_PHONE_NUMBER_ID:
        logger.debug('send_read_receipt: WhatsApp credentials not configured; skipping')
        return None

    if not message_id:
        logger.debug('send_read_receipt: missing message_id')
        return None

    url = urljoin(WHATSAPP_API_BASE, f"{WHATSAPP_PHONE_NUMBER_ID}/messages")
    headers = {
        'Authorization': f'Bearer {WHATSAPP_TOKEN}',
        'Content-Type': 'application/json'
    }

    payload = {
        'messaging_product': 'whatsapp',
        'status': 'read',
        'message_id': message_id
    }

    try:
        import requests
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        resp.raise_for_status()
        logger.info(f'send_read_receipt: marked message {message_id} as read')
        try:
            return resp.json()
        except Exception:
            return {'status_code': resp.status_code, 'text': resp.text}
    except Exception as e:
        logger.debug(f'send_read_receipt failed: {e}')
        return None