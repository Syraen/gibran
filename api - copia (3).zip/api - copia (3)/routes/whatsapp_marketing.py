import requests
import logging
import json
import traceback
import os
from typing import Optional, Dict, Any
from datetime import datetime
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin

# Configuraciones
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)

# Servicios principales
from services.chat_ai import chat_with_gemini

# Importaciones de servicios de memoria y conversación
from services.conversation_memory_utils import save_conversation_memory, get_conversation_memory

# Módulos de manejo de mensajes
from .whatsapp_message_handlers import (
    send_text_message, log_webhook_event,
    set_current_webhook_message_id, clear_current_webhook_message_id
)

# Configurar logger para este módulo
logger = logging.getLogger(__name__)

# Crear blueprint para rutas de WhatsApp Marketing
whatsapp_marketing_bp = Blueprint('whatsapp_marketing', __name__)


@whatsapp_marketing_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')

    logger.info(f"Verificación de webhook marketing: mode={mode}, token={token != None}")

    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook de marketing verificado exitosamente")
        return challenge

    logger.warning("Verificación de webhook de marketing fallida")
    return "Verification failed", 403


@whatsapp_marketing_bp.route('/webhook', methods=['POST'])
def webhook_handler():
    try:
        # Persistir el cuerpo bruto del webhook inmediatamente
        try:
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_marketing_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== MARKETING WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END MARKETING WEBHOOK ===\n")
            logger.debug("Raw marketing webhook persisted to logs/webhook_marketing_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw marketing webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST de marketing recibido")

        # Registrar información estructurada del webhook
        try:
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)

            log_webhook_event(
                event_type="webhook_marketing_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
        except Exception as e:
            logger.error(f"Error al procesar información de webhook de marketing: {e}")
            logger.error(traceback.format_exc())

        if not payload:
            logger.warning("Payload vacío recibido en marketing")
            return

        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload de marketing")
            return

        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                messages = value.get('messages', [])
                contacts = value.get('contacts', [])

                for message in messages:
                    message_type = message.get('type')
                    if message_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                        from_number = message.get('from')
                        whatsapp_profile = contacts[0].get('profile', {}) if contacts else {}

                        logger.info(f"Mensaje de marketing recibido de {from_number}: {message_text}")

                        # Procesar el mensaje con IA de marketing
                        process_user_message_marketing(from_number, message_text, whatsapp_profile)

        # Limpiar ID de mensaje actual
        clear_current_webhook_message_id()
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        logger.error(f"Error procesando webhook de marketing: {e}", exc_info=True)
        clear_current_webhook_message_id()
        return jsonify({"status": "error", "message": "Error interno"}), 500
    finally:
        clear_current_webhook_message_id()


def process_user_message_marketing(phone: str, message_text: str, whatsapp_profile: dict = None):
    """
    Procesa un mensaje individual del usuario con IA de marketing
    """
    try:
        # Prompt específico para asesor de marketing
        system_prompt = (
            "Eres un asesor de marketing especializado en estrategias de marketing digital, "
            "promoción de productos y servicios, y crecimiento de negocio. Responde de manera "
            "profesional, amigable y persuasiva. Ayuda a los usuarios con consultas sobre marketing, "
            "campañas, publicidad, redes sociales, y cómo promover sus productos o servicios. "
            "Mantén el contexto de la conversación y ofrece consejos prácticos y accionables."
        )

        # Usar IA para generar respuesta
        ai_response = chat_with_gemini(
            phone=phone,
            message=message_text,
            system_prompt=system_prompt,
            include_whatsapp_profile=whatsapp_profile or {}
        )

        if ai_response and ai_response.strip():
            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Gracias por tu mensaje. ¿En qué puedo ayudarte con estrategias de marketing hoy?")

    except Exception as e:
        logger.error(f"Error procesando mensaje de marketing: {e}", exc_info=True)
        send_text_message(phone, "Disculpa, ocurrió un error procesando tu mensaje. Por favor intenta de nuevo.")