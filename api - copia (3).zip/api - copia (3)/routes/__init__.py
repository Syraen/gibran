"""Routes package initializer.

This file intentionally avoids importing all route modules at package import
time to reduce side-effects for small scripts (like PDF generators) that
import individual route modules directly. The Flask app will import the
required modules explicitly during app startup.
"""
__all__ = []