"""Configuracion de las variables de entorno y las contsantes"""
import os
from dotenv import load_dotenv

#cargar las variables de entorno 
load_dotenv()

#Configuracion en conexion a mongo
# Conexion a MongoDB
MONGODB_URL = os.environ.get('MONGODB_URL', 'mongodb://localhost:27017')
#Conectar a la db 
MONGODB_DB = os.environ.get('MongoDB_DB' , 'splitbot')

#Configuracion de Gemini
#API KEY 
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')

#MODELO
GEMINI_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-2.0-flash')
GEMINI_AUTH_MODE = os.environ.get('GEMINI_AUTH_MODE', 'x-goog')

#Configuracion de whatsapp
WHATSAPP_API_VERSION = os.environ.get('WHATSAPP_API_VERSION', 'v17.0')
WHATSAPP_API_BASE = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/"
WHATSAPP_PHONE_NUMBER_ID = os.environ.get('WHATSAPP_PHONE_NUMBER_ID', '')
WHATSAPP_TOKEN = os.environ.get('WHATSAPP_TOKEN', '') or os.environ.get('WHATSAPP_ACCESS_TOKEN', '')
WHATSAPP_VERIFY_TOKEN = os.environ.get('WHATSAPP_VERIFY_TOKEN', '') or os.environ.get('WEBHOOK_VERIFY_TOKEN', '')

#Configuracion de la App 
DEBUG = os.environ.get('DEBUG', 'false').lower() == 'true'
PORT = int(os.environ.get('PORT', 5000))

MAX_CONVERSATION_TURNS = int(os.environ.get('MAX_CONVERSATION_TURNS', 20))
CACHE_EXPIRY = int(os.environ.get('CACHE_EXPIRY', 7200))
