require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const whatsapp = require('./lib/whatsapp');
const gemini = require('./lib/gemini');

const app = express();
app.use(bodyParser.json());

const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || 'change_me';

// webhook verification endpoint for WhatsApp
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('WEBHOOK_VERIFIED');
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// webhook to receive incoming messages from WhatsApp
app.post('/webhook', async (req, res) => {
  try {
    const body = req.body;

    if (!body) {
      console.warn('Empty body');
      return res.sendStatus(400);
    }

    // WhatsApp sends entries with changes; handle different shapes defensively
    if (body.object && Array.isArray(body.entry)) {
      for (const entry of body.entry) {
        const changes = entry.changes || [];
        for (const change of changes) {
          const value = change.value || {};

          // messages may appear under value.messages or value.messaging
          const messages = value.messages || value.messaging || [];

          for (const message of messages) {
            // detect sender and text robustly
            const from = message.from || message.sender?.id || value?.metadata?.phone_number_id || message.id;

            let text = '';
            if (message.type === 'text' && message.text) text = message.text.body;
            else if (message.text && typeof message.text === 'string') text = message.text;
            else if (message.body) text = message.body;

            if (!text) {
              console.log('Skipping non-text message or empty body', message.type);
              continue;
            }

            console.log('Received message from', from, text);

            // call gemini to generate response
            const reply = await gemini.generateReply(text);

            // send reply back via WhatsApp API
            try {
              // set global marker to allow a single reply tied to this webhook message
              global.__CURRENT_WEBHOOK_MSG_ID = message.id || null;
              global.__SENT_RESPONSES = global.__SENT_RESPONSES || new Set();
              await whatsapp.sendTextMessage(from, reply);
              // clear marker after attempt
              global.__CURRENT_WEBHOOK_MSG_ID = null;
            } catch (sendErr) {
              console.error('Failed sending WhatsApp message', sendErr?.response?.data || sendErr.message);
            }
          }
        }
      }
    } else {
      console.log('Webhook received unknown shape', Object.keys(body));
    }

    res.sendStatus(200);
  } catch (err) {
    console.error('Webhook handling error', err?.response?.data || err.message || err);
    res.sendStatus(500);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
