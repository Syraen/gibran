from datetime import datetime
from typing import Optional, Dict, Any, List
from bson import ObjectId

class MongoDocument:
    
    def __init__(self, **kwargs):
        self._id = kwargs.get('_id')
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {}
        for key, value in self.__dict__.items():
            if key == '_id' and value is None:
                continue
            if isinstance(value, ObjectId):
                result[key] = str(value)
            elif isinstance(value, datetime):
                result[key] = value.isoformat()
            else:
                result[key] = value
        return result
    
    def from_dict(cls, data: Dict[str, Any]):
        return cls(**data)
    
class Cliente(MongoDocument):
    
    def __init__(self, phone: str, name: Optional[str] = None, 
                 email: Optional[str] = None, created_at: Optional[datetime] = None, **kwargs):
        super().__init__(**kwargs)
        self.phone = phone
        self.name = name
        self.email = email
        self.created_at = created_at or datetime.utcnow()

class Conversation(MongoDocument):
    
    def __init__(self, customer_phone: str, message: str, 
                 message_type: str = "text", created_at: Optional[datetime] = None, 
                 customer_id: Optional[str] = None, **kwargs):
        super().__init__(**kwargs)
        self.customer_phone = customer_phone
        self.customer_id = customer_id  # Reference to cliente _id
        self.message = message
        self.message_type = message_type
        self.created_at = created_at or datetime.utcnow()

class Course(MongoDocument):
    
    def __init__(self, title: str, description: Optional[str] = None,
                 content: Optional[str] = None, created_at: Optional[datetime] = None, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.description = description
        self.content = content
        self.created_at = created_at or datetime.utcnow()


class Product(MongoDocument):
    
    def __init__(self, name: str, description: Optional[str] = None,
                 price: Optional[float] = None, category: Optional[str] = None,
                 created_at: Optional[datetime] = None, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.description = description
        self.price = price
        self.category = category
        self.created_at = created_at or datetime.utcnow()


class Keyword(MongoDocument):
    
    def __init__(self, keyword: str, response: str, category: Optional[str] = None,
                 created_at: Optional[datetime] = None, **kwargs):
        super().__init__(**kwargs)
        self.keyword = keyword.lower() 
        self.response = response
        self.category = category
        self.created_at = created_at or datetime.utcnow()
