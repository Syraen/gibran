"""
Helpers para flujo de cursos: listar cursos, obtener partes (fechas, precios, ubicación, temario)
Lee `splitbot.courses.json` y devuelve mensajes formateados para WhatsApp.
"""
from typing import Optional, Dict, Any, List
try:
    # When running as package
    from api.utils.json_catalog import load_courses
except Exception:
    # When running from some contexts the package root differs
    from utils.json_catalog import load_courses


def _load_courses() -> List[Dict[str, Any]]:
    """Return the list of courses using the centralized loader (DB-first)."""
    try:
        return load_courses() or []
    except Exception:
        return []


def format_course_list_message() -> str:
    courses = _load_courses()
    if not courses:
        return "Tenemos 0 cursos disponibles actualmente. Intenta de nuevo más tarde."

    parts = ["📚 *Nuestros cursos disponibles:*\n"]
    for idx, c in enumerate(courses, start=1):
        title = c.get('title') or c.get('name') or f"Curso {idx}"
        short = c.get('short_description') or c.get('description', '')[:120]
        parts.append(f"{idx}. {title} — {short}")
    parts.append("\nResponde con el número o nombre del curso para obtener información completa o pide datos específicos: fechas, precios, ubicación, temario.")
    return "\n".join(parts)


def get_course_info_part(course_identifier: Any, info_type: str) -> Optional[str]:
    """Obtener una parte específica de la información del curso.
    info_type: 'fechas', 'precios', 'ubicacion', 'temario', 'descripcion', 'todo'
    """
    courses = _load_courses()
    if not courses:
        return None

    # match by number or by id/title
    course = None
    if isinstance(course_identifier, int):
        if 1 <= course_identifier <= len(courses):
            course = courses[course_identifier - 1]
    else:
        # try match by id or title substring
        for c in courses:
            if str(c.get('id', '')).lower() == str(course_identifier).lower():
                course = c
                break
            if str(course_identifier).lower() in str(c.get('title', '')).lower():
                course = c
                break

    if not course:
        return None

    # Build responses for each info_type
    info_type = (info_type or '').lower()
    if info_type in ('fechas', 'fecha', 'dates'):
        dates = course.get('dates') or course.get('schedule') or course.get('fechas')
        if dates:
            return f"📆 Fechas para *{course.get('title','curso')}*:\n{dates}"
        return "Fechas no disponibles para este curso."

    if info_type in ('precios', 'precio', 'costos'):
        prices = course.get('price') or course.get('prices') or course.get('precios')
        if prices:
            return f"💰 Precios para *{course.get('title','curso')}*:\n{prices}"
        return "Precios no disponibles para este curso."

    if info_type in ('ubicacion', 'ubicación', 'location'):
        location = course.get('location') or course.get('sede')
        if location:
            return f"📍 Ubicación / modalidad para *{course.get('title','curso')}*:\n{location}"
        return "Ubicación no disponible para este curso."

    if info_type in ('temario', 'contenido', 'programa'):
        temario = course.get('temario') or course.get('content') or course.get('syllabus') or course.get('description')
        if temario:
            # Keep it concise; if long, indicate PDF is available
            text = temario
            if isinstance(text, list):
                text = '\n'.join(f"• {t}" for t in text)
            return f"📚 Temario de *{course.get('title','curso')}*:\n{text}\n\nSi quieres el PDF del temario responde 'temario {course.get('id','')}'"
        return "Temario no disponible para este curso."

    if info_type in ('descripcion', 'description', 'todo', 'full'):
        # Return a composed full info message
        title = course.get('title') or course.get('name')
        desc = course.get('description', '')
        dates = course.get('dates') or course.get('schedule') or ''
        prices = course.get('price') or course.get('prices') or ''
        location = course.get('location') or course.get('sede') or ''
        temario = course.get('temario') or course.get('content') or ''
        parts = [f"📚 *{title}*\n"]
        if desc:
            parts.append(desc)
        if dates:
            parts.append(f"\n📆 Fechas:\n{dates}")
        if prices:
            parts.append(f"\n💰 Precios:\n{prices}")
        if location:
            parts.append(f"\n📍 Ubicación / Modalidad:\n{location}")
        if temario:
            if isinstance(temario, list):
                temario_text = '\n'.join(f"• {t}" for t in temario)
            else:
                temario_text = temario
            parts.append(f"\n📚 Temario:\n{temario_text}")
        return '\n'.join(parts)

    # default: return a short summary
    title = course.get('title') or course.get('name')
    short = course.get('short_description') or course.get('description', '')[:200]
    return f"{title} - {short}"


def find_course_by_text(text: str) -> Optional[Dict[str, Any]]:
    courses = _load_courses()
    text = (text or '').lower()
    for idx, c in enumerate(courses, start=1):
        if text.strip() == str(idx) or text.strip() == str(c.get('id', '')):
            return c
        if text in str(c.get('title','')).lower() or text in str(c.get('name','')).lower():
            return c
    return None
