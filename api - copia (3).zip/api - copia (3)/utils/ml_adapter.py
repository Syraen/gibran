"""
Funciones para manejar la solicitud de temarios y recursos para los cursos.
"""
import logging
import os
import re
from typing import Dict, Any, Optional, List, Union
from models.courses import CourseManager, find_temario_pdf

logger = logging.getLogger(__name__)


def process_message(phone: str, 
                   message_text: str, 
                   conversation_history: Optional[List[Dict[str, Any]]] = None,
                   whatsapp_profile: Optional[Dict[str, Any]] = None,
                   skip_course_processing: bool = False) -> Dict[str, Any]:
    """
    Procesa un mensaje con servicios de ML y genera notificaciones si es necesario.
    Esta función intenta delegar en los servicios apropiados si están disponibles
    (servicios opcionales pueden no estar instalados en todos los entornos).
    """
    result = {
        'pdf_sent': False,
        'pdf_path': None,
        'notification_sent': False,
        'message_processed': False,
        'ml_results': {}
    }
    try:
        # Importar servicios dinámicamente para evitar dependencias circulares
        try:
            from services.ml_service import ml_service
        except Exception:
            ml_service = None

        try:
            from services.notification_service import notification_service
        except Exception:
            notification_service = None

        try:
            from services.course_context_manager import CourseContextManager, CourseIntent
        except Exception:
            CourseContextManager = None
            CourseIntent = None

        # 1. Procesar mensaje con ML para extraer datos y clasificar
        if ml_service:
            ml_results = ml_service.process_message(message_text, conversation_history)
        else:
            ml_results = {}

        result['ml_results'] = ml_results
        result['message_processed'] = True

        if skip_course_processing:
            logger.info('skip_course_processing=True: Omisión de procesamiento de cursos para esta petición')
            return result

        # 2. Detectar intención específica de curso usando CourseContextManager si está disponible
        course_intent = None
        intent_confidence = 0.0
        if CourseContextManager:
            try:
                course_intent, intent_confidence = CourseContextManager.detect_course_intent(
                    message_text, conversation_history
                )
            except Exception:
                course_intent = None
                intent_confidence = 0.0

        # 3. Detectar si el mensaje hace referencia a cursos (IDs, nombres o keywords)
        query_info = CourseManager.parse_course_query(message_text)
        explicit_temario_keywords = (course_intent == CourseIntent.TEMARIO) if CourseIntent else False

        has_course_reference = bool(query_info.get('course_ids') or query_info.get('keywords') or explicit_temario_keywords)
        has_course_intent = (intent_confidence > 0.75) if intent_confidence is not None else False

        if has_course_reference or has_course_intent:
            course_obj = None
            if query_info.get('course_ids'):
                try:
                    course_obj = CourseManager.get_course_by_id(query_info['course_ids'][0])
                except Exception:
                    course_obj = None

            if not course_obj and query_info.get('keywords'):
                try:
                    found = CourseManager.search_courses_by_keywords(query_info['keywords'], limit=1)
                    if found:
                        course_obj = found[0]
                except Exception:
                    course_obj = None

            # Si la intención es temario, intentar encontrar PDF correspondiente
            if explicit_temario_keywords:
                try:
                    context_courses = [course_obj.to_dict()] if course_obj else None
                    pdf_result = find_temario_pdf(query_info.get('course_ids')[0]) if query_info.get('course_ids') else None
                    if pdf_result:
                        result['pdf_sent'] = True
                        result['pdf_path'] = pdf_result
                        return result
                except Exception:
                    pass

            if course_obj:
                try:
                    course_summary = course_obj.get_formatted_informacion_completa()
                except Exception:
                    try:
                        course_summary = str(course_obj.to_dict())
                    except Exception:
                        course_summary = ''

                result['course'] = course_obj.to_dict()
                result['course_summary'] = course_summary
                result['course_id'] = getattr(course_obj, 'id', None)
                result['course_name'] = getattr(course_obj, 'nombre', None)

                system_prompt = (
                    "Tienes la siguiente información oficial del curso extraída de la base de datos:\n\n"
                    f"{course_summary}\n\n"
                    "Usa esta información como la fuente principal y responde la pregunta del usuario de forma clara y con formato amigable para WhatsApp."
                )

                result['system_prompt'] = system_prompt

        # 4. Verificar si se debe enviar notificación
        try:
            if should_notify(result.get('ml_results', {}), message_text) and notification_service:
                notification_result = notification_service.process_client_notification(
                    phone, result.get('ml_results', {}), conversation_history or []
                )
                result['notification_sent'] = notification_result.get('notification_sent', False)
                result['notification_details'] = notification_result
        except Exception:
            pass

    except Exception as e:
        logger.error(f"Error en process_message: {e}", exc_info=True)

    return result


def should_notify(ml_results: Dict[str, Any], message_text: str) -> bool:
    """
    Determina si se debe enviar una notificación basado en los resultados de ML.
    """
    try:
        # Verificar si ML service indica que requiere atención humana
        if ml_results.get('requires_human_attention', False):
            return True

        lead_prediction = ml_results.get('lead_prediction', {})
        if lead_prediction.get('lead_type') == 'caliente' and lead_prediction.get('confidence', 0) > 0.7:
            return True

        category = ml_results.get('classification', {}).get('category', '')
        if category in ['cotizacion', 'contacto_asesor']:
            return True

        urgency_patterns = [
            r'urgen(te|cia)',
            r'necesito\s+(ahora|ya|inmediatamente)',
            r'llamar?\s+(ahora|ya|hoy)',
            r'cotiz[aá](ci[oó]n|r)?',
            r'precio',
            r'compr[ao]',
            r'pag[ao]'
        ]

        if any(re.search(pattern, (message_text or '').lower()) for pattern in urgency_patterns):
            return True

        client_data = ml_results.get('client_data', {})
        has_complete_contact = (
            client_data.get('nombre') and 
            client_data.get('empresa') and 
            client_data.get('correo')
        )

        if has_complete_contact:
            return True

    except Exception:
        return False

    return False

def is_temario_request(message: str) -> bool:
    """
    Detecta si el mensaje es una solicitud de temario.
    
    Args:
        message: Texto del mensaje
        
    Returns:
        True si es solicitud de temario, False en caso contrario
    """
    temario_keywords = ['temario', 'temas', 'contenido', 'programa', 'syllabus', 
                        'qué incluye', 'que incluye', 'qué voy a aprender',
                        'qué enseñan', 'que enseñan', 'plan de estudios']
    
    message_lower = message.lower()
    return any(keyword in message_lower for keyword in temario_keywords)

def is_inscription_request(message: str) -> bool:
    """
    Detecta si el mensaje es una solicitud sobre el proceso de inscripción.
    
    Args:
        message: Texto del mensaje
        
    Returns:
        True si es solicitud sobre inscripción, False en caso contrario
    """
    inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 
                           'proceso de inscripcion', 'cómo me inscribo', 
                           'como me inscribo', 'registro', 'registrarme']
    
    message_lower = message.lower()
    return any(keyword in message_lower for keyword in inscription_keywords)

def extract_course_number(message: str) -> Optional[int]:
    """
    Extrae un número de curso (1-5) de un texto.
    
    Args:
        message: Texto del mensaje
        
    Returns:
        Número del curso si se encuentra, None en caso contrario
    """
    # Buscar un dígito aislado 1-5
    m = re.search(r"\b([1-5])\b", message)
    if m:
        return int(m.group(1))
        
    # Buscar patrones como "curso 1", "curso número 2", "el temario del curso 3"
    m = re.search(r"curso\s*(?:n[úu]mero\s*)?(?:[:#-]?\s*)([1-5])", message.lower())
    if m:
        return int(m.group(1))
    
    # Buscar nombres específicos de cursos
    course_names = {
        'cableado': 1,
        'estructurado': 1,
        'redes': 1,
        'fibra': 2,
        'planta externa': 2,
        'ftth': 3,
        'wisp': 3,
        'isp': 3,
        'ponlan': 4,
        'redes pasivas': 4,
        'enterprise': 4,
        'empalmes': 5,
        'mediciones': 5,
        'otdr': 5
    }
    
    message_lower = message.lower()
    for keyword, course_id in course_names.items():
        if keyword in message_lower:
            return course_id
            
    return None

def get_course_temario_message(course_id: int) -> str:
    """
    Genera un mensaje con el temario de un curso específico.
    
    Args:
        course_id: ID del curso
        
    Returns:
        Mensaje formateado con el temario
    """
    course = CourseManager.get_course_by_id(course_id)
    if not course:
        return "No encontré información sobre ese curso. ¿Puedes indicarme cuál de nuestros 5 cursos te interesa?"
    
    # Obtener el temario formateado
    temario = course.get_formatted_temario()
    
    # Buscar PDF del temario
    pdf_path = find_temario_pdf(course_id)
    pdf_available = pdf_path is not None
    
    # Generar mensaje
    message = [
        f"📚 *TEMARIO DEL CURSO: {course.nombre}*\n",
        temario,
        "\n"
    ]
    
    if pdf_available:
        message.append("\n💡 También puedo enviarte el temario completo en PDF si lo deseas. Solo escribe 'enviar PDF del temario'.")
    
    message.append("\n¿Hay algo específico del temario que te gustaría conocer más a fondo?")
    
    return "\n".join(message)

def get_inscription_process_message() -> str:
    """
    Devuelve el mensaje con información sobre el proceso de inscripción.
    
    Returns:
        Mensaje formateado sobre el proceso de inscripción
    """
    return (
        "📝 *PROCESO DE INSCRIPCIÓN*\n\n"
        "El proceso de inscripción es sencillo y rápido:\n\n"
        "1️⃣ Completa el formulario en el siguiente enlace:\n"
        "   https://fibremex.com/fibra-optica/views/Capacitaciones/1-fintec\n\n"
        "2️⃣ Recibirás un correo electrónico con los datos para realizar el pago\n\n"
        "3️⃣ Una vez confirmado el pago, recibirás los detalles para acceder al curso\n\n"
        "Si tienes dudas o necesitas ayuda personalizada en el proceso, puedes escribir 'asesor' y te pondré en contacto con un especialista."
    )

def ask_for_course_number() -> str:
    """
    Genera un mensaje para preguntar por el número de curso.
    
    Returns:
        Mensaje preguntando por el curso
    """
    return (
        "Por favor, indícame de cuál de nuestros cursos te gustaría conocer el temario:\n\n"
        "1️⃣ Cableado estructurado para redes de fibra y cobre\n"
        "2️⃣ Redes de fibra óptica planta externa\n"
        "3️⃣ Redes de fibra óptica FTTH para WISP e ISP\n"
        "4️⃣ PONLAN redes pasivas para entornos enterprise\n"
        "5️⃣ Empalmes y mediciones con OTDR de un enlace de fibra óptica\n\n"
        "Responde con el número del curso (1-5) o con el nombre del curso."
    )

# Funciones adicionales que podemos implementar en el futuro:
# - send_temario_pdf: para enviar el PDF del temario cuando lo soliciten
# - get_course_schedule: para obtener información sobre fechas y horarios
# - get_course_pricing: para obtener información sobre precios
# - get_course_location: para obtener información sobre ubicaciones