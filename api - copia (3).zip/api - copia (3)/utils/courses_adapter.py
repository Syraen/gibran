"""
Helper to access courses stored in MongoDB and format them for WhatsApp/AI.
"""
import re
import logging
import json
import os
from typing import Optional, List, Dict, Any
from datetime import datetime
try:
    from bson import ObjectId
except Exception:
    ObjectId = None
from data.db import get_collection

logger = logging.getLogger(__name__)


def _courses_collection():
    return get_collection('courses')


# Local JSON fallback: load the bundled `splitbot.courses.json` if DB is not present
_LOCAL_COURSES_CACHE: Optional[List[Dict[str, Any]]] = None


def _load_local_courses() -> List[Dict[str, Any]]:
    global _LOCAL_COURSES_CACHE
    if _LOCAL_COURSES_CACHE is not None:
        return _LOCAL_COURSES_CACHE
    try:
        base = os.path.abspath(os.path.dirname(__file__))
        candidate = os.path.join(base, '..', 'splitbot.courses.json')
        candidate = os.path.abspath(candidate)
        if os.path.exists(candidate):
            with open(candidate, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Normalize documents: ensure keys we expect exist
                for d in data:
                    if '_id' in d:
                        try:
                            d['_id'] = str(d['_id'].get('$oid')) if isinstance(d['_id'], dict) else str(d['_id'])
                        except Exception:
                            pass
                _LOCAL_COURSES_CACHE = data
                return _LOCAL_COURSES_CACHE
    except Exception as e:
        logger.debug(f"_load_local_courses error: {e}")
    _LOCAL_COURSES_CACHE = []
    return _LOCAL_COURSES_CACHE


def parse_course_number_from_text(text: str) -> Optional[int]:
    if not text:
        return None
    m = re.search(r"\bcurso\s*(?:n(?:ú|u)?mero\s*)?(\d{1,3})\b", text.lower())
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return None
    # also accept single digit alone if message is just a number
    t = text.strip()
    if t.isdigit():
        n = int(t)
        if 1 <= n <= 999:
            return n
    return None


def get_course_by_id(course_id) -> Optional[Dict[str, Any]]:
    col = _courses_collection()
    if col is None:
        # Fallback to local JSON
        local = _load_local_courses()
        try:
            for d in local:
                if d.get('id') == int(course_id):
                    return d
        except Exception:
            return None
        return None
    # try by numeric id field
    try:
        q = None
        if isinstance(course_id, int):
            q = {"id": course_id}
        else:
            # try ObjectId
            try:
                q = {"_id": ObjectId(str(course_id))}
            except Exception:
                q = {"id": int(course_id)} if str(course_id).isdigit() else {"title": str(course_id)}

        doc = col.find_one(q)
        if doc:
            doc['_id'] = str(doc.get('_id'))
        return doc
    except Exception as e:
        logger.debug(f"get_course_by_id error: {e}")
        return None


def search_courses_by_keywords(keywords: List[str], limit: int = 5) -> List[Dict[str, Any]]:
    col = _courses_collection()
    if col is None:
        # Fallback to local JSON search
        try:
            local = _load_local_courses()
            if not keywords:
                return local[:limit]
            results = []
            for d in local:
                text = ' '.join([str(d.get(k, '')).lower() for k in ('title', 'nombre', 'descripcion', 'description')])
                if any(kw.lower() in text for kw in keywords):
                    results.append(d)
                    if len(results) >= limit:
                        break
            return results
        except Exception:
            return []
    try:
        # If no keywords provided, return top N courses (by insertion order or title)
        if not keywords:
            cursor = col.find({}).limit(limit)
        else:
            # build a simple $or regex search across title/description/content
            regexes = [re.compile(re.escape(k), re.IGNORECASE) for k in keywords]
            or_conditions = []
            for r in regexes:
                or_conditions.append({"title": {"$regex": r}})
                or_conditions.append({"description": {"$regex": r}})
                or_conditions.append({"content": {"$regex": r}})
            cursor = col.find({"$or": or_conditions}).limit(limit)
        results = []
        for d in cursor:
            d['_id'] = str(d.get('_id'))
            results.append(d)
        return results
    except Exception as e:
        logger.debug(f"search_courses_by_keywords error: {e}")
        return []


def format_course_for_whatsapp(course: Dict[str, Any]) -> str:
    if not course:
        return "Información del curso no disponible."
    title = course.get('title') or course.get('nombre') or course.get('titulo')
    desc = course.get('description') or course.get('descripcion') or ''
    price = course.get('price') or course.get('precio')
    schedule = course.get('schedule') or course.get('fechas') or ''
    parts = [f'*{title}*' if title else 'Curso']
    if desc:
        parts.append(desc)
    if schedule:
        parts.append(f'Fechas: {schedule}')
    if price:
        parts.append(f'Precio: {price}')
    return '\n\n'.join(parts)


def compose_course_suggestion_via_ai(course: Dict[str, Any], user_query: str = None, phone: str = None) -> str:
    """
    Return a short, AI-polished suggestion message about a course using the model, but
    constrain the model to NOT invent concrete transactional details (dates, prices).

    Inputs:
    - course: course document/dict (may come from DB or local JSON)
    - user_query: original user message (optional) to provide context
    - phone: phone identifier to pass to chat_with_gemini profiling (optional)

    Output: a string ready to send to the user.
    """
    try:
        # Build a conservative system prompt that instructs the model to avoid inventing details
        title = course.get('title') or course.get('nombre') or course.get('titulo') or 'Este curso'
        short_desc = (course.get('description') or course.get('descripcion') or '')
        known_fields = {}
        if course.get('price'):
            known_fields['Precio'] = course.get('price')
        if course.get('schedule') or course.get('fechas'):
            known_fields['Fechas'] = course.get('schedule') or course.get('fechas')

        system_prompt = (
            "Eres un asistente que entrega información precisa de cursos. No inventes fechas, precios ni ubicaciones. "
            "Si faltan datos concretos, indica que el usuario puede consultar al asesor o revisar la página oficial. "
            "Devuelve un texto corto, en español, claro y útil, enfatizando puntos clave del curso y cómo el usuario puede obtener más detalles."
        )

        # Compose content that includes known fields for the assistant to summarize
        content_lines = [f"Curso: {title}"]
        if short_desc:
            content_lines.append(short_desc)
        for k, v in known_fields.items():
            content_lines.append(f"{k}: {v}")
        if user_query:
            content_lines.append(f"Pregunta del usuario: {user_query}")

        # Lazy import to avoid cycles
        from services.chat_ai import chat_with_gemini

        # Ask the model for a short summary/suggestion constrained to not invent
        ai_output = chat_with_gemini(phone=phone or '', message='\n'.join(content_lines), system_prompt=system_prompt)
        if ai_output:
            return ai_output
        # Fallback to plain formatting
        return format_course_for_whatsapp(course)
    except Exception as e:
        logger.debug(f"compose_course_suggestion_via_ai error: {e}")
        return format_course_for_whatsapp(course)


def find_pdf_for_user_message(query: str, context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
    """Try to find a PDF (temario) matching the query or the provided context.

    Strategy:
    - If context contains 'relevant_courses' (list of dicts with id/name), try to fetch course doc and look for 'pdf'/'pdf_path' field.
    - For course IDs, directly map to assets folder: {id}.pdf
    - Otherwise try to match the query against course titles and look for a pdf field.
    - If a filename is found, resolve it to the local `assets/` folder and return its absolute path.
    """
    try:
        import os
        col = _courses_collection()
        local = None
        if col is None:
            local = _load_local_courses()
        # Helper to resolve local pdf file path
        def _resolve_filename(fname: str):
            if not fname:
                return None
            # If already an absolute path and exists, return it
            if os.path.isabs(fname) and os.path.exists(fname):
                return fname
            # Check relative to api/assets (primary location for course PDFs)
            base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
            candidate = os.path.join(base, fname)
            if os.path.exists(candidate):
                return candidate
            # Check relative to api/pdfs (fallback)
            base_pdfs = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pdfs'))
            candidate_pdfs = os.path.join(base_pdfs, fname)
            if os.path.exists(candidate_pdfs):
                return candidate_pdfs
            # try basename only
            candidate2 = os.path.join(base, os.path.basename(fname))
            if os.path.exists(candidate2):
                return candidate2
            return None

        # 1) context with relevant courses - try direct mapping first
        if context and isinstance(context, dict):
            rel = context.get('relevant_courses') or context.get('candidates')
            if rel and isinstance(rel, list):
                for rc in rel:
                    cid = rc.get('id') or rc.get('_id')
                    if cid:
                        # Try direct mapping to assets folder: find file starting with {id}.
                        base_assets = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
                        if os.path.exists(base_assets):
                            for filename in os.listdir(base_assets):
                                if filename.startswith(f"{cid}.") and filename.lower().endswith('.pdf'):
                                    pdf_path = os.path.join(base_assets, filename)
                                    if os.path.isfile(pdf_path):
                                        return {'pdf_path': pdf_path, 'course_name': rc.get('name', '')}

                        # Fallback to DB lookup or local JSON
                        doc = None
                        if col:
                            try:
                                doc = col.find_one({'id': cid}) if isinstance(cid, int) else col.find_one({'_id': ObjectId(str(cid))})
                            except Exception:
                                try:
                                    doc = col.find_one({'id': int(cid)})
                                except Exception:
                                    doc = None
                        if not doc and local:
                            for d in local:
                                if d.get('id') == int(cid):
                                    doc = d
                                    break
                        if doc:
                            for key in ('pdf', 'pdf_path', 'temario', 'file'):
                                if key in doc and doc.get(key):
                                    p = _resolve_filename(doc.get(key))
                                    if p:
                                        return {'pdf_path': p, 'course_name': doc.get('title') or doc.get('nombre')}

        # 2) try matching query against titles (DB or local)
        if query:
            doc = None
            if col:
                q = {'$or': [{'title': {'$regex': re.compile(re.escape(query), re.IGNORECASE)}},
                             {'description': {'$regex': re.compile(re.escape(query), re.IGNORECASE)}}]}
                doc = col.find_one(q)
            if not doc and local:
                for d in local:
                    text = ' '.join([str(d.get(k, '')).lower() for k in ('title', 'nombre', 'descripcion', 'description')])
                    if query.lower() in text:
                        doc = d
                        break
            if doc:
                for key in ('pdf', 'pdf_path', 'temario', 'file'):
                    if key in doc and doc.get(key):
                        p = _resolve_filename(doc.get(key))
                        if p:
                            return {'pdf_path': p, 'course_name': doc.get('title') or doc.get('nombre')}

        return None
    except Exception as e:
        logger.debug(f"find_pdf_for_user_message error: {e}")
        return None


def process_advisor_submission(phone: str, message_text: str, advisor_course_id=None) -> Dict[str, Any]:
    """MEJORA: Procesa datos de asesor con confirmaciones específicas por tipo de dato"""
    import re
    from datetime import datetime
    
    col = get_collection('advisor_requests')
    try:
        # Detectar tipo de dato enviado
        text_lower = message_text.lower().strip()
        
        # Detectar email
        email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', message_text)
        # Detectar teléfono mexicano
        phone_match = re.search(r'\b(52)?1?\d{10}\b', message_text)
        # Detectar nombre (palabras con mayúsculas, sin símbolos especiales)
        name_match = re.search(r'\b[A-Z][a-záéíóúñ]+\s+[A-Z][a-záéíóúñ]+\b', message_text)
        
        # Generar respuesta específica según el tipo de dato
        if email_match:
            response = f"✅ Perfecto, guardé tu correo: {email_match.group()}. Ahora necesito tu nombre completo."
        elif phone_match:
            response = f"✅ Gracias, recibí tu telefono: {phone_match.group()}. ¿Puedes enviarme una breve descripción de tu proyecto o necesidad?"
        elif name_match:
            response = f"✅ Gracias {name_match.group()}, guardé tu nombre. Ahora necesito tu correo electrónico."
        elif len(text_lower) > 10 and any(word in text_lower for word in ['necesito', 'quiero', 'proyecto', 'instalacion', 'cotizacion', 'empresa']):
            response = "✅ Perfecto, guardé la descripción de tu proyecto. ¡Ya tengo toda la información necesaria! Un asesor especializado te contactará pronto para ayudarte."
            # Marcar como datos completos si parece una descripción de proyecto
            payload = {
                'phone': phone,
                'course_id': advisor_course_id,
                'message': message_text,
                'timestamp': datetime.now().isoformat(),
                'data_type': 'project_description'
            }
            col.insert_one(payload)
            return {"message_for_user": response, "datos_completos": True, "pdf_generated": False, "notification_sent": False}
        else:
            response = "✅ Información recibida. Para completar tu solicitud, necesito: nombre completo, correo electrónico y descripción de tu proyecto."
        
        payload = {
            'phone': phone,
            'course_id': advisor_course_id,
            'message': message_text,
            'timestamp': datetime.now().isoformat()
        }
        col.insert_one(payload)
        return {"message_for_user": response, "datos_completos": False, "pdf_generated": False, "notification_sent": False}
    except Exception as e:
        logger.debug(f"process_advisor_submission error: {e}")
        return {"message_for_user": "Ocurrió un error procesando tu solicitud.", "datos_completos": False}


def select_course_by_name(phone: str, text: str) -> Dict[str, Any]:
    """Try to find matching courses by name and return candidates and a user message."""
    # Simple substring match across title/description
    col = _courses_collection()
    try:
        q = {"$or": [{"title": {"$regex": text, "$options": "i"}}, {"description": {"$regex": text, "$options": "i"}}]}
        cursor = col.find(q).limit(5)
        candidates = []
        for d in cursor:
            d['_id'] = str(d.get('_id'))
            candidates.append(d)
        if not candidates:
            return {"selected": False, "candidates": [], "message": "No encontré cursos que coincidan con esa búsqueda."}
        # build a message listing top candidates
        lines = []
        for i, c in enumerate(candidates[:3], 1):
            title = c.get('title') or c.get('nombre') or f'Curso {i}'
            lines.append(f"{i}. {title}")
        msg = "Encontré estos cursos:\n" + "\n".join(lines) + "\nResponde con el número si quieres seleccionar uno."
        return {"selected": False, "candidates": candidates, "message": msg}
    except Exception as e:
        logger.debug(f"select_course_by_name error: {e}")
        return {"selected": False, "candidates": [], "message": "Error buscando cursos."}


def get_course_schedule_message(course_id) -> str:
    c = get_course_by_id(course_id)
    if not c:
        return "Información de fechas no disponible."
    sched = c.get('schedule') or c.get('fechas') or c.get('dates') or c.get('proximas_fechas')
    if isinstance(sched, list) and sched:
        # Try to filter out past dates and prefer upcoming ones. We'll parse date strings when possible.
        from dateutil import parser as dateparser
        upcoming = []
        now = datetime.now()
        for d in sched:
            if isinstance(d, dict):
                fecha_str = d.get('fecha', '')
                horario = d.get('horario', '')
                parsed = None
                try:
                    # Some fecha strings include ranges like '3 - 4 de Noviembre 2025' - try to parse the first date token
                    parsed = dateparser.parse(fecha_str, fuzzy=True, dayfirst=True)
                except Exception:
                    parsed = None

                # If parsed and it's in the future (or today), include; otherwise skip
                if parsed:
                    if parsed.date() >= now.date():
                        upcoming.append((parsed, fecha_str, horario))
                else:
                    # If unable to parse, keep as potential upcoming (best effort)
                    upcoming.append((None, fecha_str, horario))

        # If we found no upcoming parsed dates, fall back to listing all non-empty entries
        if not upcoming:
            dates_str = "\n".join([f"• {d.get('fecha', '')} ({d.get('horario', '')})" for d in sched if isinstance(d, dict)])
            return f"Fechas y horarios:\n{dates_str}" if dates_str else "Información de fechas no disponible."

        # Build output using upcoming dates (sorted by parsed date when available)
        upcoming_sorted = sorted(upcoming, key=lambda x: x[0] or datetime.max)
        lines = []
        for parsed, fecha_str, horario in upcoming_sorted:
            if horario:
                lines.append(f"• {fecha_str} ({horario})")
            else:
                lines.append(f"• {fecha_str}")

        return f"Fechas próximas:\n" + "\n".join(lines)
    elif sched:
        return f"Fechas y horarios:\n{sched}"
    return "Información de fechas no disponible."


def get_course_price_message(course_id) -> str:
    c = get_course_by_id(course_id)
    if not c:
        return "Información de precios no disponible."
    price = c.get('price') or c.get('precio')
    if not price:
        # try alternative keys in local JSON
        price = c.get('precio') or c.get('precio_usd')
    return f"Precio: {price}" if price else "Información de precios no disponible."


def get_course_full_details_message(course_id) -> str:
    """Generate a complete message with all course details: temario, fechas, precio, ubicación, etc."""
    c = get_course_by_id(course_id)
    if not c:
        return "Información del curso no disponible."

    msg = f"*{c.get('title') or c.get('nombre', 'Curso')}*\n"
    desc = c.get('description') or c.get('descripcion')
    if desc:
        msg += f"{desc}\n\n"

    # Temario
    temario = c.get('temario')
    if temario and isinstance(temario, list):
        msg += "*Temario:*\n"
        for i, mod in enumerate(temario, 1):
            titulo = mod.get('titulo', f'Módulo {i}')
            msg += f"{i}. {titulo}\n"
            subtemas = mod.get('subtemas')
            if subtemas and isinstance(subtemas, list):
                for sub in subtemas:
                    msg += f"   • {sub}\n"
            msg += "\n"

    # Fechas
    fechas = c.get('proximas_fechas')
    if fechas and isinstance(fechas, list):
        msg += "*Fechas disponibles:*\n"
        for f in fechas:
            if isinstance(f, dict):
                fecha = f.get('fecha', '')
                horario = f.get('horario', '')
                msg += f"• {fecha} ({horario})\n"
        msg += "\n"

    # Precio
    precio = c.get('price') or c.get('precio')
    if precio:
        msg += f"*Precio:* {precio}\n"

    # Ubicación
    ubicacion = c.get('location') or c.get('ubicacion')
    if ubicacion:
        msg += f"*Ubicación:* {ubicacion}\n"

    # Duración
    duracion = c.get('duracion')
    if duracion:
        msg += f"*Duración:* {duracion}\n"

    # Modalidad
    modalidad = c.get('modalidad')
    if modalidad:
        msg += f"*Modalidad:* {modalidad}\n"

    # Inscripción
    msg += "\n*Para inscribirte:*\n"
    msg += "Envía 'asesor' o proporciona tus datos (nombre, correo) para que te contacte un representante.\n"
    msg += "También puedes pedir más detalles sobre cualquier aspecto del curso."

    return msg.strip()


def advisor_request_prompt() -> str:
    return (
        "Perfecto 👌 solo necesito que me compartas:\n"
        "👉 tu nombre completo\n"
        "👉 nombre de tu empresa\n"
        "👉 tu RFC o razón social\n"
        "👉 correo electrónico\n"
        "👉 y el link de tu sitio web, si tienes 🌐\n\n"
        "Con eso generamos tu perfil y te dan seguimiento desde el área correspondiente."
    )


def list_courses_message() -> str:
    """
    Construye un mensaje listando los cursos de forma conversacional, sin números.
    """
    try:
        courses = [get_course_by_id(i) for i in range(1, 6)]
        lines = ["Estos son nuestros cursos disponibles:\n"]
        
        for c in courses:
            if not c:
                continue
            nombre = c.get('title') or c.get('nombre', '')
            duracion = c.get('duracion', '')
            modalidad = c.get('modalidad', '')
            precio = c.get('precio', None)
            
            line = f"🎯 *{nombre}*"
            if duracion:
                line += f" — {duracion}"
            if modalidad:
                # Normalize online modality to a user-friendly fixed phrase
                mod_low = str(modalidad).lower()
                if 'online' in mod_low or 'línea' in mod_low or 'en linea' in mod_low or 'en línea' in mod_low:
                    line += f" — en línea (cada martes)"
                else:
                    line += f" — {modalidad}"
            if precio:
                line += f" — {precio}"
            lines.append(line)

        lines.append("\nPuedes preguntarme sobre cualquier curso mencionando el tema que te interesa, por ejemplo:")
        lines.append("• 'Me interesa el cableado estructurado'")
        lines.append("• 'Cuéntame sobre FTTH'")
        lines.append("• 'Quiero información de empalmes'")
        lines.append("\nO si necesitas asesoría personalizada, solo dime 'quiero hablar con un asesor'.")
        return "\n".join(lines)
    except Exception as e:
        logger.error(f"Error construyendo lista de cursos: {e}")
        return "Tenemos varios cursos disponibles en fibra óptica y telecomunicaciones. Dime sobre qué tema te gustaría aprender."


def smart_course_selection_by_intent(user_message: str) -> Dict[str, Any]:
    """
    Detecta qué curso quiere el usuario basándose en palabras clave y contexto natural.
    Retorna el curso más relevante o None si no hay coincidencia clara.
    """
    message_lower = user_message.lower()
    courses = [get_course_by_id(i) for i in range(1, 6)]
    
    # Mapeo de palabras clave a cursos
    course_keywords = {
        1: ['cableado', 'estructurado', 'cobre', 'utp', 'cable', 'ethernet', 'lan'],
        2: ['planta externa', 'exterior', 'aereo', 'subterraneo', 'poste', 'outdoor'],
        3: ['ftth', 'wisp', 'isp', 'proveedor', 'internet', 'residencial', 'hogar'],
        4: ['ponlan', 'pon', 'pasiva', 'pasivas', 'enterprise', 'empresarial'],
        5: ['empalme', 'empalmes', 'otdr', 'medicion', 'mediciones', 'fusion', 'soldadura']
    }
    
    # Buscar coincidencias
    matches = []
    for course_id, keywords in course_keywords.items():
        score = sum(1 for keyword in keywords if keyword in message_lower)
        if score > 0:
            course = get_course_by_id(course_id)
            if course:
                matches.append((course, score))
    
    # También buscar por nombre parcial del curso
    for course in courses:
        if not course:
            continue
        course_name = (course.get('title') or course.get('nombre', '')).lower()
        course_words = course_name.split()
        
        # Verificar si alguna palabra significativa del curso está en el mensaje
        significant_words = [w for w in course_words if len(w) > 3 and w not in ['para', 'con', 'del', 'las', 'los']]
        for word in significant_words:
            if word in message_lower:
                existing_match = next((m for m in matches if m[0].get('id') == course.get('id')), None)
                if existing_match:
                    # Aumentar score si ya existe
                    matches = [(c, s+2) if c.get('id') == course.get('id') else (c, s) for c, s in matches]
                else:
                    matches.append((course, 2))
                break
    
    if matches:
        # Ordenar por score y retornar el mejor
        matches.sort(key=lambda x: x[1], reverse=True)
        best_course = matches[0][0]
        return {
            'found': True,
            'course': best_course,
            'confidence': matches[0][1],
            'message': f"Detecté que te interesa el curso '{best_course.get('title') or best_course.get('nombre', '')}'"
        }
    
    return {'found': False, 'course': None, 'message': 'No pude identificar un curso específico en tu mensaje'}


def get_courses_recommendation_message(user_query: str = "") -> str:
    """
    Proporciona una recomendación de cursos basada en la consulta del usuario.
    Incluye información completa de todos los cursos disponibles.
    """
    try:
        courses = [get_course_by_id(i) for i in range(1, 6)]
        
        # Mensaje introductorio basado en la consulta
        if "fibra" in user_query.lower() or "optic" in user_query.lower():
            intro = "Excelente, tenemos varios cursos especializados en fibra óptica. Te recomiendo especialmente:\n\n"
        elif "redes" in user_query.lower():
            intro = "Perfecto, nuestros cursos de redes y telecomunicaciones son ideales para ti:\n\n"
        else:
            intro = "Te presento nuestros cursos disponibles en fibra óptica y telecomunicaciones:\n\n"
        
        lines = [intro]
        
        for c in courses:
            if not c:
                continue
                
            idx = c.get('id', '')
            nombre = c.get('title') or c.get('nombre', '')
            descripcion = c.get('description') or c.get('descripcion', '')
            duracion = c.get('duracion', '')
            modalidad = c.get('modalidad', '')
            precio = c.get('precio', '')
            
            # Obtener fechas próximas
            fechas_info = ""
            proximas_fechas = c.get('proximas_fechas', [])
            if proximas_fechas and len(proximas_fechas) > 0:
                primera_fecha = proximas_fechas[0]
                if isinstance(primera_fecha, dict):
                    fecha_str = primera_fecha.get('fecha', '')
                    horario_str = primera_fecha.get('horario', '')
                    if fecha_str:
                        fechas_info = f"📅 Próxima fecha: {fecha_str}"
                        if horario_str:
                            fechas_info += f" ({horario_str})"
                else:
                    fechas_info = f"📅 Próxima fecha: {primera_fecha}"
            
            # Construir mensaje del curso sin números
            course_msg = f"🎯 *{nombre}*\n"
            if descripcion:
                course_msg += f"📝 {descripcion}\n"
            if duracion:
                course_msg += f"⏱️ Duración: {duracion}\n"
            if modalidad:
                course_msg += f"🎯 Modalidad: {modalidad}\n"
            if precio:
                course_msg += f"💰 Precio: {precio}\n"
            if fechas_info:
                course_msg += f"{fechas_info}\n"
            
            lines.append(course_msg)
        
        lines.append("Para obtener más información sobre algún curso específico, simplemente menciona su nombre o el tema que te interesa.")
        lines.append("\nSi deseas que un asesor te contacte, solo dime 'quiero hablar con un asesor' o 'contactar asesor'.")
        
        return "\n".join(lines)
        
    except Exception as e:
        logger.error(f"Error generando recomendación de cursos: {e}")
        return "Tenemos excelentes cursos de fibra óptica y telecomunicaciones. Escribe 'cursos' para ver la lista completa."


def get_course_duration_message(course_id) -> str:
    """
    Obtiene información sobre la duración del curso.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    duracion = course.get('duracion', '')
    if duracion:
        return f"El curso tiene una duración de {duracion}."
    else:
        return "Información de duración no especificada para este curso."


def get_course_modality_message(course_id) -> str:
    """
    Obtiene información sobre la modalidad del curso.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    modalidad = course.get('modalidad', '')
    if modalidad:
        return f"El curso se imparte en modalidad {modalidad}."
    else:
        return "Información de modalidad no especificada para este curso."


def get_course_location_message(course_id) -> str:
    """
    Obtiene información sobre la ubicación del curso.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    ubicacion = course.get('ubicacion', '')
    if ubicacion:
        return f"El curso se imparte en: {ubicacion}"
    else:
        return "La ubicación del curso es en nuestras instalaciones principales. Para más detalles específicos, contacta con un asesor."


def get_course_price_message(course_id) -> str:
    """
    Obtiene información sobre el precio del curso.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    precio = course.get('precio', '')
    if precio:
        return f"El precio del curso es: {precio}"
    else:
        return "Para conocer el precio actualizado de este curso, te recomendamos contactar con uno de nuestros asesores."


def get_course_schedule_message(course_id) -> str:
    """
    Obtiene información sobre las fechas y horarios del curso.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    proximas_fechas = course.get('proximas_fechas', [])
    if proximas_fechas and len(proximas_fechas) > 0:
        lines = ["Fechas y horarios:"]
        for fecha_info in proximas_fechas:
            if isinstance(fecha_info, dict):
                fecha = fecha_info.get('fecha', '')
                horario = fecha_info.get('horario', '')
                if fecha:
                    line = f"• {fecha}"
                    if horario:
                        line += f" ({horario})"
                    lines.append(line)
            else:
                lines.append(f"• {fecha_info}")
        
        if len(lines) == 1:
            return "Información de fechas próximamente disponible."
        
        return "\n".join(lines)
    else:
        return "Próximas fechas del curso por confirmar. Te recomendamos contactar con un asesor para información actualizada."


def get_course_full_details_message(course_id) -> str:
    """
    Obtiene información completa del curso incluyendo temario detallado.
    """
    course = get_course_by_id(course_id)
    if not course:
        return "Información del curso no disponible."
    
    lines = []
    
    # Información básica
    nombre = course.get('title') or course.get('nombre', '')
    if nombre:
        lines.append(f"📚 *{nombre}*")
    
    # Descripción
    descripcion = course.get('description') or course.get('descripcion', '')
    if descripcion:
        lines.append(f"\n📝 *Descripción:*\n{descripcion}")
    
    # Temario detallado (formateado)
    temario = course.get('temario', '')
    if temario and isinstance(temario, list):
        lines.append("\n📖 *Temario del curso:*")
        for i, modulo in enumerate(temario, 1):
            if isinstance(modulo, dict):
                titulo = modulo.get('titulo') or modulo.get('title') or f'Módulo {i}'
                lines.append(f"{i}. {titulo}")
                subtemas = modulo.get('subtemas') or modulo.get('subtopics') or []
                if isinstance(subtemas, list):
                    for sub in subtemas:
                        lines.append(f"   • {sub}")
            else:
                # If module is a plain string, just list it
                lines.append(f"{i}. {str(modulo)}")
        # blank line after temario
        lines.append("")
    elif temario:
        # If temario exists but is not a list, include as-is
        lines.append(f"\n📖 *Temario del curso:*\n{temario}")
    
    # Objetivos
    objetivos = course.get('objetivos', '')
    if objetivos:
        lines.append(f"\n🎯 *Objetivos de aprendizaje:*\n{objetivos}")
    
    # Duración
    duracion = course.get('duracion', '')
    if duracion:
        lines.append(f"\n⏱️ *Duración:* {duracion}")
    
    # Modalidad
    modalidad = course.get('modalidad', '')
    if modalidad:
        lines.append(f"\n🎯 *Modalidad:* {modalidad}")
    
    # Precio
    precio = course.get('precio', '')
    if precio:
        lines.append(f"\n💰 *Precio:* {precio}")
    
    # Fechas
    proximas_fechas = course.get('proximas_fechas', [])
    if proximas_fechas:
        lines.append(f"\n📅 *Próximas fechas:*")
        for fecha_info in proximas_fechas:
            if isinstance(fecha_info, dict):
                fecha = fecha_info.get('fecha', '')
                horario = fecha_info.get('horario', '')
                if fecha:
                    line = f"• {fecha}"
                    if horario:
                        line += f" ({horario})"
                    lines.append(line)
            else:
                lines.append(f"• {fecha_info}")
    
    # Ubicación
    ubicacion = course.get('ubicacion', '')
    if ubicacion:
        lines.append(f"\n📍 *Ubicación:* {ubicacion}")
    
    # Requisitos
    requisitos = course.get('requisitos', '')
    if requisitos:
        lines.append(f"\n📋 *Requisitos:* {requisitos}")
    
    # Instructor
    instructor = course.get('instructor', '')
    if instructor:
        lines.append(f"\n👨‍🏫 *Instructor:* {instructor}")
    
    if not lines:
        return "Información detallada del curso no disponible en este momento."
    
    return "\n".join(lines)


def get_available_courses_message() -> str:
    """
    Obtiene una lista de todos los cursos disponibles con opción de ver temario.
    """
    try:
        col = _courses_collection()
        if col is None:
            return "No hay cursos disponibles en este momento."
        
        courses = list(col.find({}, {'id': 1, 'title': 1, 'nombre': 1}).sort('id', 1))
        
        if not courses:
            return "No hay cursos disponibles en este momento."
        
        lines = ["Estos son nuestros cursos disponibles:"]
        for course in courses:
            course_id = course.get('id')
            course_name = course.get('title') or course.get('nombre', 'Curso sin nombre')
            lines.append(f"• {course_name}")
        
        return "\n".join(lines)
        
    except Exception as e:
        logger.error(f"Error obteniendo lista de cursos: {e}")
        return "No se pudo obtener la lista de cursos disponibles."


def parse_course_query(text: str) -> Dict[str, Any]:
    """
    Parsea un texto para detectar IDs de cursos y tipos de consultas.
    """
    try:
        text_lower = (text or '').lower()
        course_ids = []
        query_types = []
        
        # Detectar tipos de consulta
        if any(word in text_lower for word in ['temario', 'contenido', 'programa', 'syllabus', 'pdf']):
            query_types.append('temario')
        
        if any(word in text_lower for word in ['fecha', 'fechas', 'días', 'dias', 'horarios', 'cuándo', 'cuando']):
            query_types.append('fechas')
            
        if any(word in text_lower for word in ['precio', 'costo', 'cotiz', 'cuánto', 'cuanto', 'valor', 'tarifa']):
            query_types.append('precio')
            
        if any(word in text_lower for word in ['ubicación', 'ubicacion', 'dónde', 'donde', 'lugar', 'sede']):
            query_types.append('ubicacion')
            
        if any(word in text_lower for word in ['inscripción', 'inscripcion', 'inscribirme', 'registro', 'matricularme']):
            query_types.append('inscripcion')
            
        if any(word in text_lower for word in ['asesor', 'asesoria', 'asesoría', 'contacto', 'hablar']):
            query_types.append('asesor')
            
        if any(word in text_lower for word in ['duración', 'duracion', 'tiempo', 'cuánto dura', 'cuanto dura']):
            query_types.append('duracion')
            
        if any(word in text_lower for word in ['modalidad', 'presencial', 'virtual', 'online', 'remoto']):
            query_types.append('modalidad')
        
        # Detectar números de curso (1-5)
        import re
        numbers = re.findall(r'\b([1-5])\b', text)
        course_ids = [int(num) for num in numbers]
        
        # También detectar nombres de cursos comunes (más específicos para evitar falsos positivos)
        course_keywords = {
            1: ['cableado estructurado', 'cableado', 'estructurado', 'cobre'],  # Priorizar "cableado estructurado" completo
            2: ['planta externa', 'fibra óptica externa', 'exterior', 'outdoor'],  # Más específico
            3: ['ftth', 'fibra óptica ftth', 'wisp', 'isp'],  # FTTH es único
            4: ['ponlan', 'redes pasivas', 'enterprise', 'entornos enterprise'],  # PONLAN es único
            5: ['empalmes', 'mediciones otdr', 'otdr', 'fibra óptica enlace']  # OTDR es único
        }
        
        # Buscar con prioridad: primero términos únicos, luego genéricos
        unique_terms = {
            3: ['ftth'],
            4: ['ponlan'], 
            5: ['otdr', 'empalmes'],
            2: ['planta externa'],
            1: ['cableado estructurado']
        }
        
        # Primero buscar términos únicos
        for course_id, terms in unique_terms.items():
            if any(term in text_lower for term in terms):
                if course_id not in course_ids:
                    course_ids.append(course_id)
        
        # Luego buscar otras palabras clave si no hay términos únicos
        if not course_ids:
            for course_id, keywords in course_keywords.items():
                if any(keyword in text_lower for keyword in keywords):
                    if course_id not in course_ids:
                        course_ids.append(course_id)
        
        return {
            'course_ids': course_ids,
            'query_types': query_types
        }
        
    except Exception as e:
        logger.error(f"Error parseando query de curso: {e}")
        return {'course_ids': [], 'query_types': []}
