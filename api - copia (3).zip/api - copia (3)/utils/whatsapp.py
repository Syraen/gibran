import requests
import logging
import json
import traceback
import os
from typing import Optional, Dict, Any
from datetime import datetime
import re
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin

# Configuraciones
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)

# Servicios principales
from services.chat_ai import chat_with_gemini

# Optional fuzzy matching to improve course name detection (non-fatal)
try:
    from rapidfuzz import process as rf_process, fuzz as rf_fuzz
    RAPIDFUZZ_AVAILABLE = True
except Exception:
    RAPIDFUZZ_AVAILABLE = False

# Conversation memory helpers
from services.conversation_memory import save_selected_course, get_selected_course

# Importaciones de servicios de memoria y conversación
from services.conversation_memory_utils import (
    save_conversation_memory, get_conversation_memory,
    save_current_item, get_current_item, save_listed_items, get_listed_items
)

# Módulos de manejo de mensajes
# whatsapp_message_handlers lives under the `routes` package, import from there to avoid ModuleNotFoundError
from routes.whatsapp_message_handlers import (
    send_text_message, send_document_message, log_webhook_event,
    set_current_webhook_message_id, clear_current_webhook_message_id
)

# Herramientas para temarios y selección de curso
from utils.temario_handler import (
    is_temario_request, extract_course_number, get_course_temario_message,
    find_pdf_for_user_message, ask_for_course_number
)
from models.courses import CourseManager
from services.ml_service import ml_service
from services.notification_service import notification_service
try:
    from services.advisor_simple import start_advisor_simple, process_advisor_data as advisor_simple_process
except Exception:
    start_advisor_simple = None
    advisor_simple_process = None

# Configurar logger para este módulo
logger = logging.getLogger(__name__)

# Crear blueprint para rutas de WhatsApp Marketing
whatsapp_marketing_bp = Blueprint('whatsapp_marketing', __name__)


# Cargar datos de cursos, productos y webinars desde JSON
def load_json_data():
    base_path = os.path.join(os.path.dirname(__file__), '..', 'info')
    
    courses = []
    products = []
    webinars = []
    
    # Cargar cursos
    courses_path = os.path.join(base_path, 'courses')
    if os.path.exists(courses_path):
        for file in os.listdir(courses_path):
            if file.endswith('.json'):
                with open(os.path.join(courses_path, file), 'r', encoding='utf-8') as f:
                    courses.append(json.load(f))
    
    # Cargar productos
    products_path = os.path.join(base_path, 'products')
    if os.path.exists(products_path):
        for file in os.listdir(products_path):
            if file.endswith('.json'):
                with open(os.path.join(products_path, file), 'r', encoding='utf-8') as f:
                    products.append(json.load(f))
    
    # Cargar webinars
    webinars_path = os.path.join(base_path, 'webinars')
    if os.path.exists(webinars_path):
        for file in os.listdir(webinars_path):
            if file.endswith('.json'):
                with open(os.path.join(webinars_path, file), 'r', encoding='utf-8') as f:
                    webinars.append(json.load(f))
    
    return courses, products, webinars

def load_catalog_from_db():
    """Intentar cargar catálogos desde la base MongoDB 'splitbot' (colecciones: courses, products, webinars).
    Si no está disponible pymongo o la conexión falla, retornar None para que el caller use JSON.
    """
    try:
        from pymongo import MongoClient
    except Exception:
        logger.debug("pymongo no disponible, usando JSON local para datos de catálogo")
        return None

    mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
    try:
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=3000)
        db = client.get_database('splitbot')
        courses = list(db.get_collection('courses').find({})) if 'courses' in db.list_collection_names() else []
        products = list(db.get_collection('products').find({})) if 'products' in db.list_collection_names() else []
        webinars = list(db.get_collection('webinars').find({})) if 'webinars' in db.list_collection_names() else []
        # sanitize ObjectId and ensure lists of dicts
        import bson
        def sanitize_list(lst):
            out = []
            for d in lst:
                try:
                    od = dict(d)
                    # remove _id or convert to string
                    if od.get('_id') is not None:
                        try:
                            od['id'] = str(od.get('_id'))
                        except Exception:
                            od['id'] = od.get('_id')
                        od.pop('_id', None)
                    out.append(od)
                except Exception:
                    continue
            return out

        return sanitize_list(courses), sanitize_list(products), sanitize_list(webinars)
    except Exception as e:
        logger.debug(f"No se pudo conectar a MongoDB para cargar catálogo: {e}")
        return None


# Cargar datos al importar el módulo: preferir MongoDB splitbot -> colecciones (courses, products, webinars), si falla usar JSON local
db_catalog = load_catalog_from_db()
if db_catalog:
    COURSES_DATA, PRODUCTS_DATA, WEBINARS_DATA = db_catalog
    logger.info(f"Loaded catalog from MongoDB: courses={len(COURSES_DATA)}, products={len(PRODUCTS_DATA)}, webinars={len(WEBINARS_DATA)}")
else:
    COURSES_DATA, PRODUCTS_DATA, WEBINARS_DATA = load_json_data()
    logger.info(f"Loaded catalog from JSON files: courses={len(COURSES_DATA)}, products={len(PRODUCTS_DATA)}, webinars={len(WEBINARS_DATA)}")


def find_best_course_match(query: str):
    """Public helper: intenta encontrar el curso más parecido al query.

    Retorna el dict del curso si se encuentra, o None.
    Usa rapidfuzz si está disponible, sino hace substring match.
    """
    if not query:
        return None
    q = query.lower()
    names = []
    mapping = {}
    for c in COURSES_DATA:
        name = (c.get('nombre') or '').strip()
        if not name:
            continue
        names.append(name)
        mapping[name] = c

    if RAPIDFUZZ_AVAILABLE and names:
        try:
            # try token_sort_ratio first with a slightly lower threshold
            res = rf_process.extractOne(q, names, scorer=rf_fuzz.token_sort_ratio)
            logger.debug(f"rapidfuzz token_sort_ratio result: {res}")
            if res and res[1] >= 60:
                logger.info(f"Fuzzy matched (token_sort_ratio) '{query}' -> '{res[0]}' score={res[1]}")
                return mapping.get(res[0])
            # try token_set_ratio
            res2 = rf_process.extractOne(q, names, scorer=rf_fuzz.token_set_ratio)
            logger.debug(f"rapidfuzz token_set_ratio result: {res2}")
            if res2 and res2[1] >= 60:
                logger.info(f"Fuzzy matched (token_set_ratio) '{query}' -> '{res2[0]}' score={res2[1]}")
                return mapping.get(res2[0])
            # try partial_ratio as last resort
            res3 = rf_process.extractOne(q, names, scorer=rf_fuzz.partial_ratio)
            logger.debug(f"rapidfuzz partial_ratio result: {res3}")
            if res3 and res3[1] >= 60:
                logger.info(f"Fuzzy matched (partial_ratio) '{query}' -> '{res3[0]}' score={res3[1]}")
                return mapping.get(res3[0])
        except Exception:
            # en caso de error con rapidfuzz, continuar con fallback
            logger.exception("Error usando rapidfuzz en find_best_course_match")

    # fallback simple: substring
    for n, c in mapping.items():
        if q in n.lower():
            logger.info(f"Substring matched '{query}' -> '{n}'")
            return c

    return None


def is_greeting_only(message: str) -> bool:
    """
    Detecta si el mensaje del usuario es solo un saludo (ej. 'hola', 'buenos días', 'buenas tardes', etc.)
    En esos casos no queremos disparar automáticamente el flujo de cursos o el LLM de catálogo.
    """
    if not message:
        return False
    m = message.strip().lower()
    # eliminar emojis y puntuación simple
    import re
    m_clean = re.sub(r'[^-\w\s]', '', m)
    m_clean = re.sub(r'\s+', ' ', m_clean).strip()
    greetings = [
        'hola', 'buenos días', 'buenas tardes', 'buenas noches', 'buen dia', 'buenas', 'buen dia', 'buenas noches',
        'hi', 'hello', 'hey', 'buenas tardes 😊', 'buenas tardes :)'
    ]
    # if the cleaned message equals a greeting or is just one short greeting word
    if m_clean in greetings:
        return True
    # allow small variants like 'hola!' or 'hola 👋' already removed by cleaning
    if re.match(r'^(hola|hi|hey|hello)(\s+.*)?$', m_clean) and len(m_clean.split()) <= 3:
        # if message is only a greeting or greeting plus a short token, treat as greeting-only
        # but if it says 'hola quiero' we don't treat as greeting-only because user asks something
        if any(w in m_clean for w in ['quiero', 'información', 'informacion', 'curso', 'cursos', 'producto', 'webinar']):
            return False
        return True
    return False


@whatsapp_marketing_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')

    logger.info(f"Verificación de webhook marketing: mode={mode}, token={token != None}")

    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook de marketing verificado exitosamente")
        return challenge

    logger.warning("Verificación de webhook de marketing fallida")
    return "Verification failed", 403


@whatsapp_marketing_bp.route('/webhook', methods=['POST'])
def webhook_handler():
    try:
        # Persistir el cuerpo bruto del webhook inmediatamente
        try:
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_marketing_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== MARKETING WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END MARKETING WEBHOOK ===\n")
            logger.debug("Raw marketing webhook persisted to logs/webhook_marketing_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw marketing webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST de marketing recibido")

        # Registrar información estructurada del webhook
        try:
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)

            log_webhook_event(
                event_type="webhook_marketing_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
        except Exception as e:
            logger.error(f"Error al procesar información de webhook de marketing: {e}")
            logger.error(traceback.format_exc())

        if not payload:
            logger.warning("Payload vacío recibido en marketing")
            return

        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload de marketing")
            return

        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                messages = value.get('messages', [])
                contacts = value.get('contacts', [])

                for message in messages:
                    message_type = message.get('type')
                    if message_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                        from_number = message.get('from')
                        whatsapp_profile = contacts[0].get('profile', {}) if contacts else {}

                        logger.info(f"Mensaje de marketing recibido de {from_number}: {message_text}")

                        # Primero intentar manejar contexto de cursos/temarios
                        try:
                            handled = handle_course_and_temario_flow(from_number, message_text, whatsapp_profile)
                        except Exception as _e:
                            logger.debug(f"Error en flow de temario: {_e}")
                            handled = False

                        # Si no fue manejado por el flujo de cursos, procesarlo con IA de marketing
                        if not handled:
                            process_user_message_marketing(from_number, message_text, whatsapp_profile)

        # Limpiar ID de mensaje actual
        clear_current_webhook_message_id()
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        logger.error(f"Error procesando webhook de marketing: {e}", exc_info=True)
        clear_current_webhook_message_id()
        return jsonify({"status": "error", "message": "Error interno"}), 500
    finally:
        clear_current_webhook_message_id()


def process_user_message_marketing(phone: str, message_text: str, whatsapp_profile: dict = None):
    """
    Procesa un mensaje individual del usuario con IA de marketing
    """
    try:
        # Preparar información detallada de cursos, productos y webinars para el prompt
        courses_info = []
        for c in COURSES_DATA:
            info = f"CURSO: {c['nombre']}\n"
            info += f"Descripción: {c['descripcion']}\n"
            info += f"Modalidad: {c['modalidad']}\n"
            info += f"Precio: {c['precio']}\n"
            info += f"Ubicación: {c['ubicacion']}\n"
            info += f"Horario: {c['horario']}\n"
            info += f"Duración: {c['duracion']}\n"
            if 'proximas_fechas' in c and c['proximas_fechas']:
                fechas = [f"{f['fecha']} ({f['horario']})" for f in c['proximas_fechas']]
                info += f"Próximas fechas: {', '.join(fechas)}\n"
            if 'temario' in c and c['temario']:
                temario = []
                for t in c['temario']:
                    temario.append(f"- {t['titulo']}")
                    if 'subtemas' in t:
                        for st in t['subtemas']:
                            temario.append(f"  • {st}")
                info += f"Temario:\n" + "\n".join(temario) + "\n"
            courses_info.append(info)
        
        products_info = []
        for p in PRODUCTS_DATA:
            info = f"PRODUCTO: {p['nombre']}\n"
            info += f"Descripción: {p['descripcion']}\n"
            info += f"Precio: {p['precio']}\n"
          
            if 'especificaciones' in p:
                specs = "\n".join(f"- {s}" for s in p['especificaciones'])
                info += f"Especificaciones:\n{specs}\n"
            products_info.append(info)
        try:
            # persist the products list we prepared for pronoun resolution
            save_listed_items(phone, 'products', PRODUCTS_DATA)
        except Exception:
            pass
        
        webinars_info = []
        for w in WEBINARS_DATA:
            info = f"WEBINAR: {w['title']}\n"
            info += f"Descripción: {w['description']}\n"
            if 'fechas' in w:
                info += f"Fechas: {', '.join(w['fechas'])}\n"
            if 'horario' in w:
                info += f"Horario: {', '.join(w['horario'])}\n"
            if 'topics' in w:
                topics = "\n".join(f"- {t}" for t in w['topics'])
                info += f"Temas:\n{topics}\n"
            webinars_info.append(info)
        
        all_info = "\n---\n".join(courses_info + products_info + webinars_info)

        # Helper: fuzzy match course name using rapidfuzz when available
        def fuzzy_find_course_by_name(query: str):
            if not query:
                return None
            q = query.lower()
            # build mapping name -> course
            names = []
            mapping = {}
            for c in COURSES_DATA:
                name = (c.get('nombre') or '').strip()
                if not name:
                    continue
                names.append(name)
                mapping[name] = c

            if RAPIDFUZZ_AVAILABLE and names:
                try:
                    res = rf_process.extractOne(q, names, scorer=rf_fuzz.token_sort_ratio)
                    if res and res[1] >= 70:
                        return mapping.get(res[0])
                except Exception:
                    pass

            # fallback: simple substring check
            for n, c in mapping.items():
                if q in n.lower():
                    return c
            return None

        logger.info(f"Processing marketing message from {phone}: {message_text}")

        try:
            if is_greeting_only(message_text):
                # Reset conversation memory for a fresh session when user sends a greeting
                try:
                    from services.conversation_memory import ConversationMemory
                    ConversationMemory.reset_memory(phone, notify=False, preserve_selected_course=False)
                except Exception:
                    try:
                        # fallback to clearing via helper
                        from services.conversation_memory import clear_conversation_memory
                        clear_conversation_memory(phone)
                    except Exception:
                        pass

                # Do not populate catalog or call LLM for plain salutations; reply short
                send_text_message(phone, "Hola 👋 ¿En qué puedo ayudarte hoy? Si quieres información sobre nuestros cursos, escribe por ejemplo 'temario' o 'cursos'.")
                return
        except Exception:
            pass

        # Detectar si el usuario menciona un curso concreto y guardarlo en memoria de conversación
        try:
            import re
            course_candidate = None
            m = re.search(r"\bcurso\s+(?:id\s+)?(\d{1,3})\b", message_text.lower())
            if m:
                try:
                    cid = int(m.group(1))
                    for c in COURSES_DATA:
                        try:
                            # compare string forms first to avoid int() on ObjectId hex
                            cid_field = c.get('id')
                            if cid_field is not None and str(cid_field) == str(cid):
                                course_candidate = c
                                break
                            # fallback: try int conversion when safe
                            try:
                                if int(cid_field) == cid:
                                    course_candidate = c
                                    break
                            except Exception:
                                continue
                        except Exception:
                            continue
                except Exception:
                    course_candidate = None

            # Si no se detectó por id, intentar emparejar por nombre
            if not course_candidate:
                tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                if tokens:
                    for c in COURSES_DATA:
                        name = (c.get('nombre') or '').lower()
                        short = (c.get('nombre_corto') or '').lower()
                        if any(tok in name or tok in short for tok in tokens):
                            course_candidate = c
                            break

            # If still not found, try fuzzy matching on the whole message
            if not course_candidate:
                try:
                    course_candidate = fuzzy_find_course_by_name(message_text)
                except Exception:
                    course_candidate = None

            if course_candidate:
                try:
                    cid = int(course_candidate.get('id') or 0)
                except Exception:
                    cid = 0
                cname = course_candidate.get('nombre') or course_candidate.get('title') or 'Curso'
                try:                  
                    lower_msg = (message_text or '').strip().lower()
                    explicit_selection = False
                    try:
                        if re.match(r"^\d+$", lower_msg):
                            explicit_selection = True
                        if any(v in lower_msg for v in ['quiero', 'seleccionar', 'ese', 'ese curso', 'lo quiero', 'dame', 'quiero el']):
                            explicit_selection = True
                    except Exception:
                        explicit_selection = False

                    logger.info(f"Detected course_candidate for {phone}: id={cid}, name={cname}; explicit_selection={explicit_selection}")
                    if explicit_selection:
                        # Guardar selección en memoria (para que chat_ai pueda leerla como selected_course)
                        save_selected_course(phone, cid, cname, course_candidate)
                        try:
                            save_current_item(phone, 'course', cid, cname, course_candidate)
                        except Exception:
                            pass
                except Exception:
                    # como fallback, usar save_conversation_memory
                    try:
                        save_conversation_memory(phone, 'selected_course', {'id': cid, 'name': cname, 'details': course_candidate})
                        try:
                            save_current_item(phone, 'course', cid, cname, course_candidate)
                        except Exception:
                            pass
                    except Exception:
                        pass
        except Exception:
            pass

    # Build a compact structured block of course facts so the LLM has exact IDs and attributes
        try:
            datos_cursos = []
            # helper: parse spanish dates like '2 de diciembre del 2025' -> datetime
            def parse_spanish_date(s: str):
                if not s or not isinstance(s, str):
                    return None
                s = s.strip().lower()
                import re
                m = re.search(r"(\d{1,2})\s+de\s+([a-záéíóúñ]+)\s+(?:del\s+)?(\d{4})", s)
                if not m:
                    return None
                day = int(m.group(1))
                month_name = m.group(2)
                year = int(m.group(3))
                months = {
                    'enero':1,'febrero':2,'marzo':3,'abril':4,'mayo':5,'junio':6,
                    'julio':7,'agosto':8,'septiembre':9,'setiembre':9,'octubre':10,'noviembre':11,'diciembre':12
                }
                month = months.get(month_name.lower())
                if not month:
                    return None
                from datetime import datetime
                try:
                    return datetime(year, month, day)
                except Exception:
                    return None

            def get_item_next_date(item):
                # item may have 'fechas' list of strings or dicts
                if not item:
                    return None
                dates = item.get('fechas') or item.get('proximas_fechas') or item.get('fechas_evento') or []
                if not dates:
                    return None
                parsed = []
                for d in dates:
                    try:
                        if isinstance(d, dict):
                            candidate = d.get('fecha') or d.get('date')
                        else:
                            candidate = d
                        dt = parse_spanish_date(str(candidate))
                        if dt:
                            parsed.append(dt)
                    except Exception:
                        continue
                if not parsed:
                    return None
                # return the most recent (max)
                return max(parsed)
            # sort courses by their next date (most recent first)
            try:
                sorted_courses = sorted(COURSES_DATA, key=lambda x: get_item_next_date(x) or None, reverse=True)
            except Exception:
                sorted_courses = COURSES_DATA
            for c in sorted_courses:
                try:
                    cid = c.get('id') or ''
                except Exception:
                    cid = ''
                precio = c.get('precio') or c.get('price') or 'Consultar con asesor'
                modalidad = c.get('modalidad') or c.get('modalidad_nombre') or c.get('modalidad_tipo') or 'N/D'
                ubicacion = c.get('ubicacion') or c.get('location') or 'N/D'
                duracion = c.get('duracion') or c.get('duration') or 'N/D'
                datos_cursos.append(f"ID:{cid} | Nombre:{c.get('nombre')} | Precio:{precio} | Modalidad:{modalidad} | Ubicación:{ubicacion} | Duración:{duracion}")
            datos_cursos_block = "\n".join(datos_cursos)
            try:
                # Persist the list of courses shown so follow-up pronoun/selection resolution can use it
                save_listed_items(phone, 'courses', sorted_courses)
            except Exception:
                pass
        except Exception:
            datos_cursos_block = ''

    # If the user asks about online/modality, reply directly with webinars ordered by date (most recent first)
        try:
            mq = (message_text or '').lower()
            online_triggers = ['online', 'en linea', 'en línea', 'modalidad', 'modalidad online', 'curso en linea', 'cursos en linea', 'cursos en línea', 'modalidad online', 'webinars', 'webinar']
            if any(t in mq for t in online_triggers):
                # sort webinars by next date (most recent first)
                try:
                    sorted_webinars = sorted(WEBINARS_DATA, key=lambda w: get_item_next_date(w) or None, reverse=True)
                except Exception:
                    sorted_webinars = WEBINARS_DATA

                parts = ["¡Hola! Veo que buscas opciones en modalidad online. Aquí tienes nuestros webinars (ordenados del más próximo al más lejano):\n"]
                from textwrap import shorten
                for w in sorted_webinars:
                    title = w.get('title') or w.get('name') or 'Webinar'
                    desc = w.get('description', '')
                    fechas = w.get('fechas') or []
                    horario = w.get('horario') or []
                    link = w.get('link') or ''
                    # format dates
                    fechas_str = ', '.join([str(f) for f in fechas if f]) or 'Fechas por confirmar'
                    horario_str = ', '.join([str(h) for h in horario if h]) or 'Horario por confirmar'
                    short_desc = shorten(desc, width=300, placeholder='...')
                    parts.append(f"• {title}\n  Fechas: {fechas_str}\n  Horario: {horario_str}\n  {short_desc}\n")

                reply = "\n\n".join(parts)
                try:
                    save_listed_items(phone, 'webinars', sorted_webinars)
                except Exception:
                    pass
                # Send the webinars reply to the user and mark handled
                try:
                    send_text_message(phone, reply)
                except Exception:
                    logger.exception('Error sending webinars reply')
                return
            # Detectar si el usuario menciona un producto concreto y guardarlo
            try:
                product_candidate = None
                m2 = re.search(r"\bproducto\s+(?:id\s+)?(\d{1,6})\b", message_text.lower())
                if m2:
                    try:
                        pid = int(m2.group(1))
                        for p in PRODUCTS_DATA:
                            try:
                                if int(p.get('id', -1)) == pid:
                                    product_candidate = p
                                    break
                            except Exception:
                                continue
                    except Exception:
                        product_candidate = None

                if not product_candidate:
                    tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                    if tokens:
                        for p in PRODUCTS_DATA:
                            name = (p.get('nombre') or '').lower()
                            if any(tok in name for tok in tokens):
                                product_candidate = p
                                break

                if product_candidate:
                    try:
                        pid = product_candidate.get('id')
                        pname = product_candidate.get('nombre') or product_candidate.get('title') or 'Producto'
                        save_current_item(phone, 'product', pid, pname, product_candidate)
                        logger.info(f"Saved selected product for {phone}: id={pid}, name={pname}")
                    except Exception:
                        pass
            except Exception:
                pass

            # Detectar si el usuario menciona un webinar concreto y guardarlo
            try:
                webinar_candidate = None
                m3 = re.search(r"\bwebinar\s+(?:id\s+)?(\d{1,6})\b", message_text.lower())
                if m3:
                    try:
                        wid = int(m3.group(1))
                        for w in WEBINARS_DATA:
                            try:
                                if int(w.get('id', -1)) == wid:
                                    webinar_candidate = w
                                    break
                            except Exception:
                                continue
                    except Exception:
                        webinar_candidate = None

                if not webinar_candidate:
                    tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                    if tokens:
                        for w in WEBINARS_DATA:
                            name = (w.get('title') or w.get('name') or '').lower()
                            if any(tok in name for tok in tokens):
                                webinar_candidate = w
                                break

                if webinar_candidate:
                    try:
                        wid = webinar_candidate.get('id')
                        wname = webinar_candidate.get('title') or webinar_candidate.get('name') or 'Webinar'
                        lower_msg = (message_text or '').strip().lower()
                        explicit_selection = False
                        try:
                            if re.match(r"^\d+$", lower_msg):
                                explicit_selection = True
                            if any(v in lower_msg for v in ['quiero', 'seleccionar', 'ese', 'dame', 'quiero el', 'lo quiero']):
                                explicit_selection = True
                        except Exception:
                            explicit_selection = False

                        logger.info(f"Detected webinar_candidate for {phone}: id={wid}, name={wname}; explicit_selection={explicit_selection}")
                        if explicit_selection:
                            save_current_item(phone, 'webinar', wid, wname, webinar_candidate)
                            logger.info(f"Saved selected webinar for {phone}: id={wid}, name={wname}")
                    except Exception:
                        pass
            except Exception:
                pass
                send_text_message(phone, reply)
                return
        except Exception:
            pass
        try:
            sel = get_conversation_memory(phone, 'selected_course')
            if isinstance(sel, dict) and sel.get('id'):
                selected_course_block = f"SELECTED_COURSE: ID:{sel.get('id')} | Nombre:{sel.get('nombre') or sel.get('name')} | Detalles guardados en memoria."
            else:
                selected_course_block = ''
        except Exception:
            selected_course_block = ''

        logger.debug(f"Selected course block: {selected_course_block}")

        # Instruct model to respond with JSON when user asks for detailed attributes
        json_instruction = (
            "Si el usuario solicita datos detallados (precio, duración, fechas, ubicación, temario), "
            "RESPONDE únicamente con UN OBJETO JSON válido con las claves: type (course|product|webinar), id, name, price, duration, dates (array), location, temario (array|null), temario_pdf (string|null)."
        )

        system_prompt = f"""
            Eres un asesor técnico de Fibremex especializado en fibra óptica y telecomunicaciones.

            INFORMACIÓN COMPLETA DISPONIBLE:
            {all_info}

            INSTRUCCIONES IMPORTANTES:

            1) RESPONDER PREGUNTAS TÉCNICAS: Si el usuario formula preguntas técnicas relacionadas con física, fibra óptica, transmisión, atenuación, dispersión, empalmes, mediciones (OTDR), despliegue FTTH/plantas externas o telecomunicaciones, RESPONDE DIRECTAMENTE con una explicación técnica, clara, concisa y correcta. No rechaces ni digas que "no está cubierto". Ofrece una respuesta breve (2–6 oraciones) que explique el concepto, cuándo aplica y un ejemplo práctico si corresponde.

            2) PRECISIÓN Y TRANSPARENCIA: No inventes hechos. Si la respuesta tiene incertidumbre indica el nivel de confianza y proporciona pasos o fuentes para verificar (por ejemplo: normas, equipos, libros o búsquedas recomendadas). Si pides datos adicionales para ajustar la respuesta (longitudes de onda, tipo de fibra, distancia), solicita esa información de forma breve.

            3) CONSULTAS DE CATÁLOGO: {json_instruction}

            4) USO DEL BLOQUE DE DATOS: [DATOS_CURSOS]
            A continuación tienes la lista compacta con cursos disponibles. Usa esos datos como fuente única para preguntas sobre cursos (precio, fechas, temario, ubicación). No inventes precios, fechas ni temarios fuera de ese bloque.
            {datos_cursos_block}

            {selected_course_block}

            5) TONO Y EXTENSIÓN: Responde de forma profesional y amable. Para preguntas técnicas prioriza la claridad y la exactitud; si la explicación es larga, ofrece un resumen inicial y pregunta si desea más detalle o ejemplos. Siempre ofrece enlazar a un curso o recurso relevante cuando aplique.
"""

        # Prefer deterministic handling for catalog queries (courses/products/webinars)
        lower_msg = (message_text or '').lower()
        catalog_keywords = ['curso', 'cursos', 'producto', 'productos', 'webinar', 'webinars', 'cursos en linea', 'cursos online', 'cursos en línea', 'temario', 'precio', 'duracion', 'duración', 'fechas', 'ubicacion', 'ubicación']
        try:
            if any(k in lower_msg for k in catalog_keywords):
                handled = handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                if handled:
                    return
        except Exception:
            # fall back to LLM if deterministic handler errors
            pass

        # Usar IA para generar respuesta
        ai_response = chat_with_gemini(
            phone=phone,
            message=message_text,
            system_prompt=system_prompt,
            include_whatsapp_profile=whatsapp_profile or {}
        )

        logger.info("LLM called for marketing message; received raw response (truncated): %s", (ai_response or '')[:500])

        # Try to parse JSON if the user explicitly requested details
        try:
            lower_msg = (message_text or '').lower()
            detail_triggers = ['precio', 'duracion', 'duración', 'fechas', 'ubicacion', 'ubicación', 'temario', 'contenido']
            asked_for_details = any(t in lower_msg for t in detail_triggers)

            if asked_for_details:
                    try:
                        cur_item = get_current_item(phone)
                    except Exception:
                        cur_item = None

                    # If user asked details and we have a current_item, prefer it.
                    if cur_item and isinstance(cur_item, dict):
                        resolved = None
                        resolved_type = None
                        # Try live DB lookup first
                        try:
                            from pymongo import MongoClient
                            mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                            client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                            db = client.get_database('splitbot')
                            typ = (cur_item.get('type') or cur_item.get('item_type') or cur_item.get('kind') or '')
                            cid = cur_item.get('id') or (cur_item.get('data') and cur_item.get('data').get('id'))
                            coll = None
                            if typ and ('course' in typ.lower() or 'curso' in typ.lower()):
                                coll = db.get_collection('courses')
                                resolved_type = 'course'
                            elif typ and 'product' in typ.lower():
                                coll = db.get_collection('products')
                                resolved_type = 'product'
                            elif typ and 'webinar' in typ.lower():
                                coll = db.get_collection('webinars')
                                resolved_type = 'webinar'

                            def _resolve_by_id(coll, cid):
                                # Try _id ObjectId lookup if cid looks like a 24-char hex
                                try:
                                    from bson import ObjectId
                                    if isinstance(cid, str) and len(cid) == 24:
                                        try:
                                            d = coll.find_one({'_id': ObjectId(cid)})
                                            if d:
                                                return d
                                        except Exception:
                                            pass
                                except Exception:
                                    pass

                                # Try 'id' field as-is
                                try:
                                    d = coll.find_one({'id': cid})
                                    if d:
                                        return d
                                except Exception:
                                    pass

                                # Try numeric id if convertible
                                try:
                                    d = coll.find_one({'id': int(cid)})
                                    if d:
                                        return d
                                except Exception:
                                    pass
                                return None

                            if coll and cid:
                                doc = _resolve_by_id(coll, cid)

                                if doc:
                                    # sanitize
                                    try:
                                        if doc.get('_id') is not None:
                                            doc['id'] = str(doc.get('_id'))
                                            doc.pop('_id', None)
                                    except Exception:
                                        pass
                                    resolved = doc
                        except Exception:
                            resolved = None

                        # Fallback: search in preloaded arrays
                        if not resolved:
                            for lst, k in ((COURSES_DATA, 'course'), (PRODUCTS_DATA, 'product'), (WEBINARS_DATA, 'webinar')):
                                for item in lst:
                                    try:
                                        if str(item.get('id')) == str(cur_item.get('id')) or str(item.get('id')) == str(cur_item.get('data', {}).get('id')):
                                            resolved = item
                                            resolved_type = k
                                            break
                                    except Exception:
                                        continue
                                if resolved:
                                    break

                        if resolved:
                            # Build reply using resolved DB/in-memory item and send immediately
                            try:
                                name = resolved.get('nombre') or resolved.get('title') or resolved.get('name') or ''
                                price = resolved.get('precio') or resolved.get('price') or ''
                                duration = resolved.get('duracion') or resolved.get('duration') or ''
                                dates = resolved.get('fechas') or resolved.get('proximas_fechas') or resolved.get('fechas_evento') or []
                                location = resolved.get('ubicacion') or resolved.get('location') or ''
                                temario = resolved.get('temario') or resolved.get('topics') or []
                                temario_pdf = resolved.get('temario_pdf') or resolved.get('temarioPdf') or None

                                out_parts = []
                                out_parts.append(f"*{name}*")
                                if price:
                                    out_parts.append(f"Precio: {price}")
                                if duration:
                                    out_parts.append(f"Duración: {duration}")
                                if dates:
                                    out_parts.append(f"Fechas: {', '.join([str(d) for d in dates])}")
                                if location:
                                    out_parts.append(f"Ubicación: {location}")
                                if temario:
                                    tem_preview = '\n'.join([f"- {t.get('titulo') if isinstance(t, dict) else t}" for t in (temario[:10] if isinstance(temario, list) else [])])
                                    if tem_preview:
                                        out_parts.append(f"Temario:\n{tem_preview}")
                                if temario_pdf:
                                    out_parts.append(f"Temario PDF: {temario_pdf}")

                                send_text_message(phone, "\n\n".join(out_parts))
                                # ensure memory stores the resolved data
                                try:
                                    save_current_item(phone, resolved_type or (cur_item.get('type') or 'course'), resolved.get('id'), name, resolved)
                                except Exception:
                                    pass
                                return
                            except Exception:
                                # if anything fails, continue to LLM parsing
                                logger.exception('Error building direct DB response for current_item')
                                pass

                        # If no current_item or DB resolution failed, try to interpret the user's message as
                        # a selection by number (e.g., '1', '2') or by name using the last_listed_* caches.
                        # This makes the bot behave like a chatbot when user says 'que precio tiene' after
                        # seeing a list and selecting an index.
                        try:
                            # try parse a solo number reply
                            num = None
                            mnum = re.search(r"\b([1-9][0-9]?)\b", message_text or "")
                            if mnum:
                                num = int(mnum.group(1))

                            if num is not None:
                                # check courses, products, webinars in that order
                                for typ in ['courses', 'products', 'webinars']:
                                    listed = get_listed_items(phone, typ) or []
                                    if listed and 1 <= num <= len(listed):
                                        sel = listed[num-1]
                                        # Try to resolve by id in DB or in-memory
                                        cid = sel.get('id')
                                        # attempt DB lookup
                                        try:
                                            from pymongo import MongoClient
                                            mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                                            client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                                            db = client.get_database('splitbot')
                                            coll = db.get_collection('courses') if typ == 'courses' else (db.get_collection('products') if typ == 'products' else db.get_collection('webinars'))
                                            try:
                                                doc = _resolve_by_id(coll, cid)
                                            except Exception:
                                                doc = None
                                            if doc:
                                                # sanitize
                                                try:
                                                    if doc.get('_id') is not None:
                                                        doc['id'] = str(doc.get('_id'))
                                                        doc.pop('_id', None)
                                                except Exception:
                                                    pass
                                                save_current_item(phone, typ[:-1], doc.get('id'), doc.get('nombre') or doc.get('name') or sel.get('name'), doc)
                                                # now recursively call handler to reply using the now-saved current_item
                                                return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                        except Exception:
                                            # fallback to in-memory list
                                            found = None
                                            for lst_item in (COURSES_DATA if typ == 'courses' else (PRODUCTS_DATA if typ == 'products' else WEBINARS_DATA)):
                                                try:
                                                    if str(lst_item.get('id')) == str(cid) or lst_item.get('nombre') == sel.get('name'):
                                                        found = lst_item
                                                        break
                                                except Exception:
                                                    continue
                                            if found:
                                                save_current_item(phone, typ[:-1], found.get('id'), found.get('nombre') or found.get('name'), found)
                                                return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                            else:
                                # No number: try to match name against last_listed entries
                                for typ in ['courses', 'products', 'webinars']:
                                    listed = get_listed_items(phone, typ) or []
                                    for item in listed:
                                        nm = (item.get('name') or '').lower()
                                        if nm and nm in (message_text or '').lower():
                                            # resolve as above
                                            cid = item.get('id')
                                            # try DB then in-memory
                                            try:
                                                from pymongo import MongoClient
                                                mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                                                client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                                                db = client.get_database('splitbot')
                                                coll = db.get_collection('courses') if typ == 'courses' else (db.get_collection('products') if typ == 'products' else db.get_collection('webinars'))
                                                try:
                                                    doc = _resolve_by_id(coll, cid)
                                                except Exception:
                                                    doc = None
                                                if doc:
                                                    try:
                                                        if doc.get('_id') is not None:
                                                            doc['id'] = str(doc.get('_id'))
                                                            doc.pop('_id', None)
                                                    except Exception:
                                                        pass
                                                    save_current_item(phone, typ[:-1], doc.get('id'), doc.get('nombre') or doc.get('name') or item.get('name'), doc)
                                                    return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                            except Exception:
                                                # fallback to in-memory
                                                for lst_item in (COURSES_DATA if typ == 'courses' else (PRODUCTS_DATA if typ == 'products' else WEBINARS_DATA)):
                                                    try:
                                                        if str(lst_item.get('id')) == str(cid) or lst_item.get('nombre') == item.get('name'):
                                                            save_current_item(phone, typ[:-1], lst_item.get('id'), lst_item.get('nombre') or lst_item.get('name'), lst_item)
                                                            return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                                    except Exception:
                                                        continue
                        except Exception:
                            # if selection-by-number/name logic errors, continue to LLM parsing
                            logger.debug('Selection-by-number/name logic failed, falling back to LLM parsing')

            parsed = None
            if ai_response and ai_response.strip():
                # attempt to find a JSON object inside the response
                m = re.search(r"(\{[\s\S]*\})", ai_response)
                json_text = m.group(1) if m else ai_response.strip()
                try:
                    parsed = json.loads(json_text)
                    logger.info("Parsed JSON from LLM response successfully")
                except Exception:
                    parsed = None
                    logger.debug(f"Failed to parse JSON from LLM response. json_text startswith: {str(json_text)[:200]}")

            if parsed and isinstance(parsed, dict):
                # Build a friendly textual reply from the structured JSON
                try:
                    typ = parsed.get('type', '')
                    name = parsed.get('name') or parsed.get('title') or ''
                    pid = parsed.get('id')
                    price = parsed.get('price')
                    duration = parsed.get('duration')
                    dates = parsed.get('dates') or []
                    location = parsed.get('location')
                    temario = parsed.get('temario') or []
                    temario_pdf = parsed.get('temario_pdf')

                    out_parts = []
                    out_parts.append(f"*{name}*")
                    if price:
                        out_parts.append(f"Precio: {price}")
                    if duration:
                        out_parts.append(f"Duración: {duration}")
                    if dates:
                        out_parts.append(f"Fechas: {', '.join(dates)}")
                    if location:
                        out_parts.append(f"Ubicación: {location}")
                    if temario:
                        tem_preview = '\n'.join([f"- {t}" for t in temario[:10]])
                        out_parts.append(f"Temario:\n{tem_preview}")
                    if temario_pdf:
                        out_parts.append(f"Temario PDF: {temario_pdf}")

                    send_text_message(phone, "\n\n".join(out_parts))
                    logger.info("Sent formatted message built from LLM JSON to %s", phone)
                    try:
                        if typ and pid:
                            if typ.lower() in ['course', 'curso', 'cursos']:
                                save_current_item(phone, 'course', pid, name, parsed)
                            elif typ.lower() in ['product', 'producto', 'products', 'productos']:
                                save_current_item(phone, 'product', pid, name, parsed)
                            elif typ.lower() in ['webinar', 'webinars']:
                                save_current_item(phone, 'webinar', pid, name, parsed)
                    except Exception:
                        pass
                    # If the model included a temario_pdf or suggested the temario, and
                    # we have a selected course in memory, attempt to send the PDF automatically.
                    try:
                        sel = get_conversation_memory(phone, 'selected_course')
                        ai_lower = (ai_response or '').lower()
                        wants_send = False
                        if temario_pdf:
                            wants_send = True
                        # Also treat explicit phrases from the LLM as a recommendation to send
                        elif any(p in ai_lower for p in ['te envío el temario', 'te envio el temario', 'puedo enviarte el temario', 'puedo enviar el temario', 'te puedo enviar el temario', 'te puedo enviar el temario']):
                            wants_send = True

                        if wants_send and isinstance(sel, dict) and sel.get('id'):
                            # try to resolve the PDF for the selected course and send it
                            try:
                                pdf_info = find_pdf_for_user_message('temario', {'selected_course': sel})
                                if pdf_info and pdf_info.get('file_path'):
                                    logger.info(f"Auto-sending temario PDF for selected course (phone={phone}, course={sel.get('id')}) -> {pdf_info.get('pdf_filename')}")
                                    send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                                else:
                                    logger.info(f"No temario PDF found to auto-send for course id={sel.get('id')}")
                            except Exception:
                                logger.exception("Error trying to auto-send temario PDF based on LLM recommendation")
                    except Exception:
                        logger.debug("Skipped auto-send temario logic due to error reading conversation memory or parsing response")
                except Exception:
                    send_text_message(phone, ai_response)
            else:
                # If the model didn't give structured JSON or the user didn't ask details, use raw LLM output
                if ai_response and ai_response.strip():
                    send_text_message(phone, ai_response)
                    logger.info("Sent raw LLM text to %s", phone)
                else:
                    # last-resort fallback to local ML/JSON responder
                    logger.info("LLM returned empty, using ml_service fallback")
                    fallback_response = ml_service.answer_course_or_webinar_query(phone, message_text)
                    send_text_message(phone, fallback_response or "Gracias por tu mensaje. ¿En qué puedo ayudarte con estrategias de marketing hoy?")
        except Exception as e:
            logger.exception(f"Error procesando respuesta LLM: {e}")
            logger.info("Using ml_service fallback due to exception while processing LLM response")
            fallback_response = ml_service.answer_course_or_webinar_query(phone, message_text)
            send_text_message(phone, fallback_response or "Gracias por tu mensaje. ¿En qué puedo ayudarte con estrategias de marketing hoy?")

    except Exception as e:
        logger.error(f"Error procesando mensaje de marketing: {e}", exc_info=True)
        send_text_message(phone, "Disculpa, ocurrió un error procesando tu mensaje. Por favor intenta de nuevo.")


def handle_course_and_temario_flow(phone: str, message_text: str, whatsapp_profile: dict = None) -> bool:
    """Maneja selección de curso, respuestas sobre atributos y envío de PDF de temario.

    Retorna True si se manejó la petición (no es necesario pasar a IA), False otherwise.
    """
    msg_lower = (message_text or '').lower()

    # 1) Si el usuario pidió el temario explícitamente
    if is_temario_request(message_text):
        # Si ya hay un curso seleccionado en memoria, enviar su temario
        selected = get_conversation_memory(phone, 'selected_course')
        if isinstance(selected, dict) and selected.get('id'):
            course_id = selected.get('id')
            # Enviar temario en texto
            try:
                temario_msg = get_course_temario_message(course_id)
                send_text_message(phone, temario_msg)
            except Exception:
                pass

            # Intentar enviar PDF si existe
            try:
                    pdf_info = find_pdf_for_user_message('temario', {'selected_course': {'id': course_id, 'name': selected.get('nombre'), 'nombre': selected.get('nombre')}})
                    if pdf_info:
                        # If the user explicitly requested the temario, send it immediately.
                        try:
                            send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                            return True
                        except Exception:
                            # If sending fails, fall back to confirmation flow
                            pass
                    # If no pdf_info or sending failed, fall back to confirmation/mapping logic below
            except Exception:
                pass

            return True

        # Si no hay curso seleccionado, pedir que indique cuál
        send_text_message(phone, ask_for_course_number())
        # Guardar bandera en memoria para esperar número (context key)
        save_conversation_memory(phone, 'awaiting_temario_course', True)
        save_conversation_memory(phone, 'awaiting_temario_action', 'pdf')
        return True

    # 2) Si el usuario responde con un número de curso mientras esperamos
    awaiting = get_conversation_memory(phone, 'awaiting_temario_course') or False
    if awaiting:
        course_id = extract_course_number(message_text)
        if not course_id:
            # intentar parsear nombre
            course_id = extract_course_number(message_text)

        if course_id:
            # Guardar selección
            try:
                course = CourseManager.get_course_by_id(course_id)
                if course:
                    save_conversation_memory(phone, 'selected_course', {'id': course_id, 'nombre': course.nombre, 'name': course.nombre})
                    try:
                        save_current_item(phone, 'course', course_id, course.nombre, {'nombre': course.nombre})
                    except Exception:
                        pass
                else:
                    # intentar fallback a JSON local (temario_handler carga desde info/courses)
                    try:
                        from utils.temario_handler import load_course_json_by_id
                        cj = load_course_json_by_id(course_id)
                        if cj:
                            cname = cj.get('nombre') or cj.get('name') or f'Curso {course_id}'
                            save_conversation_memory(phone, 'selected_course', {'id': course_id, 'nombre': cname, 'name': cname})
                            try:
                                save_current_item(phone, 'course', course_id, cname, cj)
                            except Exception:
                                pass
                    except Exception:
                        # si todo falla, guardar al menos el id para poder enviar PDF/texto
                        save_conversation_memory(phone, 'selected_course', {'id': course_id, 'nombre': f'Curso {course_id}', 'name': f'Curso {course_id}'})
            except Exception:
                pass

            # Enviar temario en texto
            try:
                temario_msg = get_course_temario_message(course_id)
                # Si la función devolvió la petición para indicar número, enviarla como prompt
                send_text_message(phone, temario_msg)
            except Exception:
                pass

            # Enviar PDF si se pidió
            try:
                pdf_info = find_pdf_for_user_message(f"curso {course_id}", {'selected_course': get_conversation_memory(phone, 'selected_course')})
                if pdf_info:
                    send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
            except Exception:
                pass

            # Limpiar banderas
            save_conversation_memory(phone, 'awaiting_temario_course', None)
            save_conversation_memory(phone, 'awaiting_temario_action', None)
            return True

    # Handle pending PDF confirmation (yes/no)
    awaiting_pdf = get_conversation_memory(phone, 'awaiting_pdf_confirmation') or False
    if awaiting_pdf:
        ans = (message_text or '').strip().lower()
        if ans in ['si', 'sí', 's', 'yes']:
            pending = get_conversation_memory(phone, 'pending_pdf') or {}
            if pending and pending.get('file_path'):
                try:
                    send_document_message(phone, pending.get('file_path'), pending.get('caption'))
                except Exception:
                    pass
            send_text_message(phone, "Perfecto, te envío el PDF del temario ahora.")
        else:
            send_text_message(phone, "Entendido. No enviaré el PDF. Si lo deseas, escribe 'enviar PDF del temario' para intentarlo de nuevo.")

        # clear pending flags
        save_conversation_memory(phone, 'pending_pdf', None)
        save_conversation_memory(phone, 'awaiting_pdf_confirmation', None)
        return True

    # 3) Si el usuario pregunta por atributos del curso (precio, fechas, duración, ubicación)
    # intentar detectar mención de curso en memoria o por número
    attr_keywords = ['precio', 'cost', 'costo', 'precios', 'fecha', 'fechas', 'ubicacion', 'ubicación', 'modalidad', 'duracion', 'duración', 'horario', 'temario']
    if any(k in msg_lower for k in attr_keywords):
        # Prefer explicit selected_course, else use the current_item context (pronoun resolution)
        selected = get_conversation_memory(phone, 'selected_course')
        course_id = None
        # global current_item to handle products/webinars too
        try:
            global_current = get_current_item(phone)
        except Exception:
            global_current = None
        if isinstance(selected, dict) and selected.get('id'):
            course_id = selected.get('id')
        else:
            # Try current item from context (e.g., user said "ese" or "el primero")
            try:
                current_item = get_current_item(phone)
                if current_item and current_item.get('type') == 'course' and current_item.get('id'):
                    course_id = current_item.get('id')
            except Exception:
                current_item = None

            # if still not found, try to extract numeric id from the message
            if not course_id:
                course_id = extract_course_number(message_text)

        # If the current context is a PRODUCT, reply with product attributes
        try:
            if global_current and global_current.get('type') == 'product':
                pid = global_current.get('id')
                # find product by id
                product = None
                try:
                    for p in PRODUCTS_DATA:
                        try:
                            if str(p.get('id')) == str(pid):
                                product = p
                                break
                        except Exception:
                            continue
                except Exception:
                    product = None

                if product:
                    parts = [f"*{product.get('nombre')}*"]
                    if product.get('precio'):
                        parts.append(f"Precio: {product.get('precio')}")
                    if product.get('descripcion'):
                        parts.append(f"Descripción: {product.get('descripcion')}")
                    if product.get('especificaciones'):
                        specs = '\n'.join([f"- {s}" for s in product.get('especificaciones')])
                        parts.append(f"Especificaciones:\n{specs}")
                    # intentionally omit external links from product responses
                    send_text_message(phone, "\n\n".join(parts))
                    return True

        except Exception:
            pass

        # If the current context is a WEBINAR, reply with webinar attributes
        try:
            if global_current and global_current.get('type') == 'webinar':
                wid = global_current.get('id')
                webinar = None
                try:
                    for w in WEBINARS_DATA:
                        try:
                            if str(w.get('id')) == str(wid) or str(w.get('title')).lower() == str(global_current.get('name')).lower():
                                webinar = w
                                break
                        except Exception:
                            continue
                except Exception:
                    webinar = None

                if webinar:
                    parts = [f"*{webinar.get('title') or webinar.get('name')}*"]
                    if webinar.get('fechas'):
                        parts.append(f"Fechas: {', '.join([str(f) for f in webinar.get('fechas')])}")
                    if webinar.get('horario'):
                        parts.append(f"Horario: {', '.join([str(h) for h in webinar.get('horario')])}")
                    if webinar.get('description'):
                        parts.append(f"Descripción: {webinar.get('description')}")
                    if webinar.get('topics'):
                        topics = '\n'.join([f"- {t}" for t in webinar.get('topics')])
                        parts.append(f"Temas:\n{topics}")
                    send_text_message(phone, "\n\n".join(parts))
                    return True

        except Exception:
            pass

        # Si no hay número, intentar buscar por nombre en los JSON cargados
        course_json = None
        if not course_id:
            cleaned = (message_text or '').strip().lower()
            # avoid accidental short words
            if cleaned and len(cleaned) > 2:
                # First try exact or substring matches (safer)
                for c in COURSES_DATA:
                    name = (c.get('nombre') or '').lower()
                    short = (c.get('nombre_corto') or '').lower()
                    nodes = ' '.join(c.get('nodos', [])).lower() if c.get('nodos') else ''

                    # exact match or cleaned contains the name (longer substrings)
                    try:
                        if cleaned == name or (len(cleaned) >= 4 and cleaned in name) or (len(name) >= 6 and name in cleaned):
                            course_json = c
                            # keep course_id as raw value; conversion to int later when needed
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                        if short and (cleaned == short or (len(cleaned) >= 4 and cleaned in short)):
                            course_json = c
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                        if nodes and cleaned in nodes:
                            course_json = c
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                    except Exception:
                        continue

                # If still not found and rapidfuzz is available, use fuzzy partial ratio with high threshold
                if not course_json and 'RAPIDFUZZ_AVAILABLE' in globals() and RAPIDFUZZ_AVAILABLE:
                    try:
                        best = None
                        best_score = 0
                        for c in COURSES_DATA:
                            name = (c.get('nombre') or '').lower()
                            if not name:
                                continue
                            score = rf_fuzz.partial_ratio(cleaned, name)
                            if score > best_score:
                                best_score = score
                                best = c
                        # require a high confidence to auto-select
                        if best and best_score >= 80:
                            course_json = best
                            try:
                                course_id = best.get('id')
                            except Exception:
                                course_id = None
                    except Exception:
                        pass

        if course_id:
            try:
                course = CourseManager.get_course_by_id(course_id)

                # Si no está en la DB, buscar en los JSON cargados en memoria (COURSES_DATA)
                course_json = None
                if not course:
                    for c in COURSES_DATA:
                        # comparar por id o por nombre corto/nombre
                        try:
                            cid_field = c.get('id')
                            # compare string forms first
                            if cid_field is not None and str(cid_field) == str(course_id):
                                course_json = c
                                break
                            # fallback: try numeric comparison when both convertible
                            try:
                                if int(cid_field) == int(course_id):
                                    course_json = c
                                    break
                            except Exception:
                                pass
                        except Exception:
                            pass
                        name_low = (c.get('nombre') or '').lower()
                        short_low = (c.get('nombre_corto') or '').lower()
                        if (str(course_id).lower() in name_low) or (str(course_id).lower() in short_low):
                            course_json = c
                            break

                # Construir respuesta según keyword
                if any(k in msg_lower for k in ['precio', 'costo']):
                    if course:
                        send_text_message(phone, course.get_formatted_precio())
                    elif course_json:
                        precio = course_json.get('precio') or 'Consultar con asesor'
                        resp = f"*INVERSIÓN CURSO:* {course_json.get('nombre')}\n\n*Precio MXN:* {precio}"
                        send_text_message(phone, resp)
                    else:
                        send_text_message(phone, "No encontré información sobre el precio de ese curso. ¿Quieres que te ponga en contacto con un asesor?")
                    return True

                if any(k in msg_lower for k in ['temario', 'contenido', 'programa']):
                    if course:
                        send_text_message(phone, course.get_formatted_temario())
                        course_name = course.nombre
                    elif course_json:
                        # Formatear temario desde JSON
                        tem = []
                        for t in course_json.get('temario', []):
                            titulo = t.get('titulo') if isinstance(t, dict) else str(t)
                            tem.append(f"- {titulo}")
                            if isinstance(t, dict) and t.get('subtemas'):
                                for st in t.get('subtemas'):
                                    tem.append(f"  • {st}")
                        send_text_message(phone, f"📚 *TEMARIO - {course_json.get('nombre')}*\n\n" + "\n".join(tem))
                        course_name = course_json.get('nombre')

                    # enviar PDF si existe
                    try:
                        pdf_info = find_pdf_for_user_message(f"curso {course_id}", {'selected_course': {'id': course_id, 'name': course_name if 'course_name' in locals() else None}})
                        if pdf_info:
                            send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                    except Exception:
                        pass
                    return True

                if any(k in msg_lower for k in ['duracion', 'duración', 'horario', 'fechas', 'fecha', 'ubicacion']):
                    if course:
                        msg = course.get_formatted_informacion_completa()
                        send_text_message(phone, msg)
                    elif course_json:
                        parts = []
                        if course_json.get('duracion'):
                            parts.append(f"Duración: {course_json.get('duracion')}")
                        if course_json.get('modalidad'):
                            parts.append(f"Modalidad: {course_json.get('modalidad')}")
                        if course_json.get('ubicacion'):
                            parts.append(f"Ubicación: {course_json.get('ubicacion')}")
                        if course_json.get('horario'):
                            parts.append(f"Horario: {course_json.get('horario')}")
                        if course_json.get('proximas_fechas'):
                            fechas = []
                            for f in course_json.get('proximas_fechas'):
                                if isinstance(f, dict):
                                    fechas.append(f.get('fecha') + (f" ({f.get('horario')})" if f.get('horario') else ""))
                                else:
                                    fechas.append(str(f))
                            parts.append(f"Próximas fechas: {', '.join(fechas)}")
                        send_text_message(phone, "\n".join(parts) if parts else "No encontré información detallada de fechas/ubicación para ese curso.")
                    else:
                        send_text_message(phone, "No encontré información sobre ese curso. ¿Puedes escribir el nombre o el número del curso (1-5)?")
                    return True

            except Exception as e:
                logger.debug(f"Error al responder atributos de curso: {e}")


    # 4) Flujo: contacto con asesor / cotización / inscripción / facturación
    advisor_keywords = [
        'asesor', 'hablar con', 'contactar', 'contacto', 'asesoria', 'hablar con un asesor',
        'inscrib', 'inscripción', 'inscripcion', 'inscribirme', 'registrarme',
        'cotizacion', 'cotización', 'cotizar', 'factura', 'facturación', 'facturacion'
    ]
    # If we are already in data-collection mode for this phone, process the incoming message
    # Use a local alias 'asp' so we don't assign to the module-level name inside this
    # function and inadvertently make it a local variable (which causes
    # UnboundLocalError when referenced earlier in the function).
    asp = advisor_simple_process
    # Support both variants of the awaiting flag for compatibility
    awaiting = get_conversation_memory(phone, 'awaiting_advisor_data') or get_conversation_memory(phone, 'waiting_for_advisor_data') or False
    if awaiting:
        # Delegate to advisor_simple process if available
        try:
            if asp:
                handled = asp(phone, message_text)
                if handled:
                    return True
            # Fallback: continue with existing inline logic below if advisor_simple not available or returns False
        except Exception as e:
            logger.exception(f"advisor_simple processing failed: {e}")

    # Tightened detection: check explicit phrases OR action keywords
    advisor_phrases = ['hablar con un asesor', 'hablar con asesor', 'quiero hablar con un asesor', 'ponme en contacto', 'ponme en contacto con un asesor', 'contactar un asesor', 'contacto con asesor', 'contactar asesor', 'necesito un asesor']
    advisor_actions = ['inscrib', 'inscripción', 'inscripcion', 'inscribirme', 'registrarme', 'cotizacion', 'cotización', 'cotizar', 'factura', 'facturación', 'facturacion']

    is_advisor_request = any(p in msg_lower for p in advisor_phrases) or any(a in msg_lower for a in advisor_actions)

    if is_advisor_request:
        # If we already are waiting for advisor data, try to extract and send
        awaiting = get_conversation_memory(phone, 'awaiting_advisor_data') or get_conversation_memory(phone, 'waiting_for_advisor_data') or False
        # Decide action type
        action = 'contact_asesor'
        if any(k in msg_lower for k in ['cotizacion', 'cotización', 'cotizar']):
            action = 'cotizacion'
        elif any(k in msg_lower for k in ['inscrib', 'inscripción', 'inscripcion', 'registrarme']):
            action = 'inscripcion'
        elif any(k in msg_lower for k in ['factura', 'facturación', 'facturacion']):
            action = 'facturacion'

        # If not awaiting, start the guided data collection via advisor_simple
        if not awaiting:
            # attempt to import the advisor_simple entry points locally (safe import)
            try:
                from services.advisor_simple import start_advisor_simple
            except Exception as e:
                logger.debug(f"No se pudo importar start_advisor_simple: {e}")
                start_advisor_simple = None

            try:
                if start_advisor_simple:
                    return start_advisor_simple(phone, process_type=action if action in ['cotizacion','inscripcion','facturacion'] else 'general')
                else:
                    # Minimal fallback: ask only for the name (first step)
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_request_type', action)
                    save_conversation_memory(phone, 'advisor_client_data', {})
                    send_text_message(phone, "¡Perfecto! 👍 Empecemos. Por favor, dime tu nombre completo.")
                    return True
            except Exception as e:
                logger.exception(f"start_advisor_simple failed: {e}")
                return False

        # If awaiting, delegate processing to advisor_simple process function
        try:
            # import under a temporary name and assign to local alias 'asp'
            from services.advisor_simple import advisor_simple_process as _asp
            asp = _asp
        except Exception as e:
            logger.debug(f"No se pudo importar advisor_simple_process: {e}")
            asp = None

        if asp:
            try:
                handled = asp(phone, message_text)
                if handled:
                    return True
                else:
                    return False
            except Exception as e:
                logger.exception(f"advisor_simple processing failed: {e}")
                return False
        else:
            # If no advisor_simple available, inform the user and clear awaiting to avoid loops
            send_text_message(phone, "Estamos actualizando nuestro flujo de asesoría. Por favor, comparte tu nombre completo y te responderemos pronto.")
            save_conversation_memory(phone, 'awaiting_advisor_data', None)
            return False