import time 
import threading
from typing import Optional, Dict, Any 

class ConversationState: 
    def __init__(self, default_ttl: int = 1800):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()
        self.default_ttl = default_ttl

    def set_context(self, user_id: str, topic: str, item_type: Optional[str] = None,
                    item_id: Optional[Any] = None, data: Optional[Dict] = None, ttl: Optional[int] = None):
        expires = time.time() + (ttl if ttl is not None else self.default_ttl)
        entry = { 
            "topic": topic, 
            "item_type": item_type, 
            "item_id": item_id, 
            "data": data or {}, 
            "expires_at": expires
        }
        with self._lock: 
            self._store[user_id] = entry

    def get_context(self, user_id: str) -> Optional[Dict[str, Any]]: 
        uid = str(user_id)
        with self._lock:
            entry = self._store.get(uid)
            if not entry:
                return None
            if entry.get("expires_at", 0) < time.time():
                del self._store[uid]
                return None
            return entry.copy()
        
    def clear_context(self, user_id: str):
        with self._lock:
            self._store.pop(str(user_id), None)
    
    def update_item(self, user_id: str, item_id: Any, data: Optional[Dict] = None): 
        uid = str(user_id)
        with self._lock: 
            if uid in self._store:
                self._store[uid]["item_id"] = item_id
                if data:
                    self._store[uid]["data"].update(data)

conversation_state = ConversationState()