import os
import json
import requests
from typing import Optional, List


try:
    from config import config as _conf
except Exception:
    _conf = None

_HAS_GOOGLE_AUTH = False
_SERVICE_ACCOUNT_PATH = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
try:
    if _SERVICE_ACCOUNT_PATH:
        from google.oauth2 import service_account  # type: ignore
        import google.auth.transport.requests  # type: ignore
        _HAS_GOOGLE_AUTH = True
except Exception:
    _HAS_GOOGLE_AUTH = False

if _conf is not None:
    GEMINI_API_KEY = getattr(_conf, 'GEMINI_API_KEY', os.getenv('GEMINI_API_KEY', ''))
    GEMINI_MODEL = getattr(_conf, 'GEMINI_MODEL', os.getenv('GEMINI_MODEL', 'gemini-2.0-flash'))
    GEMINI_ENDPOINT = os.getenv('GEMINI_ENDPOINT', '')
    GEMINI_AUTH_MODE = getattr(_conf, 'GEMINI_AUTH_MODE', os.getenv('GEMINI_AUTH_MODE', '')).lower()
else:
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')
    GEMINI_ENDPOINT = os.getenv('GEMINI_ENDPOINT', '')
    GEMINI_MODEL = os.getenv('GEMINI_MODEL', 'gemini-2.0-flash')
    GEMINI_AUTH_MODE = os.getenv('GEMINI_AUTH_MODE', '').lower()  


def _parse_gemini_response(data: dict) -> Optional[str]:
    """Try multiple common response shapes from Gemini-like APIs and return the best text found."""
    if not isinstance(data, dict):
        print('Data is not a dict:', type(data), str(data)[:100])
        return None
    
    print('DEBUG: Response data structure:', json.dumps(data, ensure_ascii=False)[:500])
    
    if 'candidates' in data and isinstance(data['candidates'], list) and data['candidates']:
        cand = data['candidates'][0]
        if isinstance(cand, dict):
            if 'content' in cand and isinstance(cand['content'], dict):
                content = cand['content']
                if 'parts' in content and isinstance(content['parts'], list) and content['parts']:
                    part = content['parts'][0]
                    if isinstance(part, dict) and 'text' in part:
                        return part['text']
            
            if isinstance(cand, dict):
                for key in ('content', 'output', 'text'):
                    if key in cand:
                        if isinstance(cand[key], str):
                            return cand[key]
                        elif isinstance(cand[key], dict) and 'text' in cand[key]:
                            return cand[key]['text']
            
            if isinstance(cand, str):
                return cand
    
    if 'output' in data and isinstance(data['output'], list) and data['output']:
        first = data['output'][0]
        if isinstance(first, dict):
            return first.get('content') or first.get('text')
        if isinstance(first, str):
            return first
    
    for key in ('text', 'generated_text', 'message', 'result'):
        if key in data and isinstance(data[key], str):
            return data[key]
    
    for key, value in data.items():
        if isinstance(value, str) and (value.startswith('{') or value.startswith('[')):
            try:
                nested = json.loads(value)
                if isinstance(nested, dict):
                    nested_text = _parse_gemini_response(nested)
                    if nested_text:
                        return nested_text
            except:
                pass
    
   
    for v in data.values():
        if isinstance(v, str) and v.strip():
            return v
    
    print('DEBUG: No se pudo encontrar texto en la respuesta')
    return None


def _build_candidate_endpoints() -> List[str]:
    """Return a list of endpoints to try, ordered by preference.

    We include common domains and suffix variants to help when environment is misconfigured.
    """
    candidates: List[str] = []
    if GEMINI_ENDPOINT:
        candidates.append(GEMINI_ENDPOINT)
        
    candidates.append(f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent')
    
    if GEMINI_MODEL and GEMINI_MODEL != 'gemini-2.0-flash':
        candidates.append(f'https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent')

    hosts = [
        'generativelanguage.googleapis.com',
        'us-generativelanguage.googleapis.com',
        'europe-generativelanguage.googleapis.com',
        'gemini.googleapis.com',
    ]

    suffixes = [':generateText', ':generate', '/generateText', '/generate', ':generateContent']
    for host in hosts:
        for suf in (':generateText', ':generate', ':generateContent'):
            if host == 'generativelanguage.googleapis.com' and suf == ':generateContent' and (GEMINI_MODEL == 'gemini-2.0-flash' or not GEMINI_MODEL):
                continue
            candidates.append(f'https://{host}/v1beta/models/{GEMINI_MODEL or "gemini-2.0-flash"}{suf}')
        for suf in (':generateText', ':generate'):
            candidates.append(f'https://{host}/v1beta2/models/{GEMINI_MODEL or "gemini-2.0-flash"}{suf}')
        for suf in suffixes:
            candidates.append(f'https://{host}/v1/models/{GEMINI_MODEL or "gemini-2.0-flash"}{suf}')

    seen = set()
    uniq = []
    for u in candidates:
        if u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq


def generate_reply(prompt: str, temperature: float = 0.7, max_tokens: int = 256) -> str:

    if not GEMINI_API_KEY:
        print('GEMINI_API_KEY not set, returning canned response')
        return 'Lo siento, la IA no está configurada todavía.'

    auth_token = None
    if GEMINI_AUTH_MODE == 'api_key':
        auth_mode_forced = 'api_key'
    elif GEMINI_AUTH_MODE == 'x-goog':
        auth_mode_forced = 'x-goog'
    else:
        auth_mode_forced = None

    if not auth_mode_forced and _HAS_GOOGLE_AUTH and _SERVICE_ACCOUNT_PATH:
        try:
            creds = service_account.Credentials.from_service_account_file(_SERVICE_ACCOUNT_PATH, scopes=['https://www.googleapis.com/auth/cloud-platform'])
            request = google.auth.transport.requests.Request()
            creds.refresh(request)
            auth_token = creds.token
            print('Using service account OAuth token for Gemini requests')
        except Exception as e:
            print('Failed to obtain service account token, falling back to GEMINI_API_KEY:', e)

    headers = {
        'Content-Type': 'application/json'
    }
    if auth_token and not auth_mode_forced:
        headers['Authorization'] = f'Bearer {auth_token}'
    elif not auth_token and not auth_mode_forced:
        key = GEMINI_API_KEY or ''
        looks_like_oauth = ('.' in key) or (len(key) > 200)
        if key and not looks_like_oauth:
            headers['x-goog-api-key'] = key
        else:
            if key:
                headers['Authorization'] = f'Bearer {key}'

    payload = {
        'prompt': prompt,
        'temperature': temperature,
        'maxOutputTokens': max_tokens,
    }

    endpoints = _build_candidate_endpoints()
    last_error = None

    for ep in endpoints:
        try:
            print('Attempting Gemini endpoint:', ep)
            ep_to_call = ep
            headers_to_use = dict(headers)
            if auth_mode_forced == 'api_key':
               
                if GEMINI_API_KEY:
                    ep_to_call = ep + (('&' if '?' in ep else '?') + f'key={GEMINI_API_KEY}')
                    headers_to_use.pop('Authorization', None)
            elif auth_mode_forced == 'x-goog':
                if GEMINI_API_KEY:
                    headers_to_use.pop('Authorization', None)
                    headers_to_use['x-goog-api-key'] = GEMINI_API_KEY
            if 'generateContent' in ep or ep.endswith(':generateContent'):
               
                payload_to_send = {
                    'contents': [
                        {
                            'parts': [
                                {'text': prompt}
                            ]
                        }
                    ],
                    'generationConfig': {
                        'temperature': temperature,
                        'maxOutputTokens': max_tokens,
                    }
                }
            else:
                payload_to_send = payload

            resp = requests.post(ep_to_call, json=payload_to_send, headers=headers_to_use, timeout=20)
            status = resp.status_code
            if status == 404:
                print('Gemini API 404 at', ep)
                last_error = f'404 from {ep}'
                continue
            if status in (401, 403):
                print(f'Gemini API auth error {status} at {ep}:', resp.text)
                key = GEMINI_API_KEY or ''
                looks_like_oauth = ('.' in key) or (len(key) > 200)
                if not looks_like_oauth:
                    try:
                        ep_with_key = ep + (('&' if '?' in ep else '?') + f'key={key}')
                        print('Retrying with API key as query param:', ep_with_key)
                        headers_no_auth = dict(headers)
                        headers_no_auth.pop('Authorization', None)
                        resp2 = requests.post(ep_with_key, json=payload_to_send, headers=headers_no_auth, timeout=20)
                        if resp2.status_code // 100 == 2:
                            data = resp2.json()
                            text = _parse_gemini_response(data)
                            if text:
                                return text
                            print('Gemini: parsed empty after query-key retry', str(data)[:400])
                        else:
                            print('Retry with query key returned', resp2.status_code, resp2.text[:400])
                    except Exception as e:
                        print('Exception retrying with query param key', e)

                    try:
                        headers_key = dict(headers)
                        headers_key.pop('Authorization', None)
                        headers_key['x-goog-api-key'] = key
                        print('Retrying with x-goog-api-key header')
                        resp3 = requests.post(ep, json=payload_to_send, headers=headers_key, timeout=20)
                        if resp3.status_code // 100 == 2:
                            data = resp3.json()
                            text = _parse_gemini_response(data)
                            if text:
                                return text
                            print('Gemini: parsed empty after header-key retry', str(data)[:400])
                        else:
                            print('Retry with x-goog-api-key returned', resp3.status_code, resp3.text[:400])
                    except Exception as e:
                        print('Exception retrying with x-goog-api-key header', e)

                return 'La IA no está autorizada (clave inválida o permisos). Revisa GEMINI_API_KEY.'
            if status // 100 != 2:
                body_snippet = resp.text[:800]
                print('Gemini API error', status, 'at', ep, body_snippet)
                last_error = f'{status} from {ep} - {body_snippet[:200]}'

                if status == 400 and ('Invalid value at' in body_snippet or 'INVALID_ARGUMENT' in body_snippet or 'TextPrompt' in body_snippet):
                    alt_payloads = [
                        # prompt as object with text
                        {'prompt': {'text': prompt}, 'temperature': temperature, 'maxOutputTokens': max_tokens},
                        # prompt.text as object
                        {'prompt': {'text': {'text': prompt}}, 'temperature': temperature, 'maxOutputTokens': max_tokens},
                        # prompt.text as list of objects (some versions expect list)
                        {'prompt': {'text': [{'text': prompt}]}, 'temperature': temperature, 'maxOutputTokens': max_tokens},
                        # 'instances' shape (Vertex-style)
                        {'instances': [{'content': prompt}]},
                        # messages/chat style
                        {'messages': [{'role': 'user', 'content': prompt}]},
                    ]

                    for idx, alt in enumerate(alt_payloads, start=1):
                        try:
                            print(f'Trying alternative payload #{idx} for {ep}')
                            r2 = requests.post(ep, json=alt, headers=headers, timeout=20)
                            print(' -> status', r2.status_code)
                            if r2.status_code // 100 == 2:
                                try:
                                    data2 = r2.json()
                                    text2 = _parse_gemini_response(data2)
                                    if text2:
                                        return text2
                                    print('Alt payload succeeded but parsing failed; snapshot:', str(data2)[:800])
                                    return str(data2)
                                except Exception as ee:
                                    print('Error parsing alt response', ee)
                                    return r2.text
                            else:
                                print('Alt payload returned', r2.status_code, r2.text[:400])
                        except Exception as ee:
                            print('Exception while trying alt payload', ee)

                continue

            data = resp.json()
            text = _parse_gemini_response(data)
            if text:
                return text
            print('Gemini: could not parse response body from', ep)
            print('Response snapshot:', str(data)[:800])
            return str(data)

        except requests.exceptions.RequestException as e:
            last_error = str(e)
            print('Gemini API exception when calling', ep, e)
            continue
        except Exception as e:
            last_error = str(e)
            print('Unexpected exception calling Gemini at', ep, e)
            continue

    print('Gemini API all endpoints failed:', last_error)
    return 'Perdón, ocurrió un error al generar la respuesta.'
