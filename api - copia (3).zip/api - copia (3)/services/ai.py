import os
import random
from data.db import get_collection
from .gemini_py import generate_reply as gemini_generate_reply
from bson import ObjectId


def query_existing_db(phone, text, db=None):

    try:
        clientes_collection = get_collection('clientes')
        conversations_collection = get_collection('conversations')
        keywords_collection = get_collection('keywords')
        
        customer = clientes_collection.find_one({'phone': phone})
        
        text_lower = text.lower()
        relevant_keywords = list(keywords_collection.find({
            'keyword': {'$regex': text_lower, '$options': 'i'}
        }))
        
        recent_conversations = list(conversations_collection.find(
            {'customer_phone': phone}
        ).sort('created_at', -1).limit(5))
        
        return {
            'customer': customer,
            'keywords': relevant_keywords,
            'recent_conversations': recent_conversations
        }
        
    except Exception as e:
        print(f"Error querying database: {e}")
        return {'customer': None, 'keywords': [], 'recent_conversations': []}


def generate_reply(text, context=None):

    text_low = text.lower()
    
    if context and context.get('keywords'):
        for keyword_doc in context['keywords']:
            if keyword_doc['keyword'] in text_low:
                return keyword_doc['response']
    
    customer_name = ""
    if context and context.get('customer'):
        # Normalize name to avoid None or non-string values
        raw_name = context['customer'].get('name')
        if raw_name and isinstance(raw_name, str):
            raw_name = raw_name.strip()
            if raw_name and raw_name.lower() != 'none':
                customer_name = f" {raw_name}"

    try:
        print(f"DEBUG: generate_reply called. text={text}, customer_name={customer_name}, keywords_count={len(context.get('keywords', [])) if context else 0}")
    except Exception:
        pass
    
    if any(w in text_low for w in ['problema', 'falla', 'no funciona', 'cortada', 'error']):
        return f'Hola{customer_name}, lamentamos el inconveniente. ¿Puedes confirmar tu dirección y el número de cliente para que verifiquemos la red?'
    
    if any(w in text_low for w in ['precio', 'contratar', 'planes', 'tarifa']):
        return f'Hola{customer_name}, tenemos planes desde 30€/mes. ¿Te interesa fibra para hogar o empresa?'
    
    if any(w in text_low for w in ['hola', 'buenas', 'buenos días', 'buenas tardes']):
        return f'¡Hola{customer_name}! ¿En qué puedo ayudarte hoy?'
    
    if any(w in text_low for w in ['gracias', 'perfecto', 'ok', 'vale']):
        return f'¡De nada{customer_name}! Si necesitas algo más, no dudes en escribirnos.'
    
    system = "Eres un asistente de soporte técnico para ISP. Responde en español, con amabilidad y concisión."
    ctx_parts = []
    if context:
        if context.get('customer'):
            ctx_parts.append(f"Cliente: {context['customer'].get('name','(sin nombre)')}")
        if context.get('recent_conversations'):
            recent = ' | '.join([c.get('message','') for c in context['recent_conversations'][:3]])
            ctx_parts.append(f"Últimas: {recent}")
    ctx = '\n'.join(ctx_parts)

    prompt = f"{system}\n{ctx}\nUsuario: {text}\nAsistente:"
    
    import os
    import importlib
    
    old_model = os.environ.get('GEMINI_MODEL')
    old_auth = os.environ.get('GEMINI_AUTH_MODE')
    
    os.environ['GEMINI_MODEL'] = 'gemini-2.0-flash'
    os.environ['GEMINI_AUTH_MODE'] = 'x-goog'
    
    import services.gemini_py
    importlib.reload(services.gemini_py)
    
    ai_reply = gemini_generate_reply(prompt)
    
    if old_model:
        os.environ['GEMINI_MODEL'] = old_model
    else:
        os.environ.pop('GEMINI_MODEL', None)
        
    if old_auth:
        os.environ['GEMINI_AUTH_MODE'] = old_auth
    else:
        os.environ.pop('GEMINI_AUTH_MODE', None)
    
    if not ai_reply:
        ai_reply = f'Hola{customer_name}, gracias por tu mensaje. ¿Puedes dar más detalles?'
    return ai_reply