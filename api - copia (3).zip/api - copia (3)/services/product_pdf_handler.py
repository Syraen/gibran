import logging
import re
from typing import Dict, Any, Optional, List, Tuple
from flask import jsonify, send_file
from services.pdf_search_service import pdf_search_service, search_product_datasheet, answer_product_question
from utils.pdf_utils import extract_pdf_text, find_pdf_by_product_name, list_available_pdfs
from services.gemini_py import generate_reply

# Configurar logging
logger = logging.getLogger(__name__)

class ProductPDFHandler:
    """
    Manejador para consultas relacionadas con productos y fichas técnicas.
    Integra búsqueda inteligente de PDFs con IA para responder consultas de usuarios.
    """
    
    def __init__(self):
        self.pdf_service = pdf_search_service
        
        # Patrones para detectar solicitudes de fichas técnicas
        self.datasheet_patterns = [
            r'ficha\s+t[eé]cnica',
            r'datasheet',
            r'especificaciones?\s+t[eé]cnicas?',
            r'hoja\s+de\s+datos',
            r'informaci[oó]n\s+t[eé]cnica',
            r'caracter[ií]sticas\s+t[eé]cnicas?',
            r'manual\s+t[eé]cnico',
            r'spec\s+sheet'
        ]
        
        # Patrones para detectar consultas de productos
        self.product_query_patterns = [
            r'qu[eé]\s+es\s+(?:el\s+|un\s+)?(.+?)[\?\.]',
            r'informaci[oó]n\s+(?:sobre\s+|del\s+|de\s+)?(.+?)[\?\.]',
            r'cu[aá]les?\s+son\s+las\s+caracter[ií]sticas\s+(?:de\s+|del\s+)?(.+?)[\?\.]',
            r'c[oó]mo\s+funciona\s+(?:el\s+)?(.+?)[\?\.]',
            r'precio\s+(?:de\s+|del\s+)?(.+?)[\?\.]',
            r'dimensiones\s+(?:de\s+|del\s+)?(.+?)[\?\.]',
            r'especificaciones?\s+(?:de\s+|del\s+)?(.+?)[\?\.]',
            r'capacidad\s+(?:de\s+|del\s+)?(.+?)[\?\.]'
        ]
    
    def is_datasheet_request(self, message: str) -> bool:
        """Detectar si el mensaje es una solicitud de ficha técnica"""
        message_lower = message.lower()
        
        for pattern in self.datasheet_patterns:
            if re.search(pattern, message_lower):
                return True
        
        return False
    
    def is_product_query(self, message: str) -> bool:
        """Detectar si el mensaje es una consulta sobre un producto"""
        message_lower = message.lower()
        
        # Palabras clave que indican consulta de producto
        product_indicators = [
            'producto', 'cable', 'fibra', 'bobina', 'ducto', 'conectores?',
            'empalme', 'otdr', 'multímetro', 'fusionadora', 'cortadora',
            'cat6a?', 'cat5e?', 'hdpe', 'utp', 'stp', 'monomodo', 'multimodo',
            'odf', 'distribuidor', 'repartidor', 'marco', 'patch.*panel',
            'rack', 'bandeja', 'splice', 'sc/apc', 'lc', 'fc'
        ]
        
        for indicator in product_indicators:
            if re.search(r'\b' + indicator + r'\b', message_lower):
                return True
        
        # Verificar patrones de consulta
        for pattern in self.product_query_patterns:
            if re.search(pattern, message_lower):
                return True
        
        return False
    
    def extract_product_name(self, message: str) -> Optional[str]:
        """Extraer el nombre del producto de la consulta del usuario"""
        message_clean = message.strip().lower()
        
        # Patrones para extraer nombres de productos
        extraction_patterns = [
            r'ficha\s+t[eé]cnica\s+(?:del?\s+|de\s+)?(.+?)(?:\?|\.|$)',
            r'informaci[oó]n\s+(?:sobre\s+|del?\s+|de\s+)?(.+?)(?:\?|\.|$)',
            r'especificaciones\s+(?:del?\s+|de\s+)?(.+?)(?:\?|\.|$)',
            r'precio\s+(?:del?\s+|de\s+)?(.+?)(?:\?|\.|$)',
            r'qu[eé]\s+es\s+(?:el\s+|la\s+)?(.+?)(?:\?|\.|$)',
            r'c[oó]mo\s+funciona\s+(?:el\s+|la\s+)?(.+?)(?:\?|\.|$)',
            r'dimensiones\s+(?:del?\s+|de\s+)?(.+?)(?:\?|\.|$)',
            r'caracter[ií]sticas\s+(?:del?\s+|de\s+)?(.+?)(?:\?|\.|$)'
        ]
        
        for pattern in extraction_patterns:
            match = re.search(pattern, message_clean)
            if match:
                product_name = match.group(1).strip()
                # Limpiar palabras comunes no relevantes
                product_name = re.sub(r'\b(?:del?|la|el|los|las|un|una|este|esta|ese|esa)\b', '', product_name).strip()
                if product_name and len(product_name) > 2:
                    return product_name
        
        # Si no se encuentra patrón específico, usar IA para extraer
        return self._extract_product_with_ai(message)
    
    def _extract_product_with_ai(self, message: str) -> Optional[str]:
        """Usar IA para extraer el nombre del producto de la consulta"""
        try:
            extraction_prompt = f"""
TAREA: Extraer el nombre del producto de telecomunicaciones de la consulta del usuario.

CONSULTA DEL USUARIO: "{message}"

INSTRUCCIONES:
1. Identifica el producto específico mencionado en la consulta
2. Responde SOLO con el nombre del producto, sin explicaciones
3. Si no hay un producto específico, responde "NO_ENCONTRADO"
4. Ejemplos de productos: "bobina UTP cat6A", "ducto HDPE 50mm", "tritubo HDPE"

PRODUCTO:
"""
            
            ai_response = generate_reply(extraction_prompt, temperature=0.2, max_tokens=100)
            
            if ai_response and ai_response.strip() != "NO_ENCONTRADO":
                return ai_response.strip()
            
        except Exception as e:
            logger.error(f"Error extrayendo producto con IA: {e}")
        
        return None
    
    def handle_datasheet_request(self, message: str, phone: str = None) -> str:
        """Manejar solicitud de ficha técnica"""
        try:
            product_name = self.extract_product_name(message)
            
            if not product_name:
                return ("No pude identificar el producto específico del que necesitas la ficha técnica. "
                       "¿Podrías ser más específico con el nombre o código del producto?")
            
            logger.info(f"Buscando ficha técnica para: {product_name}")
            
            # Buscar ficha técnica
            datasheet_info = search_product_datasheet(product_name)
            
            if datasheet_info.get('success'):
                pdf_path = datasheet_info.get('pdf_path')
                product_info = datasheet_info.get('product_info', {})
                
                response = f"📋 **Ficha técnica encontrada: {datasheet_info.get('found_pdf')}**\n\n"
                
                # Incluir información del producto si está disponible
                if product_info:
                    if isinstance(product_info, dict) and 'raw_specifications' not in product_info:
                        for key, value in product_info.items():
                            if key != 'extraction_method':
                                response += f"**{key.replace('_', ' ').title()}:** {value}\n"
                    else:
                        response += f"{product_info.get('raw_specifications', 'Información técnica extraída del PDF.')}\n"
                
                response += f"\n📁 **Archivo:** {datasheet_info.get('found_pdf')}"
                
                # Si hay metadatos adicionales del producto
                metadata = datasheet_info.get('metadata', {})
                if metadata and metadata.get('precio'):
                    response += f"\n💰 **Precio:** {metadata.get('precio')}"
                
                return response
                
            else:
                # Buscar información general del producto
                return self.handle_product_question(message, phone)
                
        except Exception as e:
            logger.error(f"Error manejando solicitud de ficha técnica: {e}")
            return f"Disculpa, hubo un error al buscar la ficha técnica de '{product_name}'. Por favor intenta de nuevo."
    
    def handle_product_question(self, message: str, phone: str = None) -> str:
        """Manejar consulta general sobre un producto"""
        try:
            product_name = self.extract_product_name(message)
            
            if not product_name:
                return ("No pude identificar el producto específico sobre el que preguntas. "
                       "¿Podrías mencionar el nombre o código del producto?")
            
            logger.info(f"Consulta de producto: {product_name}")
            
            # Buscar información del producto
            response = answer_product_question(product_name, message)
            
            if response and "No encontré información" not in response:
                return response
            else:
                # Respuesta de fallback
                return self._generate_fallback_response(product_name, message)
                
        except Exception as e:
            logger.error(f"Error manejando consulta de producto: {e}")
            return f"Disculpa, hubo un error al buscar información sobre el producto. Por favor intenta de nuevo."
    
    def _generate_fallback_response(self, product_name: str, original_message: str) -> str:
        """Generar respuesta de fallback cuando no se encuentra información específica"""
        try:
            # Listar productos disponibles
            available_products = self.pdf_service.list_available_products()
            
            fallback_prompt = f"""
ERES UN ASISTENTE TÉCNICO DE FIBREMEX especializado en productos de telecomunicaciones.

El usuario preguntó sobre: "{product_name}"
Mensaje original: "{original_message}"

PRODUCTOS DISPONIBLES EN NUESTRO CATÁLOGO:
{', '.join(available_products[:10]) if available_products else 'Actualizando catálogo...'}

INSTRUCCIONES:
1. Explica que no tienes información específica sobre ese producto exacto
2. Sugiere productos similares de nuestro catálogo si es relevante
3. Ofrece ayudar con información general sobre ese tipo de producto
4. Pregunta si necesita información sobre algún otro producto específico
5. Mantén un tono profesional y servicial

RESPONDE:
"""
            
            return generate_reply(fallback_prompt, temperature=0.5, max_tokens=400)
            
        except Exception as e:
            logger.error(f"Error generando respuesta de fallback: {e}")
            return (f"No encontré información específica sobre '{product_name}' en nuestros archivos técnicos. "
                   "¿Podrías verificar el nombre del producto o consultar sobre algún otro producto de nuestro catálogo?")
    
    def get_available_products(self) -> List[str]:
        """Obtener lista de productos disponibles"""
        return self.pdf_service.list_available_products()
    
    def get_pdf_file(self, product_name: str) -> Optional[str]:
        """Obtener la ruta del archivo PDF para envío"""
        return self.pdf_service.get_pdf_file_path(product_name)
    
    def process_message(self, message: str, phone: str = None) -> Tuple[str, Optional[str]]:
        """
        Procesar mensaje del usuario y determinar el tipo de respuesta.
        
        Args:
            message: Mensaje del usuario
            phone: Número de teléfono del usuario (opcional)
            
        Returns:
            Tupla de (respuesta_texto, ruta_pdf_opcional)
        """
        try:
            # Detectar tipo de consulta
            if self.is_datasheet_request(message):
                logger.info("Detectada solicitud de ficha técnica")
                response = self.handle_datasheet_request(message, phone)
                
                # Intentar obtener ruta del PDF para envío
                product_name = self.extract_product_name(message)
                pdf_path = self.get_pdf_file(product_name) if product_name else None
                
                return response, pdf_path
                
            elif self.is_product_query(message):
                logger.info("Detectada consulta de producto")
                response = self.handle_product_question(message, phone)
                return response, None
            
            else:
                # No es una consulta de producto
                return None, None
                
        except Exception as e:
            logger.error(f"Error procesando mensaje: {e}")
            return "Disculpa, hubo un error procesando tu consulta. Por favor intenta de nuevo.", None


# Instancia global del handler
product_handler = ProductPDFHandler()


def handle_product_message(message: str, phone: str = None) -> Tuple[str, Optional[str]]:
    """Función de conveniencia para manejar mensajes de productos"""
    return product_handler.process_message(message, phone)


def is_product_related_message(message: str) -> bool:
    """Verificar si un mensaje está relacionado con productos"""
    return product_handler.is_datasheet_request(message) or product_handler.is_product_query(message)