from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional

from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory


@dataclass
class RouteDecision:
    intent: str
    confidence: float
    entities: Dict[str, str]
    needs_clarification: bool
    clarification_question: str = ""

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["confidence"] = max(0.0, min(1.0, float(data.get("confidence", 0.0))))
        return data


class IntentRouter:
    HIGH_THRESHOLD = 0.70
    MEDIUM_THRESHOLD = 0.40

    SMALL_TALK = {"hola", "buenas", "buenos dias", "gracias", "adios", "hasta luego", "hey"}

    TECH_KEYWORDS = {"configurar", "instalar", "problema", "error", "reparar", "otdr", "splice"}
    COURSE_KEYWORDS = {"curso", "cursos", "capacitacion", "temario", "inscripcion", "webinar"}
    PRODUCT_KEYWORDS = {"producto", "productos", "sku", "precio", "cotizacion", "comprar"}
    WEBINAR_KEYWORDS = {"webinar", "seminario", "evento"}
    POLICY_KEYWORDS = {"politica", "devolucion", "garantia"}
    GENERAL_KEYWORDS = {"info", "informacion", "contacto"}

    @classmethod
    def route(cls, phone: str, message: str, session_memory: Optional[Dict[str, Any]] = None) -> RouteDecision:
        text = (message or "").strip()
        lower = text.lower()

        if not lower:
            return RouteDecision("qa_general", 0.10, {}, False)

        tokens = set(re.split(r"[^a-z0-9]+", cls._normalize(lower)))
        tokens.discard("")

        active_intent = None
        if session_memory:
            ctx = session_memory.get("context") or {}
            slots = ctx.get("slots") or {}
            active_intent = slots.get("intent")

        if tokens & cls.SMALL_TALK:
            return RouteDecision("small_talk", 0.65, {}, False)
            return RouteDecision("small_talk", 0.65, {}, False)

        scores = {
            "qa_tecnico": cls._score(tokens, cls.TECH_KEYWORDS, 1.6),
            "catalogo_curso": cls._score(tokens, cls.COURSE_KEYWORDS, 1.2),
            "catalogo_producto": cls._score(tokens, cls.PRODUCT_KEYWORDS, 1.2),
            "catalogo_webinar": cls._score(tokens, cls.WEBINAR_KEYWORDS, 1.1),
            "soporte_politicas": cls._score(tokens, cls.POLICY_KEYWORDS, 1.4),
            "qa_general": cls._score(tokens, cls.GENERAL_KEYWORDS, 0.9),
        }

        if any(re.search(p, lower) for p in [r"por que", r"como\s+", r"no\s+funciona"]):
            scores["qa_tecnico"] += 1.2

        if "webinar" in lower and scores.get("catalogo_webinar", 0) <= scores.get("catalogo_curso", 0):
            scores["catalogo_webinar"] += 1.0
        if "curso" in lower and scores.get("catalogo_curso", 0) < 1.0:
            scores["catalogo_curso"] += 1.0

        entities = cls._extract_entities(lower)

        best_intent = max(scores, key=scores.get)
        best_score = scores[best_intent]
        sorted_scores = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0

        confidence = cls._confidence(best_score, second_score)

        if active_intent and active_intent != "desambiguar" and best_score < 1.0 and scores.get(active_intent, 0) > 0.5:
            best_intent = active_intent
            confidence = max(confidence, 0.45)

        needs_clarification = False
        clarification_question = ""
        if confidence < cls.MEDIUM_THRESHOLD or (best_score - second_score) < 0.5:
            needs_clarification = True
            clarification_question = cls._build_clarification([k for k, _ in sorted_scores], lower)
            best_intent = "desambiguar"

        decision = RouteDecision(intent=best_intent, confidence=confidence, entities=entities,
                                  needs_clarification=needs_clarification, clarification_question=clarification_question)

        # persist if strong
        try:
            if confidence >= cls.HIGH_THRESHOLD:
                mem = get_conversation_memory(phone) or {}
                ctx = mem.get("context") or {}
                slots = ctx.get("slots") or {}
                slots["intent"] = best_intent
                ctx["slots"] = slots
                mem["context"] = ctx
                save_conversation_memory(phone, mem)
        except Exception:
            pass

        return decision

    @staticmethod
    def _normalize(text: str) -> str:
        s = unicodedata.normalize("NFD", text)
        s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
        return re.sub(r"\s+", " ", s).strip()

    @staticmethod
    def _score(tokens: set, keywords: set, weight: float = 1.0) -> float:
        if not tokens:
            return 0.0
        kws = {IntentRouter._normalize(k) for k in keywords}
        return float(len(tokens & kws)) * weight

    @staticmethod
    def _confidence(best: float, second: float) -> float:
        if best <= 0:
            return 0.0
        if second <= 0:
            return min(0.99, best / (best + 1.0))
        ratio = best / (best + second)
        return max(0.05, min(0.99, ratio))

    @staticmethod
    def _extract_entities(text: str) -> Dict[str, str]:
        entities: Dict[str, str] = {}
        m = re.search(r"sku[:\s-]*([a-z0-9\-\.]+)", text, re.IGNORECASE)
        if m:
            entities["sku"] = m.group(1)
        m2 = re.search(r"v?(\d+\.\d+(?:\.\d+)*)", text)
        if m2:
            entities["version"] = m2.group(0)
        return entities

    @staticmethod
    def _build_clarification(candidate_intents: list, original_text: str) -> str:
        catalog = [i for i in candidate_intents if i.startswith("catalogo_")]
        if catalog:
            opts = ", ".join(c.replace("catalogo_", "") for c in catalog)
            return f"¿Te refieres a {opts}?"
        return "¿Puedes darme más detalles?"

        return "¿Puedes darme más detalles?"
