"""
Funciones auxiliares para facilitar el manejo de memoria de conversación
"""
from services.conversation_memory import ConversationMemory
import threading


def save_conversation_memory(phone: str, key: str, value) -> None:
    """
    Guarda un valor en la memoria de conversación del cliente.
    """
    try:
        depth = getattr(_thread_local, 'save_depth', 0)
        _thread_local.save_depth = depth + 1
        try:
            memory = ConversationMemory.get_client_memory(phone)

            # Mantener coherencia con el resto del código: ciertas claves críticas del flujo
            # de asesor se guardan en el nivel superior del documento de memoria.
            if key in ["waiting_for_advisor_data", "advisor_data", "advisor_course_id", "advisor_intentos", "last_action"]:
                memory[key] = value
            else:
                # Asegurar que exista la sección de contexto para otros valores
                if "context" not in memory:
                    memory["context"] = {}
                memory["context"][key] = value

            # Guardar en la base de datos
            ConversationMemory._save_to_mongodb(phone, memory)
            try:
                print(f"[CONTEXT] save_conversation_memory: {phone} -> {key}")
            except Exception:
                pass

            
            if getattr(_thread_local, 'save_depth', 0) == 1 and not getattr(_thread_local, 'suppress_sync', False):
                try:
                    if key == 'selected_course' and isinstance(value, dict) and value.get('id'):
                        save_current_item(phone, 'course', value.get('id'), value.get('nombre') or value.get('name'), value.get('details') if isinstance(value.get('details'), dict) else None)
                    if key == 'selected_product' and isinstance(value, dict) and value.get('id'):
                        save_current_item(phone, 'product', value.get('id'), value.get('nombre') or value.get('name'), value.get('details') if isinstance(value.get('details'), dict) else None)
                    if key == 'selected_webinar' and isinstance(value, dict) and value.get('id'):
                        save_current_item(phone, 'webinar', value.get('id'), value.get('nombre') or value.get('name'), value.get('details') if isinstance(value.get('details'), dict) else None)
                except Exception:
                    pass
        finally:
            current = getattr(_thread_local, 'save_depth', 1)
            _thread_local.save_depth = max(0, current - 1)
    except Exception as e:
        print(f"Error al guardar en memoria de conversación {phone}/{key}: {e}")

def get_conversation_memory(phone: str, key: str, default=None):
    """
    Recupera un valor de la memoria de conversación del cliente.
    """
    try:
        memory = ConversationMemory.get_client_memory(phone)

        if key in ["waiting_for_advisor_data", "advisor_data", "advisor_course_id", "advisor_intentos", "last_action"]:
            return memory.get(key, default)

        if "context" not in memory:
            return default

        return memory["context"].get(key, default)

    except Exception as e:
        print(f"Error al leer de memoria de conversación {phone}/{key}: {e}")
        return default


def save_current_item(phone: str, item_type: str, item_id: str, item_name: str, item_data: dict = None) -> None:
    try:
        try:
            cid = str(item_id) if item_id is not None else None
        except Exception:
            cid = item_id

        current_item = {
            'type': item_type,
            'id': cid,
            'name': item_name,
            'data': item_data or {},
            'timestamp': ConversationMemory._create_empty_memory()['last_updated']
        }
        
        save_conversation_memory(phone, 'current_item', current_item)
        save_conversation_memory(phone, 'current_topic', item_type)

       
        try:
            _thread_local.suppress_sync = True
            if item_type == 'course':
                save_conversation_memory(phone, 'selected_course', {'id': cid, 'nombre': item_name, 'name': item_name, 'details': item_data})
            elif item_type == 'product':
                save_conversation_memory(phone, 'selected_product', {'id': cid, 'nombre': item_name, 'name': item_name, 'details': item_data})
            elif item_type == 'webinar':
                save_conversation_memory(phone, 'selected_webinar', {'id': cid, 'nombre': item_name, 'name': item_name, 'details': item_data})
        finally:
            try:
                _thread_local.suppress_sync = False
            except Exception:
                pass
            
        print(f"[CONTEXT] Guardado current_item para {phone}: {item_type} - {item_name} (ID: {item_id})")
    except Exception as e:
        print(f"Error guardando current_item para {phone}: {e}")


def get_current_item(phone: str) -> dict:
    """
    Recupera el item actual de la conversación.
    
   
    """
    try:
        current = get_conversation_memory(phone, 'current_item')
        if current and isinstance(current, dict) and current.get('id'):
            return current
        
        for item_type, key in [('course', 'selected_course'), ('product', 'selected_product'), ('webinar', 'selected_webinar')]:
            item = get_conversation_memory(phone, key)
            if item and isinstance(item, dict) and item.get('id'):
                return {
                    'type': item_type,
                    'id': item.get('id'),
                    'name': item.get('nombre') or item.get('name'),
                    'data': item.get('details') or item,
                    'timestamp': None
                }
        
        return None
    except Exception as e:
        print(f"Error recuperando current_item para {phone}: {e}")
        return None


def save_listed_items(phone: str, item_type: str, items_list: list) -> None:
    """
    Guarda la lista de items mostrados recientemente al usuario.
    
    """
    try:
        key = f'last_listed_{item_type}'
        compact_list = []
        for item in items_list[:10]:  # Máximo 10 items
            if isinstance(item, dict):
                compact_list.append({
                    'id': item.get('id'),
                    'name': item.get('nombre') or item.get('name') or item.get('title')
                })
        
        save_conversation_memory(phone, key, compact_list)
        print(f"[CONTEXT] Guardados {len(compact_list)} {item_type} listados para {phone}")
    except Exception as e:
        print(f"Error guardando lista de {item_type} para {phone}: {e}")


def get_listed_items(phone: str, item_type: str) -> list:
    """
    Recupera la lista de items mostrados recientemente.
    
    """
    try:
        key = f'last_listed_{item_type}'
        items = get_conversation_memory(phone, key, [])
        return items if isinstance(items, list) else []
    except Exception as e:
        print(f"Error recuperando lista de {item_type} para {phone}: {e}")
        return []


def clear_current_context(phone: str) -> None:
    """
    Limpia el contexto actual (item seleccionado y listas recientes).
    Útil cuando el usuario cambia completamente de tema.
    """
    try:
        save_conversation_memory(phone, 'current_item', None)
        save_conversation_memory(phone, 'current_topic', None)
        save_conversation_memory(phone, 'last_listed_courses', None)
        save_conversation_memory(phone, 'last_listed_products', None)
        save_conversation_memory(phone, 'last_listed_webinars', None)
        print(f"[CONTEXT] Contexto limpiado para {phone}")
    except Exception as e:
        print(f"Error limpiando contexto para {phone}: {e}")