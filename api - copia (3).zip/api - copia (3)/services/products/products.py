import json
import os
import re
from typing import Dict, List, Optional, Tuple


class ProductService:

	def __init__(self, products_json_path: Optional[str] = None):
		base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
		default = os.path.join(base_dir, 'splitbot.products.json')
		self.products_json_path = products_json_path or default
		self.products: List[Dict] = self._load_products()

	def _load_products(self) -> List[Dict]:
		try:
			with open(self.products_json_path, 'r', encoding='utf-8') as f:
				data = json.load(f)
				return data if isinstance(data, list) else []
		except Exception:
			return []

	def detect_product(self, text: str) -> Optional[Dict]:
		if not text:
			return None
		q = (text or '').lower()

		m = re.search(r"\bid\s*(\d{1,6})\b", q)
		if m:
			pid = m.group(1)
			for p in self.products:
				if str(p.get('id')) == pid:
					return p

		if re.fullmatch(r"\d{1,6}", q.strip()):
			for p in self.products:
				if str(p.get('id')) == q.strip():
					return p
				
		sku_like = re.findall(r"[a-z0-9]+[-_.][a-z0-9.\-]+", q)
		if sku_like:
			for token in sku_like:
				for p in self.products:
					name = (p.get('nombre') or '').lower()
					if token in name:
						return p

		tokens_q = [t for t in re.findall(r"[\w\u00C0-\u017F]+", q) if len(t) >= 3]
		best: Tuple[Optional[Dict], int] = (None, 0)
		for p in self.products:
			name = (p.get('nombre') or '').lower()
			ntokens = [t for t in re.findall(r"[\w\u00C0-\u017F]+", name) if len(t) >= 3]
			score = sum(1 for t in tokens_q if t in ntokens or t in name)
			if score > best[1]:
				best = (p, score)

		return best[0] if best[1] >= 1 else None

	def detect_attribute(self, text: str) -> str:
		q = (text or '').lower()

		# Precio
		if 'precio' in q or 'precios' in q or 'cuesta' in q or 'vale' in q or '$' in q:
			return 'precio'

		# Descripción
		if 'descripcion' in q or 'descripci' in q or 'informacion' in q or 'información' in q or 'describe' in q:
			return 'descripcion'

		# Especificaciones o ficha técnica
		if 'especificacion' in q or 'especificaciones' in q or 'caracteristicas' in q or 'ficha' in q or 'datasheet' in q or 'spec' in q:
			return 'especificaciones'

		# Link / enlace
		if 'link' in q or 'enlace' in q or 'url' in q or 'pagina' in q or 'sitio' in q:
			return 'link'

		return 'all'

	def build_full_response(self, p: Dict) -> str:
		partes = []
		nombre = p.get('nombre') or 'Producto'
		partes.append(f"{nombre}")
		if p.get('descripcion'):
			partes.append(f"Descripción: {p.get('descripcion')}")
		if p.get('precio'):
			partes.append(f"Precio: {p.get('precio')}")
		especs = p.get('especificaciones') or []
		if especs:
			partes.append('Especificaciones:')
			for e in especs:
				partes.append(f"- {e}")
		if p.get('link'):
			partes.append(f"Link: {p.get('link')}")
		return '\n'.join(partes)

	def build_attribute_response(self, p: Dict, attr: str) -> str:
		if attr == 'precio':
			return f"Precio de {p.get('nombre')}: {p.get('precio', 'Consultar') }"
		if attr == 'descripcion':
			return f"Descripción de {p.get('nombre')}: {p.get('descripcion', 'Sin descripción') }"
		if attr == 'especificaciones':
			especs = p.get('especificaciones') or []
			if not especs:
				return f"{p.get('nombre')} no tiene especificaciones registradas"
			return f"Especificaciones de {p.get('nombre')}:\n" + '\n'.join(f"- {s}" for s in especs)
		if attr == 'link':
			return f"Enlace: {p.get('link', 'No disponible')}"
		return self.build_full_response(p)

	def handle_message(self, message: str) -> Optional[str]:
		if not message:
			return None
		prod = self.detect_product(message)
		if not prod:
			return None
		attr = self.detect_attribute(message)
		return self.build_attribute_response(prod, attr) if attr != 'all' else self.build_full_response(prod)


# Exportar instancia por conveniencia
products_service = ProductService()

def get_product_response(message: str) -> Optional[str]:
	return products_service.handle_message(message)