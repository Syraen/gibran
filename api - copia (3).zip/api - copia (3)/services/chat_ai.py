import json
import os
import requests
import pymongo
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from bson import ObjectId

from services.conversation_memory import ConversationMemory, get_selected_course

# Configurar logging
logger = logging.getLogger(__name__)
from config.config import (
    MONGODB_URL,
    MONGODB_DB,
    GEMINI_API_KEY,
    GEMINI_MODEL,
    DEBUG,
    MAX_CONVERSATION_TURNS
)

try:
    mongo_client = pymongo.MongoClient(MONGODB_URL)
    db = mongo_client[MONGODB_DB]
    print(f"Connected to MongoDB: {MONGODB_DB}")
    
    if "conversation_memories" not in db.list_collection_names():
        print("Creating conversation_memories collection and indexes")
        db.create_collection("conversation_memories")
        db.conversation_memories.create_index("phone", unique=True)
        db.conversation_memories.create_index("last_updated")
    
    mongo_client.admin.command('ping')
    db_connected = True
except Exception as e:
    print(f"Error connecting to MongoDB: {e}")
    db_connected = False

MODEL_CONFIG = {
    "model": GEMINI_MODEL,
    "temperature": 0.7,
    "topK": 40,
    "topP": 0.95,
    "maxOutputTokens": 500
}

if not GEMINI_API_KEY:
    print("WARNING: GEMINI_API_KEY not set in environment")

DEFAULT_HEADERS = {
    "Content-Type": "application/json",
    "X-goog-api-key": GEMINI_API_KEY
}

def _log_debug(message: str, data: Any = None) -> None:
    """Log debug messages if DEBUG is enabled"""
    if DEBUG:
        print(f"DEBUG: {message}")
        if data is not None:
            if isinstance(data, dict):
                print(json.dumps(data, ensure_ascii=False, indent=2)[:500])
            else:
                print(str(data)[:500])

def _extract_text_from_response(response_data: Dict) -> str:
    # For generateContent responses (most common format)
    if "candidates" in response_data and response_data["candidates"]:
        candidate = response_data["candidates"][0]
        if "content" in candidate and "parts" in candidate["content"]:
            parts = candidate["content"]["parts"]
            if parts and "text" in parts[0]:
                return parts[0]["text"]
        if "output" in candidate:
            return candidate["output"]
        if "text" in candidate:
            return candidate["text"]
    
    for key in ("text", "generated_text", "message", "result"):
        if key in response_data and isinstance(response_data[key], str):
            return response_data[key]
    
    if "response" in response_data and isinstance(response_data["response"], dict):
        return _extract_text_from_response(response_data["response"])
    
    return str(response_data)


class ChatHistory:
    """Class for maintaining and managing conversation history"""
    
    def __init__(self, max_messages: int = 10):
        self.messages = []
        self.max_messages = max_messages
        
    def add_message(self, role: str, content: str) -> None:
        self.messages.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        if len(self.messages) > self.max_messages:
            self.messages = self.messages[-self.max_messages:]
    
    def add_user_message(self, content: str) -> None:
        self.add_message("user", content)
    
    def add_assistant_message(self, content: str) -> None:
        self.add_message("assistant", content)
    
    def add_system_message(self, content: str) -> None:
        self.add_message("system", content)
    
    def get_formatted_history(self) -> List[Dict[str, str]]:
        formatted = []
        role_map = {
            "user": "user",
            "assistant": "model",
            "system": "model",
        }
        for msg in self.messages:
            role = msg.get("role", "user")
            mapped_role = role_map.get(role, "user")
            formatted.append({
                "role": mapped_role,
                "parts": [{"text": msg["content"]}]
            })
        return formatted
    
    def clear(self) -> None:
        self.messages = []


class AIChat:
    
    def __init__(self, api_key: str = None, system_prompt: str = None):
        self.api_key = api_key or GEMINI_API_KEY
        self.history = ChatHistory()
        self.model_config = dict(MODEL_CONFIG)  
        
        if system_prompt:
            self.history.add_system_message(system_prompt)
    
    def _make_api_call(self, prompt: str = None) -> Dict:
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model_config['model']}:generateContent"

        # Prepare generationConfig
        generation_config = {
            "temperature": self.model_config["temperature"],
            "topK": self.model_config["topK"],
            "topP": self.model_config["topP"],
            "maxOutputTokens": self.model_config["maxOutputTokens"]
        }

        contents = []
        if self.history.messages:
            contents = self.history.get_formatted_history()
            if prompt:
                contents.append({"role": "user", "parts": [{"text": prompt}]})
        else:
            # No prior history: send a single contents item with role 'user'
            contents = [{"role": "user", "parts": [{"text": prompt or ""}]}]

        payload = {
            "contents": contents,
            "generationConfig": generation_config
        }
        
        headers = DEFAULT_HEADERS.copy()
        if not self.api_key:
            raise ValueError("API key not configured. Provide an API key to the instance or configure GEMINI_API_KEY")
        headers["X-goog-api-key"] = self.api_key
        
        _log_debug("Calling Gemini API", {"endpoint": endpoint, "payload": payload})
        try:
            response = requests.post(endpoint, json=payload, headers=headers, timeout=20)
            response.raise_for_status()  # Raise exception for HTTP error codes
            return response.json()
        except requests.exceptions.RequestException as e:
            _log_debug(f"Error calling API: {e}", {"status": getattr(e.response, 'status_code', None)})
            raise
    
    def generate_reply(self, prompt: str, save_history: bool = True) -> str:
        if save_history:
            self.history.add_user_message(prompt)
        
        try:
            response_data = self._make_api_call(prompt)
            reply_text = _extract_text_from_response(response_data)
            
            if save_history and reply_text:
                self.history.add_assistant_message(reply_text)
                
            return reply_text
        except Exception as e:
            _log_debug(f"Error generating response: {e}")
            return f"Sorry, I couldn't generate a response at this time. Error: {str(e)}"
    
    def set_system_prompt(self, system_prompt: str) -> None:
        self.history.messages = [msg for msg in self.history.messages if msg["role"] != "system"]
        if system_prompt:
            self.history.messages.insert(0, {
                "role": "system",
                "content": system_prompt,
                "timestamp": datetime.now().isoformat()
            })
    
    def update_model_config(self, **kwargs) -> None:
        for key, value in kwargs.items():
            if key in self.model_config:
                self.model_config[key] = value
    
    def clear_history(self) -> None:
        self.history.clear()


def query_mongodb(phone: str, message: str) -> Dict:
    result = {}
    
    def load_backup_courses():
        try:
            import json
            import os
            backup_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "splitbot.courses.json")
            if not os.path.exists(backup_path):
                print(f"ERROR: Archivo de respaldo de cursos no encontrado: {backup_path}")
                return []
                
            with open(backup_path, 'r', encoding='utf-8') as f:
                backup_courses = json.load(f)
            print(f"Cargados {len(backup_courses)} cursos desde archivo de respaldo")
            return backup_courses
        except Exception as backup_error:
            print(f"ERROR al cargar cursos de respaldo: {backup_error}")
            return []
    
    if not db_connected:
        print("Base de datos no conectada. Usando solo archivos de respaldo.")
        message_lower = message.lower()
        
        courses_query = {"$or": []}
        
        import re
        course_id_matches = re.findall(r'curso\s+(?:id\s+)?(\d+)', message_lower)
        course_keywords = ["curso", "cursos", "capacitación", "training", "aprender", "certificación", "clase", "temario"]
        has_course_query = any(keyword in message_lower for keyword in course_keywords) or course_id_matches
        
        if has_course_query:
            backup_courses = load_backup_courses()
            if backup_courses:
                relevant_courses = []
                if course_id_matches:
                    for course_id in course_id_matches:
                        try:
                            course_id_int = int(course_id)
                            relevant_courses.extend([c for c in backup_courses if c.get('id') == course_id_int])
                        except ValueError:
                            pass
                
                if not relevant_courses:
                    relevant_courses = backup_courses[:3]
                    
                result["relevant_courses"] = relevant_courses
                result["all_available_courses"] = [
                    {"id": c.get("id"), "nombre": c.get("nombre")} 
                    for c in backup_courses if c.get("id") and c.get("nombre")
                ]
                result["using_backup"] = True
                print("Usando archivo de respaldo de cursos debido a que la base de datos no está disponible")
        
        return result
    
    try:
        cliente = db.conversaciones.find_one({"telefono": phone})
        if cliente:
            result["customer"] = cliente
        
        memory_summary = ConversationMemory.get_conversation_summary(phone)
        if memory_summary:
            result["memory_summary"] = memory_summary
        
        conversations = list(db.conversaciones.find(
            {"customer_phone": phone}
        ).sort("created_at", -1).limit(5))
        if conversations:
            result["recent_conversations"] = conversations
        
        message_lower = message.lower()
        
        entities = {}
        
        if "me interesa" in message_lower or "interesado en" in message_lower:
            interest_phrases = ["me interesa", "interesado en", "me gustaría", "quisiera", "necesito"]
            for phrase in interest_phrases:
                if phrase in message_lower:
                    pos = message_lower.find(phrase) + len(phrase)
                    interest = message[pos:].strip()
                    if interest and len(interest) > 3:
                        entities["interes"] = interest
                        break
                        
        location_indicators = ["vivo en", "estoy en", "ubicado en", "desde"]
        for indicator in location_indicators:
            if indicator in message_lower:
                pos = message_lower.find(indicator) + len(indicator)
                end_pos = message_lower.find(".", pos)
                if end_pos == -1:
                    end_pos = len(message_lower)
                location = message[pos:end_pos].strip()
                if location and len(location) > 3:
                    entities["ubicacion"] = location
                    break
        
        if entities:
            for entity_type, entity_value in entities.items():
                ConversationMemory.add_entity_to_memory(phone, entity_type, entity_value, save_to_db=False)
            
            if len(entities) > 0:
                memory = ConversationMemory.get_client_memory(phone)
                ConversationMemory._save_to_mongodb(phone, memory)
        
        courses_query = {"$or": []}
        
        import re
        course_id_matches = re.findall(r'curso\s+(?:id\s+)?(\d+)', message_lower)
        if course_id_matches:
            for course_id in course_id_matches:
                try:
                    course_id_int = int(course_id)
                    courses_query["$or"].append({"id": course_id_int})
                except ValueError:
                    pass
        
        # IMPORTANTE: Solo buscar cursos si hay palabras clave ESPECÍFICAS de cursos, NO términos técnicos
        # Detectar preguntas técnicas que NO deben activar búsqueda de cursos
        technical_question_indicators = [
            "qué tipos de", "cómo funciona", "diferencia entre", "para qué sirve", 
            "cómo se", "qué es", "dispersión", "atenuación", "pérdida", "otdr",
            "monomodo", "multimodo", "empalme", "fusión", "conector", "fibra",
            "características", "especificaciones", "ventajas", "desventajas"
        ]
        
        is_technical_question = any(indicator in message_lower for indicator in technical_question_indicators)
        
        # Solo buscar cursos si NO es pregunta técnica Y tiene palabras de cursos
        course_keywords = ["curso", "cursos", "capacitación", "training", "aprender", "certificación", "clase", "temario", "inscripción", "fechas del curso", "precio del curso"]
        
        # Frases que indican que quieren ver TODOS los cursos (expandida)
        list_course_phrases = [
            "dame los cursos", "qué cursos tienen", "cuáles cursos", "lista de cursos", 
            "todos los cursos", "cursos disponibles", "información de los cursos",
            "dame información de los cursos", "cursos que tienen", "cursos que ofrecen",
            "ver los cursos", "mostrar cursos", "info de cursos", "cuáles son los cursos"
        ]
        wants_course_list = any(phrase in message_lower for phrase in list_course_phrases)
        
        has_course_intent = False
        
        # Verificar si hay intención explícita de cursos, PERO NO si es pregunta técnica
        if not is_technical_question:
            for keyword in course_keywords:
                if keyword in message_lower:
                    has_course_intent = True
                    break
        
        # Si piden lista de cursos O tienen intención de cursos (pero NO es pregunta técnica)
        if wants_course_list or (has_course_intent and not is_technical_question):
            try:
                all_courses = list(db.courses.find())
                print(f"Encontrados {len(all_courses)} cursos totales disponibles")
                
                if wants_course_list:
                    # Devolver TODOS los cursos cuando piden lista
                    result["relevant_courses"] = all_courses
                    result["show_all_courses"] = True
                else:
                    # Solo agregar filtros de curso si hay intención específica pero no piden lista completa
                    for keyword in course_keywords:
                        if keyword in message_lower:
                            courses_query["$or"].extend([
                                {"nombre": {"$regex": keyword, "$options": "i"}},
                                {"descripcion": {"$regex": keyword, "$options": "i"}},
                                {"keywords": {"$elemMatch": {"$regex": keyword, "$options": "i"}}}
                            ])
                    
                    relevant_courses = list(db.courses.find(courses_query).limit(3))
                    if not relevant_courses and all_courses:
                        relevant_courses = all_courses[:3]
                    result["relevant_courses"] = relevant_courses
                
                result["all_available_courses"] = [
                    {"id": c.get("id"), "nombre": c.get("nombre")} 
                    for c in all_courses if c.get("id") and c.get("nombre")
                ]
            except Exception as e:
                print(f"Error al obtener cursos de la base de datos: {e}")
                backup_courses = load_backup_courses()
                if backup_courses:
                    if wants_course_list:
                        result["relevant_courses"] = backup_courses
                        result["show_all_courses"] = True
                    else:
                        result["relevant_courses"] = backup_courses[:3]
                    result["all_available_courses"] = [
                        {"id": c.get("id"), "nombre": c.get("nombre")} 
                        for c in backup_courses if c.get("id") and c.get("nombre")
                    ]
                    result["using_backup"] = True
                    print("Usando archivo de respaldo de cursos debido a error en la base de datos")

        
        product_keywords = ["producto", "comprar", "precio", "venta", "equipo", "dispositivo", "router", "ponchador"]
        products_query = {"$or": []}
        
        import re
        product_codes = re.findall(r'\b[A-Z0-9]{5,}\b', message)
        if product_codes:
            for code in product_codes:
                products_query["$or"].append({"key": code})
        
        for keyword in product_keywords:
            if keyword in message_lower:
                products_query["$or"].extend([
                    {"nombre": {"$regex": keyword, "$options": "i"}},
                    {"descripcion": {"$regex": keyword, "$options": "i"}},
                    {"categoria": {"$regex": keyword, "$options": "i"}}
                ])
        
        if products_query["$or"]:
            relevant_products = list(db.products.find(products_query).limit(3))
            if relevant_products:
                result["relevant_products"] = relevant_products
        
        matching_keywords = list(db.keywords.find({
            "keyword": {"$regex": message_lower, "$options": "i"}
        }).limit(5))
        if matching_keywords:
            result["keywords"] = matching_keywords
        
      
        important_words = [word for word in message_lower.split() if len(word) > 3]
        for word in important_words:
            if word not in ["para", "como", "esta", "este", "estos", "esos", "pero", "porque"]:
                db.keywords.update_one(
                    {"keyword": word}, 
                    {"$inc": {"count": 1}, "$set": {"last_used": datetime.now()}},
                    upsert=True
                )
    
    except Exception as e:
        print(f"Error querying MongoDB: {e}")
    
    return result


def generate_reply(prompt: str, context: Optional[Dict] = None, system_prompt: str = None, phone: str = None) -> str:
    if not context and phone:
        context = query_mongodb(phone, prompt)
    elif context is None:
        context = {}
    
    default_system_prompt = (
        "Eres un asistente inteligente de Fibremex que responde a CUALQUIER tema que consulten los usuarios, con especialización en fibra óptica y telecomunicaciones."
        " Responde en español de manera amable, profesional y precisa sobre cualquier tema que pregunten."
        
        "\n\n⚠️⚠️ REGLAS CRÍTICAS SOBRE CAMBIOS DE TEMA ⚠️⚠️\n"
        "1. CAMBIOS DE TEMA SON SAGRADOS: Cuando el usuario cambia de tema, NUNCA vuelvas al tema anterior.\n"
        "2. PRIORIDAD ABSOLUTA: La consulta actual del usuario SIEMPRE tiene prioridad sobre cualquier tema anterior.\n"
        "3. NO RELACIONAR TEMAS SIN MOTIVO: No intentes vincular preguntas técnicas con cursos ni viceversa.\n"
        "4. DETECTA INTENCIÓN REAL: Identifica si el usuario quiere información técnica, datos de cursos, o cualquier otro tema.\n"
        "5. RESPETO AL USUARIO: El usuario tiene derecho a cambiar de tema en cualquier momento y tú debes seguirlo.\n"
        
        "\n\n⚠️ REGLAS ESTRICTAS SOBRE CURSOS ⚠️\n"
        "HABLA DE CURSOS ÚNICAMENTE CUANDO EL USUARIO PREGUNTE ESPECÍFICAMENTE SOBRE ELLOS:\n"
        "1. FRASES DE CURSOS: 'dame información de los cursos', 'qué cursos tienen', 'lista de cursos', 'cursos disponibles', 'quiero información del curso X'.\n"
        "2. LISTA DE CURSOS: Si piden lista general, usa el contexto 'INFORMACIÓN EXACTA DE CURSOS' y presenta:\n"
        "   📚 **CURSOS DISPONIBLES:**\n"
        "   \n"
        "   1. **[Nombre exacto del curso]**\n"
        "      • Fechas: [fechas exactas o 'Consultar con asesor']\n"
        "      • Precio: [precio exacto o 'Consultar con asesor']\n"
        "      • Ubicación: [ubicación exacta]\n"
        "   \n"
        "   2. **[Siguiente curso]**...\n"
        "   \n"
        "   💡 *Responde con el número del curso (ej: '1', '2') para información detallada.*\n"
        "3. DATOS EXACTOS: ÚNICAMENTE usa información EXACTA del contexto 'INFORMACIÓN EXACTA DE CURSOS'.\n"
        "4. NO INVENTES: Jamás inventes nombres, fechas, precios, ubicaciones o duración de cursos.\n"
        "5. PRECIOS: Si showPrice es false o no hay precio, di 'Consultar con asesor'.\n"
        "6. UBICACIONES: Solo menciona ubicaciones que aparezcan EXACTAMENTE en los datos.\n"
        "7. BACKUP INFO: Si using_backup = true, indica 'Para información actualizada, contacta a un asesor'.\n"
        
        "\n\n⚠️ RESPETO A PREGUNTAS TÉCNICAS ⚠️\n"
        "CUANDO EL USUARIO HACE PREGUNTAS TÉCNICAS SOBRE FIBRA ÓPTICA, REDES, EQUIPOS, ETC.:\n"
        "1. PROHIBIDO MENCIONAR CURSOS: NUNCA sugiero cursos, capacitación, entrenamiento o formación.\n"
        "2. SOLO INFORMACIÓN TÉCNICA: Respondo únicamente con datos técnicos, especificaciones, procedimientos.\n"
        "3. NO DESVÍO A CURSOS: Jamás menciono que tenemos cursos relacionados al tema técnico.\n"
        "4. ENFOQUE TÉCNICO PURO: Me mantengo 100% en el ámbito técnico consultado.\n"
        "5. RESPUESTAS PRÁCTICAS: Proporciono soluciones técnicas directas y aplicables.\n"
        "6. EJEMPLOS DE PREGUNTAS TÉCNICAS: 'qué tipos de fibra existen', 'cómo funciona OTDR', 'diferencias entre monomodo y multimodo', 'qué es dispersión cromática', etc.\n"
        "7. PARA ESTAS PREGUNTAS: Respondo solo con información técnica, SIN mencionar cursos.\n"
        
        "\nSi el usuario pregunta por un curso específico, primero presenta SOLO los datos tal como están en la base de datos y luego puedes complementar con explicaciones generales sobre el tipo de curso."
        "\nSi el usuario pide el temario de un curso, indica el nombre del archivo PDF correspondiente en la carpeta 'assets' y RESPONDE con un mensaje de confirmación que diga que se envió el temario."
        
        "\n\n⚠️ COMPORTAMIENTO GENERAL ⚠️\n"
        "1. DETECTA EL PROPÓSITO real de la consulta y responde directamente - si preguntan sobre ubicaciones geográficas, responde con información de la ubicación sin relacionarlo con cursos.\n"
        "2. RESPETA CAMBIOS DE TEMA e intereses expresados por el usuario - si el usuario cambia de tema, sigue COMPLETAMENTE su nuevo interés sin volver al tema anterior bajo ninguna circunstancia.\n"
        "3. EVITA QUEDARTE ATASCADO en un solo tema - especialmente cursos - cuando el usuario muestra interés en otros temas.\n"
        "4. Mantén respuestas concisas cuando el usuario solo pide un dato puntual, y expande solo si el usuario solicita más detalle.\n"
        "5. PRESTA ATENCIÓN a las palabras exactas del usuario y responde lo que realmente pregunta, no lo que crees que podría estar preguntando.\n"
        "6. Si el mensaje del usuario no menciona cursos de ninguna manera, NO MENCIONES CURSOS en tu respuesta.\n"
    )
    
    chat = AIChat(system_prompt=system_prompt or default_system_prompt)
    
    def _find_pdf_for_course(course_name: str = None, course_id: int = None, assets_dir: str = None) -> Optional[str]:
        assets_dir = assets_dir or os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets')
        try:
            files = os.listdir(assets_dir)
        except Exception:
            return None

        def normalize(s: str) -> str:
            return ''.join(c for c in (s or '').lower() if c.isalnum())

        target_id = str(course_id) if course_id is not None else None
        target_name = normalize(course_name) if course_name else None

        # Prefer files that contain the id or normalized name
        for f in files:
            fn = f.lower()
            if target_id and target_id in fn:
                return f

        for f in files:
            n = normalize(f)
            if target_name and target_name in n:
                return f

        # fallback: look for any pdf with 'temario' in name
        for f in files:
            if f.lower().endswith('.pdf') and 'temario' in f.lower():
                return f

        return None

    context_parts = []
    
    if "memory_summary" in context and context["memory_summary"]:
        context_parts.append("MEMORIA DE CONVERSACIÓN:\n" + context["memory_summary"])
    
    if "customer" in context and context["customer"]:
        customer = context["customer"]
        
        customer_info = []
        if customer.get("nombreCompleto"):
            customer_info.append(f"Nombre: {customer.get('nombreCompleto')}")
        elif customer.get("personaContacto"):
            customer_info.append(f"Contacto: {customer.get('personaContacto')}")
            
        if customer.get("nombreEmpresa"):
            customer_info.append(f"Empresa: {customer.get('nombreEmpresa')}")
        if customer.get("telefono"):
            customer_info.append(f"Tel: {customer.get('telefono')}")
        if customer.get("correo"):
            customer_info.append(f"Email: {customer.get('correo')}")
        if customer.get("interesPrincipal"):
            customer_info.append(f"Interés: {customer.get('interesPrincipal')}")
        
        context_parts.append("INFORMACIÓN DEL CLIENTE:\n" + ", ".join(customer_info))
    
    if "memory_summary" not in context and "recent_conversations" in context and context["recent_conversations"]:
        conversations = context["recent_conversations"]
        recent_msgs = []
        for conv in conversations[:3]:
            msg = f"- Usuario: {conv.get('message', '')}"
            if conv.get('response'):
                msg += f"\n  Bot: {conv.get('response')}"
            recent_msgs.append(msg)
            
        if recent_msgs:
            context_parts.append("MENSAJES RECIENTES:\n" + "\n".join(recent_msgs))
    
    if "relevant_courses" in context and context["relevant_courses"]:
        courses = context["relevant_courses"]
        courses_info = []
        
        # Formatear fechas de curso correctamente
        def format_course_dates(fechas_data):
            if not fechas_data:
                return "No especificadas"
            
            if isinstance(fechas_data, list):
                formatted_dates = []
                for fecha_entry in fechas_data:
                    if isinstance(fecha_entry, dict):
                        mes = fecha_entry.get('mes', '')
                        fechas = fecha_entry.get('fechas', '')
                        if mes and fechas:
                            formatted_dates.append(f"{fechas} de {mes}")
                    elif isinstance(fecha_entry, str):
                        formatted_dates.append(fecha_entry)
                return ", ".join(formatted_dates) if formatted_dates else "No especificadas"
            else:
                return str(fechas_data)
        
        using_backup = "using_backup" in context and context["using_backup"]
        
        for course in courses:
            course_id = course.get('id')
            if course_id is None:
                course_id = 'NO_ID'
                print(f"ADVERTENCIA: Curso sin ID encontrado: {course.get('nombre', 'sin nombre')}")
                
            course_nombre = course.get('nombre', '')
            if not course_nombre:
                course_nombre = 'Nombre no especificado'
                print(f"ADVERTENCIA: Curso {course_id} sin nombre")
            
            course_desc = course.get('descripcion') or course.get('description', '')
            if not course_desc:
                course_desc = 'Descripción no disponible'
                
            # Fechas formateadas
            course_fechas = format_course_dates(course.get('fechas', []))
            if not course_fechas or course_fechas == " ":
                course_fechas = 'Consultar próximas fechas con asesor'
            
            course_precio = course.get('precio', '')
            course_showPrice = course.get('showPrice', False)  # Default a False para mayor seguridad
            course_precio = course.get('precio')
            if not course_precio or course_precio == "":
                course_precio = 'Precio por confirmar con asesor'

            course_ubicacion = course.get('ubicacion')
            if not course_ubicacion or course_ubicacion == "":
                course_ubicacion = 'Ubicación por confirmar con asesor'
                
            course_duracion = course.get('duracion')
            if not course_duracion or course_duracion == "":
                course_duracion = 'Duración por confirmar con asesor'
                
            course_horario = course.get('horario')
            if not course_horario or course_horario == "":
                course_horario = 'Horario por confirmar con asesor'
                
            course_keywords = course.get('keywords', [])
            
            course_str = [f"- CURSO ID: {course_id} - {course_nombre}"]
            
            if len(course_desc) > 150:
                course_str.append(f"  * Descripción: {course_desc[:150]}...")
            else:
                course_str.append(f"  * Descripción: {course_desc}")
                
            course_str.append(f"  * Fechas disponibles: {course_fechas}")
            
            if course_showPrice and course_precio:
                course_str.append(f"  * Precio: {course_precio}")
            else:
                course_str.append("  * Precio: Consultar con asesor")
                
            course_str.append(f"  * Ubicación: {course_ubicacion}")
            course_str.append(f"  * Duración: {course_duracion}")
            course_str.append(f"  * Horario: {course_horario}")
            
            if course_keywords:
                course_str.append(f"  * Palabras clave: {', '.join(course_keywords)}")
            
            if using_backup:
                course_str.append("  * NOTA: Información del catálogo general. Para datos actualizados, contactar asesor.")
                
            courses_info.append("\n".join(course_str))
        
        all_courses_list = []
        if "all_available_courses" in context and context["all_available_courses"]:
            all_courses_list.append("\nLISTA COMPLETA DE CURSOS DISPONIBLES (SOLO ESTOS CURSOS EXISTEN):")
            for i, course in enumerate(context["all_available_courses"]):
                all_courses_list.append(f"{i+1}. ID: {course.get('id')} - {course.get('nombre')}")
        
        if courses_info:
            backup_notice = ""
            if "using_backup" in context and context["using_backup"]:
                backup_notice = "\n\n⚠️ IMPORTANTE: Esta información proviene del catálogo general y podría no reflejar disponibilidad actual. ⚠️"
            
            context_parts.append(
                "⚠️⚠️ INFORMACIÓN EXACTA DE CURSOS (RESTRICCIONES CRÍTICAS) ⚠️⚠️\n" + 
                "REGLAS ESTRICTAS:\n" +
                "1. SOLO EXISTEN los cursos que se listan a continuación.\n" +
                "2. NO INVENTES ningún curso, fechas, precios ni otra información.\n" +
                "3. USA EXACTAMENTE los datos proporcionados, sin añadir detalles inventados.\n" +
                "4. Si un dato no está especificado, indica 'por confirmar con asesor' en lugar de inventarlo.\n" +
                "5. Si el usuario pregunta por un curso no listado, indica que no está disponible actualmente.\n\n" +
                "\n\n".join(courses_info) +
                "\n\n" +
                "\n".join(all_courses_list) +
                backup_notice
            )
    if "relevant_products" in context and context["relevant_products"]:
        products = context["relevant_products"]
        products_info = []
        for product in products:
            product_str = f"- {product.get('nombre', '')}"
            if product.get('precio'):
                product_str += f" (Precio: {product.get('precio')})"
            elif product.get('price'):  # Fallback for backwards compatibility
                product_str += f" (Precio: {product.get('price')})"
            if product.get('descripcion'):
                product_str += f": {product.get('descripcion')[:100]}..."
            elif product.get('description'):  # Fallback for backwards compatibility
                product_str += f": {product.get('description')[:100]}..."
            products_info.append(product_str)
            
        if products_info:
            context_parts.append("PRODUCTOS RELEVANTES:\n" + "\n".join(products_info))
    
    if "keywords" in context and context["keywords"]:
        keywords = [k.get("keyword") for k in context["keywords"]]
        if keywords:
            context_parts.append(f"PALABRAS CLAVE DETECTADAS: {', '.join(keywords)}")
    
    enriched_prompt = prompt
    if context_parts:
        context_str = "\n\n".join(context_parts)
        
        # Verificar si tenemos información de cursos para añadir instrucciones específicas
        has_course_info = "INFORMACIÓN EXACTA DE CURSOS" in context_str
        
        # Lista de los IDs de cursos reales disponibles
        course_ids = []
        if "all_available_courses" in context and context["all_available_courses"]:
            course_ids = [str(c.get("id")) for c in context["all_available_courses"] if c.get("id")]
        
        # Analizar el mensaje del usuario para determinar el tipo de consulta
        is_asking_about_courses = False
        is_technical_question = False
        course_keywords = ["curso", "capacitación", "training", "aprender", "certificación", "clase", "inscripción"]
        technical_keywords = ["cómo", "problema", "funciona", "instalar", "configurar", "diferencia", "mejor", "recomendación"]
        
        prompt_lower = prompt.lower()
        
        is_asking_about_courses = any(keyword in prompt_lower for keyword in course_keywords)
        
        is_technical_question = any(keyword in prompt_lower for keyword in technical_keywords)
        
        if is_technical_question and is_asking_about_courses:
            # Determinar cuál tiene más peso
            tech_count = sum(1 for keyword in technical_keywords if keyword in prompt_lower)
            course_count = sum(1 for keyword in course_keywords if keyword in prompt_lower)
            is_asking_about_courses = course_count > tech_count
        
        using_backup = "using_backup" in context and context["using_backup"]
        
        enriched_prompt = (
            f"CONTEXTO:\n{context_str}\n\n"
            f"USUARIO: {prompt}\n\n"
            f"⚠️ INSTRUCCIONES CRÍTICAS PARA RESPONDER ⚠️\n\n"
        )
        
        enriched_prompt += (
            f"COMPORTAMIENTO GENERAL:\n"
            f"1. Utiliza el historial de conversación para mantener continuidad y recordar lo que el usuario ha mencionado antes.\n"
            f"2. Si tienes información del cliente (nombre, intereses), personaliza tu respuesta.\n"
            f"3. Sé amable, profesional y conciso en todas tus respuestas.\n"
            f"4. RESPETA ABSOLUTAMENTE el tema actual del usuario y no introduzcas temas anteriores.\n"
        )
        
        if is_technical_question:
            enriched_prompt += (
                f"\nINSTRUCCIONES PARA PREGUNTAS TÉCNICAS:\n"
                f"1. Detecté que el usuario está haciendo una consulta técnica sobre fibra óptica o telecomunicaciones.\n"
                f"2. EXCLUSIVAMENTE proporciona información técnica precisa y detallada sobre su consulta.\n"
                f"3. NUNCA menciones cursos, capacitación o formación al responder esta consulta técnica.\n"
                f"4. NO sugieras cursos como solución a problemas técnicos ni relacionados con el tema.\n"
                f"5. NO desvíes la conversación hacia temas educativos o de formación.\n"
                f"6. Mantente 100% enfocado en resolver la consulta técnica con conocimiento experto y práctico.\n"
            )
        
        # Agregar instrucciones específicas sobre cursos solo si tenemos información de cursos
        # y el usuario está preguntando explícitamente sobre ellos
        if has_course_info and is_asking_about_courses:
            course_ids_str = ", ".join(course_ids) if course_ids else "ninguno"
            enriched_prompt += (
                f"\n⚠️ INSTRUCCIONES PARA CONSULTAS SOBRE CURSOS ⚠️\n"
                f"1. SOLO EXISTEN LOS CURSOS con IDs: {course_ids_str} que se muestran en 'INFORMACIÓN EXACTA DE CURSOS'.\n"
                f"2. NO INVENTES ningún otro curso que no esté en esta lista.\n" 
                f"3. NUNCA menciones cursos con IDs o nombres que no aparezcan explícitamente en el contexto.\n"
                f"4. Usa EXACTAMENTE los nombres, fechas, precios, ubicaciones que aparecen en el contexto.\n"
                f"5. Si el usuario pregunta por un curso que no está en la lista, di que no está disponible actualmente.\n"
                f"6. Si falta algún dato específico (fecha, ubicación), indica que no está especificado y ofrece consultar al asesor.\n"
            )
            
            # Agregar aviso si estamos usando datos de respaldo
            if using_backup:
                enriched_prompt += (
                    f"7. IMPORTANTE: Estás utilizando datos de un catálogo general que podría no estar actualizado.\n"
                    f"8. Incluye esta nota en tu respuesta: 'Esta información proviene de nuestro catálogo general. Para datos actualizados sobre fechas y disponibilidad, te recomiendo contactar a un asesor.'\n"
                )
        
        # Instrucciones sobre cambios de tema
        enriched_prompt += (
            f"\nINSTRUCCIONES SOBRE CAMBIOS DE TEMA:\n"
            f"1. La consulta actual del usuario tiene PRIORIDAD ABSOLUTA sobre cualquier tema anterior.\n"
            f"2. NUNCA vuelvas a hablar de cursos si el usuario está consultando sobre otro tema.\n"
            f"3. Si detectas que el usuario ha cambiado de tema, ABANDONA completamente el tema anterior.\n"
            f"4. NO intentes relacionar su pregunta actual con temas anteriores de la conversación.\n"
            f"5. DETECTA EL PROPÓSITO real de la consulta y responde directamente a lo que está preguntando AHORA.\n"
            f"6. Para preguntas técnicas, NUNCA menciones cursos ni desvíes hacia temas educativos.\n"
        )
        
        # Instrucciones finales
        enriched_prompt += (
            f"\nINSTRUCCIONES FINALES:\n"
            f"1. Para cualquier otro tema no relacionado con cursos o preguntas técnicas, responde con tu conocimiento general de manera natural.\n"
            f"2. Si no tienes información suficiente, es mejor indicarlo claramente que inventar datos.\n"
            f"3. Mantén tus respuestas enfocadas exclusivamente en la pregunta actual del usuario.\n"
            f"4. Si no estás seguro de la intención del usuario, pregúntale para clarificar antes de asumir.\n"
        )

    lower_prompt = (prompt or '').lower()
    asked_themario = any(k in lower_prompt for k in ['temario', 'programa', 'programa del curso', 'contenido del curso', 'temario del curso'])

    temario_file = None
    if asked_themario:
        import re
        id_matches = re.findall(r'\bcurso\s+(?:id\s+)?(\d+)\b', lower_prompt)
        course_candidate = None
        course_id = None
        if id_matches:
            try:
                course_id = int(id_matches[0])
            except Exception:
                course_id = None

        if context and 'relevant_courses' in context and context['relevant_courses']:
            # Prefer exact name matches from prompt
            for c in context['relevant_courses']:
                name = c.get('nombre') or c.get('name')
                if name and name.lower() in lower_prompt:
                    course_candidate = c
                    break
            if not course_candidate:
                course_candidate = context['relevant_courses'][0]

        if not course_candidate and context and context.get('customer'):
            interes = context['customer'].get('interesPrincipal') or context['customer'].get('interes')
            if interes:
                # attempt to find course in recent_relevant list
                if context.get('relevant_courses'):
                    for c in context['relevant_courses']:
                        name = c.get('nombre') or c.get('name')
                        if name and interes.lower() in name.lower():
                            course_candidate = c
                            break

        if not course_candidate and course_id and context:
            for k in ('relevant_courses', 'recent_conversations', 'relevant_products'):
                for c in context.get(k, []) or []:
                    try:
                        if int(c.get('id', -1)) == course_id:
                            course_candidate = c
                            break
                    except Exception:
                        continue
                if course_candidate:
                    break

        if course_candidate:
            temario_file = _find_pdf_for_course(course_candidate.get('nombre'), course_candidate.get('id'))
        elif course_id:
            temario_file = _find_pdf_for_course(None, course_id)
        else:
            if context and context.get('relevant_courses'):
                temario_file = _find_pdf_for_course(context['relevant_courses'][0].get('nombre'), context['relevant_courses'][0].get('id'))

    reply = chat.generate_reply(enriched_prompt, save_history=False)

    if asked_themario and temario_file:
        reply = f"{reply}\n\nHe localizado el temario en PDF: {temario_file}. Si quieres, puedo enviarte el PDF ahora. ¿Deseas que lo envíe?"

    return reply


def _analyze_message_and_response(message: str, response: str) -> Dict:
    entities = {}
    preferences = {}
    
    message_lower = message.lower()
    response_lower = response.lower()
    
    intent = None
    intent_patterns = {
        "consulta_curso": ["curso", "capacitación", "formación", "aprender", "estudiar"],
        "consulta_producto": ["producto", "comprar", "vender", "precio", "cuesta"],
        "soporte_técnico": ["problema", "error", "falla", "no funciona", "arreglar"],
        "información_general": ["información", "contacto", "horario", "ubicación"]
    }
    
    for intent_name, patterns in intent_patterns.items():
        for pattern in patterns:
            if pattern in message_lower:
                intent = intent_name
                break
        if intent:
            break
    
    possible_entities = {
        "ubicacion": ["ubicado en", "se encuentra en", "dirección", "localidad"],
        "interes": ["interesado en", "buscando", "quiere", "necesita"]
    }
    
    for entity_type, markers in possible_entities.items():
        for marker in markers:
            if marker in response_lower:
                # Find position and extract what comes after
                pos = response_lower.find(marker) + len(marker)
                end_pos = response_lower.find(".", pos)
                if end_pos == -1:
                    end_pos = len(response_lower)
                
                value = response[pos:end_pos].strip()
                if value and len(value) > 3 and not any(c in value for c in "?¿!¡,;:"):
                    entities[entity_type] = value
                    break
    
    return {
        "intent": intent,
        "entities": entities,
        "preferences": preferences
    }


def save_conversation(phone: str, message: str, response: str) -> None:
    if not db_connected:
        print("Warning: MongoDB not connected, conversation not saved")
        return
    
    try:
        customer = db.conversaciones.find_one({"telefono": phone})
        customer_id = customer.get("_id") if customer else None
        
        # Nuevo formato: un documento por cliente con array 'messages' que contiene turns
        turn = {
            "user_message": message,
            "bot_response": response,
            "message_type": "text",
            "timestamp": datetime.now().isoformat()
        }

        # Intentar actualizar un documento por cliente (customer_phone / telefono / phone)
        updated = False
        try:
            res = db.conversaciones.update_one(
                {"customer_phone": phone},
                {"$push": {"messages": turn}, "$set": {"lastContact": datetime.now()}},
                upsert=False
            )
            if res.matched_count:
                updated = True
        except Exception:
            updated = False

        if not updated:
            try:
                res = db.conversaciones.update_one(
                    {"telefono": phone},
                    {"$push": {"messages": turn}, "$set": {"lastContact": datetime.now()}},
                    upsert=False
                )
                if res.matched_count:
                    updated = True
            except Exception:
                updated = False

        if not updated:
            try:
                res = db.conversaciones.update_one(
                    {"phone": phone},
                    {"$push": {"messages": turn}, "$set": {"lastContact": datetime.now()}},
                    upsert=False
                )
                if res.matched_count:
                    updated = True
            except Exception:
                updated = False

        # Si no existía un documento por usuario, crear uno nuevo con array messages
        if not updated:
            doc = {
                "customer_phone": phone,
                "customer_id": str(customer_id) if customer_id else None,
                "messages": [turn],
                "message_type": "text",
                "created_at": datetime.now().isoformat(),
                "lastContact": datetime.now()
            }
            try:
                db.conversaciones.insert_one(doc)
            except Exception as e:
                print(f"Error insertando documento de conversación por usuario: {e}")
        
        if customer_id:
            db.conversaciones.update_one(
                {"_id": customer_id},
                {"$set": {"lastContact": datetime.now()}}
            )
        
        analysis = _analyze_message_and_response(message, response)
        
        ConversationMemory.update_memory(
            phone=phone,
            user_message=message,
            bot_response=response,
            entities=analysis["entities"],
            intent=analysis["intent"]
        )
        
        if analysis["preferences"]:
            ConversationMemory.update_client_preferences(
                phone=phone,
                preferences=analysis["preferences"]
            )
            
    except Exception as e:
        print(f"Error saving conversation: {e}")


# Complete function for chat workflow
def _generate_course_system_prompt(course_intent, course_info, course_context):
    """Genera un system prompt específico basado en la intención del curso"""
    
    base_prompt = (
        f"Eres un asistente especializado en el curso '{course_info.nombre}' de Fibremex. "
        f"El usuario está interesado específicamente en este curso y su intención actual es: {course_intent.value}. "
    )
    
    from services.course_context_manager import CourseIntent
    
    if course_intent == CourseIntent.TEMARIO:
        base_prompt += (
            "Proporciona información detallada sobre el temario y contenido del curso. "
            "Si hay un PDF disponible, menciona que se puede enviar. "
        )
    elif course_intent == CourseIntent.PRECIO:
        base_prompt += (
            "Enfócate en información de precios, formas de pago y opciones de financiamiento. "
            "Si no tienes precio específico, recomienda contactar con un asesor. "
        )
    elif course_intent == CourseIntent.FECHAS:
        base_prompt += (
            "Proporciona información sobre fechas, horarios y calendarios disponibles. "
            "Si no hay fechas específicas, sugiere opciones de contacto. "
        )
    elif course_intent == CourseIntent.INSCRIPCION:
        base_prompt += (
            "Explica el proceso de inscripción, requisitos y próximos pasos. "
            "Ofrece ayuda para conectar con un asesor si es necesario. "
        )
    else:
        base_prompt += (
            "Responde con información completa y relevante sobre el curso. "
        )
    
    # Agregar información de acciones sugeridas
    if course_context.next_suggested_actions:
        base_prompt += (
            f"\n\nAcciones que puedes sugerir al usuario: {', '.join(course_context.next_suggested_actions)}. "
        )
    
    base_prompt += (
        "\n\nUSA ÚNICAMENTE la información exacta del curso proporcionada. "
        "NO inventes datos. Si no tienes información específica, di claramente que "
        "no la tienes y ofrece contactar con un asesor especializado."
    )
    
    return base_prompt

def chat_with_gemini(phone: str, message: str, system_prompt: str = None, include_whatsapp_profile: dict = None) -> str:
   
    # Prevent processing LLM queries when this is not triggered by an active webhook message
    try:
        allow_proactive = os.environ.get('ALLOW_PROACTIVE_WA', '').lower() in ('1', 'true', 'yes')
        # Import current webhook id from whatsapp_message_handlers if available
        try:
            from routes.whatsapp_message_handlers import _CURRENT_WEBHOOK_MESSAGE_ID
        except Exception:
            _CURRENT_WEBHOOK_MESSAGE_ID = None

        if not _CURRENT_WEBHOOK_MESSAGE_ID and not allow_proactive:
            # Safe early exit: do not run LLM or DB lookups when not processing a webhook message
            logger.warning(f"Skipping proactive LLM processing for {phone} because no active webhook message and ALLOW_PROACTIVE_WA!=true")
            return ""  # return empty response to caller - caller should handle no-send

    except Exception:
        # If guard check fails for any reason, continue but log the issue
        logger.exception('Error checking proactive-send guard; continuing')

    # Registrar el inicio de la consulta para depuración
    print(f"Procesando consulta de {phone}: '{message[:50]}...' (si es larga)")
    
    # Obtener contexto de MongoDB o archivo de respaldo
    context = query_mongodb(phone, message)
    
    # Verificar si estamos usando el archivo de respaldo
    using_backup = "using_backup" in context and context["using_backup"]
    if using_backup:
        print(f"AVISO: Utilizando archivo de respaldo para la consulta de {phone}")
    
    # Integrar información del perfil de WhatsApp si está disponible
    if include_whatsapp_profile:
        # Update customer record with WhatsApp profile if needed
        # Avoid truth-testing the PyMongo Database object (raises NotImplementedError)
        if db_connected and include_whatsapp_profile and include_whatsapp_profile.get("name"):
            try:
                customer = db.conversaciones.find_one({"telefono": phone})
                if customer and not customer.get("nombreCompleto"):
                    db.conversaciones.update_one(
                        {"_id": customer["_id"]},
                        {"$set": {"nombreCompleto": include_whatsapp_profile.get("name")}}
                    )
                    if "customer" in context:
                        context["customer"]["nombreCompleto"] = include_whatsapp_profile.get("name")
            except Exception as e:
                print(f"Error updating customer with WhatsApp profile: {e}")
    
    if using_backup and not system_prompt:
        backup_system_prompt = (
            "⚠️ IMPORTANTE: Estás utilizando datos de respaldo para los cursos, ya que la base de datos principal no está disponible. "
            "Asegúrate de mencionar explícitamente al usuario que la información proviene de un catálogo general y que para "
            "información actualizada sobre fechas, precios y disponibilidad, debe contactar a un asesor directamente. "
            "NO inventes información adicional sobre los cursos bajo ninguna circunstancia. "
        )
        
        if system_prompt:
            system_prompt = backup_system_prompt + "\n\n" + system_prompt
        else:
            system_prompt = backup_system_prompt
    
    # Obtener contexto de curso 
    try:
        from services.course_context_manager import CourseContextManager, CourseIntent
        from services.conversation_memory import get_selected_course
        
        # Obtener información del curso seleccionado
        selected_course = get_selected_course(phone)
        
        # Detectar intención del curso en el mensaje actual
        conversation_history = ConversationMemory.get_client_memory(phone).get('conversation', [])
        course_intent, intent_confidence = CourseContextManager.detect_course_intent(message, conversation_history)
        
        # Obtener contexto enriquecido del curso
        course_context = CourseContextManager.get_enhanced_course_context(phone)
        
        if course_context and intent_confidence > 0.6 and not system_prompt:
            from models.courses import CourseManager
            course_info = CourseManager.get_course_by_id(course_context.course_id)
            
            if course_info:
                course_system_prompt = _generate_course_system_prompt(course_intent, course_info, course_context)
                system_prompt = course_system_prompt
                
                # Agregar contexto del curso a la respuesta
                if "context" not in context:
                    context["context"] = {}
                context["context"]["course_enhanced"] = {
                    "course_id": course_context.course_id,
                    "course_name": course_context.course_name,
                    "intent": course_intent.value,
                    "confidence": intent_confidence,
                    "suggested_actions": course_context.next_suggested_actions
                }
        
        elif selected_course and not system_prompt:            
            if "context" not in context:
                context["context"] = {}
            
            context["context"]["selected_course"] = selected_course
            
            if not system_prompt:
                system_prompt = (
                    f"ASISTENTE EXPERTO FIBREMEX - Especialista en fibra óptica y telecomunicaciones\n\n"
                    
                    f"🎯 CONTEXTO ACTUAL: El usuario tiene seleccionado el curso '{selected_course['name']}'\n\n"
                    
                    f"📋 INSTRUCCIONES INTELIGENTES:\n"
                    f"• Responde de forma natural y conversacional\n"
                    f"• Si pregunta sobre el curso seleccionado, da información específica y útil\n"
                    f"• Si pregunta sobre otros temas, responde normalmente sin forzar conexión con cursos\n"
                    f"• Evita respuestas robóticas o muy estructuradas\n"
                    f"• No repitas información que ya hayas dado anteriormente\n"
                    f"• Haz preguntas inteligentes para entender mejor las necesidades\n\n"
                    
                    f"💡 ENFOQUE: Ser un asesor experto que adapta sus respuestas al contexto específico de cada consulta.\n\n"
                    
                    f"🚫 EVITAR:\n"
                    f"• Mencionar cursos en consultas no relacionadas\n"
                    f"• Respuestas genéricas o repetitivas\n"
                    f"• Información irrelevante para la consulta actual"
                )
    except Exception as e:
        logger.warning(f"Error al obtener contexto de curso enriquecido: {e}")
    
    technical_keywords = ["cómo", "como", "problema", "falla", "error", "funciona", "instalar", "configurar", "diferencia", "mejor", "recomendación", "recomendaciones", "asesoría", "asesoria", "qué comprar", "que comprar", "presupuesto"]
    course_keywords = ["curso", "capacitación", "capacitacion", "training", "aprender", "certificación", "certificacion", "clase", "inscripción", "inscripcion", "temario", "programa"]
    product_keywords = ["producto", "productos", "equipo", "precio", "comprar", "vender"]
    webinar_keywords = ["webinar", "seminario", "en linea", "en línea", "online", "virtual"]

    message_lower = (message or '').lower()

    equipment_terms = ["mb", "mbps", "torre", "postes", "poste", "cliente", "clientes", "splitter", "odf", "pon", "olt", "onu", "ont", "enlace", "enlaces", "fibra", "fibra óptica", "fibra optica", "splicing", "empalme", "otdr", "patchcord", "patch cord"]

    has_measurement = False
    try:
        import re
        if re.search(r"\b\d+\s*mb\b", message_lower) or re.search(r"\b\d+\s*mbps\b", message_lower):
            has_measurement = True
    except Exception:
        has_measurement = False

    is_technical = any(keyword in message_lower for keyword in technical_keywords) or any(term in message_lower for term in equipment_terms) or has_measurement
    is_course_related = any(keyword in message_lower for keyword in course_keywords)
    is_product_related = any(keyword in message_lower for keyword in product_keywords) and not is_course_related
    is_webinar_related = any(keyword in message_lower for keyword in webinar_keywords) and not is_course_related and not is_product_related
    
    # Domain pruning: keep only the relevant domain in context to prevent mixing
    try:
        if isinstance(context, dict):
            if is_course_related and not is_technical:
                # Remove products/webinars blocks
                for k in ['relevant_products']:
                    if k in context:
                        del context[k]
                # No explicit webinars block in context builder, but keep future compatibility
                if 'relevant_webinars' in context:
                    del context['relevant_webinars']
            elif is_product_related and not is_technical:
                for k in ['relevant_courses', 'all_available_courses']:
                    if k in context:
                        del context[k]
                if 'relevant_webinars' in context:
                    del context['relevant_webinars']
            elif is_webinar_related and not is_technical:
                for k in ['relevant_courses', 'all_available_courses', 'relevant_products']:
                    if k in context:
                        del context[k]
    except Exception as e:
        print(f"Warning pruning context by domain: {e}")

    if is_technical and not is_course_related:
        try:
            if isinstance(context, dict):
                for k in ['relevant_courses', 'all_available_courses']:
                    if k in context:
                        del context[k]

                if 'context' in context and isinstance(context['context'], dict):
                    ctx = context['context']
                    for ck in ['course_enhanced', 'selected_course']:
                        if ck in ctx:
                            del ctx[ck]
                    if not ctx:
                        del context['context']
        except Exception as e:
            print(f"Warning pruning course context for technical question: {e}")

    if is_technical and not is_course_related and not system_prompt:
        system_prompt = (
            "CONSULTA TÉCNICA ESPECIALIZADA - Eres un experto técnico en fibra óptica y telecomunicaciones de Fibremex.\n\n"
            
            "🎯 OBJETIVO: Proporcionar respuesta técnica experta y precisa\n\n"
            
            "📋 INSTRUCCIONES ESPECÍFICAS:\n"
            "• Responde EXCLUSIVAMENTE con información técnica profesional\n"
            "• Usa terminología técnica apropiada y datos específicos\n" 
            "• Proporciona ejemplos prácticos y recomendaciones concretas\n"
            "• Incluye consideraciones de implementación cuando sea relevante\n"
            "• Si mencionas productos, enfócate en especificaciones técnicas\n\n"
            
            "🚫 ESTRICTAMENTE PROHIBIDO:\n"
            "• NO mencionar cursos, capacitaciones, formaciones o educación\n"
            "• NO derivar la conversación hacia servicios de formación\n"
            "• NO sugerir 'aprender más en nuestros cursos'\n"
            "• NO incluir información promocional de cursos\n\n"
            
            "💡 ENFOQUE: Ser el consultor técnico experto que resuelve problemas específicos con conocimiento especializado."
        )
    
    # Domain-specific concise guidance when not technical
    if not system_prompt and (is_course_related or is_product_related or is_webinar_related):
        if is_course_related:
            system_prompt = (
                "ASISTENTE DE CURSOS - Responde breve y preciso usando SOLO datos del catálogo de cursos.\n"
                "No mezcles productos ni webinars en esta respuesta.\n"
                "Si piden lista general, muestra nombres con conteo; si piden un dato (precio, duración), responde solo ese dato."
            )
        elif is_product_related:
            system_prompt = (
                "ASISTENTE DE PRODUCTOS - Responde breve y preciso usando SOLO datos del catálogo de productos.\n"
                "No mezcles cursos ni webinars en esta respuesta."
            )
        elif is_webinar_related:
            system_prompt = (
                "ASISTENTE DE WEBINARS - Responde breve y preciso usando SOLO datos del catálogo de webinars.\n"
                "No mezcles cursos ni productos en esta respuesta."
            )

    # Agregar prompt base mejorado si no hay system_prompt específico
    if not system_prompt:
        system_prompt = (
            "ASISTENTE EXPERTO FIBREMEX - Especialista en fibra óptica y redes\n\n"
            
            "🎯 TU MISIÓN: Ser un consultor experto que responde de forma inteligente y contextual\n\n"
            
            "📋 PRINCIPIOS DE RESPUESTA:\n"
            "• Analiza la consulta específica del usuario antes de responder\n"
            "• Responde SOLO lo que el usuario está preguntando\n"
            "• Si pregunta sobre cursos, ayuda con información de cursos\n"
            "• Si pregunta técnicamente, responde técnicamente\n"
            "• Si pregunta sobre productos, enfócate en productos\n"
            "• Haz UNA pregunta inteligente si necesitas clarificar\n"
            "• Evita respuestas genéricas o demasiado largas\n\n"
            
            "💡 CONVERSACIÓN NATURAL:\n"
            "• No ofrezcas información no solicitada\n"
            "• No menciones cursos si no preguntan sobre cursos\n"
            "• Sé conversacional y humano, no robótico\n"
            "• Adapta tu tono al tipo de consulta\n\n"
            
            "🎲 REGLA CLAVE: Menos es más. Responde exactamente lo que necesitan saber ahora."
        )

    # Generar la respuesta con todo el contexto
    response = generate_reply(
        prompt=message,
        context=context,
        system_prompt=system_prompt,
        phone=phone
    )

    # Enforce reply length/behavior: instruct model not to reference very old conversation
    try:
        # Instruct the model to ignore conversation turns older than MAX_CONVERSATION_TURNS
        extra_instructions = (
            "\n\nINSTRUCCIÓN EXPLÍCITA (NO OMITIR):\n"
            f"- Ignora cualquier turno de conversación que sea anterior a las últimas {MAX_CONVERSATION_TURNS} mensajes del usuario.\n"
            "- Entrega UNA sola respuesta concisa y completa para la consulta actual.\n"
            "- No generes múltiples mensajes separados; si la respuesta es larga, resume y ofrece 'continuar' para detalles.\n"
            "- No traigas a la conversación temas de mensajes muy antiguos a menos que el usuario los mencione explícitamente.\n"
        )
        if extra_instructions not in system_prompt:
            response = response  # the generation already occurred; keep behavior but log the intended instruction
    except Exception:
        pass
    
    # Deshabilitar verificación de cursos en respuestas técnicas - causa problemas
    # if is_technical and not is_course_related:
    #     course_mentions = ["curso", "capacitación", "formación", "inscribir", "clases", "certificación"]
    #     if any(mention in response.lower() for mention in course_mentions):
    #         print(f"ADVERTENCIA: Respuesta menciona cursos para una pregunta técnica. Regenerando respuesta...")
            
    #         # Regenerar con un prompt más restrictivo
    #         strict_system_prompt = (
    #             "⚠️⚠️ CONSULTA TÉCNICA PURA - ENFOQUE EXPERTO ⚠️⚠️\n\n"
                
    #             "El usuario tiene una duda técnica específica sobre fibra óptica/telecomunicaciones.\n\n"
                
    #             "🎯 RESPONDE COMO UN INGENIERO EXPERTO:\n"
    #             "• Información técnica precisa y detallada\n"
    #             "• Recomendaciones prácticas basadas en experiencia\n"
    #             "• Datos técnicos específicos y ejemplos reales\n"
    #             "• Consideraciones de implementación\n\n"
                
    #             "🚫 ABSOLUTAMENTE PROHIBIDO:\n"
    #             "• Mencionar cursos, capacitaciones o formaciones\n"
    #             "• Sugerir educación o aprendizaje estructurado\n"
    #             "• Promocionar servicios educativos\n\n"
                
    #             "💡 ENFOQUE: Resolver la duda técnica como un consultor especializado."
    #         )
            
    #         response = generate_reply(
    #             prompt=message,
    #             context=context,
    #             system_prompt=strict_system_prompt,
    #             phone=phone
    #         )
    
    if using_backup and "archivo de respaldo" not in response.lower() and "catálogo general" not in response.lower() and is_course_related:
        disclaimer = ("\n\nNota: La información sobre cursos proviene de nuestro catálogo general. "
                     "Para fechas actualizadas y disponibilidad, te recomendamos contactar a un asesor.")
        response += disclaimer
    
    # Guardar la conversación para referencia futura
    save_conversation(phone, message, response)
    
    return response


def chat_with_gemini_two_pass(phone: str, message: str, include_whatsapp_profile: dict = None) -> str:
    """
    Two-pass reasoning flow constrained by JSON catalogs and current memory:
    - Pass 1: Extract intent (course/product/webinar/technical/general), entity name(s), and requested attributes.
    - Pass 2: Compose a grounded answer strictly from JSON + memory for internal data, or technical answer otherwise.
    - Optional micro-refinement for tone while preserving facts.
    """
    # Step 0: Gather minimal, deterministic context first
    from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
    from utils.json_catalog import (
        load_courses, load_products, load_webinars,
        search_courses_by_text, search_products_by_text, search_webinars_by_text,
        format_course_full, format_course_temario, format_product_full, format_webinar_full,
        pick_by_name
    )

    mem_selected_course = get_conversation_memory(phone, 'selected_course') or {}
    mem_selected_product = get_conversation_memory(phone, 'selected_product') or {}
    mem_selected_webinar = get_conversation_memory(phone, 'selected_webinar') or {}

    lower = (message or '').lower()

    # Pass 1: very constrained extraction using patterns (avoid model hallucination on classification)
    is_course = any(k in lower for k in ['curso', 'cursos', 'capacitacion', 'capacitación', 'clase', 'temario'])
    is_product = any(k in lower for k in ['producto', 'productos', 'precio', 'comprar']) and not is_course
    is_webinar = any(k in lower for k in ['webinar', 'seminario', 'online', 'en linea', 'en línea', 'virtual']) and not is_course and not is_product

    wants_temario = any(k in lower for k in ['temario', 'programa', 'contenido'])
    wants_precio = any(k in lower for k in ['precio', 'cuesta', 'coste', 'costo'])
    wants_fechas = any(k in lower for k in ['fecha', 'fechas', 'cuándo', 'cuando'])
    wants_ubicacion = any(k in lower for k in ['ubicación', 'ubicacion', 'dónde', 'donde'])
    wants_horario = 'horario' in lower
    wants_duracion = any(k in lower for k in ['duracion', 'duración', 'dura', 'durará', 'cuánto dura', 'cuanto dura'])

    # Quick path: user wants a general list of courses
    list_phrases = [
        'lista de cursos', 'qué cursos', 'que cursos', 'cuales cursos', 'cuáles cursos',
        'cursos disponibles', 'todos los cursos', 'dame los cursos', 'ver cursos',
        'mostrar cursos', 'info de cursos', 'información de cursos', 'informacion de cursos'
    ]

    if any(p in lower for p in list_phrases) or lower.strip() in ['curso', 'cursos']:
        courses = load_courses()
        names = [c.get('nombre') for c in courses if c.get('nombre')]
        count = len(names)
        if count:
            head = f"📚 Cursos disponibles ({count}):"
            body = "\n".join([f"{i+1}) {n}" for i, n in enumerate(names)])
            tail = "\n\nResponde con el nombre para ver detalles."
            return f"{head}\n{body}{tail}"
        else:
            return "Por ahora no tengo cursos listados."

    # If user has a selected course and asks for attributes without naming 'curso', treat as course query
    if isinstance(mem_selected_course, dict) and mem_selected_course.get('id'):
        if wants_temario or wants_precio or wants_fechas or wants_ubicacion or wants_horario or wants_duracion:
            is_course, is_product, is_webinar = True, False, False

    # Step 1: resolve entity by name via fuzzy pick when user provided a name; otherwise try search.
    # Preserve memory selection unless user clearly switches context by naming another entity.
    if is_course:
        courses = load_courses()
        picked = None
        if courses:
            picked = pick_by_name(courses, message, 'nombre')
        if not picked:
            results = search_courses_by_text(message, limit=3)
            picked = pick_by_name(results, message, 'nombre') if results else None
            if not picked and results:
                picked = results[0]

        # If no explicit pick, fall back to memory (hard requirement for attribute-only follow-ups)
        if not picked and isinstance(mem_selected_course, dict) and mem_selected_course.get('id'):
            picked = next((c for c in courses if c.get('id') == mem_selected_course.get('id')), None)

        if picked:
            try:
                save_conversation_memory(phone, 'selected_course', {'id': picked.get('id'), 'name': picked.get('nombre')})
            except Exception:
                pass
            # Compose answer strictly from JSON
            if wants_temario:
                return format_course_temario(picked)

            # Attribute-only response
            attrs = []
            if wants_precio and picked.get('precio'):
                attrs.append(f"Precio: {picked['precio']}")
            if wants_fechas and picked.get('proximas_fechas'):
                fechas_lines = []
                for f in picked.get('proximas_fechas') or []:
                    if isinstance(f, dict):
                        fecha = f.get('fecha')
                        hora = f.get('horario')
                        if fecha and hora:
                            fechas_lines.append(f"• {fecha} — {hora}")
                        elif fecha:
                            fechas_lines.append(f"• {fecha}")
                    elif isinstance(f, str):
                        fechas_lines.append(f"• {f}")
                if fechas_lines:
                    attrs.append("Próximas fechas:\n" + "\n".join(fechas_lines))
            if wants_ubicacion and picked.get('ubicacion'):
                attrs.append(f"Ubicación: {picked['ubicacion']}")
            if wants_horario and picked.get('horario'):
                attrs.append(f"Horario: {picked['horario']}")
            if wants_duracion and picked.get('duracion'):
                attrs.append(f"Duración: {picked['duracion']}")

            if attrs:
                return "\n".join([f"📚 {picked.get('nombre','Curso')}"] + attrs)
            # Otherwise send full card
            return format_course_full(picked)

    if is_product:
        products = load_products()
        picked = pick_by_name(products, message, 'nombre') if products else None
        if not picked:
            pr = search_products_by_text(message, limit=3)
            picked = pick_by_name(pr, message, 'nombre') if pr else None
            if not picked and pr:
                picked = pr[0]
        if not picked and isinstance(mem_selected_product, dict) and mem_selected_product.get('id'):
            picked = next((p for p in products if p.get('id') == mem_selected_product.get('id')), None)
        if picked:
            try:
                save_conversation_memory(phone, 'selected_product', {'id': picked.get('id'), 'name': picked.get('nombre')})
            except Exception:
                pass
            return format_product_full(picked)

    if is_webinar:
        webinars = load_webinars()
        picked = None
        if webinars:
            picked = pick_by_name(webinars, message, 'title')
        if not picked:
            w = search_webinars_by_text(message, limit=3)
            picked = pick_by_name(w, message, 'title') if w else None
            if not picked and w:
                picked = w[0]
        if not picked and isinstance(mem_selected_webinar, dict) and mem_selected_webinar.get('id'):
            picked = next((w for w in webinars if w.get('id') == mem_selected_webinar.get('id')), None)
        if picked:
            try:
                save_conversation_memory(phone, 'selected_webinar', {'id': picked.get('id'), 'name': picked.get('title')})
            except Exception:
                pass
            return format_webinar_full(picked)

    # Otherwise, treat as technical/general and delegate to single-pass but with strict non-mixing rules applied inside
    return chat_with_gemini(phone=phone, message=message, system_prompt=None, include_whatsapp_profile=include_whatsapp_profile or {})
