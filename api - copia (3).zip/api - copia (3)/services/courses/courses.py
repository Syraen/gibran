import json 
import os
import re
from typing import Dict, List, Optional, Tuple 

class CourseService: 
    def __init__(self, courses_json_path: Optional[str] = None):
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        default = os.path.join(base_dir, 'splitbot.courses.json')
        self.courses_json_path = courses_json_path or default 
        self.courses: List[Dict] = self._load_courses()
    
    def _load_courses(self) -> List[Dict]: 
        try:
            with open(self.courses_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception: 
            return []
        
    def detect_course(self, text: str) -> Optional[Dict]:
        if not text:
            return None
        q = (text or '').lower()

        m = re.search(r"\bid\s*(\d{1,6})\b", q)
        if m:
            cid = m.group(1)
            for c in self.courses:
                if str(c.get('id')) == cid or str(c.get('_id', '')) == cid:
                    return c

        if re.fullmatch(r"\d{1,6}", q.strip()):
            for c in self.courses:
                if str(c.get('id')) == q.strip():
                    return c

        m2 = re.search(r"curso(?:\s+n(?:ú|u)?mero)?\s*(\d{1,6})", q)
        if m2:
            cid2 = m2.group(1)
            for c in self.courses:
                if str(c.get('id')) == cid2:
                    return c

        tokens_q = [t for t in re.findall(r"[\w\u00C0-\u017F]+", q) if len(t) >= 3]
        best: Tuple[Optional[Dict], int] = (None, 0)
        for c in self.courses:
            name = (c.get('nombre') or '').lower()
            ntokens = [t for t in re.findall(r"[\w\u00C0-\u017F]+", name) if len(t) >= 3]
            score = sum(1 for t in tokens_q if t in ntokens or t in name)
            if score > best[1]:
                best = (c, score)

        return best[0] if best[1] >= 1 else None
    
    def detect_attribute(self, text: str) -> str: 
        q = (text or '').lower()
        if any(k in q for k in ['precio', 'cost', 'costo', 'precios', 'costos']): 
            return 'precio'
        if any(k in q for k in ['descripcion', 'descripci', ' informacion', 'info']): 
            return 'descripcion'
        if any(k in q for k in ['modalidad', 'modalidades', 'presencial', 'presenciales']): 
            return 'modalidad'
        if any(k in q for k in['ubicacion', 'locacion', 'lugar', 'sede']):
            return 'ubicacion'
        if any(k in q for k in['horarios', 'horario', 'hora']):
            return 'horario'
        if any(k in q for k in['duracion', 'dura']):
            return 'duracion'
        if any(k in q for k in['fechas', 'dias', 'dia', 'fecha', 'proxima fecha', 'fecha mas cercana']):
            return 'fechas'
        if any(k in q for k in['temario', 'temario pdf', 'contenido', 'temas', 'subtemas']):
            return 'temario'
        if any(k in q for k in['certificacion', 'certificaciones', 'certificado']):
            return 'certificaciones'
        return all 
    
    def build_attribute_response(self, c: Dict, attr: str) -> str: 
        name = c.get('nombre') or 'Curso'
        if attr == 'precio': 
            return f"Precio del curso de {name}: {c.get('precio', 'Un asesor te proporcionara el precio')}"
        if attr == 'descripcion':
            return f"Descripción {name}: {c.get('descripción', 'sin descripción')}"
        if attr == 'modalidad': 
            return f"Modalidad {name}: {c.get('modalidad', 'La modalidad es presencial')}"
        if attr == 'ubicación':
            return f"Ubicación {name}: {c.get('ubicacion' 'la ubicacion es en el Parque Industrial Tecnológico Innovación, Querétaro, Qro.')}"
        if attr == 'horario':
            return f"El horario de{name} es: {c.get('horario', 'No especificado')}"
        if attr == 'duracion': 
            return f"Duracion de {name}: {c.get('duracion', 'No especificada')}"
        if attr == 'fechas':
            prox = c.get('proximas_fechas') or c.get('proximas_fechas', [])
            if prox:
                lines = [f"- {f.get('fecha')} ({f.get('horario','')})" for f in prox]
                return f"Próximas fechas de {name}:\n" + '\n'.join(lines)
            
            fechas = c.get('proximas fechas') or c.get('proximas') or []
            if fechas: 
                return f"Fechas de {name}: \n" + '\n'.join([str(f) for f in fechas])
            return f"No hay fehcas proximas registradas para {name}"
        if attr == 'temario': 
            temario = c.get('temario') or []
            if not temario: 
                return f"{name} no tiene temario registrado"
            parts = [f"Temario {name}:"]
            for t in temario: 
                parts.append(f"- {t.get('titulo')}")
                if 'subtemas' in t: 
                    for st in t.get('subtemas'):
                        parts.append(f"  • {st}")
            return '\n'.join(parts)
        if attr == 'certificaciones': 
            cert = c.get('certificaciones') or c.get('certificacion') or []
            if not cert: 
                return f"{name} no se tienen certificaciones"
            if isinstance(cert, list): 
                return f"Certificaciones {name}:\n" + '\n'.join(f"- {x}" for x in cert)
            return f"Certificaciones {name}: {cert}"
        return self.build_full_response(c)
    
    def build_full_response(self, c: Dict) -> str:
        parts = [c.get('nombre') or 'Curso']
        if c.get('descripcion'):
            parts.append(f"Descripción: {c.get('descripcion')}")
        if c.get('modalidad'):
            parts.append(f"Modalidad: {c.get('modalidad')}")
        if c.get('precio'):
            parts.append(f"Precio: {c.get('precio')}")
        if c.get('ubicacion'):
            parts.append(f"Ubicación: {c.get('ubicacion')}")
        if c.get('horario'):
            parts.append(f"Horario: {c.get('horario')}")
        if c.get('duracion'):
            parts.append(f"Duración: {c.get('duracion')}")
        if c.get('proximas_fechas'):
            parts.append('Próximas fechas:')
            for f in c.get('proximas_fechas'):
                parts.append(f"- {f.get('fecha')} ({f.get('horario','')})")
        if c.get('temario'):
            parts.append('Temario:')
            for t in c.get('temario'):
                parts.append(f"- {t.get('titulo')}")
        return '\n'.join(parts)
    
    def handle_message(self, message: str) -> Optional[str]: 
        if not message: 
            return None
        course = self.detect_course(message)
        if not course: 
            return None
        attr = self.detect_attribute(message)
        return self.build_attribute_response(course, attr) if attr != 'all' else self.build_full_response(course)
    
course_service = CourseService()

def get_course_response(message: str) -> Optional[str]: 
    return course_service.handle_message(message)
        