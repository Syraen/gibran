"""
Módulo para gestionar la memoria de conversaciones por cliente y de
"""

import pymongo
from datetime import datetime
import json
from typing import Dict, List, Optional, Any, Union
from bson import ObjectId
from bson import json_util
import time
from config.config import (
    MONGODB_URL,
    MONGODB_DB,
    CACHE_EXPIRY,
    MAX_CONVERSATION_TURNS
)
from utils.whatsapp import send_text_message

# Conversation TTL in seconds (1 hour)
CONVERSATION_TTL_SECONDS = 3600

try:
    mongo_client = pymongo.MongoClient(MONGODB_URL)
    db = mongo_client[MONGODB_DB]
    mongo_client.admin.command('ping')
    db_connected = True
    print(f"ConversationMemory: Conectado a MongoDB: {MONGODB_DB}")
except Exception as e:
    print(f"ConversationMemory: Error conectando a MongoDB: {e}")
    db_connected = False


class ConversationMemory:
    _conversation_cache = {}
    _processed_message_ids = set()
    
    @classmethod
    def is_message_processed(cls, message_id: str) -> bool:
        """
        Verifica si un mensaje ya ha sido procesado previamente.
        """
        # Verificar en memoria
        if message_id in cls._processed_message_ids:
            return True
            
        # Verificar en base de datos si está disponible
        if db_connected:
            try:
                if "processed_messages" not in db.list_collection_names():
                    db.create_collection("processed_messages", capped=True, size=1048576) 
                    db.processed_messages.create_index("message_id", unique=True)
                    db.processed_messages.create_index("timestamp", expireAfterSeconds=86400)  
                
                result = db.processed_messages.find_one({"message_id": message_id})
                if result:
                    cls._processed_message_ids.add(message_id)
                    return True
            except Exception as e:
                print(f"Error verificando mensaje procesado en BD: {e}")
                
        return False
    
    @classmethod
    def mark_message_as_processed(cls, message_id: str) -> None:
        cls._processed_message_ids.add(message_id)
        
        if len(cls._processed_message_ids) > 1000:
            # Conservar solo los 500 más recientes
            cls._processed_message_ids = set(list(cls._processed_message_ids)[-500:])
            
        if db_connected:
            try:
                # Asegurar que la colección existe
                if "processed_messages" not in db.list_collection_names():
                    db.create_collection("processed_messages", capped=True, size=1048576)  
                    db.processed_messages.create_index("message_id", unique=True)
                    db.processed_messages.create_index("timestamp", expireAfterSeconds=86400)  # 24 horas TTL
                
                # Insertar registro con TTL
                db.processed_messages.insert_one({
                    "message_id": message_id,
                    "timestamp": datetime.now(),
                    "processed_at": datetime.now()
                })
            except pymongo.errors.DuplicateKeyError:
                pass
            except Exception as e:
                print(f"Error guardando mensaje procesado en BD: {e}")
    
    @classmethod
    def get_client_memory(cls, phone: str) -> Dict:
        
        cls._clean_expired_cache()
        
        if phone in cls._conversation_cache:
            cls._conversation_cache[phone]["last_active"] = time.time()
            return cls._conversation_cache[phone]["memory"]
        
        memory = cls._load_from_mongodb(phone)

        # If memory is stale (older than CONVERSATION_TTL_SECONDS), reset conversation but preserve important context
        try:
            last_updated = memory.get('last_updated')
            if last_updated:
                try:
                    last_dt = datetime.fromisoformat(last_updated)
                    if (datetime.now() - last_dt).total_seconds() > CONVERSATION_TTL_SECONDS:
                        memory = cls.reset_memory(phone, notify=True)
                except Exception:
                    pass
        except Exception:
            pass
        
        cls._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": memory
        }
        
        return memory

    @classmethod
    def ensure_summary(cls, phone: str, max_turns: int = 6) -> None:
        try:
            memory = cls.get_client_memory(phone)
            ctx = memory.get('context') or {}
            summary = ctx.get('conversation_summary') if isinstance(ctx, dict) else None
            conversation = memory.get('conversation', []) or []
            if not summary or len(conversation) >= max_turns:
                cls._update_context_summary(memory)
                memory['last_updated'] = datetime.now().isoformat()
                cls._save_to_mongodb(phone, memory)
                cls._conversation_cache[phone] = {
                    'last_active': time.time(),
                    'memory': memory
                }
        except Exception:
            pass

    @classmethod
    def get_slot(cls, phone: str, key: str, default=None):
        try:
            memory = cls.get_client_memory(phone)
            ctx = memory.get('context') or {}
            slots = ctx.get('slots') or {}
            return slots.get(key, default)
        except Exception:
            return default

    @classmethod
    def set_slot(cls, phone: str, key: str, value) -> None:
        try:
            memory = cls.get_client_memory(phone)
            if 'context' not in memory:
                memory['context'] = {}
            if 'slots' not in memory['context']:
                memory['context']['slots'] = {}
            memory['context']['slots'][key] = value
            memory['last_updated'] = datetime.now().isoformat()
            cls._save_to_mongodb(phone, memory)
            cls._conversation_cache[phone] = {'last_active': time.time(), 'memory': memory}
        except Exception:
            pass
    
    @classmethod
    def update_memory(cls, phone: str, user_message: str, bot_response: str, 
                      entities: Optional[Dict] = None, intent: Optional[str] = None,
                      save_to_db: bool = True) -> Dict:
        memory = cls.get_client_memory(phone)

        conversation = memory.get("conversation", [])

        last_user_messages = memory.get("last_user_messages", [])

        try:
            if isinstance(user_message, str) and user_message.strip():
                um_low = user_message.strip().lower()
                termination_phrases = [
                    'gracias', 'es todo', 'eso es todo', 'eso sería todo', 'no, gracias', 'no gracias',
                    'listo', 'está bien', 'esta bien', 'perfecto', 'adiós', 'adios', 'chao', 'chau',
                    'hasta luego', 'hasta la próxima'
                ]
                for t in termination_phrases:
                    if um_low == t or um_low.startswith(t + ' ') or um_low.endswith(' ' + t) or (' ' + t + ' ') in (' ' + um_low + ' '):
                        try:
                            memory = cls.reset_memory(phone, notify=False)
                        except Exception:
                            pass
                        return memory
        except Exception:
            pass

        turn = {
            "user_message": user_message,
            "bot_response": bot_response,
            "timestamp": datetime.now().isoformat()
        }

        if entities:
            turn["entities"] = entities

        if intent:
            turn["intent"] = intent

        conversation.append(turn)
        if len(conversation) > MAX_CONVERSATION_TURNS:
            conversation = conversation[-MAX_CONVERSATION_TURNS:]

        try:
            if isinstance(user_message, str) and user_message.strip():
                last_user_messages.append(user_message.strip())
        except Exception:
            pass

      
        try:
            if len(last_user_messages) > 20:
                new_mem = cls.reset_memory(phone, notify=True)
                new_mem['conversation'] = [turn]
                new_mem['last_user_messages'] = [user_message.strip()] if isinstance(user_message, str) else []
                new_mem['last_updated'] = datetime.now().isoformat()

                cls._conversation_cache[phone] = {
                    'last_active': time.time(),
                    'memory': new_mem
                }

                if save_to_db:
                    try:
                        cls._save_to_mongodb(phone, new_mem)
                    except Exception:
                        pass

                return new_mem
        except Exception:
            pass

        if len(last_user_messages) > 20:
            last_user_messages = last_user_messages[-20:]

        memory["conversation"] = conversation
        memory["last_user_messages"] = last_user_messages
        memory["last_updated"] = datetime.now().isoformat()

        cls._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": memory
        }

        try:
            cls._update_context_summary(memory)
        except Exception:
            pass

        if save_to_db:
            cls._save_to_mongodb(phone, memory)

        return memory
    
    @classmethod
    def update_client_preferences(cls, phone: str, preferences: Dict, save_to_db: bool = True) -> Dict:
        
        memory = cls.get_client_memory(phone)
        
        current_preferences = memory.get("preferences", {})
        current_preferences.update(preferences)
        memory["preferences"] = current_preferences
        
        memory["last_updated"] = datetime.now().isoformat()
        
        cls._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": memory
        }
        
        if save_to_db:
            cls._save_to_mongodb(phone, memory)
            
            if db:
                try:
                    db.clientes.update_one(
                        {"telefono": phone},
                        {"$set": {"preferences": current_preferences}}
                    )
                except Exception as e:
                    print(f"Error actualizando preferencias en colección clientes: {e}")
        
        return memory
    
    @classmethod
    def add_entity_to_memory(cls, phone: str, entity_type: str, entity_value: Any, save_to_db: bool = True) -> Dict:
        
        memory = cls.get_client_memory(phone)
        
        entities = memory.get("entities", {})
        entities[entity_type] = entity_value
        memory["entities"] = entities
        
        memory["last_updated"] = datetime.now().isoformat()
        
        cls._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": memory
        }
        
        if save_to_db:
            cls._save_to_mongodb(phone, memory)
        
        return memory
    
    @classmethod
    def get_conversation_summary(cls, phone: str) -> str:
        memory = cls.get_client_memory(phone)
        conversation = memory.get("conversation", [])
        
        if not conversation:
            return ""
        
        summary_parts = []
        
        turns = []
        for i, turn in enumerate(conversation[-5:]):  # Últimas 5 interacciones
            turn_text = f"Usuario: {turn['user_message']}\nBot: {turn['bot_response']}"
            turns.append(turn_text)
        
        if turns:
            summary_parts.append("CONVERSACIÓN RECIENTE:\n" + "\n\n".join(turns))
        
        if "entities" in memory and memory["entities"]:
            entities_text = []
            for key, value in memory["entities"].items():
                entities_text.append(f"{key}: {value}")
            
            if entities_text:
                summary_parts.append("INFORMACIÓN DETECTADA:\n" + "\n".join(entities_text))
        
       
        if "preferences" in memory and memory["preferences"]:
            prefs_text = []
            for key, value in memory["preferences"].items():
                prefs_text.append(f"{key}: {value}")
            
            if prefs_text:
                summary_parts.append("PREFERENCIAS DEL CLIENTE:\n" + "\n".join(prefs_text))
        
        return "\n\n".join(summary_parts)
    
    @classmethod
    def reset_memory(cls, phone: str, notify: bool = False, preserve_selected_course: bool = True) -> Dict:
       
        try:
            current = cls.get_client_memory(phone)
        except Exception:
            current = {}

        preserved = {}
        try:
            if preserve_selected_course and isinstance(current, dict):
                ctx = current.get('context') or {}
                for k in ['selected_course', 'selected_product', 'selected_webinar']:
                    if k in ctx and ctx.get(k):
                        preserved[k] = ctx.get(k)
        except Exception:
            preserved = {}

        new_context = preserved if preserved else {}

        empty_memory = {
            "conversation": [],
            "entities": {},
            "preferences": {},
            "context": new_context,
            "last_updated": datetime.now().isoformat()
        }

        cls._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": empty_memory
        }

        try:
            cls._save_to_mongodb(phone, empty_memory)
        except Exception:
            pass

        return empty_memory
    
    @classmethod
    def _load_from_mongodb(cls, phone: str) -> Dict:
       
        if not db_connected:
            return cls._create_empty_memory()
        
        try:
            memory_doc = db.conversation_memories.find_one({"phone": phone})

            if memory_doc:
                # Use bson.json_util to safely convert BSON to JSON-serializable types
                try:
                    dumped = json_util.dumps(memory_doc)
                    sanitized = json.loads(dumped)
                except Exception:
                    # Fallback: shallow copy with simple conversions
                    sanitized = {}
                    for k, v in memory_doc.items():
                        if k == '_id':
                            try:
                                sanitized['id'] = str(v)
                            except Exception:
                                sanitized['id'] = v
                        else:
                            try:
                                # ObjectId -> str
                                if isinstance(v, ObjectId):
                                    sanitized[k] = str(v)
                                else:
                                    sanitized[k] = v
                            except Exception:
                                sanitized[k] = v

                # Ensure no internal _id remains
                if isinstance(sanitized, dict):
                    sanitized.pop('_id', None)

                return sanitized
            
            memory = cls._create_empty_memory()
            
            cliente = db.clientes.find_one({"telefono": phone})
            if cliente:
                if "interesPrincipal" in cliente and cliente["interesPrincipal"]:
                    memory["preferences"]["interes"] = cliente["interesPrincipal"]
                
                if "nombreCompleto" in cliente and cliente["nombreCompleto"]:
                    memory["entities"]["nombre"] = cliente["nombreCompleto"]
                elif "personaContacto" in cliente and cliente["personaContacto"]:
                    memory["entities"]["nombre"] = cliente["personaContacto"]
            
            return memory
            
        except Exception as e:
            print(f"Error cargando memoria desde MongoDB: {e}")
            return cls._create_empty_memory()
    
    @classmethod
    def _save_to_mongodb(cls, phone: str, memory: Dict) -> None:
        if not db_connected:
            return
        
        try:
            memory["phone"] = phone
            
            db.conversation_memories.update_one(
                {"phone": phone},
                {"$set": memory},
                upsert=True
            )
        except Exception as e:
            print(f"Error guardando memoria en MongoDB: {e}")
    
    @classmethod
    def _create_empty_memory(cls) -> Dict:
       
        return {
            "conversation": [],
            "entities": {},
            "preferences": {},
            "last_updated": datetime.now().isoformat()
        }

    @classmethod
    def _reset_conversation_preserve_context(cls, phone: str, memory: Dict = None) -> Dict:
        try:
            if memory is None:
                memory = cls._load_from_mongodb(phone)

            # Preserve selected context keys
            preserved_context = {}
            ctx = memory.get('context', {}) or {}
            for k in ['selected_course', 'last_listed_courses', 'advisor_course_id', 'waiting_for_advisor_data', 'advisor_data']:
                if k in ctx:
                    preserved_context[k] = ctx[k]

            memory['conversation'] = []
            memory['last_user_messages'] = []
            memory['entities'] = memory.get('entities', {}) or {}
            memory['preferences'] = memory.get('preferences', {}) or {}
            memory['context'] = preserved_context if preserved_context else {}
            memory['last_updated'] = datetime.now().isoformat()
            memory.pop('conversation_finished', None)
            memory.pop('conversation_finished_at', None)

            try:
                cls._save_to_mongodb(phone, memory)
            except Exception:
                pass

            cls._conversation_cache[phone] = {
                'last_active': time.time(),
                'memory': memory
            }

            return memory
        except Exception as e:
            print(f"Error resetting conversation while preserving context for {phone}: {e}")
            return memory or {}
    
    @classmethod
    def _clean_expired_cache(cls) -> None:
       
        now = time.time()
        phones_to_remove = []
        
        for phone, data in cls._conversation_cache.items():
            if now - data["last_active"] > CACHE_EXPIRY:
                phones_to_remove.append(phone)
        
        for phone in phones_to_remove:
            del cls._conversation_cache[phone]

    @classmethod
    def _update_context_summary(cls, memory: Dict) -> None:
        conversation = memory.get('conversation', []) or []
        if not conversation:
            return

        summary_lines = []
        for turn in conversation[-6:]:
            user = turn.get('user_message')
            bot = turn.get('bot_response')
            if user:
                summary_lines.append(f"U: {user[:120]}")
            if bot:
                summary_lines.append(f"B: {bot[:120]}")

        summary = "\n".join(summary_lines[-12:])
        if "context" not in memory:
            memory["context"] = {}
        memory["context"]["conversation_summary"] = summary


def get_conversation_history(phone: str) -> Dict:
    memory = ConversationMemory.get_client_memory(phone)
    conversation = memory.get('conversation', [])
    limited_conversation = conversation[-min(MAX_CONVERSATION_TURNS, 20):] if conversation else []
    return limited_conversation


def reset_conversation_history(phone: str) -> None:
    return ConversationMemory.reset_memory(phone)


def save_selected_course(phone: str, course_id: int, course_name: str, course_details: dict = None) -> bool:
    """
    Guarda información sobre el curso seleccionado por el usuario en su contexto de conversación.
    """
    try:
        memory = ConversationMemory.get_client_memory(phone)
        
        # Crear o actualizar el contexto de curso seleccionado
        if "context" not in memory or memory["context"] is None:
            memory["context"] = {}

        # Normalizar id como string para comparaciones consistentes
        try:
            cid = str(course_id) if course_id is not None else None
        except Exception:
            cid = course_id

        selected_obj = {
            "id": cid,
            "name": course_name,
            "nombre": course_name,
            "selected_at": datetime.now().isoformat(),
            "details": course_details or {}
        }

        # Guardar selected_course
        memory["context"]["selected_course"] = selected_obj

        # Guardar también current_item canónico para priorizar respuestas por contexto
        memory["context"]["current_item"] = {
            "type": "course",
            "id": cid,
            "name": course_name,
            "data": course_details or {},
            "timestamp": datetime.now().isoformat()
        }

        # Establecer topic actual
        memory["context"]["current_topic"] = "course"

        # Evitar ambigüedad: eliminar selecciones de otros tipos
        memory["context"].pop("selected_product", None)
        memory["context"].pop("selected_webinar", None)

        memory["last_updated"] = datetime.now().isoformat()

        # Persistir cambios y actualizar caché
        try:
            ConversationMemory._save_to_mongodb(phone, memory)
        except Exception:
            pass
        ConversationMemory._conversation_cache[phone] = {"last_active": time.time(), "memory": memory}

        print(f"Curso seleccionado guardado para {phone}: Curso {cid} - {course_name}")
        return True
    except Exception as e:
        print(f"Error al guardar curso seleccionado: {e}")
        return False

def get_selected_course(phone: str) -> dict:
    """
    Obtiene información sobre el curso seleccionado por el usuario.
    """
    try:
        memory = ConversationMemory.get_client_memory(phone)
        
        if "context" in memory and "selected_course" in memory["context"]:
            return memory["context"]["selected_course"]
            
        return None
    except Exception as e:
        print(f"Error al obtener curso seleccionado: {e}")
        return None

def clear_selected_course(phone: str) -> bool:
    """
    Limpia la información del curso seleccionado por el usuario.
    """
    try:
        memory = ConversationMemory.get_client_memory(phone)
        
        if "context" in memory and "selected_course" in memory["context"]:
            del memory["context"]["selected_course"]
            ConversationMemory._save_to_mongodb(phone, memory)
            print(f"Curso seleccionado eliminado para {phone}")
            return True
            
        return False
    except Exception as e:
        print(f"Error al limpiar curso seleccionado: {e}")
        return False

def clear_conversation_memory(phone: str) -> None:
    """
    Limpia completamente la memoria de conversación del usuario, 
    eliminando todos los datos y estados.
    """
    try:
        # Primero, limpiamos la caché
        if phone in ConversationMemory._conversation_cache:
            del ConversationMemory._conversation_cache[phone]
        
        # Luego, eliminamos los datos de MongoDB
        if db_connected:
            conversation_collection = db['conversations']
            conversation_collection.delete_one({"_id": phone})
            print(f"Memoria de conversación completamente eliminada para {phone}")
        
        # Inicializar con un nuevo estado limpio
        empty_memory = {
            "conversation": [],
            "entities": {},
            "preferences": {},
            "context": {},
            "last_updated": datetime.now().isoformat(),
            "waiting_for_advisor_data": False,
            "advisor_data": None,
            "advisor_course_id": None,
            "last_action": None
        }
        
        # Guardar el estado limpio
        ConversationMemory._conversation_cache[phone] = {
            "last_active": time.time(),
            "memory": empty_memory
        }
        
        if db_connected:
            conversation_collection.insert_one({"_id": phone, **empty_memory})
            
        return True
    except Exception as e:
        print(f"Error al eliminar memoria de conversación: {e}")
        return False

def clear_topic_context(phone: str, preserve_selected_course: bool = True) -> bool:
    memory = ConversationMemory.get_client_memory(phone)
    conversation = memory.get("conversation", [])
    
    # Guardar cualquier selección (curso/producto/webinar) si existe y queremos preservarlo
    preserved = {}
    if preserve_selected_course and "context" in memory:
        for k in ['selected_course', 'selected_product', 'selected_webinar']:
            if k in memory['context'] and memory['context'].get(k):
                preserved[k] = memory['context'][k]
                try:
                    name = memory['context'][k].get('name') or memory['context'][k].get('title')
                    print(f"Preservando {k} para {phone}: {name}")
                except Exception:
                    pass
    
    if not conversation:
        if not preserve_selected_course:
            if "context" in memory:
                removed_any = False
                for k in ['selected_course', 'selected_product', 'selected_webinar']:
                    if k in memory['context']:
                        try:
                            del memory['context'][k]
                            removed_any = True
                        except Exception:
                            pass
                if removed_any:
                    ConversationMemory._save_to_mongodb(phone, memory)
                    print(f"Contexto temático reseteado (sin historial) para {phone} y selecciones eliminadas")
                    return True
        return False

    # Si tenemos historial de conversación
    if conversation:
        # Mantener solo el último mensaje del usuario para preservar la pregunta actual
        last_user_message = ""
        for turn in reversed(conversation):
            if 'user_message' in turn and turn['user_message']:
                last_user_message = turn['user_message']
                break
        
        new_conversation = [{
            "user_message": "CAMBIO_DE_TEMA",
            "bot_response": "CAMBIO_DE_TEMA_DETECTADO. Estoy listo para hablar de un nuevo tema.",
            "timestamp": datetime.now().isoformat(),
            "system_note": "El sistema ha detectado un cambio de tema y ha reseteado el contexto. El asistente debe responder a la pregunta actual sin referencia a conversaciones anteriores y sin mencionar cursos a menos que el usuario los solicite explícitamente."
        }]
        
        if last_user_message:
            new_conversation.append({
                "user_message": last_user_message,
                "bot_response": "",  
                "timestamp": datetime.now().isoformat()
            })
        
        memory["conversation"] = new_conversation
        
        if not preserve_selected_course:
            if "context" in memory:
                for k in ['selected_course', 'selected_product', 'selected_webinar']:
                    if k in memory['context']:
                        try:
                            del memory['context'][k]
                        except Exception:
                            pass
        else:
            if preserved:
                if "context" not in memory:
                    memory["context"] = {}
                for k, v in preserved.items():
                    memory['context'][k] = v
                    try:
                        name = v.get('name') or v.get('title')
                        print(f"{k} restaurado para {phone}: {name}")
                    except Exception:
                        pass
        
        ConversationMemory._save_to_mongodb(phone, memory)
        print(f"Contexto temático reseteado agresivamente para {phone}")
        return True
    
    return False