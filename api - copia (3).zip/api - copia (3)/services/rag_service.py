"""Retrieval helpers for intent-driven responses."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional

from utils import json_catalog


@dataclass
class RetrievedChunk:
    chunk_id: str
    content: str
    score: float
    metadata: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["score"] = float(max(0.0, min(1.0, self.score)))
        return data


def retrieve_context(query: str, intent: str, limit: int = 4, filter_types: Optional[List[str]] = None) -> List[RetrievedChunk]:
    """Select top catalog snippets for the provided intent.

    filter_types: optional list of domain types to include (e.g. ['course','product','webinar','doc_tecnico']).
    When provided, the function will prefer items whose metadata.type is in filter_types.
    """
    lower_intent = intent or ""
    chunks: List[RetrievedChunk] = []
    filter_types = filter_types or []

    if lower_intent == "catalogo_curso":
        # prefer filtered search when asking for courses
        items = json_catalog.search_courses_by_text(query, limit=limit) or json_catalog.load_courses()[:limit]
        # if filter_types provided and does not include 'course', return empty
        if filter_types and 'course' not in filter_types and 'curso' not in filter_types:
            return []
        for item in items:
            meta = {"type": "course", "id": item.get("id"), "name": item.get("nombre")}
            content = _format_course_fact(item)
            chunks.append(RetrievedChunk(f"course::{item.get('id')}", content, 0.85, meta))

    elif lower_intent == "catalogo_producto":
        items = json_catalog.search_products_by_text(query, limit=limit) or json_catalog.load_products()[:limit]
        if filter_types and 'product' not in filter_types and 'producto' not in filter_types:
            return []
        for item in items:
            meta = {"type": "product", "id": item.get("id"), "name": item.get("nombre")}
            content = _format_product_fact(item)
            chunks.append(RetrievedChunk(f"product::{item.get('id')}", content, 0.82, meta))

    elif lower_intent == "catalogo_webinar":
        items = json_catalog.search_webinars_by_text(query, limit=limit) or json_catalog.load_webinars()[:limit]
        if filter_types and 'webinar' not in filter_types:
            return []
        for item in items:
            meta = {"type": "webinar", "id": item.get("id") or item.get("title"), "name": item.get("title")}
            content = _format_webinar_fact(item)
            chunks.append(RetrievedChunk(f"webinar::{meta['id']}", content, 0.80, meta))

    else:
        # For qa_tecnico and generic intents we do not have a structured corpus yet.
        # Return empty list to let the LLM rely on conversation context.
        return []

    return chunks[:limit]


def format_chunks_for_prompt(chunks: List[RetrievedChunk]) -> str:
    if not chunks:
        return ""
    lines = ["# CONTEXTO CATALOGADO"]
    for idx, chunk in enumerate(chunks, start=1):
        meta = chunk.metadata
        label = f"{meta.get('type','data').upper()} {meta.get('id','')}: {meta.get('name','')}".strip()
        lines.append(f"[[{idx}]] {label}\n{chunk.content}\n")
    return "\n".join(lines)


def _format_course_fact(item: Dict[str, Any]) -> str:
    lines = []
    if item.get("descripcion"):
        lines.append(item["descripcion"])
    if item.get("precio"):
        lines.append(f"Precio: {item['precio']}")
    if item.get("duracion"):
        lines.append(f"Duracion: {item['duracion']}")
    if item.get("proximas_fechas"):
        fechas = []
        for entry in item.get("proximas_fechas") or []:
            if isinstance(entry, dict):
                fecha = entry.get("fecha")
                horario = entry.get("horario")
                if fecha and horario:
                    fechas.append(f"- {fecha} / {horario}")
                elif fecha:
                    fechas.append(f"- {fecha}")
            elif isinstance(entry, str):
                fechas.append(f"- {entry}")
        if fechas:
            lines.append("Fechas:\n" + "\n".join(fechas))
    if item.get("nodos"):
        lines.append("Nodos: " + ", ".join(item.get("nodos")))
    return "\n".join(lines)


def _format_product_fact(item: Dict[str, Any]) -> str:
    lines = []
    if item.get("descripcion"):
        lines.append(item["descripcion"])
    if item.get("precio"):
        lines.append(f"Precio: {item['precio']}")
    if item.get("especificaciones"):
        for spec in item.get("especificaciones") or []:
            lines.append(f"- {spec}")
    return "\n".join(lines)


def _format_webinar_fact(item: Dict[str, Any]) -> str:
    lines = []
    if item.get("description"):
        lines.append(item["description"])
    if item.get("fechas"):
        lines.append("Fechas: " + ", ".join(item.get("fechas")))
    if item.get("horario"):
        if isinstance(item.get("horario"), list):
            lines.append("Horarios: " + ", ".join(item.get("horario")))
        else:
            lines.append(f"Horario: {item.get('horario')}")
    if item.get("topics"):
        lines.append("Temas: " + ", ".join(item.get("topics")))
    return "\n".join(lines)
