"""
Servicio para generar PDFs y notificar a asesores.

Este módulo gestiona la generación de PDFs con información de clientes
y su envío a los asesores correspondientes vía WhatsApp.
"""

import os
import logging
import tempfile
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from services.ml_service import ml_service, PDFGenerator

# Configura logging
logger = logging.getLogger("notification_service")
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Asesores disponibles por categoría
ADVISORS = {
    'default': '4442136200',  
    'soporte_tecnico': '4442136200',
    'ventas': '4442136200',
    'cotizacion': '4442136200',
    'cursos': '4442136200',
}

class NotificationService:
    """
    Servicio para manejar notificaciones a asesores y generación de PDFs.
    """
    def __init__(self):
        self.pdf_generator = PDFGenerator()
    
    def generate_client_profile(self, 
                               client_data: Dict[str, str], 
                               classification_info: Dict[str, Any],
                               conversation_history: Optional[List[Dict[str, Any]]] = None) -> str:
        """
        Genera un PDF con la información del cliente.
        
        """
        if conversation_history:
            lead_info = ml_service.lead_predictor.predict_lead_type(conversation_history)
            client_data['lead_type'] = lead_info.get('lead_type', 'neutro')
            
            # Si no hay segmento, intentar predecirlo
            if 'segmento' not in client_data and ('empresa' in client_data or 'web' in client_data):
                client_data['mensajes'] = ' '.join([
                    msg.get('text', '') for msg in conversation_history 
                    if msg.get('from_client', True)
                ])
                client_data['segmento'] = ml_service.extractor.predict_segment(client_data)
        
        # Generar PDF
        pdf_path = ml_service.generate_client_pdf(client_data, classification_info)
        logger.info(f"PDF generado: {pdf_path}")
        
        return pdf_path
    
    def get_advisor_for_category(self, category: str) -> str:
        """
        Devuelve el número de teléfono del asesor correspondiente a una categoría.
        
        """
        return ADVISORS.get(category, ADVISORS['default'])
    
    def send_notification_to_advisor(self, 
                                    phone_number: str, 
                                    pdf_path: str, 
                                    summary: str) -> bool:
        """
        Envía una notificación con el PDF a un asesor vía WhatsApp.
        
        """
        try:
            from utils.whatsapp import send_document_to_phone
            
            # Enviar documento
            result = send_document_to_phone(
                phone_number, 
                pdf_path,
                caption=summary
            )
            
            logger.info(f"Notificación intentada a {phone_number}: {result}")
            return bool(result)
            
        except Exception as e:
            logger.error(f"Error enviando notificación a {phone_number}: {e}")
            return False
    
    def process_client_notification(self,
                                   client_phone: str,
                                   ml_results: Dict[str, Any],
                                   conversation_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Procesa los resultados de ML para enviar notificaciones a los asesores
        cuando sea necesario.
        
        """
        results = {
            'notification_sent': False,
            'reason': '',
            'advisor': '',
            'pdf_path': ''
        }
        
        classification = ml_results.get('classification', {})
        client_data = ml_results.get('client_data', {})
        requires_human = ml_results.get('requires_human_attention', False)
        
        # Incluir el número de teléfono en los datos del cliente
        client_data['telefono'] = client_phone
        
        # Determinar si es necesario enviar notificación
        category = classification.get('category', '')
        lead_type = ml_results.get('lead_prediction', {}).get('lead_type', 'neutro')
        
        notification_needed = False
        reason = ''
        
        # Verificar las condiciones para enviar una notificación
        if requires_human:
            notification_needed = True
            reason = 'Requiere atención humana según clasificación'
        elif lead_type == 'caliente' and ml_results.get('lead_prediction', {}).get('confidence', 0) > 0.7:
            notification_needed = True
            reason = 'Lead caliente detectado'
        elif category in ['cotizacion', 'contacto_asesor']:
            notification_needed = True
            reason = f'Solicitud de categoría: {category}'
            
        if not notification_needed:
            results['reason'] = 'No se requiere notificación'
            return results
        
       
        critical_fields = ['nombre', 'correo']
        missing = [f for f in critical_fields if not client_data.get(f)]
        if category == 'contacto_asesor' and missing:
            results['reason'] = f'Faltan datos críticos: {missing}'
            results['notification_sent'] = False
            results['pdf_path'] = ''
            results['missing_fields'] = missing
            return results

        # Evitar generación de PDFs duplicados en un corto lapso: comprobar colección advisor_notifications
        from data.db import get_collection
        notif_collection = get_collection('advisor_notifications')
        # Crear un identificador por teléfono y categoría para deduplicar en ventana de 5 minutos
        dedup_id = f"{client_phone}_{category}"
        five_minutes_ago = datetime.now() - timedelta(minutes=5)
        if notif_collection.find_one({"dedup_id": dedup_id, "timestamp": {"$gte": five_minutes_ago}}):
            results['reason'] = 'Notificación reciente ya enviada, evitando duplicado'
            results['notification_sent'] = True
            results['advisor'] = self.get_advisor_for_category(category)
            # intentar devolver el último pdf_path conocido
            last = notif_collection.find_one({"dedup_id": dedup_id}, sort=[('timestamp', -1)])
            results['pdf_path'] = last.get('pdf_path') if last else ''
            return results

        # Generar PDF con la información del cliente
        pdf_path = self.generate_client_profile(client_data, classification, conversation_history)
        
        # Determinar asesor según categoría
        advisor_phone = self.get_advisor_for_category(category)
        
        # Crear resumen para enviar al asesor
        summary = self._generate_advisor_summary(client_data, ml_results, client_phone)
        
        # Enviar notificación
        sent = self.send_notification_to_advisor(advisor_phone, pdf_path, summary)

        # Actualizar resultados
        results['notification_sent'] = bool(sent)
        results['reason'] = reason
        results['advisor'] = advisor_phone
        results['pdf_path'] = pdf_path
        
        return results
    
    def _generate_advisor_summary(self,
                                client_data: Dict[str, str],
                                ml_results: Dict[str, Any],
                                client_phone: str) -> str:
        """
        Genera un texto resumido para enviar al asesor junto con el PDF.
        """
        category = ml_results.get('classification', {}).get('category', 'No clasificada').replace('_', ' ').title()
        lead_type = ml_results.get('lead_prediction', {}).get('lead_type', 'neutro').title()
        
        client_name = client_data.get('nombre', 'Cliente')
        company = client_data.get('empresa', 'No especificada')
        
        summary = f"🔔 *ALERTA DE CLIENTE PRIORITARIO*\n\n"
        summary += f"👤 *Cliente:* {client_name}\n"
        summary += f"🏢 *Empresa:* {company}\n"
        summary += f"📱 *Teléfono:* {client_phone}\n"
        summary += f"📊 *Categoría:* {category}\n"
        summary += f"🔥 *Tipo de Lead:* {lead_type}\n\n"
        
        if client_data.get('segmento'):
            summary += f"🏆 *Segmento:* {client_data['segmento']}\n\n"
        if client_data.get('necesidad'):
            summary += f"📝 *Necesidad:* {client_data.get('necesidad')}\n\n"
            
        summary += "Te adjunto el PDF con todos los detalles del cliente. Por favor, contáctalo a la brevedad posible."
        
        return summary


notification_service = NotificationService()