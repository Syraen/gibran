import os
import re
import json 
from typing import Optional, Dict, List, Tuple 

class WebinarService: 
    def __init__(self, webinars_json_path: Optional[str] = None):
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        default = os.path.join(base_dir, 'splitbot.webinars.json')
        self.webinars_json_path = webinars_json_path or default
        self.webinars: List[Dict] = self._load_webinars()

    def _load_webinars(self) -> List[Dict]: 
        try: 
            with open(self.webinars_json_path, 'r', encoding='utf-8') as f: 
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception: 
            return []
        
    def detect_webinar(self, text: str) -> Optional[str]: 
        if not text:
            return None
        q = (text or '').lower()

        #buscar titulo 
        tokens_q = [t for t in re.findall(r"[\w\u00C0-\u017F]+", q) if len(t) >= 3]
        best: Tuple[Optional[Dict], int] = (None, 0)
        for w in self.webinars: 
            title = (w.get('title') or '').lower()
            ntokens = [t for t in re.findall(r"[\w\u00C0-\u017F]+", title) if len(t) >= 3]
            score = sum(1 for t in tokens_q if t in ntokens or t in title)
            if score > best[1]:
                best = (w, score)
                return best[0] if best[1] >= 1 else None
            
    def detect_attribute(self, text: str) -> str: 
        q = (text or '').lower()
        if any(k in q for k in ['descripcion', 'describe', ]):
            return 'description'
        if any(k in q for k in['tema', 'temas']):
            return 'topic'
        if any(k in q for k in['fechas', 'dias', 'dia', 'fecha']):
            return 'fechas'
        if any(k in q for k in['hora', 'horario', 'horarios']):
            return 'horario'
        if any(k in q for k in['link', 'enlce', 'url']):
            return 'link'
        return 'all'
    
    def build_attribute_response(self, w: Dict, attr: str) -> str: 
        title = w.get('title') or 'webinar'
        if attr == 'description': 
            return f"Descripción de {title}: {w.get('description', 'Sin descripción')}"
        if attr == 'topics':
            tops = w.get('topics') or []
            if not tops: 
                return f"{title} no tiene temas listados"
            return f"Temas de {title}:\n" + '\n'.join(f"- {t}" for t in tops)
        if attr == 'fechas':
            fechas = w.get('fechas') or []
            if not fechas: 
                return f"No fechas proximas para {title}"
            return f"Fechas de {title}:\n" + '\n'.join(f"- {f}" for f in fechas if f)
        if attr == 'horario': 
            horario = w.get('horario') or []
            if isinstance(horario, list):
                return f"Hoario de {title}: {', '.join(horario)}"
            return f"Horario de {title}: {horario}"
        if attr == 'link': 
            return f"Enlace de {title}: {w.get('link', 'No disponible')}"
        
        parts = [title]
        if w.get('description'):
            parts.append(f"Descripción: {w.get('description')}")
        if w.get('topics'):
            parts.append('Temas:')
            for t in w.get('topics'):
                parts.append(f"- {t}")
        if w.get('fechas'):
            parts.append('Fechas:')
            for f in w.get('fechas'):
                if f:
                    parts.append(f"- {f}")
        if w.get('horario'):
            parts.append('Horario: ' + (', '.join(w.get('horario')) if isinstance(w.get('horario'), list) else str(w.get('horario'))))
        if w.get('link'):
            parts.append(f"Link: {w.get('link')}")
        return '\n'.join(parts)
            
    def handle_message(self, message: str) -> Optional[str]: 
        if not message: 
            return None
        w = self.detect_webinar(message)
        if not w: 
            return None 
        attr = self.build_attribute(message)
        return self.build_attribute_response(w, attr)
    
webinar_service = WebinarService()

def get_webinar_response(message: str) -> Optional[str]:
    return webinar_service.handle_message(message)