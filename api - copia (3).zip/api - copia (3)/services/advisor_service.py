"""
Servicio para manejar las notificaciones a asesores, inspirado en la estructura de advisorServices.js
"""
import logging
import os
import json
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

logger = logging.getLogger(__name__)

# Número de teléfono del asesor por defecto (se puede sobreescribir con una variable de entorno)
ADVISOR_PHONE = os.environ.get('ADVISOR_PHONE', '')

def build_advisor_message(request_type: str, user_name: str, user_phone: str, details: Dict[str, Any] = None) -> str:
    """
    Construye un mensaje con los datos obtenidos para enviar al asesor.
    
    """
    lines = []
    lines.append('🔔 NOTIFICACIÓN ASESOR')
    lines.append(f'• Motivo: {request_type}')
    lines.append(f'• Usuario: {user_name or "Sin nombre"}')
    lines.append(f'• Teléfono contacto: {user_phone}')
    
    if details and len(details) > 0:
        lines.append('• Detalles proporcionados:')
        for key, value in details.items():
            lines.append(f'   - {key}: {value}')
    
    lines.append('')
    lines.append('Contacta con el usuario.')
    return '\n'.join(lines)

def normalize_phone_number(phone: str) -> List[str]:
    """
    Normaliza un número de teléfono y genera variantes para intentar el envío.
    

    """
    # Eliminar caracteres no numéricos excepto '+'
    base = ''.join(c for c in phone if c.isdigit() or c == '+')
    
    variants = set()
    if base:
        variants.add(base)
        variants.add(base[1:] if base.startswith('+') else f'+{base}')
        
        no_plus = base.replace('+', '')
        if not no_plus.startswith('521') and len(no_plus) >= 10:
            variants.add(f'521{no_plus}')
            variants.add(f'+521{no_plus}')
    else:
        #variants.add('+5214442136200')
        variants.add( '5214427843528')
        #variants.add('4442136200')
    
    return list(variants)

def notify_advisor(
    user_phone: str, 
    request_type: str = 'asesor', 
    user_name: str = None, 
    details: Dict[str, Any] = None, 
    advisor_phone: str = None,
    pdf_path: str = None
) -> Dict[str, Any]:
    """
    Notifica al asesor sobre la solicitud de un cliente.
    
    """
    try:
        if not user_phone:
            raise ValueError("userPhone es requerido")
        
        message = build_advisor_message(request_type, user_name, user_phone, details or {})
        
        # Normalizar número del asesor y preparar variantes para reintento
        configured = advisor_phone if advisor_phone else ADVISOR_PHONE
        variants = normalize_phone_number(configured)
        
        logger.info(f"[AdvisorService] Intentando notificar al asesor (variantes: {', '.join(variants)}) motivo={request_type} usuario={user_phone}")
        
        # Importar aquí para evitar dependencia circular
        from utils.whatsapp import send_text_message, send_document_to_phone
        
        last_error = None
        for variant in variants:
            try:
                logger.info(f"[AdvisorService] Enviando notificación al asesor a: {variant}")
                res = send_text_message(variant, message)
                logger.info(f"[AdvisorService] Resultado sendText -> {json.dumps(res) if isinstance(res, dict) else str(res)}")
                
                if not res or (isinstance(res, dict) and res.get('error')):
                    last_error = res or {'error': True, 'message': 'Respuesta vacía'}
                    logger.warning(f"[AdvisorService] Falló envío a {variant}: {json.dumps(last_error) if isinstance(last_error, dict) else str(last_error)}")
                    continue  # Intentar siguiente variante
                
                # Si hay un PDF, enviarlo después del mensaje
                pdf_result = None
                if pdf_path and os.path.exists(pdf_path):
                    logger.info(f"[AdvisorService] Enviando PDF a: {variant}")
                    pdf_result = send_document_to_phone(variant, pdf_path, "Datos del cliente")
                    if not pdf_result:
                        logger.warning(f"[AdvisorService] Falló envío de PDF a {variant}")
                
                logger.info(f"[AdvisorService] Notificación enviada correctamente a {variant}")
                return {'success': True, 'result': {'message': res, 'pdf': pdf_result}, 'sent_to': variant, 'pdf_sent': bool(pdf_result)}
            except Exception as err:
                last_error = err
                logger.error(f"[AdvisorService] Excepción enviando a {variant}: {str(err)}")
        
        logger.error(f"[AdvisorService] No fue posible notificar al asesor. Último error: {str(last_error)}")
        return {'success': False, 'error': last_error}
        
    except Exception as error:
        logger.error(f"[AdvisorService] notify_advisor error: {str(error)}")
        return {'success': False, 'error': str(error)}

def notify_advisor_and_user(
    user_phone: str, 
    request_type: str = 'asesor', 
    user_name: str = None, 
    details: Dict[str, Any] = None, 
    advisor_phone: str = None,
    confirm_user: bool = True,
    pdf_path: str = None
) -> Dict[str, Any]:
    advisor_notification = notify_advisor(user_phone, request_type, user_name, details, advisor_phone, pdf_path)
    user_notification = None
    
    if confirm_user:
        try:
            from utils.whatsapp import send_text_message
            
            confirm_msg = f"Hemos notificado a un asesor. Pronto te contactarán al {user_phone}."
            user_notification = send_text_message(user_phone, confirm_msg)
        except Exception as err:
            logger.warning(f"[AdvisorService] No se pudo enviar confirmación al usuario: {str(err)}")
            user_notification = {'error': str(err)}
    
    return {'advisor': advisor_notification, 'user': user_notification}

def send_pdf_to_advisor(
    pdf_path: str,
    user_phone: str,
    user_name: str = None,
    segment: str = "Sin clasificar",
    request_type: str = "Solicitud de información",
    details: Dict[str, Any] = None,
    advisor_phone: str = None
) -> Dict[str, Any]:
    
    try:
        if not os.path.exists(pdf_path):
            logger.error(f"[AdvisorService] El archivo PDF no existe: {pdf_path}")
            # Intentar buscar el PDF más reciente en la carpeta pdfs como respaldo
            try:
                pdfs_dir = os.path.dirname(pdf_path)
                if os.path.exists(pdfs_dir):
                    pdf_files = [f for f in os.listdir(pdfs_dir) if f.endswith('.pdf')]
                    if pdf_files:
                        pdf_files.sort(reverse=True)
                        latest_pdf = os.path.join(pdfs_dir, pdf_files[0])
                        logger.info(f"[AdvisorService] Usando PDF alternativo más reciente: {latest_pdf}")
                        pdf_path = latest_pdf
                    else:
                        raise FileNotFoundError(f"No se encontraron PDFs en {pdfs_dir}")
                else:
                    raise FileNotFoundError(f"El directorio de PDFs no existe: {pdfs_dir}")
            except Exception as e:
                logger.error(f"[AdvisorService] Error buscando PDF alternativo: {e}")
                raise FileNotFoundError(f"El archivo PDF no existe y no se encontró alternativa")
            
        # Importar aquí para evitar dependencia circular
        from utils.whatsapp import send_text_message, send_document_to_phone
        
        # Primero enviar un mensaje de notificación
        message = (
            f"*NUEVA SOLICITUD DE CONTACTO*\n\n"
            f"👤 *Cliente:* {user_name or 'Sin nombre'}\n"
            f"📱 *Teléfono:* {user_phone}\n"
            f"📊 *Segmento:* {segment}\n"
            f"🔍 *Motivo:* {request_type}\n\n"
            f"Adjunto encontrarás el PDF con toda la información del prospecto."
        )
        
        # Normalizar número del asesor y preparar variantes para reintento
        configured = advisor_phone if advisor_phone else ADVISOR_PHONE
        variants = normalize_phone_number(configured)
        
        logger.info(f"[AdvisorService] Intentando enviar PDF al asesor (variantes: {', '.join(variants)})")
        
        # Verificar si el PDF existe y está accesible
        if not os.path.exists(pdf_path):
            logger.error(f"[AdvisorService] PDF no encontrado: {pdf_path}")
            
            # Intentar encontrar el PDF más reciente como fallback
            try:
                pdf_dir = os.path.dirname(pdf_path)
                if not os.path.exists(pdf_dir):
                    pdf_dir = os.path.join(os.getcwd(), 'pdfs')
                    
                if os.path.exists(pdf_dir):
                    pdf_files = [f for f in os.listdir(pdf_dir) if f.endswith('.pdf') and 'cliente_' in f]
                    
                    if pdf_files:
                        # Ordenar por fecha de creación, el más reciente primero
                        pdf_files.sort(key=lambda x: os.path.getctime(os.path.join(pdf_dir, x)), reverse=True)
                        latest_pdf = os.path.join(pdf_dir, pdf_files[0])
                        logger.info(f"[AdvisorService] Usando PDF alternativo más reciente: {latest_pdf}")
                        pdf_path = latest_pdf
                        
            except Exception as e:
                logger.error(f"[AdvisorService] Error al buscar PDF alternativo: {str(e)}")
        
        # Verificación final de PDF
        if not os.path.exists(pdf_path):
            return {'success': False, 'error': f'PDF no encontrado: {pdf_path}'}
        
        last_error = None
        # Usaremos un conjunto para evitar intentar números duplicados
        attempted_variants = set()
        
        for variant in variants:
            # Evitar intentar el mismo número más de una vez (podría ocurrir por normalización)
            if variant in attempted_variants:
                logger.info(f"[AdvisorService] Omitiendo variante duplicada: {variant}")
                continue
                
            attempted_variants.add(variant)
            
            try:
                logger.info(f"[AdvisorService] Enviando mensaje a: {variant}")
                msg_res = send_text_message(variant, message)
                
                logger.info(f"[AdvisorService] Enviando PDF a: {variant}, ruta: {pdf_path}")
                pdf_res = send_document_to_phone(variant, pdf_path, "Datos del prospecto")
                
                if pdf_res:
                    logger.info(f"[AdvisorService] PDF enviado correctamente a {variant}")
                    return {'success': True, 'result': {'message': msg_res, 'document': pdf_res}, 'sent_to': variant}
                else:
                    last_error = {'error': True, 'message': 'Fallo al enviar PDF'}
                    continue  # Intentar siguiente variante
            except Exception as err:
                last_error = err
                logger.error(f"[AdvisorService] Excepción enviando a {variant}: {str(err)}")
        
        logger.error(f"[AdvisorService] No fue posible enviar el PDF al asesor. Último error: {str(last_error)}")
        return {'success': False, 'error': last_error}
        
    except Exception as error:
        logger.error(f"[AdvisorService] send_pdf_to_advisor error: {str(error)}")
        return {'success': False, 'error': str(error)}

# Exportar como un objeto similar al advisorServices.js
advisor_service = {
    'notify_advisor': notify_advisor,
    'notify_advisor_and_user': notify_advisor_and_user,
    'build_advisor_message': build_advisor_message,
    'send_pdf_to_advisor': send_pdf_to_advisor
}