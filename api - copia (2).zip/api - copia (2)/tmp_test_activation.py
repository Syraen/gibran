from services.chat_ai import chat_with_gemini_two_pass

cases = [
    ("+521234000000","Redes de Fibra Óptica FTTH para WISP e ISP"),
    ("+521234000000","ftth para wisp"),
    ("+521234000000","curso id 3")
]

for phone, msg in cases:
    print('=== MESSAGE ===')
    print(msg)
    try:
        out = chat_with_gemini_two_pass(phone, msg)
        print('--- OUTPUT ---')
        print(out[:2000])
    except Exception as e:
        print('ERROR CALLING:', e)
    print('\n')
