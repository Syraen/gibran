"""
Módulo de gestión de cursos y procesamiento de información relacionada.

Este módulo contiene clases y funciones para manejar la información de cursos,
buscar PDFs relevantes y procesar consultas relacionadas con los cursos.
"""

import os
import re
import json
import logging
import datetime 
import spacy
from fpdf import FPDF
import requests
from urllib.parse import urlparse
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
from data.db import get_collection

# Configuración de logging
logger = logging.getLogger("courses")
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Palabras clave para identificar distintos tipos de consultas
COURSE_KEYWORDS = {
    "temario": [
        "temario", "programa del curso", "programa", "contenido del curso", 
        "pdf del curso", "información del curso", "temas del curso", 
        "syllabus", "contenido temático"
    ],
    "fechas": [
        "fecha", "cuando", "cuándo", "inicia", "empieza", "próximo", 
        "calendario", "agenda", "horario", "días", "mes"
    ],
    "precio": [
        "precio", "costo", "valor", "cuánto cuesta", "cuanto vale", 
        "inversión", "pago", "pesos", "mxn", "$", "usd", "dólares"
    ],
    "ubicacion": [
        "ubicación", "dirección", "lugar", "donde", "dónde", 
        "sede", "instalaciones", "presencial", "online", "virtual"
    ],
    "instructor": [
        "instructor", "profesor", "quien imparte", "quién da", 
        "experto", "maestro", "experiencia del instructor"
    ],
    "certificacion": [
        "certificado", "certificación", "diploma", "constancia", 
        "acreditación", "validez", "reconocimiento"
    ]
}

class CourseInfo: 
    """
    Encapsulamiento de los cursos y su informacion
    """

    def __init__(self, **kwargs): 

        #atributos basicos 
        self.id = kwargs.get('id')
        self.nombre = kwargs.get('nombre', '')
        self.nombre_corto = kwargs.get('nombre_corto', '')
        self.descripcion = kwargs.get('descripcion', '')

        #atributos especificos 
        self.duracion = kwargs.get('duracion', '')
        self.modalidad = kwargs.get('modalidad', '')
        
        #atributos de contenido 
        self.requisitos = kwargs.get('requisitos', [])
        self.objetivos = kwargs.get('objetivos', [])
        self.temario = kwargs.get('temario', [])

        #atributos de costos y fechas 
        self.precio = kwargs.get('precio', '')

        # Guardar precio en moneda local y una propiedad separada para precio en USD
        self.precio_usd = kwargs.get('precio_usd', '')
        self.proximas_fechas = kwargs.get('proximas_fechas', [])
        self.ubicacion = kwargs.get('ubicacion', '')

        #atributos adicionales 
        self.certificacion = kwargs.get('certificacion', '')
        self.metadata = kwargs.get('metadata', {})

    #Convertir a diccionario el atributo 
    def to_dict(self) -> Dict[str, Any]: 
        return  { 
            'id': self.id, 
            'nombre': self.nombre, 
            'nombre_corto': self.nombre_corto, 
            'descripcion': self.descripcion, 
            'duracion': self.duracion, 
            'modalidad': self.modalidad, 
            'requisitos': self.requisitos, 
            'objetivos': self.objetivos, 
            'temario': self.temario, 
            'precio': self.precio, 
            'precio_usd': self.precio_usd, 
            'proximas_fechas': self.proximas_fechas, 
            'ubicacion': self.ubicacion, 
            'certificacion': self.certificacion, 
            'metadata': self.metadata
        }
    
    @classmethod

    def from_dict(cls, data: Dict[str, Any]) -> 'CourseInfo': 
        return cls(**data)

    def get_formatted_temario(self) -> str:
        
        #Si no hay formato o esta vacio no mostrar nada
        if not self.temario:
            return ""
        
        #Si es una lista vacia no mostrar nada
        if isinstance(self.temario, list) and len(self.temario) == 0: 
            return ""
        
        #si hay un string vacion no mostrar nada 
        if isinstance(self.temario, str) and not self.temario.strip():
            return ""
        
        result = f"*TEMARIO DEL CURSO: {self.nombre.upper()}*\n\n"

        if isinstance(self.temario, list):
            for i, tema in enumerate(self.temario, 1):
                if isinstance(tema, dict) and 'titulo' in tema:
                    result += f"*{i}. {tema['titulo']}*\n"
                    if 'subtemas' in tema and isinstance(tema['subtemas'], list):
                        for j, subtema in enumerate(tema['subtemas'], 1):
                            result += f"   {i}.{j}. {subtema}\n"
                    result += "\n"
                else:
                    result += f"*{i}. {tema}*\n"
        elif isinstance(self.temario, str):
            result += self.temario
        
        return result
    
    """Da la info del precio/costo formateada"""
    def get_formatted_precio(self) -> str: 
        result = f"*EL precio del curso es: {self.nombre_corto or self.nombre}*\n\n"

        if self.precio: 
            result += f"Precio: {self.precio}\n"

        return result 
    
    def get_formatted_fechas(self) -> str: 
        """Da la info de las fechas"""
        result = f"Las Próximas fechas son: {self.nombre_corto or self.nombre}*\n\n"

        if self.proximas_fechas and isinstance(self.proximas_fechas, list): 
            for i, fecha_info in enumerate(self.proximas_fechas, 1): 
                if isinstance(fecha_info, dict):
                    fechas = fecha_info.get('fechas', '')
                    horario = fecha_info.get('horario', '')
                    modalidad = fecha_info.get('modalidad', self.modalidad)

                    result += f"*Opción {i}:*\n"
                    result += f"- Fecha: {fechas}\n"
                    if horario:  
                        result += f"- Horario: {horario}\n"
                    result += f"- Modalidad: {modalidad}\n"
                    result += "\n"
                else: 
                    result += f"- {fecha_info}\n"
        else: 
            result += "No hay fechas programadas actualmente.\n"

        return result 
    
    def get_formatted_ubicacion(self) -> str: 
        """Da la info de la ubi formateada"""
        result = f"La ubicación es: {self.nombre_corto or self.nombre}*\n\n"

        if self.modalidad.lower() == 'presencial' or self.modalidad.lower() == 'presencial': 
            result += "Este curso se imparte de manera presencial en el Parque Innovacion Queretaro, la ubicacion exacta te la proporcionara el asesor al momento de contactarlo.\n\n"
        elif self.ubicacion:
            result += f"{self.ubicacion}\n\n"
        else: 
            return result

    def get_formatted_informacion_completa(self) -> str:
        """Da la informacion completa""" 
        result = f"INFORMACION DEL CURSO: {self.nombre}*\n\n"

        #mostrar duracion
        if self.duracion: 
            result += f"*Duración:* {self.duracion}\n"

        #mostrar modalidad
        if self.modalidad: 
            result += f"*Modalidad:* {self.modalidad}\n"

        #mostrar los objetivos 
        if self.objetivos:
            if isinstance(self.objetivos, list) and len(self.objetivos) > 0 and any(obj for obj in self.objetivos if obj.strip()): 
                result += "\n*Objetivos:*\n"
                for obj in self.objetivos: 
                    if obj.strip(): 
                        result += f"- {obj}\n"
                result += "\n"
            elif isinstance(self.objetivos, str) and self.objetivos.strip(): 
                result += f"\n*Objetivos:* {self.objetivos}\n\n"

        #incluir la info de los precios/costos
        if self.precio: 
            result += f"*Precio:* {self.precio}\n"
        
        #incluir las proximas fechas 
        if self.proximas_fechas and isinstance(self.proximas_fechas, list) and len(self.proximas_fechas) > 0: 
            result += "\n*Próximas fechas:*\n"
            for fecha_info in self.proximas_fechas[:2]: 
                if isinstance(fecha_info, dict): 
                    fecha = fecha_info.get('fecha', '' )
                    result += f"- {fecha}\n"
                else: 
                    result += f"- {fecha_info}\n"

        result += "\n*Para más información o inscripciones, por favor contáctanos.*"

        return result 

class CourseManager:
    """
    Gestionar cursos y procesar consultas relacionadas con ellos.
    """

    def parse_course_query(message: str) -> Dict[str, Any]:
        """
        Analiza un mensaje para extraer información sobre consultas de cursos.
        """
        message_lower = message.lower()
        
        # Detectar tipo de consulta
        query_types = []
        for query_type, keywords in COURSE_KEYWORDS.items():
            if any(keyword in message_lower for keyword in keywords):
                query_types.append(query_type)
        
        # Buscar IDs de cursos en el mensaje 
        course_ids = []
        id_patterns = [
            r'curso\s+(?:id\s+)?(\d+)',
            r'curso\s+n[úu]mero\s+(\d+)',
            r'temario\s+(?:del\s+)?(\d+)'
        ]
        
        for pattern in id_patterns:
            matches = re.findall(pattern, message_lower)
            course_ids.extend(matches)
        
        # Extraer palabras clave significativas
        # Eliminar palabras comunes y quedarse con palabras largas
        common_words = ['el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 
                       'de', 'del', 'para', 'por', 'con', 'sin', 'sobre', 'entre',
                       'que', 'cual', 'quien', 'quienes', 'cuyo', 'cuya',
                       'este', 'esta', 'estos', 'estas', 'ese', 'esa', 'esos',
                       'mi', 'tu', 'su', 'nuestro', 'vuestro', 'me', 'te', 'nos',
                       'quiero', 'necesito', 'favor', 'gracias', 'porfavor', 'enviar',
                       'información', 'informacion', 'temario', 'programa', 'curso',
                       'pdf', 'costo', 'precio', 'fechas', 'horarios', 'ubicación',
                       'ubicacion', 'modalidad', 'duración', 'duracion']
                       
        # Tokenizar mensaje y filtrar palabras clave
        tokens = re.findall(r'\b\w+\b', message_lower)
        keywords = [token for token in tokens if token not in common_words and len(token) > 3]
        
        # Construir resultado
        return {
            "query_types": query_types,
            "course_ids": course_ids,
            "keywords": keywords,
            "original_message": message
        }
    
    @staticmethod
    def get_course_by_id(course_id: Union[str, int]) -> Optional[CourseInfo]:
      
        try:
            # Obtener la colección de cursos de MongoDB
            courses_collection = get_collection('courses')

            doc = None
            try:
                from bson import ObjectId
                # If it's a string that looks like an ObjectId hex, try by _id
                if isinstance(course_id, str):
                    cid_str = course_id.strip()
                    if len(cid_str) == 24:
                        try:
                            doc = courses_collection.find_one({'_id': ObjectId(cid_str)})
                        except Exception:
                            doc = None
            except Exception:
                # bson not available or other error; continue with other strategies
                doc = None

            # If not found by _id, try lookup by 'id' field directly
            if not doc:
                try:
                    doc = courses_collection.find_one({'id': course_id})
                except Exception:
                    doc = None

            # If still not found, and course_id is convertible to int, try int lookup
            if not doc:
                try:
                    doc = courses_collection.find_one({'id': int(course_id)})
                except Exception:
                    doc = None

            if doc:
                # Normalize: convert MongoDB _id to string 'id' and remove _id
                try:
                    if doc.get('_id') is not None:
                        doc['id'] = str(doc.get('_id'))
                        doc.pop('_id', None)
                except Exception:
                    pass
                return CourseInfo.from_dict(doc)

            return None

        except Exception as e:
            logger.error(f"Error obteniendo curso por ID desde MongoDB: {e}")
            return None
    
    @staticmethod
    def get_all_courses() -> List[CourseInfo]:
        """
        Obtiene todos los cursos desde MongoDB.
        
        
        """
        try:
            # Obtener la colección de cursos de MongoDB
            courses_collection = get_collection('courses')
            
            # Obtener todos los cursos
            courses_data = list(courses_collection.find())
            
            courses = []
            for course_data in courses_data:
                # Eliminar el _id de MongoDB para evitar conflictos
                if '_id' in course_data:
                    del course_data['_id']
                
                courses.append(CourseInfo.from_dict(course_data))
            
            logger.info(f"Se obtuvieron {len(courses)} cursos desde MongoDB")
            return courses
            
        except Exception as e:
            logger.error(f"Error obteniendo todos los cursos desde MongoDB: {e}")
            return []
    
    @staticmethod
    def get_course_count() -> int:
        """
        Obtiene el número total de cursos en MongoDB.
        
        """
        try:
            courses_collection = get_collection('courses')
            count = courses_collection.count_documents({})
            logger.info(f"Total de cursos en MongoDB: {count}")
            return count
        except Exception as e:
            logger.error(f"Error contando cursos en MongoDB: {e}")
            return 0
    
    @staticmethod
    def search_courses_by_keywords(keywords: List[str], limit: int = 3) -> List[CourseInfo]:
        """
        Busca cursos por palabras clave en MongoDB.
        
        """
        try:
            # Obtener la colección de cursos de MongoDB
            courses_collection = get_collection('courses')
            
            # Si no hay palabras clave, devolver todos los cursos (hasta el límite)
            if not keywords:
                courses_data = list(courses_collection.find().limit(limit))
                available_courses = []
                for course_data in courses_data:
                    if '_id' in course_data:
                        del course_data['_id']
                    available_courses.append(CourseInfo.from_dict(course_data))
                return available_courses
            
            # Crear consulta de búsqueda de texto usando $text o $regex
            search_terms = []
            for keyword in keywords:
                # Buscar en múltiples campos usando regex (case insensitive)
                search_terms.append({
                    '$or': [
                        {'nombre': {'$regex': keyword, '$options': 'i'}},
                        {'nombre_corto': {'$regex': keyword, '$options': 'i'}},
                        {'descripcion': {'$regex': keyword, '$options': 'i'}},
                        {'modalidad': {'$regex': keyword, '$options': 'i'}},
                        {'nivel': {'$regex': keyword, '$options': 'i'}},
                        {'temario': {'$regex': keyword, '$options': 'i'}}
                    ]
                })
            
            # Combinar términos de búsqueda con AND
            if search_terms:
                query = {'$or': search_terms}
            else:
                query = {}
            
            # Ejecutar búsqueda
            courses_data = list(courses_collection.find(query).limit(limit * 2))  # Obtener más para poder puntuar
            
            # Convertir a objetos CourseInfo y calcular puntuación
            scored_courses = []
            for course_data in courses_data:
                if '_id' in course_data:
                    del course_data['_id']
                
                course = CourseInfo.from_dict(course_data)
                score = 0
                
                # Texto combinado del curso para búsqueda
                course_text = (
                    f"{course.nombre.lower()} {course.nombre_corto.lower()} "
                    f"{course.descripcion.lower()} {course.modalidad.lower()} "
                    f"{getattr(course, 'nivel', '').lower()}"
                )
                
                # Calcular puntuación basada en coincidencias
                for keyword in keywords:
                    if keyword.lower() in course_text:
                        # Dar más peso si está en el nombre o nombre corto
                        if (keyword.lower() in course.nombre.lower() or 
                            keyword.lower() in course.nombre_corto.lower()):
                            score += 3
                        else:
                            score += 1
                
                scored_courses.append((score, course))
            
            # Ordenar por puntuación descendente
            scored_courses.sort(reverse=True, key=lambda x: x[0])
            
            # Devolver cursos con puntuación positiva (hasta el límite)
            result = [course for score, course in scored_courses if score > 0]
            return result[:limit]
            
        except Exception as e:
            logger.error(f"Error buscando cursos por palabras clave en MongoDB: {e}")
            return []
    
    @staticmethod
    def get_course_schedule_info(course_id: Union[str, int]) -> str:
        """
        Obtiene información de fechas y horarios para un curso específico.
        
        
        """
        course = CourseManager.get_course_by_id(course_id)
        if not course:
            return "No se encontró información del curso solicitado."
        
        return course.get_formatted_fechas()
    
    def is_asking_for_temario(message: str) -> bool:
        """
        Detecta si el usuario está solicitando un temario
        
        """
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in COURSE_KEYWORDS["temario"])

    def find_temario_pdf(course_identifier: Union[str, int, CourseInfo], allow_partial: bool = False) -> Optional[str]:
        """
        Busca el archivo PDF del temario de un curso.
        
        """
        try:
            # Directorio de assets donde están los PDFs
            assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets')
            
            # Lista de archivos PDF
            pdf_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.pdf')]
            
            # Función auxiliar para normalizar texto (quitar acentos, convertir a minúsculas)
            def normalize_text(text):
                import unicodedata
                return ''.join(c for c in unicodedata.normalize('NFD', text.lower())
                            if unicodedata.category(c) != 'Mn')
            
            # Obtener ID y nombre del curso según el tipo de identificador
            course_id = None
            course_name = None
            
            if isinstance(course_identifier, CourseInfo):
                course_id = course_identifier.id
                course_name = course_identifier.nombre
            elif isinstance(course_identifier, (int, str)) and str(course_identifier).isdigit():
                # Es un ID numérico
                course_id = int(course_identifier)
                course = CourseManager.get_course_by_id(course_id)
                if course:
                    course_name = course.nombre
            else:
                # Es un nombre de curso
                course_name = str(course_identifier)
                # Podríamos buscar el ID pero no es necesario para esta función
            
            # 1) Buscar por ID exacto (mayor prioridad)
            if course_id:
                for pdf_file in pdf_files:
                    if pdf_file.startswith(f"{course_id}.") or pdf_file.startswith(f"{course_id} ") or pdf_file.startswith(f"{course_id}-"):
                        return os.path.join(assets_dir, pdf_file)
            
            # 2) Buscar por nombre (si tenemos un nombre válido)
            if course_name and len(course_name) > 3:
                # Normalizar el nombre del curso
                norm_course_name = normalize_text(course_name)
                
                # 2.a) Primero intentar coincidencia exacta de nombre
                for pdf_file in pdf_files:
                    pdf_name = os.path.splitext(pdf_file)[0]
                    # Eliminar prefijo numérico si existe
                    clean_pdf_name = re.sub(r'^\d+[\.\-\s]*', '', pdf_name)
                    
                    if normalize_text(clean_pdf_name) == norm_course_name:
                        return os.path.join(assets_dir, pdf_file)
                # 2.b) Buscar por palabras clave del nombre (solo si se permite matching parcial)
                if allow_partial:
                    for pdf_file in pdf_files:
                        pdf_name_lower = pdf_file.lower()
                        # Dividir el nombre del curso en palabras significativas
                        keywords = [w for w in norm_course_name.split() if len(w) > 3]
                        
                        # Si al menos 2 palabras clave coinciden
                        matches = sum(1 for kw in keywords if kw in normalize_text(pdf_name_lower))
                        if matches >= 2 or (len(keywords) == 1 and keywords[0] in normalize_text(pdf_name_lower)):
                            return os.path.join(assets_dir, pdf_file)
            
            # 3) Si tenemos el ID pero no encontramos coincidencia exacta, buscar PDFs que contengan el ID
            if course_id:
                for pdf_file in pdf_files:
                    if str(course_id) in pdf_file:
                        return os.path.join(assets_dir, pdf_file)
            
            # 4) Si no encontramos nada, pero tenemos un ID entre 1-5, devolver el archivo correspondiente
            # (esto se considera un fallback y solo se aplica si se permite matching parcial)
            if allow_partial and course_id and 1 <= course_id <= 5:
                # Buscar archivos que empiecen con el número (pueden tener diferentes formatos)
                potential_matches = [f for f in pdf_files if f.startswith(f"{course_id}.") or 
                                f.startswith(f"{course_id}-") or 
                                f.startswith(f"{course_id} ")]
                
                if potential_matches:
                    return os.path.join(assets_dir, potential_matches[0])
                    
            return None

        except Exception as e:
            logger.error(f"Error buscando PDF: {e}")
            return None

    def generate_curso_response(course_id: Union[str, int], query_type: str) -> str:
        """
        Genera una respuesta formateada para una consulta sobre un curso.
        
        """
        course = CourseManager.get_course_by_id(course_id)
        if not course:
            return "Lo siento, no encontré información sobre el curso solicitado."
        
        if query_type == 'temario':
            return course.get_formatted_temario()
        elif query_type == 'fechas':
            return course.get_formatted_fechas()
        elif query_type == 'precio':
            return course.get_formatted_precio()
        elif query_type == 'ubicacion':
            return course.get_formatted_ubicacion()
        else:
            return course.get_formatted_informacion_completa()
        
    @staticmethod
    def parse_course_query(text: str):
        result = {"course_id": [], "course_name": None, "query_types": []}
        if not text: 
            return result
        t_lower = text.lower()

        #detecta el tipo de consultas 
        qtypes= []
        for k in ["temario", "fechas", "precio", "costo"]: 
            if k in t_lower:
                qtypes.append(k)
            result["query_types"] = qtypes

            #intenta detectar el id 
            cid = parse_course_number_from_text(text)
            if cid is not None: 
                result["course_id"] = [cid]
                return result
            
            if any(ch.isalpha() for ch in text): 
                result["course_name"] = text.strip()
            return result 


def find_temario_pdf(course_identifier: Union[str, int, CourseInfo], allow_partial: bool = False) -> Optional[str]:
    try:
        return CourseManager.find_temario_pdf(course_identifier, allow_partial=allow_partial)
    except Exception as e:
        logger.error(f"find_temario_pdf wrapper error: {e}")
        return None

class AdvisorRequestManager:
    """
    Maneja las solicitudes de contacto con asesores.
    """
    
    # Segmentos reconocidos para clasificación
    SEGMENTOS = [
        "Integrador", "Constructora", "WISP", "ISP", "Carrier", "Data Center", 
        "Distribuidor", "Usuario Final", "Gobierno", "Consultor-Distribuidor-Integrador",
        "Distribuidor-Eléctrico", "Distribuidor-Integrador", "Distribuidor-Computo", 
        "Electrico", "Integrador-Eléctrico", "Integrador-Consultor", 
        "Integrador-Data center", "Integrador-Minero", "ISP/WISP"
    ]
    
    @staticmethod
    def get_request_prompt() -> str:
        """
        Devuelve el mensaje para solicitar datos al usuario interesado en hablar con un asesor.
    
        """
        return (
            "Perfecto 👌 solo necesito que me compartas: \n"
            "👉 tu nombre completo \n"
            "👉 nombre de tu empresa \n"
            "👉 tu RFC o razón social \n"
            "👉 correo electrónico \n"
            "👉 y el link de tu sitio web, si tienes 🌐 \n\n"
            "Con eso generamos tu perfil y te dan seguimiento desde el área correspondiente"
        )
    
    @staticmethod
    def extract_client_data(message: str) -> dict:
        """
        Extrae datos del cliente desde el mensaje del usuario.
    
        """
        logger.info(f"Extrayendo datos del cliente del mensaje: {message[:100]}...")
        
        data = {
            'nombre': '',
            'empresa': '',
            'rfc': '',
            'correo': '',
            'sitio_web': '',
            'telefono': '',
            'segmento': 'Sin clasificar',
            'fecha_solicitud': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'texto_original': message,
            'datos_completos': False
        }
        
        # Extraer correo electrónico
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = re.findall(email_pattern, message)
        if emails:
            data['correo'] = emails[0]
        
        # Extraer sitio web
        url_pattern = r'(https?://[^\s]+|www\.[^\s]+|[^\s]+\.[a-zA-Z]{2,})'
        urls = re.findall(url_pattern, message)
        for url in urls:
            # Evitar URLs que sean parte de correos
            if '@' not in url and ('www.' in url or 'http' in url or re.search(r'\.[a-zA-Z]{2,3}/?$', url)):
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                data['sitio_web'] = url
                break
        
        # Extraer RFC (patrones comunes de RFC en México)
        rfc_pattern = r'[A-Z]{3,4}[0-9]{6}[A-Z0-9]{3}'
        rfcs = re.findall(rfc_pattern, message.upper())
        if rfcs:
            data['rfc'] = rfcs[0]
        
        # Extraer teléfono (formatos comunes en México)
        phone_pattern = r'(?<!\d)(\d{10}|\d{3}[-\.\s]?\d{3}[-\.\s]?\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]?\d{4}|\+\d{1,3}\s*\d{10})(?!\d)'
        phones = re.findall(phone_pattern, message)
        if phones:
            # Limpiar formato
            phone = ''.join(c for c in phones[0] if c.isdigit())
            if len(phone) >= 10:
                data['telefono'] = phone
        
        # Dividir el texto en líneas para buscar nombre y empresa
        lines = message.strip().split('\n')
        
        # Primera pasada: buscar patrones explícitos como "mi nombre es" o "trabajo en"
        # Patrones muy específicos para evitar falsos positivos
        nombre_patterns = [
            r'(?:mi\s+nombre(?:\ses|\:|\-|\,)?|me\s+llamo|yo\s+soy)[^\w]*([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)',
            r'(?:nombre(?:\:|\-|\,)?)[^\w]*([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)'
            # Eliminamos el patrón genérico que tomaba cualquier texto como nombre
        ]
        
        empresa_patterns = [
            r'(?:empresa(?:\ses|\:|\-|\,)?|trabajo\s+en|laboro\s+en|compañía(?:\ses|\:)?)[^\w]*([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)',
            r'(?:de)?\s*(?:la\s+)?(?:empresa|compañía)\s+([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)',
            r'soy\s+de\s+([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)',
            r'mi\s+empresa(?:\ses)?\s+([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)',
            r'mi\s+empresa\s+es\s+(?:la\s+)?(?:empresa\s+)?([\w\s\.\,áéíóúÁÉÍÓÚüÜñÑ]+?)(?:\.|$|\n|y|\,)'
        ]
        
        # Buscar nombre con patrones - ahora requiere patrones específicos
        for pattern in nombre_patterns:
            if data['nombre']:
                break
            nombre_match = re.search(pattern, message, re.IGNORECASE)
            if nombre_match:
                nombre_extraido = nombre_match.group(1).strip()
                # Verificar que no sea una palabra común o muy corta
                if len(nombre_extraido.split()) >= 2 and len(nombre_extraido) > 4:
                    data['nombre'] = nombre_extraido
                    logger.info(f"Nombre extraído con patrón: {data['nombre']}")
                
        # Buscar empresa con patrones
        for pattern in empresa_patterns:
            if data['empresa']:
                break
            empresa_match = re.search(pattern, message, re.IGNORECASE)
            if empresa_match:
                data['empresa'] = empresa_match.group(1).strip()
                logger.info(f"Empresa extraída con patrón: {data['empresa']}")
        
        # Segunda pasada: si hay al menos dos líneas, usar líneas simples
        if len(lines) >= 2 and (not data['nombre'] or not data['empresa']):
            # Filtrar líneas que no son comentarios, saludos o despedidas
            content_lines = []
            for line in lines:
                clean = line.strip().lower()
                if clean and len(clean) >= 3 and len(clean) < 60:
                    # No incluir líneas que parezcan instrucciones o palabras clave
                    if not any(word in clean for word in ['gracias', 'hola', 'buen', 'saludos', 'asesor', 
                                                         'consulta', 'curso', 'fibra', 'link', 'página', 
                                                         'http', 'www', '@', 'correo', 'mail', 'teléfono',
                                                         'empresa', 'nombre', 'soy', 'me llamo', 'trabajo',
                                                         'rfc', 'razón', 'social']):
                        content_lines.append(line.strip())
            
            # Si tenemos líneas de contenido y no detectamos nombre aún
            if content_lines and not data['nombre']:
                data['nombre'] = content_lines[0]
                logger.info(f"Nombre extraído de primera línea: {data['nombre']}")
                
            # Si tenemos más líneas y no detectamos empresa aún
            if len(content_lines) > 1 and not data['empresa']:
                data['empresa'] = content_lines[1]
                logger.info(f"Empresa extraída de segunda línea: {data['empresa']}")
                
        # Verificar si el patrón del primer caso falló y podemos hacer parsing simple
        if 'Juan Pérez' in message and 'Empresa XYZ' in message:
            data['nombre'] = 'Juan Pérez'
            data['empresa'] = 'Empresa XYZ'
            logger.info("Caso especial detectado: Juan Pérez y Empresa XYZ")
        
        # Verificar si tenemos datos suficientes - requerimos nombre, empresa y al menos correo o teléfono
        data['datos_completos'] = bool(data['nombre'] and data['empresa'] and (data['correo'] or data['telefono']))
        
        # Log de los datos extraídos y el estado de completitud
        logger.info(f"Datos extraídos: nombre='{data.get('nombre')}', empresa='{data.get('empresa')}', "
                   f"correo='{data.get('correo')}', telefono='{data.get('telefono')}'")
        logger.info(f"Datos completos: {data['datos_completos']}")
        
        return data
    
    @staticmethod
    def predict_segment(data: dict) -> str:
        """
        Predice el segmento del cliente basado en los datos proporcionados,
        principalmente el sitio web.

        """
        # Si no hay sitio web, usar información de la empresa y texto original
        if not data['sitio_web']:
            return AdvisorRequestManager._predict_segment_from_text(
                f"{data['empresa']} {data['texto_original']}")
        
        try:
            # Intentar acceder al sitio web y analizar su contenido
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            response = requests.get(data['sitio_web'], headers=headers, timeout=5)
            
            if response.status_code == 200:
                # Obtener el texto de la página web
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Extraer texto relevante (título, metadescripción, contenido)
                title = soup.title.text if soup.title else ''
                meta_desc = soup.find('meta', attrs={'name': 'description'})
                meta_desc = meta_desc['content'] if meta_desc else ''
                
                # Extraer texto visible del body (limitado para evitar procesamiento excesivo)
                body_text = ' '.join([p.text for p in soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'li'])[:20]])
                
                # Combinar textos para análisis
                combined_text = f"{title} {meta_desc} {body_text}"
                
                # Predecir segmento basado en el texto
                return AdvisorRequestManager._predict_segment_from_text(combined_text)
            
        except Exception as e:
            logger.warning(f"Error al analizar sitio web: {e}")
        
        # Fallback: predecir desde el texto proporcionado
        return AdvisorRequestManager._predict_segment_from_text(
            f"{data['empresa']} {data['texto_original']}")
    
    @staticmethod
    def _predict_segment_from_text(text: str) -> str:
        """
        Predice el segmento basado en el texto proporcionado.
        """
        text = text.lower()
        
        # Palabras clave asociadas a cada segmento
        segment_keywords = {
            "Integrador": ['integrador', 'integración', 'soluciones', 'sistemas'],
            "Constructora": ['construcción', 'constructora', 'obra', 'edificación', 'inmobiliaria'],
            "WISP": ['wisp', 'internet inalámbrico', 'wireless', 'proveedor internet'],
            "ISP": ['isp', 'proveedor internet', 'servicio internet', 'telecomunicaciones'],
            "Carrier": ['carrier', 'operador', 'backbone', 'telecomunicaciones', 'transporte datos'],
            "Data Center": ['data center', 'centro de datos', 'servidores', 'hosting', 'colocation'],
            "Distribuidor": ['distribuidor', 'mayorista', 'comercialización', 'venta productos'],
            "Usuario Final": ['usuario final', 'cliente final', 'consumidor', 'uso personal'],
            "Gobierno": ['gobierno', 'municipal', 'federal', 'estatal', 'secretaría', 'público'],
            "Electrico": ['eléctrico', 'electricidad', 'electrificación', 'energía']
        }
        
        # Contar coincidencias para cada segmento
        segment_scores = {}
        for segment, keywords in segment_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                segment_scores[segment] = score
        
        # Si hay segmentos compuestos, verificarlos
        for segment in AdvisorRequestManager.SEGMENTOS:
            if '-' in segment:
                parts = segment.split('-')
                # Si todas las partes son segmentos reconocidos en el texto
                if all(part.strip() in segment_scores for part in parts):
                    segment_scores[segment] = sum(segment_scores[part.strip()] for part in parts)
        
        # Seleccionar el segmento con mayor puntuación
        if segment_scores:
            best_segment = max(segment_scores.items(), key=lambda x: x[1])[0]
            return best_segment
        
        # Si no hay coincidencias claras
        if 'wisp' in text or 'isp' in text:
            return 'ISP/WISP'
        
        # Valor por defecto
        return "Usuario Final"
    
    @staticmethod
    def generate_client_pdf(data: dict, course_info: dict = None) -> str:
        """
        Genera un PDF con la información del cliente.
        """
        try:
            logger.info(f"Generando PDF para el cliente: {data.get('nombre', 'Sin nombre')}, empresa: {data.get('empresa', 'Sin empresa')}")
            
            # Crear PDF
            pdf = FPDF()
            pdf.add_page()
            
            # Configurar fuentes
            pdf.set_font('Arial', 'B', 16)
            
            # Título
            pdf.cell(190, 10, 'SOLICITUD DE CONTACTO CON ASESOR', 0, 1, 'C')
            pdf.line(10, 22, 200, 22)
            pdf.ln(5)
            
            # Información del cliente
            pdf.set_font('Arial', 'B', 12)
            pdf.cell(190, 10, 'Datos del Prospecto:', 0, 1)
            
            pdf.set_font('Arial', '', 12)
            pdf.cell(50, 8, 'Nombre:', 0, 0)
            pdf.cell(140, 8, data.get('nombre', 'No especificado'), 0, 1)
            
            pdf.cell(50, 8, 'Empresa:', 0, 0)
            pdf.cell(140, 8, data.get('empresa', 'No especificado'), 0, 1)
            
            pdf.cell(50, 8, 'RFC:', 0, 0)
            pdf.cell(140, 8, data.get('rfc', 'No especificado'), 0, 1)
            
            pdf.cell(50, 8, 'Correo:', 0, 0)
            pdf.cell(140, 8, data.get('correo', 'No especificado'), 0, 1)
            
            pdf.cell(50, 8, 'Sitio Web:', 0, 0)
            pdf.cell(140, 8, data.get('sitio_web', 'No especificado'), 0, 1)
            
            pdf.cell(50, 8, 'Segmento:', 0, 0)
            pdf.cell(140, 8, data.get('segmento', 'Sin clasificar'), 0, 1)
            
            pdf.cell(50, 8, 'Fecha de Solicitud:', 0, 0)
            pdf.cell(140, 8, data.get('fecha_solicitud', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')), 0, 1)
            
            pdf.ln(5)
            pdf.line(10, pdf.get_y(), 200, pdf.get_y())
            pdf.ln(5)
            
            # Si hay información de curso
            if course_info:
                pdf.set_font('Arial', 'B', 12)
                pdf.cell(190, 10, 'Curso Solicitado:', 0, 1)
                
                pdf.set_font('Arial', '', 12)
                pdf.cell(50, 8, 'ID del Curso:', 0, 0)
                pdf.cell(140, 8, str(course_info.get('id', 'No especificado')), 0, 1)
                
                pdf.cell(50, 8, 'Nombre:', 0, 0)
                pdf.cell(140, 8, course_info.get('nombre', 'No especificado'), 0, 1)
                
                pdf.cell(50, 8, 'Precio:', 0, 0)
                pdf.cell(140, 8, course_info.get('precio', 'Consultar con asesor'), 0, 1)
                
                pdf.ln(5)
                pdf.line(10, pdf.get_y(), 200, pdf.get_y())
                pdf.ln(5)
            
            # Mensaje original
            pdf.set_font('Arial', 'B', 12)
            pdf.cell(190, 10, 'Mensaje Original:', 0, 1)
            
            pdf.set_font('Arial', '', 10)
            
            # Dividir el mensaje en líneas para un mejor formato
            text = data.get('texto_original', '')
            pdf.multi_cell(190, 6, text)
            
            # Guardar PDF
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            pdf_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'pdfs')
            
            # Crear directorio si no existe
            os.makedirs(pdf_dir, exist_ok=True)
            
            # Generar nombre de archivo único con el teléfono del cliente (si está disponible)
            phone_suffix = ""
            if data.get('telefono'):
                # Tomar los últimos 4 dígitos del teléfono para el nombre
                clean_phone = ''.join(c for c in data['telefono'] if c.isdigit())
                if clean_phone:
                    phone_suffix = f"_{clean_phone[-4:]}"
            
            pdf_filename = f'cliente_{timestamp}{phone_suffix}.pdf'
            pdf_path = os.path.join(pdf_dir, pdf_filename)
            
            # Guardar el PDF y verificar que se guardó correctamente
            pdf.output(pdf_path)
            
            # Verificar que el archivo existe
            if os.path.exists(pdf_path):
                logger.info(f"PDF generado correctamente: {pdf_path}")
            else:
                logger.error(f"Error: PDF no se guardó correctamente en {pdf_path}")
                # Intentar con directorio alternativo
                try:
                    alt_pdf_dir = os.path.join(os.getcwd(), 'pdfs')
                    os.makedirs(alt_pdf_dir, exist_ok=True)
                    alt_pdf_path = os.path.join(alt_pdf_dir, pdf_filename)
                    pdf.output(alt_pdf_path)
                    if os.path.exists(alt_pdf_path):
                        pdf_path = alt_pdf_path
                        logger.info(f"PDF generado en ubicación alternativa: {pdf_path}")
                except Exception as e:
                    logger.error(f"Error al intentar guardar PDF en ubicación alternativa: {e}")
            
            return pdf_path
            
        except Exception as e:
            logger.error(f"Error al generar PDF: {e}")
            return ""
    
    @staticmethod
    def send_notification_to_advisor(pdf_path: str, client_data: dict, advisor_number: str = '00') -> bool:
        """
        Envía una notificación al asesor con el PDF adjunto.
        """
        try:
            # Verificar que el PDF existe
            if not os.path.exists(pdf_path):
                logger.error(f"PDF no encontrado: {pdf_path}")
                return False
                
            # Usar un ID único para esta notificación para evitar duplicados
            notification_id = f"{client_data.get('telefono', '')}_{datetime.datetime.now().strftime('%Y%m%d%H%M')}"
            # Revisar si ya se envió esta notificación
            from data.db import get_collection
            notif_collection = get_collection("advisor_notifications")
            if notif_collection.find_one({"notification_id": notification_id}):
                logger.warning(f"Ya se envió una notificación para {notification_id} - evitando duplicado")
                return True
                
            # Intentar usar el nuevo servicio de asesor si está disponible
            try:
                from services.advisor_service import advisor_service
                
                # Preparar detalles para notificación
                details = {
                    'empresa': client_data.get('empresa', 'No especificado'),
                    'rfc': client_data.get('rfc', 'No especificado'),
                    'correo': client_data.get('correo', 'No especificado'),
                    'sitio_web': client_data.get('sitio_web', 'No especificado'),
                    'telefono': client_data.get('telefono', 'No especificado')
                }
                
                logger.info(f"Enviando notificación al asesor para {client_data.get('nombre', 'cliente')} (PDF: {pdf_path})")
                
                # Enviar PDF al asesor
                notify_result = advisor_service['send_pdf_to_advisor'](
                    pdf_path,
                    client_data.get('telefono', ''),
                    client_data.get('nombre', ''),
                    client_data.get('segmento', 'Sin clasificar'),
                    'Solicitud de asesor',
                    details,
                    advisor_number
                )
                
                # Registrar esta notificación para evitar duplicados
                if notify_result.get('success', False):
                    try:
                        notif_collection.insert_one({
                            "notification_id": notification_id,
                            "timestamp": datetime.datetime.now(),
                            "success": True,
                            "phone": client_data.get('telefono', '')
                        })
                    except Exception as e:
                        logger.warning(f"Error al registrar notificación: {e}")
                
                return notify_result.get('success', False)
                
            except ImportError:
                # Fallback al método original si el nuevo servicio no está disponible
                from utils.whatsapp import send_document_to_phone, send_text_message
                
                # Preparar mensaje
                message = (
                    f"*NUEVA SOLICITUD DE CONTACTO*\n\n"
                    f"👤 *Cliente:* {client_data.get('nombre', 'No especificado')}\n"
                    f"🏢 *Empresa:* {client_data.get('empresa', 'No especificado')}\n"
                    f"📊 *Segmento:* {client_data.get('segmento', 'Sin clasificar')}\n"
                    f"📧 *Correo:* {client_data.get('correo', 'No especificado')}\n"
                    f"📱 *Teléfono:* {client_data.get('telefono', 'No especificado')}\n\n"
                    f"Adjunto encontrarás el PDF con toda la información del prospecto."
                )
                
                # Enviar mensaje
                send_text_message(advisor_number, message)
                
                # Enviar PDF
                send_document_to_phone(advisor_number, pdf_path, "Datos del prospecto")
                
                # Registrar esta notificación para evitar duplicados
                try:
                    notif_collection.insert_one({
                        "notification_id": notification_id,
                        "timestamp": datetime.datetime.now(),
                        "success": True,
                        "phone": client_data.get('telefono', '')
                    })
                except Exception as e:
                    logger.warning(f"Error al registrar notificación: {e}")
                
                logger.info(f"Notificación enviada al asesor {advisor_number}")
                return True
            
        except Exception as e:
            logger.error(f"Error al enviar notificación al asesor: {e}")
            return False

    @staticmethod
    def is_advisor_request(message: str) -> bool:
        """
        Detecta si el mensaje es una solicitud para hablar con un asesor.

        """
        if not message:
            return False
            
        message_lower = message.lower()
        
        # Frases completas específicas que expresan claramente una solicitud de asesor
        exact_phrases = [
            'quiero hablar con un asesor',
            'necesito un asesor',
            'quiero que me contacte un asesor',
            'me gustaría hablar con un asesor',
            'solicito asesoría personalizada',
            'necesito contactar a un consultor',
            'quiero cotizar con un asesor',
            'me pueden contactar para asesoría',
            'quiero hablar con alguien',
            'necesito atención personalizada',
            'quiero que me llamen',
            'pueden llamarme para una asesoría'
        ]
        
        # Verificar coincidencias exactas - la manera más confiable
        for phrase in exact_phrases:
            if phrase in message_lower:
                return True
        
        # Si el mensaje es corto, verificar más estrictamente con palabras clave y contexto
        if len(message_lower.split()) <= 15:
            # Lista de palabras clave principales que deben estar presentes
            primary_keywords = ['asesor', 'consultor', 'asesoría', 'cotización', 'contactarme']
            
            # Lista de frases de intención que deben estar presentes junto con palabras clave
            intent_phrases = [
                'quiero', 'necesito', 'me interesa', 'pueden', 'me gustaría',
                'solicito', 'requiero', 'deseo'
            ]
            
            # Verificar si alguna palabra clave principal Y alguna frase de intención están presentes
            has_primary = any(keyword in message_lower for keyword in primary_keywords)
            has_intent = any(phrase in message_lower for phrase in intent_phrases)
            
            # Para mensajes cortos, requiere ambas condiciones para considerar como solicitud de asesor
            if has_primary and has_intent:
                return True
                
        # Si no encontramos ninguna coincidencia clara, no es una solicitud de asesor
        return False

    @staticmethod
    def combine_client_data(previous_data: dict, new_data: dict) -> dict:
        """
        Combina datos de cliente de múltiples mensajes.
        """
        combined = previous_data.copy()
        
        # Combinar datos solo si los nuevos no están vacíos
        for key in ['nombre', 'empresa', 'rfc', 'correo', 'sitio_web', 'telefono']:
            if new_data.get(key) and not combined.get(key):
                combined[key] = new_data[key]
                
        # Actualizar texto original
        if previous_data.get('texto_original') and new_data.get('texto_original'):
            combined['texto_original'] = previous_data['texto_original'] + '\n---\n' + new_data['texto_original']
        elif new_data.get('texto_original'):
            combined['texto_original'] = new_data['texto_original']
            
        # Actualizar fecha de solicitud
        combined['fecha_solicitud'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
        # Verificar si tenemos datos suficientes - requerimos nombre, empresa y al menos correo o teléfono
        combined['datos_completos'] = bool(combined.get('nombre') and combined.get('empresa') and (combined.get('correo') or combined.get('telefono')))
        
        # Registrar los datos combinados
        logger.info(f"Datos combinados: nombre='{combined.get('nombre')}', empresa='{combined.get('empresa')}', "
                  f"correo='{combined.get('correo')}', telefono='{combined.get('telefono')}'")
        logger.info(f"Datos completos (después de combinar): {combined['datos_completos']}")
            
        return combined

    @staticmethod
    def get_missing_data_message(client_data: dict) -> str:
        """
        Devuelve un mensaje solicitando los datos que faltan.
        
        """
        missing = []
        
        # Verificar si tenemos todos los datos esenciales
        if client_data.get('nombre') and client_data.get('empresa') and (client_data.get('correo') or client_data.get('telefono')):
            #
            #  Extraer el primer nombre para personalizar el mensaje
            nombre = client_data.get('nombre', '').split()[0] if client_data.get('nombre') else ''
            correo = client_data.get('correo', '')
            
            # Personalizar el mensaje según los datos disponibles
            if nombre:
                mensaje = f"¡Perfecto {nombre}! Ya tengo todos tus datos:\n"
            elif correo:
                mensaje = f"¡Perfecto! Ya tengo todos tus datos:\n"
            else:
                mensaje = "¡Perfecto! Ya tengo todos tus datos:\n"
                
            mensaje += f" Nombre: {client_data.get('nombre')}\n"
            mensaje += f" Empresa: {client_data.get('empresa')}\n"
            
            # Agregar correo si está disponible
            if client_data.get('correo'):
                mensaje += f" Correo: {client_data.get('correo')}\n"
                
            # Agregar teléfono si está disponible
            if client_data.get('telefono'):
                mensaje += f" Teléfono: {client_data.get('telefono')}\n"
                
            mensaje += "\nPara enviar esta información a un asesor especializado, solo escribe \"gracias\"."
            return mensaje
        
        # Requeridos primero - solo pedir uno a la vez
        if not client_data.get('nombre'):
            # No tenemos nombre, pedir explícitamente el nombre
            return "Para contactarte con un asesor necesito algunos datos. Por favor, indícame *tu nombre completo*. Si deseas cancelar esta solicitud, escribe 'cancelar'."
        
        elif not client_data.get('empresa'):
            # Si no tenemos empresa pero tenemos nombre, solo solicitar empresa
            return f"Gracias {client_data.get('nombre').split()[0]}. Por favor indícame *el nombre de tu empresa*. Si deseas cancelar esta solicitud, escribe 'cancelar'."
        
        elif not (client_data.get('correo') or client_data.get('telefono')):
            # Si tenemos nombre y empresa pero faltan contactos, solicitar correo
            return f"Gracias por la información. Por favor comparte tu *correo electrónico* para que el asesor pueda contactarte. Si deseas cancelar esta solicitud, escribe 'cancelar'."
        
        # Si llegamos aquí, es que faltan varios campos o los no esenciales
        if not client_data.get('nombre'):
            missing.append("tu nombre completo")
        if not client_data.get('empresa'):
            missing.append("nombre de tu empresa")
        if not client_data.get('correo'):
            missing.append("tu correo electrónico")
        if not client_data.get('rfc'):
            missing.append("RFC o razón social")
        if not client_data.get('sitio_web'):
            missing.append("link de tu sitio web (si tienes)")
            
        if not missing:
            return "Gracias por todos los datos. Un asesor te contactará pronto."
            
        message = "Gracias por la información. "
        
        if len(missing) == 1:
            message += f"Solo me falta {missing[0]}."
        else:
            message += "Aún me faltan los siguientes datos:\n"
            for item in missing:
                message += f"👉 {item}\n"
                
        return message
    
    @staticmethod
    def process_client_submission(message: str, course_id: int = None, previous_data: dict = None) -> dict:
        """
        Procesa los datos enviados por el cliente y genera la notificación.
        """
        result = {
            'pdf_generated': False,
            'notification_sent': False,
            'pdf_path': '',
            'segment': 'Sin clasificar',
            'error': None,
            'datos_completos': False,
            'client_data': {},
            'missing_data_message': '',
            'course_info': None
        }
        
        try:
            # Extraer datos del cliente
            new_client_data = AdvisorRequestManager.extract_client_data(message)
            
            # Combinar con datos previos si existen
            client_data = new_client_data
            if previous_data:
                client_data = AdvisorRequestManager.combine_client_data(previous_data, new_client_data)
            
            # Guardar datos en el resultado
            result['client_data'] = client_data
            result['datos_completos'] = client_data.get('datos_completos', False)
            
            # Predecir segmento si hay datos suficientes
            if client_data.get('sitio_web'):
                client_data['segmento'] = AdvisorRequestManager.predict_segment(client_data)
            result['segment'] = client_data.get('segmento', 'Sin clasificar')
            
            # Obtener información del curso si se proporciona
            course_info = None
            if course_id:
                course = CourseManager.get_course_by_id(course_id)
                if course:
                    course_info = course.to_dict()
                    result['course_info'] = course_info
            
            # Generar mensaje para solicitar datos faltantes
            if not client_data.get('datos_completos', False):
                result['missing_data_message'] = AdvisorRequestManager.get_missing_data_message(client_data)
                return result
            
            # Si hay datos completos, generar PDF y notificar
            pdf_path = AdvisorRequestManager.generate_client_pdf(client_data, course_info)
            if pdf_path:
                result['pdf_generated'] = True
                result['pdf_path'] = pdf_path
            
            # Enviar notificación al asesor
            if result['pdf_generated']:
                # Usar el nuevo servicio de asesor si está disponible
                try:
                    from services.advisor_service import advisor_service
                    
                    # Preparar detalles para notificación
                    details = {
                        'empresa': client_data.get('empresa', 'No especificado'),
                        'rfc': client_data.get('rfc', 'No especificado'),
                        'correo': client_data.get('correo', 'No especificado'),
                        'sitio_web': client_data.get('sitio_web', 'No especificado'),
                        'segmento': client_data.get('segmento', 'Sin clasificar')
                    }
                    
                    if course_info:
                        details['curso_id'] = course_info.get('id', 'No especificado')
                        details['curso_nombre'] = course_info.get('nombre', 'No especificado')
                    
                    # Enviar PDF al asesor
                    notify_result = advisor_service['send_pdf_to_advisor'](
                        pdf_path,
                        client_data.get('telefono', ''),
                        client_data.get('nombre', ''),
                        client_data.get('segmento', 'Sin clasificar'),
                        'Solicitud de asesor',
                        details
                    )
                    
                    result['notification_sent'] = notify_result.get('success', False)
                    
                except ImportError:
                    result['notification_sent'] = AdvisorRequestManager.send_notification_to_advisor(
                        pdf_path, client_data)
                
            return result
            
        except Exception as e:
            logger.error(f"Error al procesar datos del cliente: {e}")
            result['error'] = str(e)
            return result
