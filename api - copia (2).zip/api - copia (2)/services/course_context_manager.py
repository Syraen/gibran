from dataclasses import dataclass
from enum import Enum
from typing import List, Tuple, Optional


class CourseIntent(Enum):
    TEMARIO = 'temario'
    PRECIO = 'precio'
    FECHAS = 'fechas'
    INSCRIPCION = 'inscripcion'
    GENERAL = 'general'


@dataclass
class CourseContext:
    course_id: Optional[str] = None
    course_name: Optional[str] = None
    next_suggested_actions: List[str] = None


class CourseContextManager:


    @staticmethod
    def detect_course_intent(message: str, conversation_history: List[dict] = None) -> Tuple[CourseIntent, float]:

        if not message:
            return CourseIntent.GENERAL, 0.0

        text = message.lower()
        if any(k in text for k in ['temario', 'contenido', 'programa']):
            return CourseIntent.TEMARIO, 0.8
        if any(k in text for k in ['precio', 'cost', 'costo', 'cuesta', 'tarifa']):
            return CourseIntent.PRECIO, 0.8
        if any(k in text for k in ['fecha', 'fechas', 'horario', 'calendar']):
            return CourseIntent.FECHAS, 0.8
        if any(k in text for k in ['inscripcion', 'inscrib', 'registro', 'registrar']):
            return CourseIntent.INSCRIPCION, 0.8

        return CourseIntent.GENERAL, 0.25

    @staticmethod
    def get_enhanced_course_context(phone: str) -> Optional[CourseContext]:

        try:
            from services.conversation_memory import get_selected_course
        except Exception:
            try:
                from services.conversation_memory_utils import get_conversation_memory

                sel = get_conversation_memory(phone, 'selected_course')
                if sel:
                    return CourseContext(course_id=str(sel.get('id') or sel.get('course_id') or sel.get('_id')), course_name=sel.get('name') or sel.get('title'), next_suggested_actions=[])
                return None
            except Exception:
                return None

        try:
            sel = get_selected_course(phone)
            if not sel:
                return None
            cid = sel.get('id') if isinstance(sel, dict) else getattr(sel, 'id', None)
            cname = sel.get('name') if isinstance(sel, dict) else getattr(sel, 'name', None)
            return CourseContext(course_id=str(cid) if cid else None, course_name=cname, next_suggested_actions=[])
        except Exception:
            return None


__all__ = ['CourseIntent', 'CourseContextManager', 'CourseContext']
