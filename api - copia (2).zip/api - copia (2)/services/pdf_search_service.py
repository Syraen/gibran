import os
import json
import logging
import re
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path

try:
    _PDF_BACKEND = "pymupdf"
except Exception:
    fitz = None
    try:
        # fallback a PyPDF2 si está instalado
        import PyPDF2
        _PDF_BACKEND = "pypdf2"
    except Exception:
        PyPDF2 = None
        _PDF_BACKEND = None

from services.gemini_py import generate_reply
from config.config import GEMINI_API_KEY

# Configurar logging
logger = logging.getLogger(__name__)

class PDFSearchService:
    """
    Servicio para búsqueda inteligente de PDFs y extracción de información
    usando IA para análisis de contenido y búsqueda por productos.
    """
    
    def __init__(self):
        self.pdf_directory = Path("pdfs")
        self.info_directory = Path("info")
        self.products_directory = self.info_directory / "products" 
        self.courses_directory = self.info_directory / "courses"
        self.webinars_directory = self.info_directory / "webinars"
        
        # Cache para contenido de PDFs extraído
        self.pdf_cache = {}
        
        # Inicializar directorios si no existen
        self._ensure_directories()
        
        # Cargar metadatos de productos
        self.products_data = self._load_products_metadata()
        
    def _ensure_directories(self):
        """Crear directorios necesarios si no existen"""
        for directory in [self.pdf_directory, self.info_directory, 
                         self.products_directory, self.courses_directory, 
                         self.webinars_directory]:
            directory.mkdir(exist_ok=True)
    
    def _load_products_metadata(self) -> Dict[str, Any]:
        """Cargar metadatos de productos desde archivos JSON"""
        products = {}
        
        if self.products_directory.exists():
            for json_file in self.products_directory.glob("*.json"):
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        product_data = json.load(f)
                        # Usar el ID o nombre como clave
                        key = str(product_data.get('id', product_data.get('nombre', json_file.stem)))
                        products[key] = product_data
                except Exception as e:
                    logger.error(f"Error cargando producto {json_file}: {e}")
        
        return products
    
    def extract_text_from_pdf(self, pdf_path: Path) -> str:
        """Extraer texto completo de un archivo PDF"""
        try:
            if str(pdf_path) in self.pdf_cache:
                return self.pdf_cache[str(pdf_path)]
            
            doc = fitz.open(pdf_path)
            text_content = ""
            
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text_content += page.get_text()
                text_content += "\n" + "="*50 + f" PÁGINA {page_num + 1} " + "="*50 + "\n"
            
            doc.close()
            
            # Guardar en cache
            self.pdf_cache[str(pdf_path)] = text_content
            
            return text_content
            
        except Exception as e:
            logger.error(f"Error extrayendo texto de {pdf_path}: {e}")
            return ""
    
    def find_pdfs_by_keywords(self, keywords: List[str]) -> List[Path]:
        """Buscar PDFs que contengan palabras clave en el nombre del archivo"""
        if not self.pdf_directory.exists():
            return []
        
        matching_pdfs = []
        pdf_files = list(self.pdf_directory.glob("*.pdf"))
        
        for pdf_file in pdf_files:
            filename_lower = pdf_file.name.lower()
            
            # Verificar si alguna palabra clave está en el nombre del archivo
            for keyword in keywords:
                if keyword.lower() in filename_lower:
                    matching_pdfs.append(pdf_file)
                    break
        
        return matching_pdfs
    
    def search_product_in_pdfs(self, product_query: str) -> Tuple[Optional[Path], str, Dict]:
        """
        Buscar información de producto específico en PDFs
       
        """
        logger.info(f"Búsqueda de producto: {product_query}")
        
        # Paso 1: Buscar en metadatos de productos
        matching_product = self._find_matching_product(product_query)
        
        # Paso 2: Generar palabras clave para búsqueda de PDFs
        search_keywords = self._generate_search_keywords(product_query, matching_product)
        
        # Paso 3: Buscar PDFs relevantes
        candidate_pdfs = self.find_pdfs_by_keywords(search_keywords)
        
        # Si no hay PDFs candidatos, buscar en todos los PDFs
        if not candidate_pdfs:
            candidate_pdfs = list(self.pdf_directory.glob("*.pdf"))
        
        # Paso 4: Analizar PDFs con IA para encontrar el más relevante
        best_pdf, best_content = self._analyze_pdfs_with_ai(candidate_pdfs, product_query, matching_product)
        
        return best_pdf, best_content, matching_product or {}
    
    def _find_matching_product(self, query: str) -> Optional[Dict]:
        """Buscar producto que coincida con la consulta"""
        query_lower = query.lower()
        
        for product_data in self.products_data.values():
            # Buscar por nombre
            if 'nombre' in product_data:
                if query_lower in product_data['nombre'].lower():
                    return product_data
            
            # Buscar por ID
            if 'id' in product_data:
                if str(product_data['id']) == query or query_lower in str(product_data['id']).lower():
                    return product_data
            
            # Buscar en especificaciones
            if 'especificaciones' in product_data:
                for spec in product_data['especificaciones']:
                    if query_lower in spec.lower():
                        return product_data
        
        return None
    
    def _generate_search_keywords(self, query: str, product_data: Optional[Dict] = None) -> List[str]:
        """Generar palabras clave para búsqueda de PDFs"""
        keywords = []
        
        # Palabras de la consulta original
        query_words = re.findall(r'\b\w+\b', query.lower())
        keywords.extend(query_words)
        
        if product_data:
            # Palabras del nombre del producto
            if 'nombre' in product_data:
                product_words = re.findall(r'\b\w+\b', product_data['nombre'].lower())
                keywords.extend(product_words)
            
            # ID del producto
            if 'id' in product_data:
                keywords.append(str(product_data['id']))
        
        # Palabras clave técnicas comunes
        technical_keywords = ['ficha', 'tecnica', 'especificaciones', 'datasheet', 'spec']
        keywords.extend(technical_keywords)
        
        return list(set(keywords))  # Eliminar duplicados
    
    def _analyze_pdfs_with_ai(self, pdf_files: List[Path], query: str, product_data: Optional[Dict] = None) -> Tuple[Optional[Path], str]:
        """Usar IA para analizar PDFs y encontrar el más relevante"""
        if not pdf_files:
            return None, ""
        
        best_pdf = None
        best_content = ""
        best_score = 0
        
        # Contexto del producto para la IA
        product_context = ""
        if product_data:
            product_context = f"""
INFORMACIÓN DEL PRODUCTO BUSCADO:
- Nombre: {product_data.get('nombre', 'N/A')}
- ID: {product_data.get('id', 'N/A')}
- Descripción: {product_data.get('descripcion', 'N/A')}
- Especificaciones: {', '.join(product_data.get('especificaciones', []))}
"""
        
        for pdf_file in pdf_files[:5]:  # Limitar a 5 PDFs para no sobrecargar
            try:
                logger.info(f"Analizando PDF: {pdf_file.name}")
                
                # Extraer texto del PDF
                pdf_content = self.extract_text_from_pdf(pdf_file)
                
                if not pdf_content.strip():
                    continue
                
                # Truncar contenido si es muy largo
                if len(pdf_content) > 8000:
                    pdf_content = pdf_content[:8000] + "\n... [CONTENIDO TRUNCADO] ..."
                
                # Prompt para que la IA evalúe la relevancia
                analysis_prompt = f"""
TAREA: Analizar si este PDF contiene información sobre el producto solicitado.

CONSULTA DEL USUARIO: "{query}"

{product_context}

CONTENIDO DEL PDF "{pdf_file.name}":
{pdf_content}

INSTRUCCIONES:
1. Evalúa si este PDF contiene información relevante sobre el producto buscado
2. Asigna una puntuación de relevancia del 1 al 10 (10 = muy relevante)
3. Si es relevante (puntuación >= 7), extrae la información más importante del producto

RESPONDE EN ESTE FORMATO:
RELEVANCIA: [número del 1-10]
RAZÓN: [explicación breve]
INFORMACIÓN_EXTRAÍDA: [información relevante del producto si puntuación >= 7]
"""
                
                ai_response = generate_reply(analysis_prompt, temperature=0.3, max_tokens=800)
                
                # Parsear respuesta de la IA
                relevance_score = self._extract_relevance_score(ai_response)
                
                logger.info(f"PDF {pdf_file.name} - Puntuación: {relevance_score}")
                
                if relevance_score > best_score:
                    best_score = relevance_score
                    best_pdf = pdf_file
                    best_content = ai_response
                
            except Exception as e:
                logger.error(f"Error analizando PDF {pdf_file}: {e}")
                continue
        
        return best_pdf, best_content
    
    def _extract_relevance_score(self, ai_response: str) -> int:
        """Extraer puntuación de relevancia de la respuesta de la IA"""
        try:
            # Buscar patrón "RELEVANCIA: X"
            match = re.search(r'RELEVANCIA:\s*(\d+)', ai_response, re.IGNORECASE)
            if match:
                return int(match.group(1))
            
            # Buscar números del 1-10 en la respuesta
            numbers = re.findall(r'\b([1-9]|10)\b', ai_response)
            if numbers:
                return int(numbers[0])
            
        except:
            pass
        
        return 0
    
    def get_product_datasheet(self, product_query: str) -> Dict[str, Any]:
        """
        Obtener ficha técnica de un producto específico
      
        """
        try:
            pdf_file, ai_analysis, product_metadata = self.search_product_in_pdfs(product_query)
            
            result = {
                'success': False,
                'product_query': product_query,
                'found_pdf': None,
                'pdf_path': None,
                'product_info': {},
                'ai_analysis': '',
                'metadata': product_metadata
            }
            
            if pdf_file and ai_analysis:
                # Extraer información técnica específica usando IA
                technical_info = self._extract_technical_specifications(ai_analysis, product_query)
                
                result.update({
                    'success': True,
                    'found_pdf': pdf_file.name,
                    'pdf_path': str(pdf_file),
                    'product_info': technical_info,
                    'ai_analysis': ai_analysis
                })
                
                logger.info(f"Ficha técnica encontrada: {pdf_file.name}")
            else:
                logger.warning(f"No se encontró ficha técnica para: {product_query}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error obteniendo ficha técnica: {e}")
            return {
                'success': False,
                'error': str(e),
                'product_query': product_query
            }
    
    def _extract_technical_specifications(self, ai_analysis: str, product_query: str) -> Dict[str, Any]:
        """Extraer especificaciones técnicas específicas usando IA"""
        try:
            extraction_prompt = f"""
TAREA: Extraer especificaciones técnicas específicas del análisis del PDF.

PRODUCTO CONSULTADO: "{product_query}"

ANÁLISIS PREVIO:
{ai_analysis}

INSTRUCCIONES:
Extrae y organiza la información técnica más importante en formato JSON:
- Nombre del producto
- Especificaciones técnicas principales
- Dimensiones (si aplica)
- Materiales
- Certificaciones
- Precio (si está disponible)
- Cualquier información técnica relevante

RESPONDE SOLO CON UN JSON VÁLIDO:
"""
            
            ai_response = generate_reply(extraction_prompt, temperature=0.2, max_tokens=600)
            
            # Intentar parsear como JSON
            try:
                # Buscar JSON en la respuesta
                json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group())
            except:
                pass
            
            # Si no se puede parsear como JSON, devolver texto estructurado
            return {
                'raw_specifications': ai_response,
                'extraction_method': 'text_analysis'
            }
            
        except Exception as e:
            logger.error(f"Error extrayendo especificaciones: {e}")
            return {'error': str(e)}
    
    def search_product_info(self, product_query: str, user_question: str) -> str:
        """
        Buscar información específica de un producto basada en una pregunta del usuario
        
       
        """
        try:
            # Buscar el PDF y información del producto
            pdf_file, ai_analysis, product_metadata = self.search_product_in_pdfs(product_query)
            
            if not pdf_file or not ai_analysis:
                return f"No encontré información específica sobre '{product_query}'. ¿Podrías ser más específico con el nombre o código del producto?"
            
            # Extraer el contenido completo del PDF para análisis detallado
            full_pdf_content = self.extract_text_from_pdf(pdf_file)
            
            # Truncar si es muy largo
            if len(full_pdf_content) > 6000:
                full_pdf_content = full_pdf_content[:6000] + "\n... [CONTENIDO TRUNCADO] ..."
            
            # Contexto del producto
            product_context = ""
            if product_metadata:
                product_context = f"""
INFORMACIÓN BASE DEL PRODUCTO:
- Nombre: {product_metadata.get('nombre', 'N/A')}
- Descripción: {product_metadata.get('descripcion', 'N/A')}
- Precio: {product_metadata.get('precio', 'N/A')}
"""
            
            # Prompt para respuesta específica
            answer_prompt = f"""
ERES UN EXPERTO TÉCNICO de FIBREMEX especializado en productos de telecomunicaciones.

CONSULTA DEL USUARIO: "{user_question}"
PRODUCTO: "{product_query}"

{product_context}

INFORMACIÓN TÉCNICA DETALLADA (PDF: {pdf_file.name}):
{full_pdf_content}

INSTRUCCIONES:
1. Responde ESPECÍFICAMENTE lo que el usuario pregunta sobre este producto
2. Usa la información técnica del PDF como fuente principal
3. Si la información no está en el PDF, indícalo claramente
4. Sé preciso y técnico, pero fácil de entender
5. Mantén el contexto del producto durante toda la respuesta
6. Si hay especificaciones técnicas relevantes, inclúyelas

RESPONDE DE FORMA DIRECTA Y ÚTIL:
"""
            
            response = generate_reply(answer_prompt, temperature=0.4, max_tokens=800)
            
            logger.info(f"Información encontrada para {product_query}: {pdf_file.name}")
            
            return response
            
        except Exception as e:
            logger.error(f"Error buscando información del producto: {e}")
            return f"Disculpa, hubo un error al buscar información sobre '{product_query}'. Por favor intenta de nuevo."
    
    def list_available_products(self) -> List[str]:
        """Listar productos disponibles en el sistema"""
        products = []
        
        # Productos de metadata
        for product_data in self.products_data.values():
            if 'nombre' in product_data:
                products.append(product_data['nombre'])
        
        # PDFs disponibles
        if self.pdf_directory.exists():
            pdf_files = [f.stem for f in self.pdf_directory.glob("*.pdf")]
            products.extend(pdf_files)
        
        return sorted(list(set(products)))
    
    def get_pdf_file_path(self, product_query: str) -> Optional[str]:
        """Obtener la ruta del archivo PDF para un producto específico"""
        try:
            pdf_file, _, _ = self.search_product_in_pdfs(product_query)
            return str(pdf_file) if pdf_file else None
        except Exception as e:
            logger.error(f"Error obteniendo ruta PDF: {e}")
            return None


# Instancia global del servicio
pdf_search_service = PDFSearchService()


def search_product_datasheet(product_query: str) -> Dict[str, Any]:
    """Función de conveniencia para buscar ficha técnica"""
    return pdf_search_service.get_product_datasheet(product_query)


def answer_product_question(product_query: str, user_question: str) -> str:
    """Función de conveniencia para responder preguntas sobre productos"""
    return pdf_search_service.search_product_info(product_query, user_question)


def get_product_pdf_path(product_query: str) -> Optional[str]:
    """Función de conveniencia para obtener ruta de PDF"""
    return pdf_search_service.get_pdf_file_path(product_query)