"""
Servicio de Machine Learning para el chatbot de Fibremex.

Este módulo implementa funcionalidades de ML para:
1. Clasificación de mensajes (soporte, ventas, quejas, etc.)
2. Extracción de datos de clientes (nombre, RFC, correo, etc.)
3. Segmentación de clientes (Integrador, WISP, ISP, etc.)
4. Predicción de leads 
"""

import re
import os
import json
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime
from fpdf import FPDF

try:
    import spacy
    import sklearn
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report
    from sklearn.preprocessing import LabelEncoder
    import joblib
    ML_AVAILABLE = True
except ImportError:
    logging.warning("Machine Learning libraries not available. Some features will be disabled.")
    ML_AVAILABLE = False

# Configurar logging
logger = logging.getLogger("ml_service")
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

try:
    nlp = spacy.load("es_core_news_md")
    NLP_AVAILABLE = True
    logger.info("SpaCy model loaded successfully")
except:
    logger.warning("SpaCy model not available. Using fallback methods for extraction.")
    NLP_AVAILABLE = False

# Constantes para clasificación
MESSAGE_CATEGORIES = [
    'soporte_tecnico',
    'ventas',
    'cotizacion',
    'precios',
    'pagos',
    'quejas',
    'contacto_asesor',
    'info_general',
    'cursos',
    'webinars'
]

# Lista de segmentos de clientes
CLIENT_SEGMENTS = [
    'Integrador',
    'Constructora',
    'WISP',
    'ISP',
    'Carrier',
    'Data Center',
    'Distribuidor',
    'Usuario Final',
    'Gobierno',
    'Consultor-Distribuidor-Integrador',
    'Distribuidor-Eléctrico',
    'Distribuidor-Integrador',
    'Distribuidor-Computo',
    'Electrico',
    'Integrador-Eléctrico',
    'Integrador-Consultor',
    'Integrador-Data center',
    'Integrador-Minero',
    'ISP/WISP'
]

# Palabras clave asociadas a cada segmento
SEGMENT_KEYWORDS = {
    'Integrador': ['integración', 'soluciones', 'proyectos', 'implementación', 'redes'],
    'Constructora': ['construcción', 'obra', 'inmuebles', 'edificación', 'proyecto'],
    'WISP': ['wisp', 'internet inalámbrico', 'wireless', 'servicio internet'],
    'ISP': ['isp', 'internet', 'proveedor servicios', 'banda ancha'],
    'Carrier': ['carrier', 'telecomunicaciones', 'backbone', 'transporte datos'],
    'Data Center': ['data center', 'centro de datos', 'servidores', 'hosting', 'colocation'],
    'Distribuidor': ['distribuidor', 'mayorista', 'canal', 'reseller', 'venta productos'],
    'Usuario Final': ['usuario', 'cliente', 'empresa', 'particular', 'consumidor final'],
    'Gobierno': ['gobierno', 'sector público', 'administración', 'oficial', 'municipal'],
}

class MessageClassifier:
    """
    Clasificador de mensajes basado en ML para determinar la categoría 
    y la intención del usuario.
    """
    def __init__(self, model_path: str = None):
        self.model = None
        self.vectorizer = None
        self.label_encoder = None
        self.model_path = model_path or os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 
            'models', 'message_classifier.joblib'
        )
        self._load_model()
    
    def _load_model(self):
        if not ML_AVAILABLE:
            logger.warning("ML libraries not available, using rule-based classification")
            return
            
        try:
            if os.path.exists(self.model_path):
                loaded = joblib.load(self.model_path)
                # Support two formats: a) a sklearn Pipeline saved directly
                # b) a dict {'pipeline': Pipeline, 'label_encoder': LabelEncoder}
                if isinstance(loaded, dict):
                    self.model = loaded.get('pipeline')
                    self.label_encoder = loaded.get('label_encoder')
                    logger.info(f"Model (dict) loaded from {self.model_path}; pipeline and label_encoder set")
                else:
                    self.model = loaded
                    logger.info(f"Model loaded from {self.model_path}")
                # If label_encoder not set, try companion file
                if not self.label_encoder:
                    label_path = os.path.splitext(self.model_path)[0] + '_label_encoder.joblib'
                    if os.path.exists(label_path):
                        try:
                            self.label_encoder = joblib.load(label_path)
                            logger.info(f"Label encoder loaded from {label_path}")
                        except Exception:
                            logger.debug(f"Failed loading label encoder from {label_path}")
            else:
                logger.info("No model found, using rule-based classification")
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            
    def _rule_based_classification(self, message: str) -> Dict[str, float]:
        message = message.lower()
        categories = {cat: 0.0 for cat in MESSAGE_CATEGORIES}
        
        # Palabras clave por categoría
        keywords = {
            'soporte_tecnico': ['error', 'problema', 'falla', 'no funciona', 'ayuda', 'soporte', 'técnico'],
            'ventas': ['comprar', 'adquirir', 'vender', 'venta', 'producto', 'equipo'],
            'cotizacion': ['cotización', 'cotizar', 'costo', 'presupuesto', 'precio'],
            'precios': ['precio', 'costo', 'cuánto cuesta', 'valor', 'tarifa'],
            'pagos': ['pago', 'factura', 'abonar', 'pagar', 'transferencia'],
            'quejas': ['queja', 'molesto', 'insatisfecho', 'problema', 'mal servicio'],
            'contacto_asesor': ['asesor', 'hablar', 'representante', 'atención', 'contactar'],
            'info_general': ['información', 'datos', 'detalles', 'catálogo'],
            'cursos': ['curso', 'capacitación', 'taller', 'entrenamiento', 'aprender'],
            'webinars': ['webinar', 'seminario', 'online', 'virtual', 'conferencia']
        }
        
        # Detectar palabras clave en el mensaje
        for category, words in keywords.items():
            for word in words:
                if word in message:
                    categories[category] += 0.3
                    
        total = sum(categories.values())
        if total > 0:
            for cat in categories:
                categories[cat] /= total
        else:
            categories['info_general'] = 1.0
            
        return categories
    
    def classify(self, message: str) -> Dict[str, Any]:
        if not message or not isinstance(message, str):
            return {
                'category': 'info_general',
                'probabilities': {'info_general': 1.0},
                'confidence': 0.0,
                'requires_human': False
            }
            
        if ML_AVAILABLE and self.model:
            try:
                # Preprocesar mensaje
                processed_msg = message.lower()
                
                probabilities = self.model.predict_proba([processed_msg])[0]
                
                # Obtener categoría y etiquetas
                categories = self.label_encoder.classes_
                category_probs = {cat: float(prob) for cat, prob in zip(categories, probabilities)}
                
                # Obtener categoría principal
                main_category = max(category_probs, key=category_probs.get)
                confidence = category_probs[main_category]
                
                return {
                    'category': main_category,
                    'probabilities': category_probs,
                    'confidence': float(confidence),
                    'requires_human': confidence < 0.6  
                }
            except Exception as e:
                logger.error(f"Error during ML classification: {e}")
        
        category_probs = self._rule_based_classification(message)
        main_category = max(category_probs, key=category_probs.get)
        confidence = category_probs[main_category]

        # Forzar intervención humana para temas sensibles/financieros o cuando aparezcan keywords
        lower_msg = (message or '').lower()
        force_human_keywords = ['cotiz', 'cotización', 'factura', 'facturación', 'pago', 'facturar', 'recibo', 'nota fiscal', 
                               'queja', 'problema urgente', 'cancelar', 'reembolso', 'urgente', 'gerente', 'supervisor']
        force_human_categories = {'cotizacion', 'pagos', 'precios', 'quejas'}

        requires_human = confidence < 0.4 or main_category in force_human_categories or any(k in lower_msg for k in force_human_keywords)
        
        # Detectar casos adicionales que requieren intervención humana
        complex_cases = ['no entiendo', 'no me ayuda', 'mal servicio', 'estoy molesto', 'quiero hablar con una persona']
        if any(case in lower_msg for case in complex_cases):
            requires_human = True

        return {
            'category': main_category,
            'probabilities': category_probs,
            'confidence': confidence,
            'requires_human': requires_human
        }
    
    def train(self, data: List[Tuple[str, str]]) -> None:
        """
        Entrena el modelo con datos nuevos
        """
        if not ML_AVAILABLE:
            logger.error("Cannot train model: ML libraries not available")
            return
            
        try:
            # Preparar datos
            messages, labels = zip(*data)
            
            # Crear pipeline de clasificación
            self.vectorizer = TfidfVectorizer(
                ngram_range=(1, 2), 
                min_df=2, 
                max_df=0.85
            )
            
            self.label_encoder = LabelEncoder()
            encoded_labels = self.label_encoder.fit_transform(labels)
            
            # Crear y entrenar modelo
            self.model = Pipeline([
                ('vectorizer', self.vectorizer),
                ('classifier', MultinomialNB())
            ])
            
            self.model.fit(messages, encoded_labels)
            
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            logger.info(f"Model trained and saved to {self.model_path}")
            
        except Exception as e:
            logger.error(f"Error training model: {e}")


class DataExtractor:
    """
    Extrae datos estructurados de mensajes de texto, como información de clientes.
    """
    def __init__(self):
        self.patterns = {
            'nombre': r'(?i)(?:mi nombre|me llamo|soy)[^\w]*([\w\s]+?)(?:[,\.]|$|\s(?:de|del|y|con))',
            'empresa': r'(?i)(?:empresa|compañía|compania|organización|negocio)[^\w]*([\w\s]+?)(?:[,\.]|$|\s(?:de|del|y|con))',
            'rfc': r'(?i)(?:rfc|registro fiscal)[\s:]*([A-Z0-9]{10,13})',
            'razon_social': r'(?i)(?:razón social|razon social)[\s:]*([^,\.\n]{5,50})',
            'correo': r'[\w\.-]+@[\w\.-]+\.\w+',
            'web': r'(?:https?://)?(?:www\.)?[\w-]+\.[\w\.-]+(?:/[\w\.-]*)*'
        }
    
    def extract_entities_rule_based(self, text: str) -> Dict[str, str]:
        """
        Extrae entidades usando expresiones regularess
        """
        result = {}
        
        for entity, pattern in self.patterns.items():
            matches = re.findall(pattern, text)
            if matches:
                # Tomar la coincidencia más larga o la primera
                if entity in ['nombre', 'empresa', 'razon_social']:
                    matches = [match.strip() for match in matches if len(match.strip()) > 2]
                    if matches:
                        result[entity] = max(matches, key=len).strip()
                else:
                    result[entity] = matches[0].strip()
        
        if 'nombre' not in result:
            lines = text.split('\n')
            for line in lines:
                if re.match(r'(?i)^[\s*•.:-]*(?:nombre|me llamo)', line):
                    name_part = re.sub(r'(?i)^[\s*•.:-]*(?:nombre|me llamo)[\s*•.:-]*', '', line).strip()
                    if name_part:
                        result['nombre'] = name_part

        
        try:
            if 'nombre' not in result and text:
                text_stripped = text.strip()
                words = re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñüÜ]+", text_stripped)
                if 2 <= len(words) <= 4 and len(text_stripped) <= 60:
                    lower = text_stripped.lower()
                    skip_keywords = ['quiero', 'necesito', 'asesor', 'precio', 'cotización', 'contacto', 'hola', 'gracias']
                    if not any(k in lower for k in skip_keywords):
                        result['nombre'] = ' '.join(words).strip()
        except Exception:
            pass
        
        return result
    
    def extract_entities_spacy(self, text: str) -> Dict[str, str]:

        if not NLP_AVAILABLE:
            return {}
            
        result = {}
        doc = nlp(text)
        
        for ent in doc.ents:
            if ent.label_ == 'PER' and 'nombre' not in result:
                result['nombre'] = ent.text
            elif ent.label_ == 'ORG' and 'empresa' not in result:
                result['empresa'] = ent.text
        
        correo_matches = re.findall(self.patterns['correo'], text)
        if correo_matches:
            result['correo'] = correo_matches[0]
            
        web_matches = re.findall(self.patterns['web'], text)
        if web_matches:
            result['web'] = web_matches[0]
        
        return result
    
    def extract_client_data(self, conversation_history: List[Dict[str, Any]]) -> Dict[str, str]:
        
        all_client_data = {}
        
        # Primero intentamos con spaCy si está disponible
        if NLP_AVAILABLE:
            for message in conversation_history:
                if message.get('from_client', True):
                    text = message.get('text', '')
                    if text:
                        entities = self.extract_entities_spacy(text)
                        all_client_data.update(entities)
        
        # Complementamos con la extracción basada en reglas
        for message in conversation_history:
            if message.get('from_client', True):
                text = message.get('text', '')
                if text:
                    entities = self.extract_entities_rule_based(text)
                    # Solo actualizamos campos que no se hayan extraído con spaCy
                    for key, value in entities.items():
                        if key not in all_client_data or not all_client_data[key]:
                            all_client_data[key] = value
        
        return all_client_data
    
    def predict_segment(self, client_data: Dict[str, str]) -> str:
        """
        Predice el segmento del cliente basado en los datos extraídos
        """
        # Texto a analizar: combinamos empresa, web y mensajes
        text_to_analyze = ' '.join([
            client_data.get('empresa', ''),
            client_data.get('web', ''),
            client_data.get('mensajes', '')
        ]).lower()
        
        if not text_to_analyze:
            return "No determinado"
            
        # Conteo de keywords por segmento
        segment_scores = {segment: 0 for segment in CLIENT_SEGMENTS}
        
        for segment, keywords in SEGMENT_KEYWORDS.items():
            for keyword in keywords:
                if keyword.lower() in text_to_analyze:
                    segment_scores[segment] += 1
        
        # Determinar el segmento con mayor score
        best_segment = max(segment_scores.items(), key=lambda x: x[1])
        
        # Si no hay coincidencias claras
        if best_segment[1] == 0:
            return "No determinado"
            
        return best_segment[0]


class PDFGenerator:
    """
    Genera PDFs con la información de clientes para asesores.
    """
    def __init__(self):
        self.pdf_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 
            'pdfs'
        )
        os.makedirs(self.pdf_dir, exist_ok=True)
    
    def generate_client_profile_pdf(self, client_data: Dict[str, str], 
                                    classification_info: Dict[str, Any]) -> str:
        """
        Genera un PDF con el perfil del cliente y la clasificación de su consulta
        """
        pdf = FPDF()
        pdf.add_page()
        
        # Configurar fuente
        pdf.set_font("Arial", size=12)
        
        # Título
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(200, 10, "Perfil de Cliente - Fibremex", ln=True, align='C')
        pdf.ln(10)
        
        # Fecha y hora
        pdf.set_font("Arial", 'I', 10)
        pdf.cell(200, 10, f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}", ln=True)
        pdf.ln(5)
        
        # Datos del cliente
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(200, 10, "INFORMACIÓN DEL CLIENTE:", ln=True)
        pdf.ln(5)
        
        # Campos de cliente (aceptar alias en inglés/otros formatos)
        nombre = client_data.get('nombre') or client_data.get('name') or client_data.get('cliente') or 'No proporcionado'
        empresa = client_data.get('empresa') or client_data.get('company') or ''
        rfc = client_data.get('rfc') or client_data.get('razon_social') or ''
        email = client_data.get('correo') or client_data.get('email') or ''
        web = client_data.get('web') or client_data.get('website') or ''
        telefono = client_data.get('telefono') or client_data.get('phone') or client_data.get('tel') or ''
        segment = client_data.get('segmento') or client_data.get('segment') or 'No determinado'

        pdf.set_font("Arial", '', 11)
        fields = [
            ("Nombre", nombre),
            ("Empresa", empresa or 'No proporcionada'),
            ("Necesidad / Solicitud", client_data.get('necesidad') or client_data.get('mensajes') or ''),
            ("RFC / Razón Social", rfc or 'No proporcionado'),
            ("Teléfono", telefono or 'No proporcionado'),
            ("Correo electrónico", email or 'No proporcionado'),
            ("Sitio web", web or 'No proporcionado'),
            ("Segmento", segment)
        ]

        for label, value in fields:
            pdf.set_font("Arial", 'B', 11)
            pdf.cell(60, 10, f"{label}:", align='L')
            pdf.set_font("Arial", '', 11)
            # protect very long values by truncating
            if value and len(value) > 120:
                value = value[:117] + '...'
            pdf.cell(130, 10, value, ln=True, align='L')
        
        pdf.ln(10)
        
        # Clasificación del mensaje
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(200, 10, "CLASIFICACIÓN DE LA CONSULTA:", ln=True)
        pdf.ln(5)
        
        category = classification_info.get('category', 'No clasificada')
        confidence = classification_info.get('confidence', 0.0) * 100
        
        pdf.set_font("Arial", 'B', 11)
        pdf.cell(60, 10, "Categoría:", align='L')
        pdf.set_font("Arial", '', 11)
        pdf.cell(130, 10, category.replace('_', ' ').title(), ln=True, align='L')
        
        pdf.set_font("Arial", 'B', 11)
        pdf.cell(60, 10, "Confianza:", align='L')
        pdf.set_font("Arial", '', 11)
        pdf.cell(130, 10, f"{confidence:.1f}%", ln=True, align='L')
        
        pdf.set_font("Arial", 'B', 11)
        pdf.cell(60, 10, "Requiere atención:", align='L')
        pdf.set_font("Arial", '', 11)
        requires_human = "Sí" if classification_info.get('requires_human', False) else "No"
        pdf.cell(130, 10, requires_human, ln=True, align='L')
        
        # Guardar PDF
        # Build filename: <clientname>_<YYYYMMDD>_<count>.pdf
        date_part = datetime.now().strftime("%Y%m%d")
        raw_name = client_data.get('nombre', '') or client_data.get('empresa', '') or 'cliente'
        client_name = re.sub(r'[^A-Za-z0-9_-]', '_', raw_name).strip('_')[:30] or 'cliente'

        # Determine sequential count for today for this client
        existing = [f for f in os.listdir(self.pdf_dir) if f.startswith(f"{client_name}_{date_part}_") and f.lower().endswith('.pdf')]
        max_count = 0
        for f in existing:
            try:
                parts = f.rsplit('.', 1)[0].split('_')
                # expect: name_YYYYMMDD_count
                cnt = int(parts[-1])
                if cnt > max_count:
                    max_count = cnt
            except Exception:
                continue

        next_count = max_count + 1
        filename = f"{client_name}_{date_part}_{next_count}.pdf"
        filepath = os.path.join(self.pdf_dir, filename)

        pdf.output(filepath)

        return filepath


class LeadPredictor:
    """
    Predice si un cliente es un lead caliente o frío basado en la conversación.
    """
    def __init__(self):
        self.hot_lead_indicators = [
            'precio', 'cotización', 'cotizar', 'comprar', 'adquirir',
            'costo', 'pago', 'inmediato', 'urgente', 'cuánto cuesta',
            'necesito ya', 'disponibilidad', 'enviar', 'stock'
        ]
        
        self.cold_lead_indicators = [
            'información', 'catálogo', 'preguntar', 'duda',
            'solo quiero saber', 'más adelante', 'estoy investigando',
            'comparando', 'opciones', 'alternativas'
        ]
    
    def predict_lead_type(self, conversation_history: List[Dict[str, Any]]) -> Dict[str, Any]:
       
        # Combinar todos los mensajes del cliente
        client_text = ""
        for message in conversation_history:
            if message.get('from_client', True):
                text = message.get('text', '')
                if text:
                    client_text += " " + text.lower()
        
        hot_count = 0
        cold_count = 0
        
        for indicator in self.hot_lead_indicators:
            if indicator.lower() in client_text:
                hot_count += 1
                
        for indicator in self.cold_lead_indicators:
            if indicator.lower() in client_text:
                cold_count += 1
        
        if hot_count > cold_count:
            lead_type = "caliente"
            confidence = min(0.9, 0.5 + 0.1 * (hot_count - cold_count))
        elif cold_count > hot_count:
            lead_type = "frío"
            confidence = min(0.9, 0.5 + 0.1 * (cold_count - hot_count))
        else:
            lead_type = "neutro"
            confidence = 0.5
        
        return {
            'lead_type': lead_type,
            'confidence': confidence,
            'hot_indicators': hot_count,
            'cold_indicators': cold_count
        }


class MLService:
   
    def __init__(self):
        self.classifier = MessageClassifier()
        self.extractor = DataExtractor()
        self.pdf_generator = PDFGenerator()
        self.lead_predictor = LeadPredictor()
        # Caches for local course/webinar data
        self._courses = None
        self._webinars = None
        logger.info("ML Service initialized")
    
    def process_message(self, message: str, conversation_history: List[Dict[str, Any]] = None, phone: str = None) -> Dict[str, Any]:
        """
        Procesa un mensaje del usuario aplicando todas las capacidades de ML
        
        """
        result = {
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        
        # Clasificar mensaje
        classification = self.classifier.classify(message)
        result['classification'] = classification
        
        # Preparar historial si no se proporciona
        if conversation_history is None:
            conversation_history = [{'text': message, 'from_client': True}]
        
        # Extraer datos del cliente
        client_data = self.extractor.extract_client_data(conversation_history)
        
        # Predecir segmento si tenemos suficientes datos
        if client_data.get('empresa') or client_data.get('web'):
            # Añadir mensajes al contexto para mejor predicción
            client_data['mensajes'] = ' '.join([
                msg.get('text', '') for msg in conversation_history 
                if msg.get('from_client', True)
            ])
            
            segment = self.extractor.predict_segment(client_data)
            client_data['segmento'] = segment
        
        result['client_data'] = client_data
        
        # Predecir tipo de lead
        lead_prediction = self.lead_predictor.predict_lead_type(conversation_history)
        result['lead_prediction'] = lead_prediction
        
        # Determinar si necesita atención humana
        requires_human = (
            classification.get('requires_human', False) or
            (lead_prediction.get('lead_type') == 'caliente' and lead_prediction.get('confidence', 0) > 0.7)
        )

        result['requires_human_attention'] = requires_human
        try:
            mq = (message or '').lower()
            is_course_intent = classification.get('category') == 'cursos' or any(k in mq for k in ['curso', 'cursos'])
            is_webinar_intent = classification.get('category') == 'webinars' or any(k in mq for k in ['webinar', 'webinars', 'seminario', 'seminarios'])

            if is_course_intent or is_webinar_intent:
                kind = 'course' if is_course_intent else 'webinar'
                try:
                    reply = self.answer_course_or_webinar_query(message, kind=kind)
                    if reply:
                        if 'bot_reply' in result and result['bot_reply']:
                            result['bot_reply'] = result['bot_reply'] + "\n\n" + reply
                        else:
                            result['bot_reply'] = reply
                except Exception as e:
                    logger.debug(f"Error answering course/webinar query: {e}")

                
                advisor_request_keywords = ['asesor', 'hablar con', 'contactar', 'contacto', 'hablar con un asesor', 'inscrib', 'inscripción', 'inscripcion', 'cotiz', 'pagar', 'precio', 'factura']
                if any(k in mq for k in advisor_request_keywords):
                    # allow normal requires_human handling below
                    pass
                else:
                    requires_human = False
                    result['requires_human_attention'] = False
        except Exception as e:
            logger.debug(f"Error attempting to answer course/webinar query: {e}")

        # Si requiere atención humana, generar PDF con datos y notificar al asesor
        if requires_human:
            try:
                # Detectar teléfono en el historial (patrón simple)
                phone = client_data.get('telefono') or client_data.get('phone') or None
                if not phone:
                    for m in conversation_history:
                        if m.get('from_client', True):
                            phones = re.findall(r"\+?\d{10,15}", m.get('text', ''))
                            if phones:
                                phone = phones[0]
                                break

                if phone:
                    client_data['telefono'] = phone

                # Preferir iniciar el flujo guiado de asesor si aún no está en progreso
                try:
                    if not phone:
                        logger.info("No phone provided to process_message: cannot start advisor flow here. Returning advisor_action_needed flag.")
                        result['advisor_action_needed'] = True
                        return result

                    # Import dinámico para evitar circular imports
                    start_fn = None
                    try:
                        from routes.whatsapp import start_advisor_flow
                        start_fn = start_advisor_flow
                    except Exception:
                        # Intentar fallback al nuevo módulo advisor_simple
                        try:
                            from services.advisor_simple import start_advisor_simple
                            start_fn = start_advisor_simple
                        except Exception as e:
                            logger.debug(f"No start function available to initiate advisor flow: {e}")

                    from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
                    waiting = False
                    try:
                        waiting = bool(get_conversation_memory(phone, 'waiting_for_advisor_data'))
                    except Exception:
                        waiting = False

                    if not waiting:
                        # Iniciar el flujo guiado; esto preguntará por nombre, correo, RFC, teléfono, etc.
                        logger.warning(f"⚠️ Cliente {phone or 'desconocido'} requiere atención humana — iniciando flujo de asesor")
                        try:
                            if start_fn:
                             
                                try:
                                    start_fn(phone)
                                except TypeError:
                                    start_fn(phone)

                                save_conversation_memory(phone, 'advisor_prompt_sent', True)
                                save_conversation_memory(phone, 'waiting_for_advisor_data', True)
                                result['advisor_flow_started'] = True
                            else:
                                logger.debug("No start function to initiate advisor flow (start_fn is None)")
                        except Exception as e:
                            logger.error(f"Error iniciando función de inicio de asesoría: {e}")
                    else:
                        # Si ya estamos recolectando datos, comprobar si están completos
                        form_state = None
                        try:
                            form_state = get_conversation_memory(phone, 'advisor_form_state')
                        except Exception:
                            form_state = None

                        collected = {}
                        if form_state and isinstance(form_state, dict):
                            collected = form_state.get('collected', {})

                        # Considerar completos si tenemos al menos nombre, email y teléfono
                        if collected and collected.get('name') and (collected.get('email') or client_data.get('correo')) and (collected.get('phone') or client_data.get('telefono')):
                            # fusionar collected con client_data
                            client_data['nombre'] = client_data.get('nombre') or collected.get('name')
                            client_data['correo'] = client_data.get('correo') or collected.get('email')
                            client_data['telefono'] = client_data.get('telefono') or collected.get('phone')
                            client_data['empresa'] = client_data.get('empresa') or collected.get('company')

                            # Generar PDF con los datos completos
                            pdf_path = ''
                            try:
                                pdf_path = self.generate_client_pdf(client_data, classification)
                            except Exception as e:
                                logger.error(f"Error generando PDF: {e}")

                            # Enviar PDF al asesor usando advisor_service si está disponible
                            try:
                                from services.advisor_service import send_pdf_to_advisor
                                user_name = client_data.get('nombre') or client_data.get('empresa')
                                segment = client_data.get('segmento', 'Sin clasificar')
                                details = {
                                    'mensaje': message,
                                    'lead_type': lead_prediction.get('lead_type'),
                                    'lead_confidence': lead_prediction.get('confidence')
                                }

                                logger.info(f"Enviando PDF del prospecto al asesor para {phone}")
                                send_res = send_pdf_to_advisor(
                                    pdf_path=pdf_path,
                                    user_phone=phone,
                                    user_name=user_name,
                                    segment=segment,
                                    request_type=classification.get('category', 'asesor'),
                                    details=details
                                )
                                result['advisor_notification'] = send_res

                                # Marcar flujo completado en memoria
                                try:
                                    save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                                    save_conversation_memory(phone, 'advisor_form_state', None)
                                except Exception:
                                    pass
                            except Exception as e:
                                logger.error(f"Error enviando PDF al asesor: {e}")
                                result['advisor_notification'] = {'error': str(e)}
                        else:
                            # Si no hay datos completos, pedir al usuario que complete el formulario
                            logger.info(f"Esperando que el usuario {phone} complete datos para asesor")
                            result['advisor_flow_waiting_for_data'] = True

                except Exception as e:
                    # Fallback: notificar al asesor directamente si no podemos iniciar el flujo guiado
                    logger.error(f"No se pudo iniciar el flujo guiado de asesor: {e}. Intentando notificación directa.")
                    try:
                        from services.advisor_service import notify_advisor_and_user
                        user_name = client_data.get('nombre') or client_data.get('empresa')
                        details = {
                            'mensaje': message,
                            'lead_type': lead_prediction.get('lead_type'),
                            'lead_confidence': lead_prediction.get('confidence')
                        }
                        notify_res = notify_advisor_and_user(
                            user_phone=phone or '',
                            request_type=classification.get('category', 'asesor'),
                            user_name=user_name,
                            details=details,
                            confirm_user=True,
                            pdf_path=None
                        )
                        result['advisor_notification'] = notify_res
                    except Exception as e2:
                        logger.error(f"Error en notificación directa fallback: {e2}")
                        result['advisor_notification'] = {'error': str(e2)}

            except Exception as e:
                logger.error(f"Error en flujo de atención humana: {e}")

        return result
    
    def generate_client_pdf(self, client_data: Dict[str, str], 
                          classification: Dict[str, Any]) -> str:
        """
        Genera un PDF con los datos del cliente y la clasificación de su consulta
        """
        return self.pdf_generator.generate_client_profile_pdf(client_data, classification)


    def _load_courses(self):
        if self._courses is not None:
            return self._courses
        try:
            try:
                from api.utils.json_catalog import load_courses
            except Exception:
                from utils.json_catalog import load_courses
            self._courses = load_courses() or []
            return self._courses
        except Exception as e:
            logger.debug(f"Could not load courses via loader: {e}")
            self._courses = []
            return self._courses

    def _load_webinars(self):
        if self._webinars is not None:
            return self._webinars
        try:
            try:
                from api.utils.json_catalog import load_webinars
            except Exception:
                from utils.json_catalog import load_webinars
            self._webinars = load_webinars() or []
            return self._webinars
        except Exception as e:
            logger.debug(f"Could not load webinars via loader: {e}")
            self._webinars = []
            return self._webinars

    def _format_course_summary(self, course: Dict[str, Any]) -> str:
        try:
            title = course.get('nombre') or course.get('title') or course.get('nombre_corto') or 'Curso'
            price = course.get('precio') or course.get('price') or 'Precio no disponible'
            location = course.get('ubicacion') or course.get('location') or 'Ubicación no disponible'
            duration = course.get('duracion') or course.get('duration') or 'Duración no disponible'
            dates = course.get('proximas_fechas') or course.get('fechas') or []
            temario = course.get('temario') or []
            temario_short = ', '.join([t.get('titulo', str(t)) if isinstance(t, dict) else str(t) for t in temario[:3]])
            dates_str = ', '.join([d.get('fecha', d) if isinstance(d, dict) else str(d) for d in dates]) if dates else 'Fechas no disponibles'
            summary = f"{title}\nPrecio: {price}\nUbicación: {location}\nDuración: {duration}\nFechas: {dates_str}\nTemario (resumen): {temario_short}"
            return summary
        except Exception:
            return "Información del curso no disponible."

    def answer_course_or_webinar_query(self, message: str, kind: str = 'course') -> Optional[str]:
        mq = (message or '').lower()
        local_parts = []
        if any(x in mq for x in ['lista', 'todos', 'all', 'lista de cursos', 'qué cursos', 'que cursos', 'muestrame cursos', 'conoce los cursos', 'webinars disponibles']):
            local_parts = [self._format_course_summary(c if kind == 'course' else c) for c in items[:5]]

        try:
            from services.chat_ai import chat_with_gemini
            system_prompt = (
                "Eres un asistente experto en los cursos y webinars de Fibremex. Responde en español de forma "
                "corta y clara a la consulta del usuario. NO INVENTES fechas, precios, duraciones ni ubicaciones. "
                "Si el usuario solicita detalles concretos, indica en la respuesta que vas a adjuntar la sección [DATOS] "
                "con la información exacta tomada del sistema. Responde adecuadamente al tipo de consulta: lista, "
                "detalles de un curso o preguntas técnicas."
            )
            ai_resp = chat_with_gemini(phone=None, message=message, system_prompt=system_prompt)
            if ai_resp and isinstance(ai_resp, str) and ai_resp.strip():
                datos_block = None
                m = re.search(r"\b(\d{1,3})\b", mq)
                if m:
                    cid = int(m.group(1))
                    for c in items:
                        if (isinstance(c.get('id'), int) and c.get('id') == cid) or (str(c.get('_id', '')).endswith(str(cid))):
                            datos_block = self._format_course_summary(c)
                            break

                if not datos_block and local_parts:
                    datos_block = "\n\n".join(local_parts)

                if not datos_block and items:
                    datos_block = self._format_course_summary(items[0])

                if datos_block:
                    return ai_resp.strip() + "\n\n[DATOS]\n" + datos_block
                return ai_resp.strip()
        except Exception:
            pass
        q = (message or '').lower()
        if kind == 'course':
            items = self._load_courses() or []
        else:
            items = self._load_webinars() or []

        if not items:
            return None

        if any(x in q for x in ['lista', 'todos', 'all', 'lista de cursos', 'qué cursos', 'que cursos', 'muestrame cursos', 'conoce los cursos']):
            parts = [self._format_course_summary(c if kind == 'course' else c) for c in items]
            header = 'Cursos disponibles:' if kind == 'course' else 'Webinars disponibles:'
            return header + "\n\n" + "\n\n".join(parts)

        #
        m = re.search(r"\b(\d{1,3})\b", q)
        if m:
            cid = int(m.group(1))
            for c in items:
                if (isinstance(c.get('id'), int) and c.get('id') == cid) or (str(c.get('_id', '')).endswith(str(cid))):
                    return self._format_course_summary(c)

        candidates = []
        for c in items:
            txt = ' '.join([str(c.get(k, '') or '') for k in ('nombre', 'nombre_corto', 'title', 'description', 'descripcion')]).lower()
            if any(tok in txt for tok in q.split() if len(tok) > 3):
                candidates.append(c)

        if len(candidates) == 1:
            return self._format_course_summary(candidates[0])
        elif len(candidates) > 1:
            parts = [self._format_course_summary(c) for c in candidates[:5]]
            return "Encontré varios resultados relacionados. Aquí algunos:\n\n" + "\n\n".join(parts)

        parts = [self._format_course_summary(c) for c in items[:5]]
        return ("No encontré coincidencias exactas. Estos son algunos cursos/webinars disponibles:\n\n" + "\n\n".join(parts))
    
    def extract_data_from_text(self, text: str) -> Dict[str, str]:
        """
        Extrae datos estructurados de un texto libre
        """
        # Primero intenta con spaCy si está disponible
        entities = {}
        if NLP_AVAILABLE:
            entities.update(self.extractor.extract_entities_spacy(text))
        
        # Complementa con reglas
        rule_entities = self.extractor.extract_entities_rule_based(text)
        for key, value in rule_entities.items():
            if key not in entities or not entities[key]:
                entities[key] = value
                
        return entities


ml_service = MLService()