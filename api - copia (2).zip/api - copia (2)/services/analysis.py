import os
import pandas as pd
from collections import Counter

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    _HAS_SKLEARN = True
except Exception:
    TfidfVectorizer = None
    _HAS_SKLEARN = False


def extract_top_keywords(series, n=20):
    texts = series.fillna('').astype(str).tolist()
    if not texts:
        return []
    if _HAS_SKLEARN and TfidfVectorizer is not None:
        try:
            vect = TfidfVectorizer(stop_words='spanish', max_features=1000)
            X = vect.fit_transform(texts)
            feature_names = vect.get_feature_names_out()
            summed = X.sum(axis=0)
            scores = [(feature_names[i], float(summed[0, i])) for i in range(len(feature_names))]
            scores.sort(key=lambda x: x[1], reverse=True)
            return scores[:n]
        except Exception:
            pass

    counter = Counter()
    for t in texts:
        for token in [w.strip().lower() for w in t.split() if len(w.strip()) > 2]:
            counter[token] += 1
    scores = sorted(counter.items(), key=lambda x: x[1], reverse=True)
    return [(k, float(v)) for k, v in scores[:n]]


def count_new_customers(df):
    return df.shape[0]


def generate_report(conversations_df, output_path=None):
    if output_path is None:
        output_path = os.path.abspath('conversations_report.xlsx')

    df = conversations_df.copy()
    
    if df.empty:
        df = pd.DataFrame(columns=['_id', 'customer_phone', 'customer_id', 'message', 'created_at'])
    
    message_column = 'message' if 'message' in df.columns else pd.Series()
    keywords = extract_top_keywords(df[message_column] if isinstance(message_column, str) else message_column)
    kw_df = pd.DataFrame(keywords, columns=['keyword', 'score'])

    stats = {
        'total_messages': int(df.shape[0]),
        'total_customers': None,
        'date_range': None
    }
    
    customer_columns = ['customer_id', 'customer_phone', 'phone']
    for col in customer_columns:
        if col in df.columns and not df[col].isna().all():
            stats['total_customers'] = int(df[col].nunique())
            break
    
    if 'created_at' in df.columns and not df['created_at'].isna().all():
        try:
            dates = pd.to_datetime(df['created_at'], errors='coerce')
            if not dates.isna().all():
                stats['date_range'] = f"{dates.min()} to {dates.max()}"
        except Exception as e:
            print(f"Warning: Could not parse dates: {e}")

    try:
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='conversations', index=False)
            
            if not kw_df.empty:
                kw_df.to_excel(writer, sheet_name='keywords', index=False)
            
            stats_df = pd.DataFrame([stats])
            stats_df.to_excel(writer, sheet_name='stats', index=False)
            
        print(f"Report generated successfully: {output_path}")
        
    except Exception as e:
        print(f"Error generating Excel report: {e}")
        csv_path = output_path.replace('.xlsx', '.csv')
        df.to_csv(csv_path, index=False)
        return csv_path

    return output_path