"""
Motor de conversación inteligente para cursos con detección de intención y respuestas contextuales.
"""
import logging
import re
import unicodedata
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from services.conversation_memory_utils import save_conversation_memory, get_conversation_memory

logger = logging.getLogger(__name__)


class CourseIntentEngine:
    """Motor de detección de intención para consultas sobre cursos."""
    
    # Patrones de intención más sofisticados
    INTENT_PATTERNS = {
        'discovery': {
            'patterns': [
                r'qué cursos tienen?', r'que cursos tienen?', r'cursos disponibles',
                r'opciones de curso', r'qué me recomiendas?', r'que me recomiendas?',
                r'busco.*curso', r'necesito.*curso', r'interesado en.*curso'
            ],
            'keywords': ['opciones', 'disponibles', 'recomien', 'sugier', 'busco'],
            'weight': 1.0
        },
        'specific_course_info': {
            'patterns': [
                r'curso \d+', r'información.*curso', r'detalles.*curso',
                r'qué incluye.*curso', r'que incluye.*curso', r'sobre el curso',
                r'háblame.*curso', r'hablame.*curso'
            ],
            'keywords': ['información', 'detalles', 'incluye', 'sobre', 'háblame', 'hablame'],
            'weight': 1.2
        },
        'temario_request': {
            'patterns': [
                r'temario.*curso', r'contenido.*curso', r'programa.*curso',
                r'qué se ve.*curso', r'que se ve.*curso', r'syllabus'
            ],
            'keywords': ['temario', 'contenido', 'programa', 'se ve', 'syllabus', 'aprenderé'],
            'weight': 1.5
        },
        'practical_info': {
            'patterns': [
                r'fechas.*curso', r'precio.*curso', r'cuánto cuesta',
                r'cuanto cuesta', r'horarios.*curso', r'dónde.*curso', r'donde.*curso'
            ],
            'keywords': ['fechas', 'precio', 'cuesta', 'horarios', 'dónde', 'donde', 'ubicación'],
            'weight': 1.3
        },
        'enrollment': {
            'patterns': [
                r'cómo.*inscrib', r'como.*inscrib', r'quiero inscrib',
                r'proceso.*inscripción', r'proceso.*inscripcion'
            ],
            'keywords': ['inscrib', 'registro', 'matricul', 'apuntar'],
            'weight': 1.4
        },
        'comparison': {
            'patterns': [
                r'diferencia entre.*curso', r'cuál.*mejor.*curso', r'cual.*mejor.*curso',
                r'comparar.*curso', r'elegir.*curso'
            ],
            'keywords': ['diferencia', 'mejor', 'comparar', 'elegir', 'recomiendas'],
            'weight': 1.1
        }
    }

    # Cursos específicos y sus variaciones
    COURSE_VARIATIONS = {
        1: {
            'names': ['cableado estructurado', 'cableado', 'estructurado', 'cobre', 'redes cobre'],
            'keywords': ['cableado', 'estructurado', 'cobre', 'utp', 'ethernet']
        },
        2: {
            'names': ['fibra óptica planta externa', 'planta externa', 'fibra externa'],
            'keywords': ['planta', 'externa', 'exterior', 'outdoor']
        },
        3: {
            'names': ['ftth', 'fibra hasta el hogar', 'wisp', 'isp'],
            'keywords': ['ftth', 'hogar', 'wisp', 'isp', 'proveedor']
        },
        4: {
            'names': ['pon', 'lan', 'pasivas', 'enterprise', 'empresarial'],
            'keywords': ['pon', 'lan', 'pasivas', 'enterprise', 'empresarial', 'corporativo']
        },
        5: {
            'names': ['empalmes', 'otdr', 'mediciones', 'fusión'],
            'keywords': ['empalmes', 'otdr', 'mediciones', 'fusión', 'splice', 'reflectometro']
        }
    }

    @classmethod
    def analyze_message_intent(cls, message: str, conversation_history: List[Dict] = None) -> Tuple[str, float, Dict]:
        """
        Analiza la intención del usuario en el mensaje.
        
        """
        if not message:
            return 'unknown', 0.0, {}

        message_norm = cls._normalize_text(message)
        message_lower = message_norm.strip()
        
        # Detectar curso específico mencionado
        detected_course = cls._detect_specific_course(message_lower)
        
        # Detectar intención principal
        intent_scores = {}
        
        for intent_name, intent_data in cls.INTENT_PATTERNS.items():
            score = 0.0
            
            # Patrones regex
            for pattern in intent_data['patterns']:
                if re.search(pattern, message_lower):
                    score += intent_data['weight'] * 2
            
            # Keywords
            for keyword in intent_data['keywords']:
                if keyword in message_lower:
                    score += intent_data['weight']
            
            intent_scores[intent_name] = score
        
        # Encontrar la mejor intención
        best_intent = max(intent_scores.items(), key=lambda x: x[1])
        intent_name, confidence = best_intent
        
        # Normalizar confianza (0-1)
        max_possible_score = max(len(data['patterns']) * data['weight'] * 2 + 
                               len(data['keywords']) * data['weight'] 
                               for data in cls.INTENT_PATTERNS.values())
        
        confidence = min(confidence / max_possible_score, 1.0) if max_possible_score > 0 else 0.0
        
        # Si no hay intención clara, verificar si al menos menciona cursos
        if confidence < 0.1:
            course_indicators = ['curso', 'capacitación', 'formación', 'aprender', 'estudiar']
            if any(indicator in message_lower for indicator in course_indicators):
                intent_name = 'general_course_interest'
                confidence = 0.3
        
        details = {
            'detected_course': detected_course,
            'course_confidence': cls._calculate_course_confidence(message_lower, detected_course),
            'all_scores': intent_scores,
            'keywords_found': cls._extract_found_keywords(message_lower)
        }
        
        return intent_name, confidence, details

    @classmethod
    def _detect_specific_course(cls, message_lower: str) -> Optional[int]:
        """Detecta si se menciona un curso específico."""
        # Números directos
        course_num_match = re.search(r'curso\s*(\d+)|^(\d+)$|\b(\d+)\b', message_lower)
        if course_num_match:
            for group in course_num_match.groups():
                if group and group.isdigit():
                    num = int(group)
                    if 1 <= num <= 5:
                        return num
        
        # Nombres y keywords de cursos
        for course_id, course_data in cls.COURSE_VARIATIONS.items():
            # Nombres completos
            for name in course_data['names']:
                # Normalize the course names as well for matching
                name_norm = cls._normalize_text(name)
                if name_norm in message_lower:
                    return course_id
            
            # Keywords (requiere al menos 2 coincidencias para mayor precisión)
            keyword_matches = sum(1 for keyword in course_data['keywords'] 
                                if keyword in message_lower)
            if keyword_matches >= 2:
                return course_id
        
        return None

    @classmethod
    def _calculate_course_confidence(cls, message_lower: str, detected_course: Optional[int]) -> float:
        """Calcula la confianza de que el usuario se refiere a un curso específico."""
        if not detected_course:
            return 0.0
        course_data = cls.COURSE_VARIATIONS.get(detected_course, {})

        # Contar coincidencias
        name_matches = sum(1 for name in course_data.get('names', []) 
                          if cls._normalize_text(name) in message_lower)
        keyword_matches = sum(1 for keyword in course_data.get('keywords', []) 
                              if keyword in message_lower)

        # Calcular confianza
        total_possible = len(course_data.get('names', [])) + len(course_data.get('keywords', []))
        if total_possible == 0:
            return 0.0

        return min((name_matches * 2 + keyword_matches) / total_possible, 1.0)

    @classmethod
    def _extract_found_keywords(cls, message_lower: str) -> List[str]:
        """Extrae las palabras clave encontradas en el mensaje."""
        found = []
        for intent_data in cls.INTENT_PATTERNS.values():
            for keyword in intent_data['keywords']:
                if keyword in message_lower and keyword not in found:
                    found.append(keyword)
        return found

    @classmethod
    def _normalize_text(cls, text: str) -> str:
        if not text:
            return ''
        try:
            nfkd = unicodedata.normalize('NFKD', text)
            only_ascii = nfkd.encode('ASCII', 'ignore').decode('ASCII')
            return only_ascii.lower()
        except Exception:
            return text.lower()


class CourseConversationFlow:
    """Gestor del flujo de conversación para cursos."""
    
    CONVERSATION_STAGES = {
        'discovery': {
            'next_stages': ['course_selection', 'comparison'],
            'suggested_actions': ['Explorar cursos disponibles', 'Ver recomendaciones personalizadas']
        },
        'course_selection': {
            'next_stages': ['course_details', 'temario_request', 'practical_info'],
            'suggested_actions': ['Ver temario completo', 'Consultar fechas y precios', 'Información práctica']
        },
        'course_details': {
            'next_stages': ['temario_request', 'practical_info', 'enrollment'],
            'suggested_actions': ['Descargar temario PDF', 'Ver fechas disponibles', 'Proceso de inscripción']
        },
        'temario_request': {
            'next_stages': ['practical_info', 'enrollment', 'comparison'],
            'suggested_actions': ['Ver fechas y precios', 'Iniciar inscripción', 'Comparar con otros cursos']
        },
        'practical_info': {
            'next_stages': ['enrollment', 'course_details', 'comparison'],
            'suggested_actions': ['Proceder con inscripción', 'Ver más detalles', 'Comparar opciones']
        },
        'enrollment': {
            'next_stages': ['advisor_contact', 'course_details'],
            'suggested_actions': ['Contactar asesor', 'Revisar información del curso']
        }
    }

    @classmethod
    def get_conversation_stage(cls, phone: str) -> str:
        """Obtiene la etapa actual de conversación."""
        return get_conversation_memory(phone, 'conversation_stage') or 'discovery'

    @classmethod
    def update_conversation_stage(cls, phone: str, new_stage: str, context: Dict = None):
        """Actualiza la etapa de conversación."""
        save_conversation_memory(phone, 'conversation_stage', new_stage)
        save_conversation_memory(phone, 'stage_context', context or {})
        save_conversation_memory(phone, 'stage_updated_at', datetime.now().isoformat())

    @classmethod
    def get_next_suggested_actions(cls, current_stage: str, context: Dict = None) -> List[str]:
        """Obtiene las acciones sugeridas para la siguiente etapa."""
        stage_data = cls.CONVERSATION_STAGES.get(current_stage, {})
        
        # Personalizar sugerencias basadas en el contexto
        suggestions = stage_data.get('suggested_actions', []).copy()
        
        if context and context.get('selected_course'):
            course_name = context['selected_course'].get('name', 'este curso')
            suggestions = [s.replace('curso', course_name) for s in suggestions]
        
        return suggestions

    @classmethod
    def determine_next_stage(cls, current_intent: str, current_stage: str) -> str:
        """Determina la siguiente etapa basada en la intención actual."""
        intent_to_stage_map = {
            'discovery': 'discovery',
            'specific_course_info': 'course_selection',
            'temario_request': 'temario_request',
            'practical_info': 'practical_info',
            'enrollment': 'enrollment',
            'comparison': 'comparison'
        }
        
        proposed_stage = intent_to_stage_map.get(current_intent, current_stage)
        
        # Validar transición
        current_stage_data = cls.CONVERSATION_STAGES.get(current_stage, {})
        valid_next_stages = current_stage_data.get('next_stages', [])
        
        if not valid_next_stages or proposed_stage in valid_next_stages or proposed_stage == current_stage:
            return proposed_stage
        
        # Si no es una transición válida, mantener etapa actual
        return current_stage


class CourseResponseGenerator:
    """Generador de respuestas contextuales para cursos."""
    
    @classmethod
    def generate_contextual_prompt(cls, intent: str, stage: str, course_context: Dict, user_message: str) -> str:
        """Genera un prompt contextual basado en la intención y etapa."""
        
        base_context = cls._get_base_course_context()
        
        # Prompt específico por intención y etapa
        if intent == 'discovery' and stage == 'discovery':
            return cls._generate_discovery_prompt(base_context, user_message)
        
        elif intent == 'specific_course_info' and course_context.get('detected_course'):
            return cls._generate_course_info_prompt(base_context, course_context, user_message)
        
        elif intent == 'temario_request':
            return cls._generate_temario_prompt(base_context, course_context, user_message)
        
        elif intent == 'practical_info':
            return cls._generate_practical_info_prompt(base_context, course_context, user_message)
        
        elif intent == 'enrollment':
            return cls._generate_enrollment_prompt(base_context, course_context, user_message)
        
        elif intent == 'comparison':
            return cls._generate_comparison_prompt(base_context, course_context, user_message)
        
        else:
            return cls._generate_general_prompt(base_context, user_message)

    @classmethod
    def _get_base_course_context(cls) -> str:
        """Contexto base sobre los cursos disponibles."""
        return """
FIBREMEX - CURSOS ESPECIALIZADOS EN FIBRA ÓPTICA Y REDES:

1. 📡 Cableado estructurado para redes de fibra y cobre
   - Diseño e implementación de infraestructuras de cableado
   - Estándares de la industria y mejores prácticas

2. 🌐 Redes de fibra óptica planta externa  
   - Instalación y mantenimiento de redes exteriores
   - Técnicas de despliegue y protección

3. 🏠 Redes de fibra óptica FTTH para WISP e ISP
   - Fibra hasta el hogar para proveedores de servicios
   - Arquitecturas y modelos de negocio

4. 🏢 PON/LAN redes pasivas para entornos enterprise
   - Soluciones empresariales y corporativas
   - Optimización para grandes instalaciones

5. 🔧 Empalmes y mediciones con OTDR
   - Técnicas avanzadas de fusión y empalme
   - Mediciones y certificación de enlaces
"""

    @classmethod
    def _generate_discovery_prompt(cls, base_context: str, user_message: str) -> str:
        return f"""
{base_context}

INSTRUCCIONES PARA RESPUESTA DE DESCUBRIMIENTO:

El usuario está explorando opciones de cursos. Tu objetivo es:

1. 🎯 Hacer UNA pregunta inteligente para entender sus necesidades específicas
2. 📋 Mencionar máximo 2-3 cursos más relevantes (no todos)
3. 🚀 Guiar hacia el siguiente paso natural sin abrumar

ENFOQUE CONVERSACIONAL:
- Sé curioso sobre su experiencia actual o proyecto específico
- Evita listar todos los cursos de inmediato
- Haz que la conversación fluya naturalmente hacia sus intereses

MENSAJE DEL USUARIO: "{user_message}"

Responde de forma conversacional y enfocada, como un asesor experto que quiere entender primero antes de recomendar.
"""

    @classmethod
    def _generate_course_info_prompt(cls, base_context: str, course_context: Dict, user_message: str) -> str:
        detected_course = course_context.get('detected_course')
        course_names = {
            1: "Cableado estructurado para redes de fibra y cobre",
            2: "Redes de fibra óptica planta externa", 
            3: "Redes de fibra óptica FTTH para WISP e ISP",
            4: "PON/LAN redes pasivas para entornos enterprise",
            5: "Empalmes y mediciones con OTDR"
        }
        
        course_name = course_names.get(detected_course, "el curso mencionado")
        
        return f"""
{base_context}

INSTRUCCIONES PARA INFORMACIÓN ESPECÍFICA DEL CURSO:

El usuario está preguntando sobre: {course_name}

Tu respuesta debe:

1. ✨ Dar información relevante y específica sobre este curso
2. 🎯 Enfocarse en los beneficios y aplicaciones prácticas
3. 📚 Mencionar 2-3 aspectos clave que lo hacen único
4. 🎲 Ofrecer UNA opción específica para profundizar (temario, fechas, o proceso)

EVITA:
- Mencionar todos los otros cursos
- Dar información genérica
- Abrumar con demasiados detalles técnicos

MENSAJE DEL USUARIO: "{user_message}"

Responde enfocándote específicamente en el curso {detected_course}, siendo informativo pero conciso.
"""

    @classmethod
    def _generate_temario_prompt(cls, base_context: str, course_context: Dict, user_message: str) -> str:
        return f"""
INSTRUCCIONES PARA SOLICITUD DE TEMARIO:

El usuario quiere ver el contenido/temario de un curso.

Tu respuesta debe:

1. 📋 Confirmar que tienes el temario disponible
2. 📄 Ofrecer envío del PDF completo
3. ✨ Dar un adelanto breve de 2-3 módulos principales
4. 🎯 Preguntar si quiere el PDF ahora o información adicional

MENSAJE DEL USUARIO: "{user_message}"

Sé directo y útil, enfocándote en facilitar el acceso al temario.
"""

    @classmethod
    def _generate_practical_info_prompt(cls, base_context: str, course_context: Dict, user_message: str) -> str:
        return f"""
INSTRUCCIONES PARA INFORMACIÓN PRÁCTICA:

El usuario busca información sobre fechas, precios, ubicación o horarios.

Tu respuesta debe:

1. 📅 Proporcionar la información específica solicitada
2. 💡 Ser transparente sobre qué información está disponible
3. 👥 Ofrecer contacto con asesor para detalles actualizados
4. 🎯 Preguntar si necesita información adicional específica

MENSAJE DEL USUARIO: "{user_message}"

Sé preciso y honesto sobre la información disponible.
"""

    @classmethod
    def _generate_enrollment_prompt(cls, base_context: str, course_context: Dict, user_message: str) -> str:
        return f"""
INSTRUCCIONES PARA PROCESO DE INSCRIPCIÓN:

El usuario quiere inscribirse o saber cómo inscribirse.

Tu respuesta debe:

1. 🎉 Mostrar entusiasmo por su interés
2. 📝 Explicar el proceso paso a paso de forma simple
3. 👥 Ofrecer conexión directa con asesor
4. ⚡ Hacer el siguiente paso muy claro y fácil

MENSAJE DEL USUARIO: "{user_message}"

Haz que el proceso sea simple y directo, facilitando la acción inmediata.
"""

    @classmethod
    def _generate_comparison_prompt(cls, base_context: str, course_context: Dict, user_message: str) -> str:
        return f"""
{base_context}

INSTRUCCIONES PARA COMPARACIÓN DE CURSOS:

El usuario quiere comparar opciones o decidir entre cursos.

Tu respuesta debe:

1. 🤔 Hacer 1-2 preguntas para entender su contexto específico
2. 📊 Comparar solo los cursos más relevantes (máximo 2-3)
3. 🎯 Enfocarse en diferencias prácticas y aplicaciones
4. 💡 Recomendar basándose en casos de uso específicos

MENSAJE DEL USUARIO: "{user_message}"

Ayuda a tomar una decisión informada sin abrumar con opciones.
"""

    @classmethod
    def _generate_general_prompt(cls, base_context: str, user_message: str) -> str:
        return f"""
{base_context}

INSTRUCCIONES PARA RESPUESTA GENERAL:

El usuario tiene una consulta relacionada con cursos pero no es específica.

Tu respuesta debe:

1. 🎯 Entender mejor su necesidad con una pregunta inteligente  
2. 🚀 Guiar hacia la información más útil
3. 💬 Mantener la conversación natural y enfocada
4. 📞 Ofrecer alternativas claras para continuar

MENSAJE DEL USUARIO: "{user_message}"

Sé un guía inteligente que ayuda a encontrar exactamente lo que busca.
"""