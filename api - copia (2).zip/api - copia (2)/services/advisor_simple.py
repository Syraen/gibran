import logging
import os
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger('advisor_simple')
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

from services.conversation_memory_utils import get_conversation_memory, save_conversation_memory
from services.ml_service import ml_service
from utils.whatsapp import send_text_message, send_document_to_phone

# Default advisor phone can be overridden via env var
DEFAULT_ADVISOR_PHONE = os.environ.get('ADVISOR_PHONE', '+5214442136200')


def start_advisor_simple(phone: str, process_type: str = 'general') -> bool:
    """Función simple para iniciar el proceso de contacto con asesor."""
    try:
        logger.info(f"[ADVISOR_SIMPLE] Iniciando proceso de asesor para {phone}")

        advisor_data = get_conversation_memory(phone, 'advisor_data')
        if advisor_data and advisor_data.get('step'):
            logger.info(f"[ADVISOR_SIMPLE] Ya hay proceso activo en paso: {advisor_data.get('step')}")
            return continue_advisor_process(phone, advisor_data)

        logger.info(f"[ADVISOR_SIMPLE] Iniciando nuevo proceso de asesor")

        expected_fields = [
            'nombre', 'empresa', 'rfc', 'email', 'telefono', 'web',
            'puesto', 'ciudad', 'curso_solicitado', 'descripcion_proyecto'
        ]

        step_count = len(expected_fields)
        message = f"¡Perfecto! 👍 Un asesor te contactará pronto.\n\n📝 PASO 1 DE {step_count}: Por favor compárteme tu *nombre completo*."
        save_conversation_memory(phone, 'advisor_data', {
            'step': 'waiting_info',
            'process_type': process_type,
            'fields_needed': expected_fields,
            'current_field': 0,
            'data': {},
            'started_at': datetime.now().isoformat(),
            'completed': False
        })

        save_conversation_memory(phone, 'advisor_prompt_sent', True)
        save_conversation_memory(phone, 'waiting_for_advisor_data', True)
        save_conversation_memory(phone, 'awaiting_advisor_data', True)
        save_conversation_memory(phone, 'advisor_intentos', 0)
        save_conversation_memory(phone, 'advisor_client_data', {})
        save_conversation_memory(phone, 'advisor_request_type', process_type)

        send_text_message(phone, message)
        logger.info(f"[ADVISOR_SIMPLE] Proceso iniciado exitosamente para {phone}")
        return True

    except Exception as e:
        logger.error(f"[ADVISOR_SIMPLE] Error: {e}")
        try:
            send_text_message(phone, "Hubo un problema iniciando el contacto con el asesor. Intenta de nuevo escribiendo 'asesor'.")
        except Exception:
            pass
        return False


def continue_advisor_process(phone: str, advisor_data: dict) -> bool:
    """Continúa el proceso de asesor en curso."""
    try:
        step = advisor_data.get('step')

        if step == 'waiting_info':
            send_text_message(phone, "Estoy esperando tu información de contacto. Por favor envía:\n\n📝 Nombre completo\n🏢 Empresa\n📧 Correo\n📱 Teléfono\n💼 ¿Qué necesitas?")
        elif step == 'processing':
            send_text_message(phone, "Estoy procesando tu información. Un asesor te contactará pronto.")
        else:
            return start_advisor_simple(phone)

        return True

    except Exception as e:
        logger.error(f"continue_advisor_process error: {e}")
        return False


def process_advisor_data(phone: str, message_text: str) -> bool:

    try:
        logger.info(f"[ADVISOR_STEP_BY_STEP] Procesando datos de {phone}: {message_text[:50]}...")

        advisor_data = get_conversation_memory(phone, 'advisor_data')
        if not advisor_data or advisor_data.get('step') != 'waiting_info':
            return False

        fields = advisor_data.get('fields_needed', ['nombre', 'telefono', 'email', 'empresa'])
        current_field_index = advisor_data.get('current_field', 0)
        data = advisor_data.get('data', {})
        process_type = advisor_data.get('process_type', 'general')

        try:
            ml_res = ml_service.process_message(message_text, conversation_history=[{'text': message_text, 'from_client': True}], phone=phone)
            extracted = ml_res.get('client_data', {}) or {}
            classification = ml_res.get('classification', {})
            lead_pred = ml_res.get('lead_prediction', {})
            key_map = {
                'nombre': 'nombre', 'name': 'nombre',
                'empresa': 'empresa', 'company': 'empresa',
                'rfc': 'rfc',
                'correo': 'email', 'email': 'email',
                'telefono': 'telefono', 'phone': 'telefono', 'tel': 'telefono',
                'web': 'web', 'website': 'web'
            }
            for k, v in extracted.items():
                if not v:
                    continue
                target = key_map.get(k, None)
                if not target:
                    target = key_map.get(k.lower()) if isinstance(k, str) else None
                if target and (not data.get(target)):
                    data[target] = v
                    logger.info(f"[ADVISOR_STEP_BY_STEP] Auto-extraído {target}: {str(v)[:60]}")

            # If we have a web or empresa and no segmento yet, use ML extractor to predict segmento
            try:
                if (data.get('web') or data.get('empresa')) and not data.get('segmento'):
                    pred_input = {
                        'empresa': data.get('empresa', ''),
                        'web': data.get('web', ''),
                        'mensajes': message_text or ''
                    }
                    segmento_pred = None
                    try:
                        segmento_pred = ml_service.extractor.predict_segment(pred_input)
                    except Exception:
                        segmento_pred = None
                    if segmento_pred:
                        data['segmento'] = segmento_pred
                        logger.info(f"[ADVISOR_STEP_BY_STEP] Segmento predicho por ML: {segmento_pred}")
                        try:
                            save_conversation_memory(phone, 'advisor_client_data', data)
                        except Exception:
                            pass
            except Exception:
                logger.debug('Segment prediction failed')

        except Exception as e:
            logger.debug(f"ML extraction failed: {e}")

        if current_field_index < len(fields):
            field_name = fields[current_field_index]
            if not data.get(field_name):
                data[field_name] = message_text.strip()
                logger.info(f"[ADVISOR_STEP_BY_STEP] Guardado manual {field_name}: {message_text[:30]}...")

        next_field_index = current_field_index + 1

        if next_field_index < len(fields):
            next_field = fields[next_field_index]
            field_prompts = {
                'nombre': f"📝 **PASO 1 DE {len(fields)}**\nPor favor compárteme tu **nombre completo**:",
                'empresa': f"🏢 **PASO 2 DE {len(fields)}**\nPerfecto {data.get('nombre', '')}.\n¿Cuál es el **nombre de tu empresa** o proyecto?",
                'rfc': f"🏷️ **PASO 3 DE {len(fields)}**\nPor favor indica tu **RFC** o razón social (si aplica):",
                'email': f"📧 **PASO 4 DE {len(fields)}**\nGracias. Ahora compárteme tu **correo electrónico**:",
                'telefono': f"📱 **PASO 5 DE {len(fields)}**\nPerfecto. ¿Cuál es tu **número de teléfono** de contacto?",
                'web': f"🌐 **PASO 6 DE {len(fields)}**\nSi tienes sitio web, compárteme el enlace (o escribe 'no tengo'):",
            }

            prompt = field_prompts.get(next_field, f"Por favor proporciona: {next_field}")
            send_text_message(phone, prompt)

            advisor_data.update({
                'current_field': next_field_index,
                'data': data
            })
            save_conversation_memory(phone, 'advisor_data', advisor_data)
            # keep a synchronized mirror for other parts of the system
            try:
                save_conversation_memory(phone, 'advisor_client_data', data)
            except Exception:
                pass

        else:
            try:
                ml_res = ml_service.process_message(' '.join([v for v in data.values() if isinstance(v, str)]), conversation_history=None, phone=phone)
            except Exception:
                ml_res = {}

            classification = ml_res.get('classification') if isinstance(ml_res, dict) else {}
            lead_pred = ml_res.get('lead_prediction') if isinstance(ml_res, dict) else {}

            pdf_path = None
            try:
                client_data = {
                    'nombre': data.get('nombre'),
                    'empresa': data.get('empresa'),
                    'rfc': data.get('rfc'),
                    'correo': data.get('email') or data.get('correo'),
                    'telefono': data.get('telefono'),
                    'web': data.get('web'),
                    # predict segmento using ML extractor if not present
                    'segmento': data.get('segmento') or (ml_res.get('client_data', {}) or {}).get('segmento'),
                    'necesidad': data.get('descripcion_proyecto') or data.get('necesidad') or ''
                }
                pdf_path = ml_service.generate_client_pdf(client_data, classification or {})
            except Exception as e:
                logger.error(f"Error generando PDF con MLService: {e}")

            # Notify advisor and inform user (do this regardless of PDF generation success)
            try:
                advisor_phone = DEFAULT_ADVISOR_PHONE
                user_need = data.get('descripcion_proyecto') or data.get('necesidad') or ''
                category = (classification.get('category') if isinstance(classification, dict) else None) or process_type
                lead_type = (lead_pred.get('lead_type') if isinstance(lead_pred, dict) else None) or 'no determinado'
                lead_conf = (lead_pred.get('confidence') if isinstance(lead_pred, dict) else None) or 0.0

                notif = (
                    f"🔔 NUEVA SOLICITUD - {category.upper()}\n"
                    f"Cliente: {client_data.get('nombre','N/D')}\n"
                    f"Teléfono: {client_data.get('telefono','N/D')}\n"
                    f"Email: {client_data.get('correo','N/D')}\n"
                    f"Empresa: {client_data.get('empresa','N/D')}\n"
                    f"Segmento: {client_data.get('segmento','N/D')}\n\n"
                    f"REQUERIMIENTO: {user_need or 'No especificado'}\n"
                    f"Preclasificación ML: {category} | Lead: {lead_type} ({lead_conf:.2f})\n\n"
                    f"Se adjunta PDF con los datos del cliente."
                )

                send_text_message(advisor_phone, notif)
                if pdf_path and os.path.exists(pdf_path):
                    send_document_to_phone(advisor_phone, pdf_path, caption=f"Solicitud - {client_data.get('nombre','Cliente')}")
                send_text_message(phone, "Gracias — envié tu solicitud al asesor. En breve te contactarán.")
            except Exception as e:
                logger.error(f"Error notificando al asesor: {e}")

            # mark completed and clear legacy/inline flags so webhook flows stop delegating
            try:
                save_conversation_memory(phone, 'advisor_data', {'step': 'completed'})
                save_conversation_memory(phone, 'waiting_for_advisor_data', False)
                save_conversation_memory(phone, 'awaiting_advisor_data', None)
                save_conversation_memory(phone, 'advisor_form_state', None)
                save_conversation_memory(phone, 'advisor_prompt_sent', None)
                # keep the collected client data available in the legacy key for a short time
                try:
                    save_conversation_memory(phone, 'advisor_client_data', data)
                except Exception:
                    pass
                save_conversation_memory(phone, 'advisor_request_type', None)
            except Exception:
                pass

        return True

    except Exception as e:
        logger.error(f"[ADVISOR_STEP_BY_STEP] Error procesando datos: {e}")
        try:
            send_text_message(phone, "Hubo un problema. Un asesor se pondrá en contacto contigo pronto.")
        except Exception:
            pass
        return True


def complete_advisor_process(phone: str, data: dict, process_type: str):
    try:
        nombre = data.get('nombre', 'Cliente')
        process_names = {
            'inscripcion': 'inscripción',
            'cotizacion': 'cotización',
            'facturacion': 'facturación',
            'general': 'solicitud'
        }
        process_name = process_names.get(process_type, 'solicitud')
        confirmation_msg = (
            f"✅ **DATOS COMPLETADOS**\n\n"
            f"Gracias {nombre}, tu solicitud de **{process_name}** ha sido registrada.\n\n"
            f"📋 **RESUMEN:**\n• Nombre: {data.get('nombre', 'N/A')}\n• Teléfono: {data.get('telefono', 'N/A')}\n• Email: {data.get('email', 'N/A')}\n• Empresa: {data.get('empresa', 'N/A')}\n\n"
            f"🤝 **Un asesor especializado te contactará en máximo 2 horas hábiles.**\n\n"
            f"¿Hay algo más en lo que pueda ayudarte mientras tanto?"
        )
        send_text_message(phone, confirmation_msg)

        pdf_content = generate_advisor_pdf_content(data, process_type, phone)

        advisor_notification = (
            f"🔔 NUEVA SOLICITUD - {process_name.upper()}\n\n"
            f"Cliente: {data.get('nombre', 'N/A')}\n"
            f"Teléfono: {data.get('telefono', 'N/A')}\n"
            f"Email: {data.get('email', 'N/A')}\n"
            f"Empresa: {data.get('empresa', 'N/A')}\n\n"
            f"WhatsApp: {phone}\n"
            f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            f"Tipo de solicitud: {process_name}\n\n"
            f"SIGUIENTE ACCIÓN:\n{''}\n\n"
            f"(El asesor recibirá el PDF con los datos del cliente en este chat.)"
        )

        try:
            send_text_message(DEFAULT_ADVISOR_PHONE, advisor_notification)
            temp_pdf_path = None
            try:
                from fpdf import FPDF
                pdf = FPDF()
                pdf.add_page()
                pdf.set_auto_page_break(auto=True, margin=15)
                pdf.set_font('Arial', size=12)
                for line in pdf_content.split('\n'):
                    pdf.multi_cell(0, 6, line)
                tmp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'logs'))
                os.makedirs(tmp_dir, exist_ok=True)
                temp_pdf_path = os.path.join(tmp_dir, f'advisor_request_{phone.replace("+","_").replace(" ","_")}.pdf')
                pdf.output(temp_pdf_path)
            except Exception:
                temp_pdf_path = None

            if temp_pdf_path and os.path.exists(temp_pdf_path):
                send_document_to_phone(DEFAULT_ADVISOR_PHONE, temp_pdf_path, caption=f"Solicitud - {nombre}")
        except Exception as e:
            logger.error(f"Error notificando al asesor: {e}")

        logger.info(f"[ADVISOR_COMPLETE] Proceso completado para {phone}")
        save_conversation_memory(phone, 'advisor_data', {'step': 'completed'})
        try:
            save_conversation_memory(phone, 'waiting_for_advisor_data', False)
            save_conversation_memory(phone, 'advisor_prompt_sent', None)
            save_conversation_memory(phone, 'advisor_form_state', None)
            save_conversation_memory(phone, 'advisor_intentos', 0)
        except Exception:
            pass

    except Exception as e:
        logger.error(f"Error completando proceso de asesor: {e}")


def generate_advisor_pdf_content(data: dict, process_type: str, phone: str) -> str:
    fecha = datetime.now().strftime('%d/%m/%Y %H:%M')
    nombre = data.get('nombre', 'No especificado')
    empresa = data.get('empresa', '')
    rfc = data.get('rfc', '')
    correo = data.get('email') or data.get('correo') or ''
    telefono = data.get('telefono', '')
    sitio = data.get('web') or ''
    segmento = data.get('segmento') or ''
    puesto = data.get('puesto') or ''
    ciudad = data.get('ciudad') or ''
    curso = data.get('curso_solicitado') or data.get('curso') or 'No especificado'
    descripcion = data.get('descripcion_proyecto') or data.get('necesidad') or ''

    lines = []
    lines.append('SOLICITUD DE CONTACTO CON ASESOR')
    lines.append('')
    lines.append(f'Generado: {fecha}')
    lines.append('')
    lines.append('Datos del Prospecto:')
    lines.append('')
    lines.append(f'Nombre completo: {nombre}')
    if empresa:
        lines.append(f'Empresa: {empresa}')
    if rfc:
        lines.append(f'RFC: {rfc}')
    if correo:
        lines.append(f'Correo electrónico: {correo}')
    if telefono:
        lines.append(f'Teléfono: {telefono}')
    if sitio:
        lines.append(f'Sitio web: {sitio}')
    if segmento:
        lines.append(f'Segmento de cliente: {segmento}')
    if puesto:
        lines.append(f'Puesto: {puesto}')
    if ciudad:
        lines.append(f'Ciudad: {ciudad}')
    lines.append('')
    lines.append('Curso Solicitado:')
    lines.append(curso)
    lines.append('')
    lines.append('Descripción del Proyecto/Solicitud:')
    lines.append(descripcion or 'No especificado')

    return '\n'.join(lines)
