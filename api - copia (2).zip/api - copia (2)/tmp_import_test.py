try:
    from routes.whatsapp import process_user_message
    print('Import OK')
except Exception as e:
    print('Import failed:', e)
