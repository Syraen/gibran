"""
Utilidades para manejo de conversaciones con la nueva estructura
"""
from datetime import datetime
from typing import Optional, Dict, List, Any
import re
from bson import ObjectId
from data.db import get_collection


def _normalize_phone(phone: str) -> Optional[str]:
    try:
        if phone is None:
            return None
        s = str(phone).strip()
        if not s:
            return None
        s = re.sub(r'[\s\-()]+', '', s)
        if s.startswith('+'):
            s = s[1:]
        return s
    except Exception:
        return str(phone) if phone is not None else None


def _build_phone_filters(phone: str):
    numbers = set()
    if phone:
        numbers.add(str(phone).strip())

    norm = _normalize_phone(phone)
    if norm:
        numbers.add(norm)
    if norm and not norm.startswith('+'):
        numbers.add(f"+{norm}")

    phone_str = str(phone).strip() if phone else None
    if phone_str and not phone_str.startswith('+'):
        numbers.add(f"+{phone_str}")

    numbers = {n for n in numbers if n}

    filters = []
    for value in numbers:
        filters.append({'phone': value})
        filters.append({'telefono': value})
        filters.append({'customer_phone': value})
        filters.append({'customerPhone': value})

    unique_filters = []
    seen = set()
    for f in filters:
        key = tuple(sorted(f.items()))
        if key not in seen:
            seen.add(key)
            unique_filters.append(f)

    return unique_filters, numbers, norm

def add_message_to_conversation(
    phone: str, 
    message_text: str, 
    sender: str = "user", 
    message_type: str = "text",
    response_text: Optional[str] = None
) -> bool:
    """
    Agregar un mensaje (y opcionalmente una respuesta) a una conversación existente
    o crear una nueva conversación si no existe.
    
    Args:
        phone: Número de teléfono del contacto
        message_text: Texto del mensaje
        sender: Quién envía el mensaje ('user', 'bot', 'agent')
        message_type: Tipo de mensaje ('text', 'image', 'audio', etc.)
        response_text: Respuesta opcional del bot (si aplica)
    
    Returns:
        bool: True si se guardó exitosamente, False en caso contrario
    """
    try:
        conv_col = get_collection('conversaciones')
        current_time = datetime.utcnow()
        message_id = str(ObjectId())
        
        # Crear mensajes a agregar
        messages_to_add = []
        
        # Mensaje principal
        if message_text:
            user_message = {
                "id": f"{message_id}_{sender}",
                "text": message_text,
                "sender": sender,
                "message_type": message_type,
                "created_at": current_time,
                "timestamp": current_time
            }
            messages_to_add.append(user_message)
        
        # Respuesta opcional (típicamente del bot)
        if response_text:
            bot_message = {
                "id": f"{message_id}_bot",
                "text": response_text,
                "sender": "bot",
                "message_type": "text",
                "created_at": current_time,
                "timestamp": current_time
            }
            messages_to_add.append(bot_message)
        
        if not messages_to_add:
            return False
        
        # Buscar conversación existente
        filters, numbers, norm = _build_phone_filters(phone)
        conversation = conv_col.find_one({'$or': filters}) if filters else None
        canonical_phone = None
        
        if conversation:
            # Actualizar conversación existente
            last_message = messages_to_add[-1]  # El último mensaje agregado
            
            canonical_phone = conversation.get("phone") or conversation.get("customer_phone") or norm or (next(iter(numbers)) if numbers else None)
            update_fields = {
                "$push": {"messages": {"$each": messages_to_add}},
                "$set": {
                    "last_message_at": current_time,
                    "last_message": last_message["text"],
                    "last_message_sender": last_message["sender"],
                    "message_count": len(conversation.get("messages", [])) + len(messages_to_add)
                }
            }

            if canonical_phone:
                update_fields["$set"].update({
                    "phone": canonical_phone,
                    "customer_phone": canonical_phone,
                    "telefono": canonical_phone
                })

            update_result = conv_col.update_one(
                {"_id": conversation.get("_id")},
                update_fields
            )
            return update_result.modified_count > 0
        else:
            # Crear nueva conversación
            last_message = messages_to_add[-1]
            canonical_phone = norm or (next(iter(numbers)) if numbers else str(phone).strip())

            if not canonical_phone:
                canonical_phone = str(phone).strip() or norm

            new_conversation = {
                "phone": canonical_phone,
                "customer_phone": canonical_phone,
                "telefono": canonical_phone,
                "customer_id": None,
                "customer_name": "",
                "messages": messages_to_add,
                "created_at": current_time,
                "last_message_at": current_time,
                "last_message": last_message["text"],
                "last_message_sender": last_message["sender"],
                "message_count": len(messages_to_add),
                "ai_mode": False,
                "aiMode": False,
                "tags": [],
                "session_id": None,
                "etiqueta_id": None,
                "etiqueta_nombre": None,
                "etiqueta_color": None
            }
            
            result = conv_col.insert_one(new_conversation)
            return bool(result.inserted_id)
            
    except Exception as e:
        print(f"Error adding message to conversation: {e}")
        return False

def get_conversation_messages(phone: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Obtener los mensajes de una conversación específica
    
    Args:
        phone: Número de teléfono del contacto
        limit: Límite de mensajes a retornar
    
    Returns:
        List: Lista de mensajes ordenados por timestamp
    """
    try:
        conv_col = get_collection('conversaciones')
        filters, _, _ = _build_phone_filters(phone)
        query = {'$or': filters} if filters else {"phone": phone}
        conversation = conv_col.find_one(query)
        
        if conversation and 'messages' in conversation:
            messages = conversation['messages']
            # Ordenar por timestamp y limitar
            messages.sort(key=lambda x: x.get('timestamp', x.get('created_at', datetime.min)))
            return messages[-limit:] if limit > 0 else messages
        
        return []
        
    except Exception as e:
        print(f"Error getting conversation messages: {e}")
        return []

def update_conversation_info(
    phone: str, 
    customer_name: str = None,
    ai_mode: bool = None,
    tags: List[str] = None,
    etiqueta_id: int = None,
    etiqueta_nombre: str = None,
    etiqueta_color: str = None
) -> bool:
    """
    Actualizar información de una conversación
    
    Args:
        phone: Número de teléfono del contacto
        customer_name: Nombre del cliente
        ai_mode: Modo AI habilitado/deshabilitado
        tags: Lista de etiquetas
        etiqueta_id: ID de etiqueta
        etiqueta_nombre: Nombre de etiqueta
        etiqueta_color: Color de etiqueta
    
    Returns:
        bool: True si se actualizó exitosamente
    """
    try:
        conv_col = get_collection('conversaciones')
        filters, _, norm = _build_phone_filters(phone)
        target_phone = norm or str(phone).strip()
        
        update_data = {}
        if customer_name is not None:
            update_data["customer_name"] = customer_name
        if ai_mode is not None:
            update_data["ai_mode"] = ai_mode
        if tags is not None:
            update_data["tags"] = tags
        if etiqueta_id is not None:
            update_data["etiqueta_id"] = etiqueta_id
        if etiqueta_nombre is not None:
            update_data["etiqueta_nombre"] = etiqueta_nombre
        if etiqueta_color is not None:
            update_data["etiqueta_color"] = etiqueta_color
        
        if not update_data:
            return False
            
        update_query = {'$or': filters} if filters else {"phone": phone}

        # Ensure canonical phone fields get updated when provided
        if target_phone:
            update_data.setdefault("phone", target_phone)
            update_data.setdefault("customer_phone", target_phone)
            update_data.setdefault("telefono", target_phone)

        result = conv_col.update_one(
            update_query,
            {"$set": update_data},
            upsert=True
        )

        return bool(result.modified_count or getattr(result, "upserted_id", None))
        
    except Exception as e:
        print(f"Error updating conversation info: {e}")
        return False

def get_conversation_summary(phone: str) -> Optional[Dict[str, Any]]:
    """
    Obtener resumen de una conversación
    
    Args:
        phone: Número de teléfono del contacto
    
    Returns:
        Dict: Información resumida de la conversación o None si no existe
    """
    try:
        conv_col = get_collection('conversaciones')
        filters, _, _ = _build_phone_filters(phone)
        query = {'$or': filters} if filters else {"phone": phone}
        conversation = conv_col.find_one(query)

        if conversation:
            return {
                "phone": conversation.get("phone"),
                "customer_name": conversation.get("customer_name", ""),
                "message_count": conversation.get("message_count", 0),
                "last_message": conversation.get("last_message", ""),
                "last_message_sender": conversation.get("last_message_sender", ""),
                "last_message_at": conversation.get("last_message_at"),
                "created_at": conversation.get("created_at"),
                "ai_mode": conversation.get("ai_mode", False),
                "tags": conversation.get("tags", []),
                "etiqueta_id": conversation.get("etiqueta_id"),
                "etiqueta_nombre": conversation.get("etiqueta_nombre"),
                "etiqueta_color": conversation.get("etiqueta_color")
            }

        return None
        
    except Exception as e:
        print(f"Error getting conversation summary: {e}")
        return None