from fpdf import FPDF
import os
import logging
from typing import Optional, List, Dict, Any
from pathlib import Path

# Configurar logging
logger = logging.getLogger(__name__)

try:
    import fitz  # PyMuPDF
    HAVE_PYMUPDF = True
except Exception:
    fitz = None
    HAVE_PYMUPDF = False
    logger.warning("PyMuPDF (fitz) not available: PDF text extraction and PDF info features will be limited. Install with 'pip install PyMuPDF' if you need full PDF support.")

def extract_pdf_text(pdf_path: str) -> str:
    """
    Extrae todo el texto de un archivo PDF.
    
    Args:
        pdf_path: Ruta al archivo PDF
        
    Returns:
        Texto extraído del PDF
    """
    try:
        # Soportar archivos de texto plano además de PDF
        path = Path(pdf_path)
        if path.suffix.lower() in ['.txt', '.md']:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"Error leyendo texto plano {pdf_path}: {e}")
                return ""

        doc = fitz.open(pdf_path)
        text_content = ""

        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            text_content += page.get_text()
            text_content += f"\n--- PÁGINA {page_num + 1} ---\n"

        doc.close()
        return text_content

    except Exception as e:
        logger.error(f"Error extrayendo texto de {pdf_path}: {e}")
        return ""

def find_pdf_by_product_name(product_name: str, pdf_directory: str = "pdfs") -> Optional[str]:
    """
    Busca un PDF que contenga el nombre del producto en su nombre de archivo.
    
    Args:
        product_name: Nombre del producto a buscar
        pdf_directory: Directorio donde buscar los PDFs
        
    Returns:
        Ruta del PDF encontrado o None si no se encuentra
    """
    try:
        pdf_dir = Path(pdf_directory)
        if not pdf_dir.exists():
            logger.warning(f"Directorio de PDFs no existe: {pdf_directory}")
            return None
        
        product_keywords = product_name.lower().split()
        
        # Buscar en varias extensiones
        for ext in ("*.pdf", "*.txt", "*.md"):
            for pdf_file in pdf_dir.glob(ext):
                filename_lower = pdf_file.name.lower()

                # Verificar si todas las palabras clave del producto están en el nombre del archivo
                matches = sum(1 for keyword in product_keywords if keyword in filename_lower)

                # Si coincide al menos el 50% de las palabras, considerarlo una coincidencia
                if matches >= max(1, len(product_keywords) // 2):
                    return str(pdf_file)
        
        return None
        
    except Exception as e:
        logger.error(f"Error buscando PDF para producto {product_name}: {e}")
        return None

def search_text_in_pdf(pdf_path: str, search_terms: List[str]) -> Dict[str, Any]:
    """
    Busca términos específicos dentro de un PDF y retorna las coincidencias.
    
    Args:
        pdf_path: Ruta al archivo PDF
        search_terms: Lista de términos a buscar
        
    Returns:
        Diccionario con información de las coincidencias encontradas
    """
    try:
        doc = fitz.open(pdf_path)
        results = {
            'found_terms': [],
            'pages_with_matches': [],
            'excerpts': []
        }
        
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            text = page.get_text()
            text_lower = text.lower()
            
            page_matches = []
            for term in search_terms:
                if term.lower() in text_lower:
                    if term not in results['found_terms']:
                        results['found_terms'].append(term)
                    
                    if page_num not in results['pages_with_matches']:
                        results['pages_with_matches'].append(page_num)
                    
                    page_matches.append(term)
            
            # Si hay coincidencias en esta página, extraer fragmentos de texto
            if page_matches:
                # Buscar contexto alrededor de cada coincidencia
                for term in page_matches:
                    term_lower = term.lower()
                    start_idx = text_lower.find(term_lower)
                    if start_idx != -1:
                        # Extraer contexto de ±100 caracteres alrededor del término
                        context_start = max(0, start_idx - 100)
                        context_end = min(len(text), start_idx + len(term) + 100)
                        excerpt = text[context_start:context_end].strip()
                        
                        results['excerpts'].append({
                            'term': term,
                            'page': page_num + 1,
                            'context': excerpt
                        })
        
        doc.close()
        return results
        
    except Exception as e:
        logger.error(f"Error buscando en PDF {pdf_path}: {e}")
        return {'found_terms': [], 'pages_with_matches': [], 'excerpts': []}

def get_pdf_info(pdf_path: str) -> Dict[str, Any]:
    """
    Obtiene información básica del PDF (número de páginas, metadatos, etc.).
    
    Args:
        pdf_path: Ruta al archivo PDF
        
    Returns:
        Diccionario con información del PDF
    """
    try:
        path = Path(pdf_path)

        info = {
            'filename': path.name,
            'page_count': 0,
            'metadata': {},
            'file_size': path.stat().st_size if path.exists() else 0,
            'has_text': False
        }

        # Si es texto plano
        if path.suffix.lower() in ['.txt', '.md']:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    info['page_count'] = 1
                    info['has_text'] = bool(content.strip())
                return info
            except Exception as e:
                logger.error(f"Error leyendo archivo de texto {pdf_path}: {e}")
                return info

        # Si es PDF
        try:
            doc = fitz.open(pdf_path)
            info['page_count'] = len(doc)
            info['metadata'] = doc.metadata

            for page_num in range(min(3, len(doc))):  # Revisar las primeras 3 páginas
                page = doc.load_page(page_num)
                if page.get_text().strip():
                    info['has_text'] = True
                    break

            doc.close()
            return info
        except Exception as e:
            logger.error(f"Error obteniendo información de PDF {pdf_path}: {e}")
            return info
        
    except Exception as e:
        logger.error(f"Error obteniendo información de PDF {pdf_path}: {e}")
        return {}

def list_available_pdfs(pdf_directory: str = "pdfs") -> List[Dict[str, Any]]:
    """
    Lista todos los PDFs disponibles en el directorio con información básica.
    
    Args:
        pdf_directory: Directorio donde buscar PDFs
        
    Returns:
        Lista de diccionarios con información de cada PDF
    """
    try:
        pdf_dir = Path(pdf_directory)
        if not pdf_dir.exists():
            return []
        
        pdfs_info = []
        
        # Incluir varias extensiones
        for ext in ("*.pdf", "*.txt", "*.md"):
            for pdf_file in pdf_dir.glob(ext):
                try:
                    info = get_pdf_info(str(pdf_file))
                    if info:
                        info['file_path'] = str(pdf_file)
                        pdfs_info.append(info)
                except Exception as e:
                    logger.error(f"Error procesando archivo {pdf_file}: {e}")
                    continue
        
        # Ordenar por nombre de archivo
        pdfs_info.sort(key=lambda x: x.get('filename', ''))
        
        return pdfs_info
        
    except Exception as e:
        logger.error(f"Error listando PDFs en {pdf_directory}: {e}")
        return []

def generar_pdf_datos_prospecto(datos: dict, output_path: str) -> str:
    """
    Genera un PDF con los datos del prospecto y lo guarda en output_path.
    Retorna la ruta del PDF generado.
    """
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(0, 10, "Datos del Prospecto:", ln=True, align="L")
    pdf.ln(4)
    campos = [
        ("Nombre completo", datos.get("nombre")),
        ("Empresa", datos.get("empresa")),
        ("¿Qué necesita?", datos.get("necesidad") or datos.get("mensajes")),
        ("RFC", datos.get("rfc")),
        ("Correo electrónico", datos.get("email")),
        ("Teléfono", datos.get("telefono")),
        ("Sitio web", datos.get("web")),
        ("Segmento de cliente", datos.get("segmento")),
        ("Puesto", datos.get("puesto")),
        ("Ciudad", datos.get("ciudad")),
    ]
    for label, value in campos:
        if value:
            pdf.cell(0, 10, f"{label}: {value}", ln=True, align="L")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    pdf.output(output_path)
    return output_path
