"""
Funciones para manejar la solicitud de temarios y recursos para los cursos.
"""
import logging
import os
import re
import json
from typing import Dict, Any, Optional, List, Union
from models.courses import CourseManager, find_temario_pdf

logger = logging.getLogger(__name__)

def is_temario_request(message: str) -> bool:
	"""
	Detecta si el mensaje es una solicitud de temario.
	"""
	temario_keywords = ['temario', 'temas', 'contenido', 'programa', 'syllabus', 
						'qué incluye', 'que incluye', 'qué voy a aprender',
						'qué enseñan', 'que enseñan', 'plan de estudios']
    
	message_lower = (message or '').lower()
	return any(keyword in message_lower for keyword in temario_keywords)


def is_inscription_request(message: str) -> bool:
	"""
	Detecta si el mensaje es una solicitud sobre el proceso de inscripción.
	"""
	inscription_keywords = ['inscripción', 'inscripcion', 'inscribirme', 
						   'proceso de inscripcion', 'cómo me inscribo', 
						   'como me inscribo', 'registro', 'registrarme']
    
	message_lower = (message or '').lower()
	return any(keyword in message_lower for keyword in inscription_keywords)


def extract_course_number(message: str) -> Optional[int]:
	"""
	Extrae un número de curso (1-5) de un texto.
	"""
	if not message:
		return None
	# Buscar un dígito aislado 1-5
	m = re.search(r"\b([1-5])\b", message)
	if m:
		return int(m.group(1))
        
	# Buscar patrones como "curso 1", "curso número 2", "el temario del curso 3"
	m = re.search(r"curso\s*(?:n[úu]mero\s*)?(?:[:#-]?\s*)([1-5])", message.lower())
	if m:
		return int(m.group(1))
    
	# Buscar nombres específicos de cursos
	course_names = {
		'cableado': 1,
		'estructurado': 1,
		'redes': 1,
		'fibra': 2,
		'planta externa': 2,
		'ftth': 3,
		'wisp': 3,
		'isp': 3,
		'ponlan': 4,
		'redes pasivas': 4,
		'enterprise': 4,
		'empalmes': 5,
		'mediciones': 5,
		'otdr': 5
	}
    
	message_lower = message.lower()
	for keyword, course_id in course_names.items():
		if keyword in message_lower:
			return course_id
            
	return None


def get_course_temario_message(course_id: int) -> str:
	"""
	Genera un mensaje con el temario de un curso específico.
	"""
	# Intentar obtener curso desde la capa de datos (MongoDB o similar)
	course = CourseManager.get_course_by_id(course_id)

	# Si no hay objeto Course en DB, intentar cargar desde los JSON locales en info/courses
	course_json = None
	if not course:
		try:
			course_json = load_course_json_by_id(course_id)
		except Exception:
			course_json = None

	# Si tampoco encontramos nada en JSON, pedir al usuario que indique el número
	if not course and not course_json:
		# Devolver la pregunta para que el caller la use (no usar el mensaje "No encontré...")
		return ask_for_course_number()

	# Obtener temario formateado: preferir objeto Course, sino usar JSON
	if course:
		temario_text = course.get_formatted_temario()
		course_name = course.nombre
	else:
		# Formatear temario desde el JSON
		tem = []
		for t in course_json.get('temario', []):
			if isinstance(t, dict):
				titulo = t.get('titulo')
				tem.append(f"- {titulo}")
				if t.get('subtemas'):
					for st in t.get('subtemas'):
						tem.append(f"  • {st}")
			else:
				tem.append(f"- {t}")

		temario_text = f"📚 *TEMARIO - {course_json.get('nombre')}*\n\n" + "\n".join(tem)
		course_name = course_json.get('nombre')

	# Buscar PDF del temario
	pdf_path = find_temario_pdf(course_id)
	pdf_available = pdf_path is not None

	# Generar mensaje de temario (siempre incluir el temario en texto)
	message_parts = [
		f"📚 *TEMARIO DEL CURSO: {course_name}*\n",
		temario_text,
		"\n"
	]

	if pdf_available:
		# Indicar que se enviará el PDF (el caller normalmente lo enviará automáticamente)
		message_parts.append("\n💡 También puedes recibir el temario completo en PDF. Te lo envío a continuación.")

	message_parts.append("\n¿Hay algo específico del temario que te gustaría conocer más a fondo?")

	return "\n".join(message_parts)


def load_course_json_by_id(course_id: int) -> Optional[Dict[str, Any]]:
	"""
	Cargar el JSON del curso desde el directorio info/courses por id (fallback local).
	"""
	try:
		base = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'info', 'courses')
		if not os.path.exists(base):
			return None
		# Buscar archivos que empiecen por el id seguido de '_' o '<id>.'
		for fn in os.listdir(base):
			if not fn.lower().endswith('.json'):
				continue
			if fn.startswith(f"{course_id}_") or fn.startswith(f"{course_id}.") or fn.startswith(f"{course_id}-"):
				path = os.path.join(base, fn)
				try:
					with open(path, 'r', encoding='utf-8') as f:
						return json.load(f)
				except Exception:
					continue

		# Si no hay archivo con prefijo numérico, intentar buscar por campo 'id' dentro de cada JSON
		for fn in os.listdir(base):
			if not fn.lower().endswith('.json'):
				continue
			path = os.path.join(base, fn)
			try:
				with open(path, 'r', encoding='utf-8') as f:
					j = json.load(f)
					if str(j.get('id')) == str(course_id):
						return j
			except Exception:
				continue

		return None
	except Exception:
		return None


def get_inscription_process_message() -> str:
	"""
	Devuelve el mensaje con información sobre el proceso de inscripción.
	"""
	return (
		"📝 *PROCESO DE INSCRIPCIÓN*\n\n"
		"El proceso de inscripción es sencillo y rápido:\n\n"
		"1️⃣ Completa el formulario en el siguiente enlace:\n"
		"   https://fibremex.com/fibra-optica/views/Capacitaciones/1-fintec\n\n"
		"2️⃣ Recibirás un correo electrónico con los datos para realizar el pago\n\n"
		"3️⃣ Una vez confirmado el pago, recibirás los detalles para acceder al curso\n\n"
		"Si tienes dudas o necesitas ayuda personalizada en el proceso, puedes escribir 'asesor' y te pondré en contacto con un especialista."
	)


def ask_for_course_number() -> str:
	"""
	Genera un mensaje para preguntar por el número de curso.
	"""
	return (
		"Por favor, indícame de cuál de nuestros cursos te gustaría conocer el temario:\n\n"
		"1️⃣ Cableado estructurado para redes de fibra y cobre\n"
		"2️⃣ Redes de fibra óptica planta externa\n"
		"3️⃣ Redes de fibra óptica FTTH para WISP e ISP\n"
		"4️⃣ PONLAN redes pasivas para entornos enterprise\n"
		"5️⃣ Empalmes y mediciones con OTDR de un enlace de fibra óptica\n\n"
		"Responde con el número del curso (1-5) o con el nombre del curso."
	)


def find_pdf_for_user_message(message: str, context: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
	"""
	Dado un mensaje del usuario, intenta inferir qué temario PDF enviar.

	Args:
		message: Texto del usuario (p. ej. "enviar pdf del curso 3")
		context: Contexto opcional, puede incluir selected_course {id, name}

	Returns:
		Dict con { 'file_path': str, 'caption': str } o None si no se encuentra
	"""
	try:
		if not message and not context:
			return None

		# Prioridad 1: si hay curso seleccionado en contexto
		course_id = None
		course_name = None
		if context and isinstance(context, dict):
			selected = context.get('selected_course') or context.get('context', {}).get('selected_course')
			if isinstance(selected, dict):
				# If the selection already recorded a pdf_path, prefer it immediately
				details = selected.get('details') or {}
				if isinstance(details, dict):
					pdf_path_from_details = details.get('pdf_path') or details.get('pdf') or details.get('temario_pdf')
					if pdf_path_from_details:
						pdf_filename = os.path.basename(pdf_path_from_details)
						caption = f"Temario del curso {selected.get('name') or selected.get('nombre') or selected.get('id')}"
						return {'file_path': pdf_path_from_details, 'caption': caption, 'pdf_filename': pdf_filename}

				course_id = selected.get('id')
				# accept both 'name' and 'nombre'
				course_name = selected.get('name') or selected.get('nombre')

		# Prioridad 2: extraer número/clave del mensaje
		if not course_id and message:
			cid = extract_course_number(message)
			if cid:
				course_id = cid

		# Si aún no tenemos id, intentar por nombre en el texto
		if not course_id and message:
			# Buscar heurísticamente por nombre
			keywords = (message or '').lower().split()
			try:
				found = CourseManager.search_courses_by_keywords(keywords, limit=1)
				if found:
					course = found[0]
					course_id = getattr(course, 'id', None) or course.get('id')
					course_name = getattr(course, 'nombre', None) or course.get('nombre')
			except Exception:
				pass

		if not course_id and not course_name:
			logger.debug("find_pdf_for_user_message: no course_id or course_name resolved, returning None")
			return None

		# List available pdf files for debugging
		assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets')
		try:
			pdf_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.pdf')]
		except Exception:
			pdf_files = []
		logger.debug(f"find_pdf_for_user_message: available pdf_files={pdf_files}")

		pdf_path = None

		# If course_id is a numeric string, convert to int
		try:
			if isinstance(course_id, str) and course_id.isdigit():
				course_id = int(course_id)
		except Exception:
			pass

		# Try by id first (if available)
		if course_id is not None:
			try:
				pdf_path = find_temario_pdf(course_id, allow_partial=True)
			except Exception:
				pdf_path = None

		# If not found by id, try by name (if available)
		if not pdf_path and course_name:
			try:
				pdf_path = find_temario_pdf(course_name, allow_partial=True)
			except Exception:
				pdf_path = None

		# If still not found and course_id looks like an ObjectId hex, try resolving the course in DB
		if not pdf_path and isinstance(course_id, str) and len(course_id) == 24:
			try:
				course_obj = CourseManager.get_course_by_id(course_id)
				if course_obj:
					# try with numeric id or name from DB
					try:
						pdf_path = find_temario_pdf(course_obj.id or course_obj.nombre, allow_partial=True)
					except Exception:
						pdf_path = None
			except Exception:
				pass

		if not pdf_path:
			logger.debug("find_pdf_for_user_message: no pdf found for course")
			return None

		pdf_filename = os.path.basename(pdf_path)
		logger.info(f"find_pdf_for_user_message: resolved pdf_path={pdf_path} (filename={pdf_filename}) for course_id={course_id} course_name={course_name}")

		# Obtener nombre de curso legible
		if not course_name:
			try:
				course = CourseManager.get_course_by_id(course_id)
				if course:
					course_name = getattr(course, 'nombre', None) or course.get('nombre')
			except Exception:
				pass

		caption = f"Temario del curso {course_name or course_id}"
		return { 'file_path': pdf_path, 'caption': caption, 'pdf_filename': pdf_filename }

	except Exception as e:
		logger.error(f"find_pdf_for_user_message error: {e}")
		return None
