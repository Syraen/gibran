"""Compatibility wrapper for socketio safe_emit inside the 'api' package.

This duplicates the helper placed at top-level utils/socketio_utils.py so that
imports like `from utils.socketio_utils import safe_emit` resolve when the
application is started from the `api` package (common in this repository).
"""
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


def safe_emit(sio: Any, event: str, data: Any = None, room: Optional[str] = None,
              namespace: Optional[str] = None) -> None:
    """Emit an event using the provided SocketIO server object without 'broadcast'.

    Some Socket.IO server implementations for Flask don't accept the 'broadcast'
    keyword on emit. This helper standardizes emits and logs any errors.
    """
    try:
        sio.emit(event, data, room=room, namespace=namespace)
    except Exception as e:
        logger.exception(f"safe_emit error for event {event}: {e}")
