"""
Utilidades para cargar, buscar y formatear respuestas basadas en los JSON:
- splitbot.courses.json
- splitbot.products.json
- splitbot.webinars.json
"""
from __future__ import annotations

import json
import os
import unicodedata
from typing import List, Dict, Any, Optional, Tuple

try:
    from config.config import MONGODB_URL, MONGODB_DB, DEBUG
except Exception:
    MONGODB_URL = None
    MONGODB_DB = None
    DEBUG = False

try:
    import pymongo
except Exception:
    pymongo = None

_CACHE: Dict[str, Any] = {}


def clear_cache():
    global _CACHE
    _CACHE.clear()


def _root_dir() -> str:
    return os.path.dirname(os.path.dirname(__file__))


def _load_json(filename: str) -> List[Dict[str, Any]]:
    key = f"json::{filename}"
    if key in _CACHE:
        return _CACHE[key]
    path = os.path.join(_root_dir(), filename)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict):
                data = [data]
            _CACHE[key] = data
            return data
    except Exception:
        _CACHE[key] = []
        return []


def _load_json_dir(dirpath: str) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    if not os.path.isdir(dirpath):
        return items
    for fname in sorted(os.listdir(dirpath)):
        if not fname.lower().endswith('.json'):
            continue
        p = os.path.join(dirpath, fname)
        try:
            with open(p, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    items.extend(data)
                elif isinstance(data, dict):
                    items.append(data)
        except Exception:
            continue
    return items


def load_courses() -> List[Dict[str, Any]]:
    key = 'db::courses'
    if key in _CACHE:
        return _CACHE[key]

    if pymongo and MONGODB_URL and MONGODB_DB:
        try:
            client = pymongo.MongoClient(MONGODB_URL, serverSelectionTimeoutMS=2000)
            db = client[MONGODB_DB]
            coll_name = 'courses' if 'courses' in db.list_collection_names() else ('course' if 'course' in db.list_collection_names() else None)
            if coll_name:
                items = list(db[coll_name].find())
                for it in items:
                    if '_id' in it:
                        try:
                            it['_id'] = str(it['_id'])
                        except Exception:
                            pass
                _CACHE[key] = items
                if DEBUG:
                    print(f"Loaded {len(items)} courses from MongoDB collection '{coll_name}'")
                return items
        except Exception as e:
            if DEBUG:
                print(f"Warning: could not load courses from MongoDB: {e}")

    root = _root_dir()
    info_courses_dir = os.path.join(root, 'info', 'courses')
    if os.path.isdir(info_courses_dir):
        key = f"dir::{info_courses_dir}"
        if key in _CACHE:
            return _CACHE[key]
        items = _load_json_dir(info_courses_dir)
        _CACHE[key] = items
        return items

    candidates = ['info/courses.json', 'splitbot.courses.json', 'courses.json']
    for c in candidates:
        p = os.path.join(_root_dir(), c)
        if os.path.exists(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        data = [data]
                    _CACHE[key] = data
                    return data
            except Exception:
                continue

    _CACHE[key] = []
    return []


def load_products() -> List[Dict[str, Any]]:
    key = 'db::products'
    if key in _CACHE:
        return _CACHE[key]

    if pymongo and MONGODB_URL and MONGODB_DB:
        try:
            client = pymongo.MongoClient(MONGODB_URL, serverSelectionTimeoutMS=2000)
            db = client[MONGODB_DB]
            coll_name = 'products' if 'products' in db.list_collection_names() else ('product' if 'product' in db.list_collection_names() else None)
            if coll_name:
                items = list(db[coll_name].find())
                for it in items:
                    if '_id' in it:
                        try:
                            it['_id'] = str(it['_id'])
                        except Exception:
                            pass
                _CACHE[key] = items
                if DEBUG:
                    print(f"Loaded {len(items)} products from MongoDB collection '{coll_name}'")
                return items
        except Exception as e:
            if DEBUG:
                print(f"Warning: could not load products from MongoDB: {e}")

    root = _root_dir()
    info_products_dir = os.path.join(root, 'info', 'products')
    if os.path.isdir(info_products_dir):
        key = f"dir::{info_products_dir}"
        if key in _CACHE:
            return _CACHE[key]
        items = _load_json_dir(info_products_dir)
        _CACHE[key] = items
        return items

    candidates = ['info/products.json', 'splitbot.products.json', 'products.json']
    for c in candidates:
        p = os.path.join(_root_dir(), c)
        if os.path.exists(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        data = [data]
                    _CACHE[key] = data
                    return data
            except Exception:
                continue

    _CACHE[key] = []
    return []


def load_webinars() -> List[Dict[str, Any]]:
    key = 'db::webinars'
    if key in _CACHE:
        return _CACHE[key]

    if pymongo and MONGODB_URL and MONGODB_DB:
        try:
            client = pymongo.MongoClient(MONGODB_URL, serverSelectionTimeoutMS=2000)
            db = client[MONGODB_DB]
            coll_name = 'webinars' if 'webinars' in db.list_collection_names() else ('webinar' if 'webinar' in db.list_collection_names() else None)
            if coll_name:
                items = list(db[coll_name].find())
                for it in items:
                    if '_id' in it:
                        try:
                            it['_id'] = str(it['_id'])
                        except Exception:
                            pass
                _CACHE[key] = items
                if DEBUG:
                    print(f"Loaded {len(items)} webinars from MongoDB collection '{coll_name}'")
                return items
        except Exception as e:
            if DEBUG:
                print(f"Warning: could not load webinars from MongoDB: {e}")

    root = _root_dir()
    info_webinars_dir = os.path.join(root, 'info', 'webinars')
    if os.path.isdir(info_webinars_dir):
        key = f"dir::{info_webinars_dir}"
        if key in _CACHE:
            return _CACHE[key]
        items = _load_json_dir(info_webinars_dir)
        _CACHE[key] = items
        return items

    candidates = ['info/webinars.json', 'splitbot.webinars.json', 'webinars.json']
    for c in candidates:
        p = os.path.join(_root_dir(), c)
        if os.path.exists(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        data = [data]
                    _CACHE[key] = data
                    return data
            except Exception:
                continue

    _CACHE[key] = []
    return []


def _norm(s: Optional[str]) -> str:
    s = (s or '').strip().lower()
    s = ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')
    return s


def _tokenize(s: str) -> List[str]:
    return [t for t in _norm(s).replace('/', ' ').replace('-', ' ').split() if t]


def _score_text(needle_tokens: List[str], hay: str) -> int:
    hay_tokens = set(_tokenize(hay))
    return sum(1 for t in needle_tokens if t in hay_tokens)


def search_courses_by_text(query: str, limit: int = 3) -> List[Dict[str, Any]]:
    tokens = _tokenize(query)
    if not tokens:
        return []
    items = load_courses()

    alias_map = {
        'ftth': ['ftth', 'f.t.t.h', 'home', 'ont', 'olt', 'isp', 'wisp'],
        'ponlan': ['ponlan', 'pon lan', 'pon-lan', 'pol', 'passive optical lan', 'optical lan', 'enterprise pon', 'enterprise'],
        'otdr': ['otdr', 'empalmes', 'empalme', 'fusion', 'fusión', 'fusionadora', 'mediciones']
    }

    def in_any(hay: str, words: List[str]) -> bool:
        h = _norm(hay)
        return any(_norm(w) in h for w in words)

    def score(item: Dict[str, Any]) -> int:
        s = 0
        nombre = item.get('nombre', '')
        descripcion = item.get('descripcion', '')
        s += _score_text(tokens, nombre) * 5
        s += _score_text(tokens, descripcion) * 2
        for bloque in item.get('temario', []) or []:
            s += _score_text(tokens, bloque.get('titulo', '')) * 2
            for sub in bloque.get('subtemas', []) or []:
                s += _score_text(tokens, str(sub))

        name_desc = f"{nombre} {descripcion} " + " ".join(
            [
                f"{b.get('titulo', '')} " + " ".join([str(x) for x in (b.get('subtemas') or [])])
                for b in (item.get('temario') or [])
            ]
        )

        lower_norm_query = _norm(query)
        for key, words in alias_map.items():
            mentions_alias = any(w in tokens for w in [_norm(w) for w in words]) or any(_norm(w) in lower_norm_query for w in words + [key])
            if mentions_alias:
                if in_any(name_desc, [key]) or in_any(name_desc, words):
                    s += 4
        return s

    scored = [(score(i), i) for i in items]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [i for sc, i in scored if sc > 0][:limit]


def search_products_by_text(query: str, limit: int = 3) -> List[Dict[str, Any]]:
    tokens = _tokenize(query)
    if not tokens:
        return []
    items = load_products()
    def score(item: Dict[str, Any]) -> int:
        s = 0
        s += _score_text(tokens, item.get('nombre', '')) * 5
        s += _score_text(tokens, item.get('descripcion', '')) * 2
        for spec in item.get('especificaciones', []) or []:
            s += _score_text(tokens, str(spec))
        return s
    scored = [(score(i), i) for i in items]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [i for sc, i in scored if sc > 0][:limit]


def search_webinars_by_text(query: str, limit: int = 3) -> List[Dict[str, Any]]:
    tokens = _tokenize(query)
    if not tokens:
        return []
    items = load_webinars()
    def score(item: Dict[str, Any]) -> int:
        s = 0
        s += _score_text(tokens, item.get('title', '')) * 5
        s += _score_text(tokens, item.get('description', '')) * 2
        for t in item.get('topics', []) or []:
            s += _score_text(tokens, str(t))
        return s
    scored = [(score(i), i) for i in items]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [i for sc, i in scored if sc > 0][:limit]


def format_course_full(course: Dict[str, Any]) -> str:
    parts: List[str] = []
    parts.append(f"📚 {course.get('nombre', 'Curso')}")
    if course.get('descripcion'):
        parts.append(course['descripcion'])
    if course.get('modalidad'):
        parts.append(f"Modalidad: {course['modalidad']}")
    if course.get('precio'):
        parts.append(f"Precio: {course['precio']}")
    if course.get('ubicacion'):
        parts.append(f"Ubicación: {course['ubicacion']}")
    if course.get('horario'):
        parts.append(f"Horario: {course['horario']}")
    if course.get('duracion'):
        parts.append(f"Duración: {course['duracion']}")
    fechas = course.get('proximas_fechas') or []
    if fechas:
        fechas_lines = []
        for f in fechas:
            fecha = f.get('fecha') if isinstance(f, dict) else str(f)
            hora = f.get('horario') if isinstance(f, dict) else ''
            if fecha and hora:
                fechas_lines.append(f"• {fecha} — {hora}")
            elif fecha:
                fechas_lines.append(f"• {fecha}")
        if fechas_lines:
            parts.append("Próximas fechas:\n" + "\n".join(fechas_lines))
    return "\n".join(parts)


def format_course_temario(course: Dict[str, Any]) -> str:
    temario = course.get('temario') or []
    if not temario:
        return "Este curso no tiene temario detallado en el catálogo."
    lines: List[str] = [f"📚 TEMARIO — {course.get('nombre','Curso')}"]
    for bloque in temario:
        titulo = bloque.get('titulo')
        if titulo:
            lines.append(f"\n• {titulo}")
        subs = bloque.get('subtemas') or []
        for s in subs:
            lines.append(f"   - {s}")
    return "\n".join(lines)


def format_webinar_full(webinar: Dict[str, Any]) -> str:
    parts: List[str] = []
    parts.append(f"🎓 Webinar: {webinar.get('title','')}")
    if webinar.get('description'):
        parts.append(webinar['description'])
    fechas = [f for f in (webinar.get('fechas') or []) if f]
    horarios = [h for h in (webinar.get('horario') or []) if h]
    if fechas:
        parts.append("Fechas: " + ", ".join(fechas))
    if horarios:
        parts.append("Horario: " + ", ".join(horarios))
    if webinar.get('link'):
        parts.append(f"Registro: {webinar['link']}")
    return "\n".join(parts)


def format_product_full(product: Dict[str, Any]) -> str:
    parts: List[str] = []
    parts.append(f"🛒 {product.get('nombre','Producto')}")
    if product.get('descripcion'):
        parts.append(product['descripcion'])
    if product.get('precio'):
        parts.append(f"Precio: {product['precio']}")
    specs = product.get('especificaciones') or []
    if specs:
        parts.append("Especificaciones:\n" + "\n".join(f"• {s}" for s in specs))
    if product.get('link'):
        parts.append(f"Más info: {product['link']}")
    return "\n".join(parts)


def mentions_online_courses(text: str) -> bool:
    t = _norm(text)
    return any(k in t for k in ['en linea', 'en línea', 'online', 'virtual'])


def pick_by_name(candidates: List[Dict[str, Any]], user_text: str, name_key: str) -> Optional[Dict[str, Any]]:
    if not candidates:
        return None
    t = _norm(user_text)
    for c in candidates:
        name = _norm(c.get(name_key, ''))
        if name and name in t:
            return c
    tokens = set(_tokenize(user_text))
    best: Tuple[int, Optional[Dict[str, Any]]] = (0, None)
    for c in candidates:
        name = c.get(name_key, '')
        sc = _score_text(list(tokens), name)
        if sc > best[0]:
            best = (sc, c)
    return best[1]
