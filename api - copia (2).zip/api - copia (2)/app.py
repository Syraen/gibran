from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO
import os
import pandas as pd
from datetime import datetime
from data.db import init_db, get_collection, close_db
from models.models import Cliente, Conversation
from services import ai, analysis
from routes.whatsapp_marketing import whatsapp_marketing_bp
from services.chat_ai import chat_with_gemini
from config.config import (
    MONGODB_URL,
    GEMINI_MODEL,
    GEMINI_AUTH_MODE,
    WHATSAPP_VERIFY_TOKEN,
    PORT,
    DEBUG
)

# Mostrar configuración
print(f"Configuración Gemini: MODEL={GEMINI_MODEL}, AUTH_MODE={GEMINI_AUTH_MODE}")
print(f"MongoDB URL: {MONGODB_URL}")

app = Flask(__name__)

app.url_map.strict_slashes = False


raw_allowed = os.environ.get('FRONTEND_ORIGINS', '').strip()
if raw_allowed:
    # split CSV into list and strip spaces
    allowed_origins = [o.strip() for o in raw_allowed.split(',') if o.strip()]
else:
    allowed_origins = None

if allowed_origins:
    app.logger.info('CORS configured for explicit origins: %s', allowed_origins)
    CORS(
        app,
        resources={r"/*": {"origins": allowed_origins}},
        supports_credentials=True,
        allow_headers=['Content-Type', 'Authorization', 'ngrok-skip-browser-warning'],
        send_wildcard=False,
        vary_header=True,
    )
else:
    app.logger.warning('FRONTEND_ORIGINS not set; falling back to permissive CORS. For credentialed requests set FRONTEND_ORIGINS env.')
    CORS(
        app,
        resources={r"/*": {"origins": "*"}},
        supports_credentials=True,
        allow_headers=['Content-Type', 'Authorization', 'ngrok-skip-browser-warning'],
        send_wildcard=False,
        vary_header=True,
    )


socketio = SocketIO(app, cors_allowed_origins=allowed_origins or "*")
app.socketio = socketio


@app.after_request
def add_cors_headers(response):
    origin = request.headers.get('Origin')
    
    if origin:
        if allowed_origins:
            if origin in allowed_origins:
                response.headers['Access-Control-Allow-Origin'] = origin
            else:
                # Origin not explicitly in the list — log for visibility but still reflect
                app.logger.warning('Origin %s not found in FRONTEND_ORIGINS; reflecting it in response to avoid browser CORS wildcard issues', origin)
                response.headers['Access-Control-Allow-Origin'] = origin
        else:
            response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Vary'] = 'Origin'
        response.headers['Access-Control-Allow-Credentials'] = 'true'

    req_headers = request.headers.get('Access-Control-Request-Headers')
    if req_headers:
        response.headers['Access-Control-Allow-Headers'] = req_headers
    else:
        response.headers.setdefault('Access-Control-Allow-Headers', 'Content-Type,Authorization,ngrok-skip-browser-warning')
    response.headers.setdefault('Access-Control-Allow-Methods', 'GET,POST,OPTIONS,PUT,DELETE')
    response.headers.setdefault('Access-Control-Max-Age', '3600')
    return response


@app.route('/<path:any_path>', methods=['OPTIONS'])
@app.route('/', methods=['OPTIONS'])
def handle_options(any_path=''):
    return ('', 200)

@app.route('/', methods=['GET'])
def index_root():
    return jsonify({
        'ok': True,
        'service': 'splitbot api',
        'endpoints': {
            'health': '/health',
            'contacts': '/contacts',
            'webhook_get': '/webhook',
            'webhook_post': '/webhook'
        }
    }), 200


@app.route('/favicon.ico', methods=['GET'])
def favicon():
    return ('', 204)


@app.errorhandler(403)
def handle_403(e):
    from flask import make_response
    resp = make_response(jsonify({'error': 'forbidden', 'message': str(e)}), 403)
    return resp


@app.errorhandler(500)
def handle_500(e):
    from flask import make_response
    resp = make_response(jsonify({'error': 'internal_server_error', 'message': str(e)}), 500)
    return resp

app.register_blueprint(whatsapp_marketing_bp, url_prefix='/whatsapp-marketing')
from routes.contacts import contacts_bp
app.register_blueprint(contacts_bp, url_prefix='/contacts')
from routes.product_routes import product_bp
app.register_blueprint(product_bp)


@app.before_request
def log_incoming_request():
    try:
        # avoid logging large bodies; show method, path and a few headers
        headers_preview = {k: v for k, v in list(request.headers.items())[:10]}
        app.logger.debug('Incoming request: %s %s from %s headers=%s', request.method, request.path, request.remote_addr, headers_preview)
    except Exception:
        app.logger.exception('Failed to log incoming request')

@app.route('/webhook', methods=['GET'])
def webhook_verify_root():
    from routes.whatsapp import verify_webhook
    return verify_webhook()


@app.route('/webhook', methods=['POST'])
def webhook_post_root():
    from routes.whatsapp import webhook_handler
    return webhook_handler()


@app.route('/health', methods=['GET', 'OPTIONS'])
def health_check():
    app.logger.info('Health check received from %s', request.remote_addr)
    return jsonify({
        'status': 'ok',
        'time': datetime.utcnow().isoformat() + 'Z'
    }), 200

init_db(MONGODB_URL)

import logging
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
))
app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO if not DEBUG else logging.DEBUG)

VERIFY_TOKEN = WHATSAPP_VERIFY_TOKEN

@app.route('/reports/conversations.xlsx', methods=['GET'])
def export_conversations():
    try:
        conversations_collection = get_collection('conversations')
        
        conversations = list(conversations_collection.find())
        
        if conversations:
            for conv in conversations:
                conv['_id'] = str(conv['_id'])  
                if 'created_at' in conv:
                    conv['created_at'] = conv['created_at'].isoformat()
            
            df = pd.DataFrame(conversations)
        else:
            df = pd.DataFrame(columns=['_id', 'customer_phone', 'message', 'created_at'])
        
        report_path = analysis.generate_report(df)
        return jsonify({'report': report_path}), 200
        
    except Exception as e:
        app.logger.exception('Report generation failed')
        return jsonify({'error': str(e)}), 500


@app.route('/api/collections/info', methods=['GET'])
def get_collections_info():
    try:
        collections = [ 'courses', 'products', 'keywords','conversaciones']
        info = {}
        
        for collection_name in collections:
            collection = get_collection(collection_name)
            info[collection_name] = collection.count_documents({})
        
        return jsonify({'collections': info}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/keywords', methods=['POST'])
def add_keyword():
    try:
        data = request.get_json()
        keyword = data.get('keyword')
        response = data.get('response')
        category = data.get('category', 'general')
        
        if not keyword or not response:
            return jsonify({'error': 'Keyword and response are required'}), 400
        
        keywords_collection = get_collection('keywords')
        from models.models import Keyword
        
        keyword_data = Keyword(
            keyword=keyword,
            response=response,
            category=category
        ).to_dict()
        
        result = keywords_collection.insert_one(keyword_data)
        return jsonify({'id': str(result.inserted_id), 'status': 'created'}), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/debug/gemini', methods=['POST'])
def debug_gemini():
    try:
        data = request.get_json(force=True, silent=True) or {}
        prompt = data.get('prompt')
        if not prompt:
            return jsonify({'ok': False, 'error': 'missing prompt in JSON body'}), 400

        # Import here to ensure app config is loaded
        from services import gemini_py
        reply = gemini_py.generate_reply(prompt)
        return jsonify({'ok': True, 'prompt': prompt, 'reply': reply}), 200
    except Exception as e:
        app.logger.exception('Debug Gemini failed')
        return jsonify({'ok': False, 'error': str(e)}), 500



import atexit
atexit.register(close_db)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    socketio.run(
        app,
        host='0.0.0.0',  
        port=port,
        debug=False,  
        allow_unsafe_werkzeug=True  
    )
