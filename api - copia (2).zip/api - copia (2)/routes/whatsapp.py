import requests
import logging
import json
import traceback
import os
import fitz
from typing import Optional, Dict, Any
from datetime import datetime
import re
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin

# Configuraciones
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)

# Servicios principales
from services.chat_ai import chat_with_gemini

import importlib

# Attempt to load rapidfuzz dynamically. Keep optional so the module is not
# required for basic operation and static analyzers don't flag a top-level
# unresolved import.
RAPIDFUZZ = False
rf_process = None
rf_fuzz = None
try:
    rapidfuzz = importlib.import_module('rapidfuzz')
    # import submodules
    rf_process = importlib.import_module('rapidfuzz.process').process
    rf_fuzz = importlib.import_module('rapidfuzz.fuzz')
    RAPIDFUZZ = True
except Exception:
    RAPIDFUZZ = False

# Conversation memory helpers
from services.conversation_memory import save_selected_course, get_selected_course, clear_conversation_memory

# Importaciones de servicios de memoria y conversación
from services.conversation_memory_utils import (
    save_conversation_memory, get_conversation_memory,
    save_current_item, get_current_item, save_listed_items, get_listed_items
)

# Módulos de manejo de mensajes
from .whatsapp_message_handlers import (
    send_text_message, send_document_message, log_webhook_event,
    set_current_webhook_message_id, clear_current_webhook_message_id
)

# Herramientas para temarios y selección de curso
from utils.temario_handler import (
    is_temario_request, extract_course_number, get_course_temario_message,
    find_pdf_for_user_message, ask_for_course_number
)
from models.courses import CourseManager
from services.ml_service import ml_service
from services.notification_service import notification_service
try:
    from services.advisor_simple import start_advisor_simple, process_advisor_data as advisor_simple_process
except Exception:
    start_advisor_simple = None
    advisor_simple_process = None

try: 
    from services.products.products import get_product_response, products_services
except Exception:
    get_product_response = None
    products_services = None

try:
    from services.webinars.webinars import get_webinar_response, webinar_service
except Exception:
    get_webinar_response = None
    webinar_service = None

try:
    from services.courses.courses import get_course_response, course_service
except Exception: 
    get_course_response = None
    course_service = None


# Configurar logger para este módulo
logger = logging.getLogger(__name__)

def normalize_text(s: str) -> str:
    if not s or not isinstance(s, str):
        return ''
    return re.sub(r"\s+", ' ', s.strip().lower())

def contains_any(s: str, terms: list) -> bool:
    if not s:
        return False
    low = s.lower()
    return any(t in low for t in terms)

def is_greeting(s: str) -> bool:
    greetings = ['hola', 'buenas', 'buenos dias', 'buenos días', 'buenas tardes', 'buenas noches', 'hi', 'hello']
    t = normalize_text(s)
    if not t:
        return False
    if len(t) <= 60 and any(g in t for g in greetings):
        return True
    return False

def mentions_presencial(s: str) -> bool:
    presencial_terms = ['presencial', 'presenciales', 'en persona', 'sede', 'local', 'presencialmente', 'presencialidad']
    return contains_any(s, presencial_terms)

def is_catalog_mention(s: str, presencial_only: bool = False) -> bool:
    catalog_terms = ['curso', 'cursos', 'webinar', 'webinars', 'producto', 'productos', 'temario']
    t = normalize_text(s)
    if not t:
        return False
    if presencial_only:
        return contains_any(t, catalog_terms) and mentions_presencial(t)
    return contains_any(t, catalog_terms)


def detect_generic_attribute(text: str) -> Optional[str]:
    if not text:
        return None
    q = text.lower()
    if any(k in q for k in ['precio', 'costo', 'cost', '$']):
        return 'precio'
    if any(k in q for k in ['descripcion', 'descripci', 'describe', 'informacion', 'información']):
        return 'descripcion'
    if any(k in q for k in ['especificacion', 'especificaciones', 'caracteristica', 'características', 'ficha', 'spec']):
        return 'especificaciones'
    if any(k in q for k in ['link', 'enlace', 'url', 'página', 'pagina', 'sitio']):
        return 'link'
    if any(k in q for k in ['modalidad', 'online', 'en linea', 'en línea', 'presencial']):
        return 'modalidad'
    if any(k in q for k in ['ubicacion', 'ubicación', 'sede', 'lugar']):
        return 'ubicacion'
    if any(k in q for k in ['horario', 'hora', 'horarios']):
        return 'horario'
    if any(k in q for k in ['duracion', 'duración']):
        return 'duracion'
    if any(k in q for k in ['fecha', 'fechas', 'próximas', 'proximas', 'próxima', 'proxima']):
        return 'fechas'
    if any(k in q for k in ['temario', 'temas', 'contenido', 'subtemas']):
        return 'temario'
    if any(k in q for k in ['topic', 'topics', 'tema', 'temas']):
        return 'topics'
    return None


def _format_fecha_entry(entry) -> str:
    """Format a fecha/horario entry into a human readable string.

    Handles several common shapes found in the catalog JSONs:
    - dict with keys like 'fecha' and 'horario'
    - plain string
    - other types (fall back to str)
    """
    try:
        if entry is None:
            return ''
        if isinstance(entry, dict):
            fecha = entry.get('fecha') or entry.get('date') or entry.get('fecha_inicio') or ''
            horario = entry.get('horario') or entry.get('hora') or entry.get('time') or ''
            parts = []
            if fecha:
                parts.append(str(fecha).strip())
            if horario:
                parts.append(str(horario).strip())
            if parts:
                return ' '.join(parts)
            # if dict but no expected keys, try to stringify gracefully
            return ', '.join(f"{k}: {v}" for k, v in entry.items())
        if isinstance(entry, str):
            return entry.strip()
        return str(entry)
    except Exception:
        try:
            return str(entry)
        except Exception:
            return ''

def is_advisor_request_text(s: str) -> bool:
    if not s:
        return False
    t = normalize_text(s)
    advisor_phrases = ['hablar con un asesor', 'hablar con asesor', 'quiero hablar con un asesor', 'ponme en contacto', 'ponme en contacto con un asesor', 'contactar un asesor', 'contacto con asesor', 'contactar asesor', 'necesito un asesor']
    advisor_actions = ['inscrib', 'inscripción', 'inscripcion', 'inscribirme', 'registrarme', 'cotizacion', 'cotización', 'cotizar', 'factura', 'facturación', 'facturacion']
    return any(p in t for p in advisor_phrases) or any(a in t for a in advisor_actions)


# Crear blueprint para rutas de WhatsApp Marketing
whatsapp_bp = Blueprint('whatsapp_marketing', __name__)

# Cargar datos de cursos, productos y webinars desde JSON
def load_json_data():
    base_path = os.path.join(os.path.dirname(__file__), '..', 'info')
    
    courses = []
    products = []
    webinars = []
    
    # Cargar cursos
    courses_path = os.path.join(base_path, 'courses')
    if os.path.exists(courses_path):
        for file in os.listdir(courses_path):
            if file.endswith('.json'):
                with open(os.path.join(courses_path, file), 'r', encoding='utf-8') as f:
                    courses.append(json.load(f))
    
    # Cargar productos
    products_path = os.path.join(base_path, 'products')
    if os.path.exists(products_path):
        for file in os.listdir(products_path):
            if file.endswith('.json'):
                with open(os.path.join(products_path, file), 'r', encoding='utf-8') as f:
                    products.append(json.load(f))
    
    # Cargar webinars
    webinars_path = os.path.join(base_path, 'webinars')
    if os.path.exists(webinars_path):
        for file in os.listdir(webinars_path):
            if file.endswith('.json'):
                with open(os.path.join(webinars_path, file), 'r', encoding='utf-8') as f:
                    webinars.append(json.load(f))
    
    return courses, products, webinars

def load_catalog_from_db():

    try:
        from pymongo import MongoClient
    except Exception:
        logger.debug("pymongo no disponible, usando JSON local para datos de catálogo")
        return None

    mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
    try:
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=3000)
        db = client.get_database('splitbot')
        courses = list(db.get_collection('courses').find({})) if 'courses' in db.list_collection_names() else []
        products = list(db.get_collection('products').find({})) if 'products' in db.list_collection_names() else []
        webinars = list(db.get_collection('webinars').find({})) if 'webinars' in db.list_collection_names() else []
        import bson
        def sanitize_list(lst):
            out = []
            for d in lst:
                try:
                    od = dict(d)
                    if od.get('_id') is not None:
                        try:
                            od['id'] = str(od.get('_id'))
                        except Exception:
                            od['id'] = od.get('_id')
                        od.pop('_id', None)
                    out.append(od)
                except Exception:
                    continue
            return out

        return sanitize_list(courses), sanitize_list(products), sanitize_list(webinars)
    except Exception as e:
        logger.debug(f"No se pudo conectar a MongoDB para cargar catálogo: {e}")
        return None

# Cargar datos al importar el módulo: preferir MongoDB splitbot -> colecciones (courses, products, webinars), si falla usar JSON local
db_catalog = load_catalog_from_db()
if db_catalog:
    COURSES_DATA, PRODUCTS_DATA, WEBINARS_DATA = db_catalog
    logger.info(f"Loaded catalog from MongoDB: courses={len(COURSES_DATA)}, products={len(PRODUCTS_DATA)}, webinars={len(WEBINARS_DATA)}")
else:
    COURSES_DATA, PRODUCTS_DATA, WEBINARS_DATA = load_json_data()
    logger.info(f"Loaded catalog from JSON files: courses={len(COURSES_DATA)}, products={len(PRODUCTS_DATA)}, webinars={len(WEBINARS_DATA)}")

def find_best_course_match(query: str):
    if not query:
        return None
    q = query.lower()
    names = []
    mapping = {}
    for c in COURSES_DATA:
        name = (c.get('nombre') or '').strip()
        if not name:
            continue
        names.append(name)
        mapping[name] = c

    if RAPIDFUZZ and names:
        try:
            res = rf_process.extractOne(q, names, scorer=rf_fuzz.token_sort_ratio)
            logger.debug(f"rapidfuzz token_sort_ratio result: {res}")
            if res and res[1] >= 60:
                logger.info(f"Fuzzy matched (token_sort_ratio) '{query}' -> '{res[0]}' score={res[1]}")
                return mapping.get(res[0])
            res2 = rf_process.extractOne(q, names, scorer=rf_fuzz.token_set_ratio)
            logger.debug(f"rapidfuzz token_set_ratio result: {res2}")
            if res2 and res2[1] >= 60:
                logger.info(f"Fuzzy matched (token_set_ratio) '{query}' -> '{res2[0]}' score={res2[1]}")
                return mapping.get(res2[0])
            res3 = rf_process.extractOne(q, names, scorer=rf_fuzz.partial_ratio)
            logger.debug(f"rapidfuzz partial_ratio result: {res3}")
            if res3 and res3[1] >= 60:
                logger.info(f"Fuzzy matched (partial_ratio) '{query}' -> '{res3[0]}' score={res3[1]}")
                return mapping.get(res3[0])
        except Exception:
            # en caso de error con rapidfuzz, continuar con fallback
            logger.exception("Error usando rapidfuzz en find_best_course_match")

    # fallback simple: substring
    for n, c in mapping.items():
        if q in n.lower():
            logger.info(f"Substring matched '{query}' -> '{n}'")
            return c

    return None

@whatsapp_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')

    logger.info(f"Verificación de webhook marketing: mode={mode}, token={token != None}")

    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook de marketing verificado exitosamente")
        return challenge

    logger.warning("Verificación de webhook de marketing fallida")
    return "Verification failed", 403

@whatsapp_bp.route('/webhook', methods=['POST'])
def webhook_handler():
    try:
        try:
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_marketing_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== MARKETING WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END MARKETING WEBHOOK ===\n")
            logger.debug("Raw marketing webhook persisted to logs/webhook_marketing_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw marketing webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST de marketing recibido")

        # Registrar información estructurada del webhook
        try:
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)

            log_webhook_event(
                event_type="webhook_marketing_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
        except Exception as e:
            logger.error(f"Error al procesar información de webhook de marketing: {e}")
            logger.error(traceback.format_exc())

        if not payload:
            logger.warning("Payload vacío recibido en marketing")
            return

        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload de marketing")
            return

        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                messages = value.get('messages', [])
                contacts = value.get('contacts', [])

                for message in messages:
                    # Guardar message_id y prevenir reprocesar el mismo mensaje
                    message_id = message.get('id') or message.get('message_id')
                    message_type = message.get('type')

                    # Solo procesar tipos de mensaje que nos interesen
                    if message_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                        from_number = message.get('from')
                        whatsapp_profile = contacts[0].get('profile', {}) if contacts else {}

                        logger.info(f"Mensaje de marketing recibido de {from_number}: id={message_id} text={message_text}")

                        try:
                            try:
                                msg_count = get_conversation_memory(from_number, 'message_count') or 0
                                msg_count = int(msg_count)
                            except Exception:
                                msg_count = 0
                            msg_count += 1
                            try:
                                save_conversation_memory(from_number, 'message_count', msg_count)
                            except Exception:
                                pass

                            # Si el usuario envía un saludo corto y ya había una conversación iniciada,
                            # reiniciar la memoria para evitar arrastrar selecciones previas.
                            def _is_short_greeting(txt: str) -> bool:
                                if not txt:
                                    return False
                                t = txt.strip().lower()
                                greetings = ['hola', 'buenas', 'buenos dias', 'buenos días', 'buenas tardes', 'buenas noches', 'hi', 'hello']
                                
                                # consideramos saludo corto si contiene una palabra de saludo y es relativamente breve
                                if len(t) > 120:
                                    return False
                                for g in greetings:
                                    if t == g or t.startswith(g + ' ') or t.endswith(' ' + g) or (' ' + g + ' ') in (' ' + t + ' '):
                                        return True
                                return False

                            try:
                                started_flag = get_conversation_memory(from_number, 'conversation_started') or False
                            except Exception:
                                started_flag = False

                            if _is_short_greeting(message_text) and started_flag:
                                try:
                                    clear_conversation_memory(from_number)
                                except Exception:
                                    try:
                                        from services.conversation_memory import ConversationMemory
                                        ConversationMemory.reset_memory(from_number, notify=False)
                                    except Exception:
                                        pass
                                # reiniciar contador y marcar como nueva conversación
                                try:
                                    save_conversation_memory(from_number, 'message_count', 1)
                                    # marcar como no iniciada antes de presentar, luego la presentación activará el inicio
                                    save_conversation_memory(from_number, 'conversation_started', False)
                                except Exception:
                                    pass

                               
                                logger.debug(f"Short greeting received from {from_number}; reset conversation memory and will reprocess as new.")

                            # Si alcanzó el umbral de mensajes, reiniciar la memoria y empezar de nuevo
                            # Aumentado de 10 a 20 según solicitud
                            if msg_count >= 20:
                                try:
                                    clear_conversation_memory(from_number)
                                except Exception:
                                    try:
                                        from services.conversation_memory import ConversationMemory
                                        ConversationMemory.reset_memory(from_number, notify=False)
                                    except Exception:
                                        pass
                                try:
                                    save_conversation_memory(from_number, 'message_count', 0)
                                except Exception:
                                    pass
                                
                                clear_current_webhook_message_id()
                                continue
                        except Exception as _e:
                            logger.debug(f"Error manejando contador de mensajes/reset: {_e}")

                        try:
                            # Marcar current message id en el módulo handler (runtime guard)
                            if message_id:
                                set_current_webhook_message_id(message_id)

                            # Consultar memoria para evitar reprocesar el mismo message id
                            last_id = None
                            try:
                                last_id = get_conversation_memory(from_number, 'last_processed_message_id')
                            except Exception:
                                last_id = None

                            if message_id and last_id and str(last_id) == str(message_id):
                                # Ya fue procesado: marcarlo como leído y no responder
                                try:
                                    from .whatsapp_message_handlers import send_read_receipt
                                    send_read_receipt(message_id)
                                except Exception:
                                    pass
                                logger.debug(f"Ignoring duplicated webhook message {message_id} from {from_number}")
                                clear_current_webhook_message_id()
                                continue

                            try:
                                save_conversation_memory(from_number, 'last_processed_message_id', message_id)
                            except Exception:
                                pass

                        except Exception as _e:
                            logger.debug(f"Error handling message id guard: {_e}")

                       
                        
                        try:
                            handled = handle_course_and_temario_flow(from_number, message_text, whatsapp_profile)
                        except Exception as _e:
                            logger.debug(f"Error en flow de temario: {_e}")
                            handled = False

                        if not handled:
                            process_user_message(from_number, message_text, whatsapp_profile)

        clear_current_webhook_message_id()
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        logger.error(f"Error procesando webhook de marketing: {e}", exc_info=True)
        clear_current_webhook_message_id()
        return jsonify({"status": "error", "message": "Error interno"}), 500
    finally:
        clear_current_webhook_message_id()

def process_user_message(phone: str, message_text: str, whatsapp_profile: dict = None):

    try:
        def _format_fecha_entry(e):
            try:
                if not e:
                    return ''
                if isinstance(e, dict):
                    fecha = e.get('fecha') or e.get('date') or ''
                    horario = e.get('horario') or e.get('time') or ''
                    fecha = str(fecha).strip()
                    horario = str(horario).strip()
                    if fecha and horario:
                        return f"{fecha} ({horario})"
                    return fecha or horario or ''
                if isinstance(e, (list, tuple)):
                    return ', '.join([_format_fecha_entry(x) for x in e if _format_fecha_entry(x)])
                s = str(e).strip()
                s = re.sub(r"^[\[\{\(]+\s*|\s*[\]\}\)]+$", "", s)
                s = s.replace("'", "").replace('"', '')
                return s
            except Exception:
                return str(e)
            
        courses_info = []
        for c in COURSES_DATA:
            info = f"CURSO: {c['nombre']}\n"
            info += f"Descripción: {c['descripcion']}\n"
            info += f"Modalidad: {c['modalidad']}\n"
            info += f"Precio: {c['precio']}\n"
            info += f"Ubicación: {c['ubicacion']}\n"
            info += f"Horario: {c['horario']}\n"
            info += f"Duración: {c['duracion']}\n"
            if 'proximas_fechas' in c and c['proximas_fechas']:
                fechas = [_format_fecha_entry(f) for f in c['proximas_fechas']]
                fechas = [f for f in fechas if f]
                info += f"Próximas fechas: {', '.join(fechas)}\n"
            if 'temario' in c and c['temario']:
                temario = []
                for t in c['temario']:
                    temario.append(f"- {t['titulo']}")
                    if 'subtemas' in t:
                        for st in t['subtemas']:
                            temario.append(f"  • {st}")
                info += f"Temario:\n" + "\n".join(temario) + "\n"
            courses_info.append(info)
        
        products_info = []
        for p in PRODUCTS_DATA:
            info = f"PRODUCTO: {p['nombre']}\n"
            info += f"Descripción: {p['descripcion']}\n"
            info += f"Precio: {p['precio']}\n"
          
            if 'especificaciones' in p:
                specs = "\n".join(f"- {s}" for s in p['especificaciones'])
                info += f"Especificaciones:\n{specs}\n"
            products_info.append(info)
        try:
            save_listed_items(phone, 'products', PRODUCTS_DATA)
        except Exception:
            pass
        
        def _parse_spanish_date_local(s: str):
            import re
            from datetime import datetime
            if not s or not isinstance(s, str):
                return None
            s = s.strip().lower()
            m = re.search(r"(\d{1,2})\s+de\s+([a-záéíóúñ]+)\s+(?:del\s+)?(\d{4})", s)
            if not m:
                return None
            day = int(m.group(1))
            month_name = m.group(2)
            year = int(m.group(3))
            months = {
                'enero':1,'febrero':2,'marzo':3,'abril':4,'mayo':5,'junio':6,
                'julio':7,'agosto':8,'septiembre':9,'setiembre':9,'octubre':10,'noviembre':11,'diciembre':12
            }
            month = months.get(month_name.lower())
            if not month:
                return None
            try:
                return datetime(year, month, day)
            except Exception:
                return None

        def _get_webinar_next_date(item):
            if not item:
                return None
            dates = item.get('fechas') or item.get('proximas_fechas') or item.get('fechas_evento') or []
            if not dates:
                return None
            parsed = []
            for d in dates:
                try:
                    if isinstance(d, dict):
                        candidate = d.get('fecha') or d.get('date')
                    else:
                        candidate = d
                    dt = _parse_spanish_date_local(str(candidate))
                    if dt:
                        parsed.append(dt)
                except Exception:
                    continue
            if not parsed:
                return None
            return max(parsed)

        try:
            sorted_webinars = sorted(WEBINARS_DATA, key=lambda w: _get_webinar_next_date(w) or None, reverse=True)
        except Exception:
            sorted_webinars = WEBINARS_DATA

        webinars_info = []
        for w in sorted_webinars:
            info = f"WEBINAR: {w.get('title') or w.get('name')}\n"
            info += f"Descripción: {w.get('description','')}\n"
            if 'fechas' in w:
                try:
                    info += f"Fechas: {', '.join(w.get('fechas') or [])}\n"
                except Exception:
                    info += "Fechas: N/D\n"
            if 'horario' in w:
                try:
                    info += f"Horario: {', '.join(w.get('horario') or [])}\n"
                except Exception:
                    info += "Horario: N/D\n"
            if 'topics' in w:
                topics = "\n".join(f"- {t}" for t in (w.get('topics') or []))
                info += f"Temas:\n{topics}\n"
            webinars_info.append(info)
        
        all_info = "\n---\n".join(courses_info + products_info + webinars_info)

        def fuzzy_find_course_by_name(query: str):
            if not query:
                return None
            q = query.lower()
            names = []
            mapping = {}
            for c in COURSES_DATA:
                name = (c.get('nombre') or '').strip()
                if not name:
                    continue
                names.append(name)
                mapping[name] = c

            if RAPIDFUZZ and names:
                try:
                    res = rf_process.extractOne(q, names, scorer=rf_fuzz.token_sort_ratio)
                    if res and res[1] >= 70:
                        return mapping.get(res[0])
                except Exception:
                    pass

            for n, c in mapping.items():
                if q in n.lower():
                    return c
            return None
        
        try: 
            if get_product_response: 
                prod_resp = get_product_response(message_text)
                if prod_resp: 
                    logger.info(f"Atendiendo la consulta de {phone}")

                    #enviar la respuesta simple 
                    # guardar contexto del producto para futuras preguntas cortas
                    try:
                        prod_item = None
                        if 'products_service' in globals() and products_services is not None:
                            # note: products_services variable name may differ; try both
                            svc = globals().get('products_service') or globals().get('products_services') or products_services
                            try:
                                prod_item = svc.detect_product(message_text)
                            except Exception:
                                prod_item = None
                        if prod_item:
                            save_current_item(phone, 'product', str(prod_item.get('id') or prod_item.get('_id') or ''), prod_item.get('nombre') or prod_item.get('name') or prod_item.get('title') or '', prod_item)
                    except Exception:
                        logger.debug('No se pudo guardar contexto de producto')

                    send_text_message(phone, prod_resp)
                    return 
        except Exception: 
            logger.exception(f"Error al intentar responder")

        try:
            if get_course_response:
                course_resp = get_course_response(message_text)
                if course_resp: 
                    logger.info(f"Respondiendo a {phone}")
                    # intentar detectar el curso y guardarlo como seleccionado/contexto
                    try:
                        selected = None
                        if 'course_service' in globals() and course_service is not None:
                            try:
                                selected = course_service.detect_course(message_text)
                            except Exception:
                                selected = None
                        if selected and isinstance(selected, dict) and selected.get('id'):
                            try:
                                save_selected_course(phone, selected)
                            except Exception:
                                pass
                            try:
                                save_current_item(phone, 'course', str(selected.get('id') or selected.get('_id') or ''), selected.get('nombre') or selected.get('name') or '', selected)
                            except Exception:
                                pass
                    except Exception:
                        logger.debug('No se pudo guardar curso seleccionado')

                    send_text_message(phone, course_resp)
                    return 
        except Exception: 
            logger.exception(f"Error al intentar responder")

        # Intentar respuesta rápida por webinar (descripcion, topics, fechas, horario, link)
        try:
            if get_webinar_response:
                webinar_resp = get_webinar_response(message_text)
                if webinar_resp:
                    logger.info(f"WebinarService atendió la consulta de {phone}")
                    try:
                        witem = None
                        if 'webinar_service' in globals() and webinar_service is not None:
                            try:
                                witem = webinar_service.detect_webinar(message_text)
                            except Exception:
                                witem = None
                        if witem:
                            save_current_item(phone, 'webinar', str(witem.get('id') or witem.get('_id') or ''), witem.get('title') or witem.get('name') or '', witem)
                    except Exception:
                        logger.debug('No se pudo guardar contexto de webinar')

                    send_text_message(phone, webinar_resp)
                    return
        except Exception:
            logger.exception(f"Error al intentar responder (webinar)")

        try:
            mq_early = (message_text or '').lower()
            online_triggers_early = ['online', 'en linea', 'en línea', 'modalidad', 'modalidad online', 'curso en linea', 'cursos en linea', 'cursos en línea', 'modalidad online', 'webinars', 'webinar', 'cuentas con webinars']
            if any(t in mq_early for t in online_triggers_early):
                try:
                    sorted_webinars_early = sorted(WEBINARS_DATA, key=lambda w: _get_webinar_next_date(w) or None, reverse=True)
                except Exception:
                    sorted_webinars_early = WEBINARS_DATA

                parts_early = ["Veo que buscas opciones en modalidad online. Aquí tienes nuestros webinars (ordenados del más próximo al más lejano):\n"]
                from textwrap import shorten
                for w in sorted_webinars_early:
                    title = w.get('title') or w.get('name') or 'Webinar'
                    desc = w.get('description', '')
                    fechas = w.get('fechas') or []
                    horario = w.get('horario') or []
                    link = w.get('link') or w.get('url') or w.get('enlace') or ''
                    fechas_str = ', '.join([_format_fecha_entry(f) for f in fechas if _format_fecha_entry(f)]) or 'Fechas por confirmar'
                    horario_str = ', '.join([_format_fecha_entry(h) for h in horario if _format_fecha_entry(h)]) or 'Horario por confirmar'
                    short_desc = shorten(desc, width=300, placeholder='...')
                    if link:
                        parts_early.append(f"• {title}\n  Fechas: {fechas_str}\n  Horario: {horario_str}\n  {short_desc}\n  Enlace: {link}\n")
                    else:
                        parts_early.append(f"• {title}\n  Fechas: {fechas_str}\n  Horario: {horario_str}\n  {short_desc}\n")

                reply_early = "\n\n".join(parts_early)
                try:
                    save_listed_items(phone, 'webinars', sorted_webinars_early)
                except Exception:
                    pass
                try:
                    send_text_message(phone, reply_early)
                except Exception:
                    logger.exception('Error sending webinars reply (early deterministic handler)')
                return
        except Exception:
            logger.debug('Early webinar deterministic handler raised an exception, falling back')

        logger.info(f"Procesando msg desde {phone}: {message_text}")

        def is_technical_message(text: str) -> bool:
            if not text or not isinstance(text, str):
                return False
            t = text.lower()
            technical_indicators = [
                'cómo', 'como', 'cómo funciona', 'dispersión', 'dispersi', 'otdr', 'empalme', 'empalmes',
                'fusión', 'fusion', 'conector', 'atenuación', 'atenuacion', 'pérdida', 'perdida',
                'monomodo', 'multimodo', 'especificaciones', 'características', 'caracteristicas',
                'configurar', 'instalar', 'mediciones', 'medicion', 'prueba', 'pruebas'
            ]
            return any(k in t for k in technical_indicators)

        # Si el mensaje es una pregunta por atributo corto (ej: "precio", "descripcion")
        # y ya existe un current_item en memoria, responder usando ese contexto para evitar perder el hilo.
        try:
            short_attr = detect_generic_attribute(message_text)
            current = None
            try:
                current = get_current_item(phone) or None
            except Exception:
                current = None

            if short_attr and current and isinstance(current, dict):
                # current tiene la forma {'type','id','name','data',...}
                itype = current.get('type')
                item_data = current.get('data') or {}
                item_name = current.get('name') or current.get('nombre') or ''
                reply = None
                if itype == 'product':
                    try:
                        # usar products_service si está disponible para construir respuesta por atributo
                        svc = globals().get('products_service')
                        if svc:
                            if short_attr == 'descripcion':
                                reply = f"Descripción de {item_name}: {item_data.get('descripcion','No disponible')}"
                            elif short_attr == 'precio':
                                reply = f"Precio de {item_name}: {item_data.get('precio','Consultar con asesor')}"
                            elif short_attr == 'especificaciones':
                                specs = item_data.get('especificaciones') or []
                                reply = f"Especificaciones de {item_name}:\n" + '\n'.join(f"- {s}" for s in specs) if specs else f"{item_name} no tiene especificaciones registradas"
                            elif short_attr == 'link':
                                reply = f"Enlace: {item_data.get('link','No disponible')}"
                            else:
                                reply = None
                    except Exception:
                        reply = None

                elif itype == 'course':
                    try:
                        # respuestas de curso basadas en campos comunes
                        if short_attr == 'precio':
                            reply = f"Precio de {item_name}: {item_data.get('precio','Consultar con asesor')}"
                        elif short_attr == 'descripcion':
                            reply = f"Descripción de {item_name}: {item_data.get('descripcion','No disponible')}"
                        elif short_attr == 'modalidad':
                            reply = f"Modalidad de {item_name}: {item_data.get('modalidad','No especificada')}"
                        elif short_attr == 'ubicacion':
                            reply = f"Ubicación de {item_name}: {item_data.get('ubicacion','No especificada')}"
                        elif short_attr == 'horario':
                            reply = f"Horario de {item_name}: {item_data.get('horario','No especificado')}"
                        elif short_attr == 'duracion':
                            reply = f"Duración de {item_name}: {item_data.get('duracion','No especificada')}"
                        elif short_attr == 'fechas':
                            pf = item_data.get('proximas_fechas') or []
                            if pf:
                                lines = [f"- {x.get('fecha')} ({x.get('horario','')})" if isinstance(x, dict) else f"- {x}" for x in pf]
                                reply = f"Próximas fechas de {item_name}:\n" + '\n'.join(lines)
                            else:
                                reply = f"No hay próximas fechas registradas para {item_name}"
                        elif short_attr == 'temario':
                            t = item_data.get('temario') or []
                            if t:
                                parts = [f"Temario de {item_name}:"]
                                for s in t:
                                    parts.append(f"- {s.get('titulo')}")
                                    if 'subtemas' in s:
                                        for st in s.get('subtemas'):
                                            parts.append(f"  • {st}")
                                reply = '\n'.join(parts)
                            else:
                                reply = f"{item_name} no tiene temario registrado"
                        else:
                            reply = None
                    except Exception:
                        reply = None

                elif itype == 'webinar':
                    try:
                        if short_attr == 'description':
                            reply = f"Descripción de {item_name}: {item_data.get('description','No disponible')}"
                        elif short_attr == 'topics' or short_attr == 'temario':
                            tops = item_data.get('topics') or []
                            reply = f"Temas de {item_name}:\n" + '\n'.join(f"- {t}" for t in tops) if tops else f"{item_name} no tiene topics listados"
                        elif short_attr == 'fechas':
                            fechas = item_data.get('fechas') or []
                            reply = f"Fechas de {item_name}:\n" + '\n'.join(f"- {f}" for f in fechas if f) if fechas else f"No hay fechas registradas para {item_name}"
                        elif short_attr == 'horario':
                            horario = item_data.get('horario') or []
                            reply = f"Horario de {item_name}: {', '.join(horario) if isinstance(horario, list) else horario}"
                        elif short_attr == 'link':
                            reply = f"Enlace de {item_name}: {item_data.get('link','No disponible')}"
                        else:
                            reply = None
                    except Exception:
                        reply = None

                if reply:
                    try:
                        send_text_message(phone, reply)
                        return
                    except Exception:
                        logger.exception('Error sending short attr reply from context')
        except Exception:
            logger.debug('Error handling short attribute with context, continuing to IA path')
        try:
            already_started = get_conversation_memory(phone, 'conversation_started') or False
            def is_initial_greeting(txt: str) -> bool:
                if not txt:
                    return False
                t = txt.strip().lower()
                greetings = [
                    'hola', 'buenas', 'buenos dias', 'buenos días', 'buenas tardes', 'buenas noches',
                    'hi', 'hello'
                ]
                catalog_terms = ['curso', 'cursos', 'webinar', 'webinars', 'producto', 'productos', 'temario']

                if len(t) <= 60:
                    if any(g in t for g in greetings):
                        return True

                    tokens = [w for w in re.findall(r"\w+", t) if w]
                    if tokens and all((tok in catalog_terms or tok in [g.replace(' ', '') for g in greetings] or tok in greetings) for tok in tokens) and len(tokens) <= 6:
                        return True

                return False

            if not already_started and is_initial_greeting(message_text):
                intro = "¡Hola! 👋 ¿En que te puedo ayudar hoy?."
                send_text_message(phone, intro)
                try:
                    save_conversation_memory(phone, 'conversation_started', True)
                except Exception:
                    pass
                try:
                    save_conversation_memory(phone, 'awaiting_course_intro_confirmation', True)
                except Exception:
                    pass
                return
        except Exception:
            logger.debug('Error detecting initial greeting, continuing with normal flow')

        try:
            import re
            course_candidate = None
            lower_msg = (message_text or '').strip().lower()

            m = re.search(r"\bcurso\s+(?:id\s+)?(\d{1,6})\b", lower_msg)
            if m:
                try:
                    cid = int(m.group(1))
                    for c in COURSES_DATA:
                        try:
                            cid_field = c.get('id')
                            if cid_field is not None and str(cid_field) == str(cid):
                                course_candidate = c
                                break
                            try:
                                if int(cid_field) == cid:
                                    course_candidate = c
                                    break
                            except Exception:
                                continue
                        except Exception:
                            continue
                except Exception:
                    course_candidate = None

            if not course_candidate:
                tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                if tokens:
                    for c in COURSES_DATA:
                        name = (c.get('nombre') or '').lower()
                        short = (c.get('nombre_corto') or '').lower()
                        if any(tok in name or tok in short for tok in tokens):
                            course_candidate = c
                            break

            if not course_candidate:
                try:
                    if re.match(r"^\d+$", lower_msg):
                        cid_only = int(lower_msg)
                        for c in COURSES_DATA:
                            cid_field = c.get('id')
                            if cid_field is not None and str(cid_field) == str(cid_only):
                                course_candidate = c
                                break
                except Exception:
                    pass

            if not course_candidate and lower_msg:
                for c in COURSES_DATA:
                    try:
                        full_name = (c.get('nombre') or '').strip().lower()
                        short_name = (c.get('nombre_corto') or '').strip().lower()
                        if full_name and (lower_msg == full_name or lower_msg == f"curso {full_name}"):
                            course_candidate = c
                            break
                        if short_name and lower_msg == short_name:
                            course_candidate = c
                            break
                    except Exception:
                        continue


            if not course_candidate:
                try:
                    course_candidate = fuzzy_find_course_by_name(message_text)
                except Exception:
                    course_candidate = None

            if course_candidate:
                try:
                    cid = int(course_candidate.get('id') or 0)
                except Exception:
                    cid = 0
                cname = course_candidate.get('nombre') or course_candidate.get('title') or 'Curso'
                try:                  
                    lower_msg = (message_text or '').strip().lower()
                    explicit_selection = False
                    try:
                        if re.match(r"^\d+$", lower_msg):
                            explicit_selection = True
                        if any(v in lower_msg for v in ['quiero', 'seleccionar', 'ese', 'ese curso', 'lo quiero', 'dame', 'quiero el']):
                            explicit_selection = True
                    except Exception:
                        explicit_selection = False

                    logger.info(f"Detected course_candidate for {phone}: id={cid}, name={cname}; explicit_selection={explicit_selection}")
                    if explicit_selection:
                        save_selected_course(phone, cid, cname, course_candidate)
                        try:
                            save_current_item(phone, 'course', cid, cname, course_candidate)
                        except Exception:
                            pass
                except Exception:
                    try:
                        save_conversation_memory(phone, 'selected_course', {'id': cid, 'name': cname, 'details': course_candidate})
                        try:
                            save_current_item(phone, 'course', cid, cname, course_candidate)
                        except Exception:
                            pass
                    except Exception:
                        pass
        except Exception:
            pass

        try:
            datos_cursos = []
            def parse_spanish_date(s: str):
                if not s or not isinstance(s, str):
                    return None
                s = s.strip().lower()
                import re
                m = re.search(r"(\d{1,2})\s+de\s+([a-záéíóúñ]+)\s+(?:del\s+)?(\d{4})", s)
                if not m:
                    return None
                day = int(m.group(1))
                month_name = m.group(2)
                year = int(m.group(3))
                months = {
                    'enero':1,'febrero':2,'marzo':3,'abril':4,'mayo':5,'junio':6,
                    'julio':7,'agosto':8,'septiembre':9,'setiembre':9,'octubre':10,'noviembre':11,'diciembre':12
                }
                month = months.get(month_name.lower())
                if not month:
                    return None
                from datetime import datetime
                try:
                    return datetime(year, month, day)
                except Exception:
                    return None

            def get_item_next_date(item):
                if not item:
                    return None
                dates = item.get('fechas') or item.get('proximas_fechas') or item.get('fechas_evento') or []
                if not dates:
                    return None
                parsed = []
                for d in dates:
                    try:
                        if isinstance(d, dict):
                            candidate = d.get('fecha') or d.get('date')
                        else:
                            candidate = d
                        dt = parse_spanish_date(str(candidate))
                        if dt:
                            parsed.append(dt)
                    except Exception:
                        continue
                if not parsed:
                    return None
                return max(parsed)
            try:
                sorted_courses = sorted(COURSES_DATA, key=lambda x: get_item_next_date(x) or None, reverse=True)
            except Exception:
                sorted_courses = COURSES_DATA
            for c in sorted_courses:
                try:
                    cid = c.get('id') or ''
                except Exception:
                    cid = ''
                precio = c.get('precio') or c.get('price') or 'Consultar con asesor'
                modalidad = c.get('modalidad') or c.get('modalidad_nombre') or c.get('modalidad_tipo') or 'N/D'
                ubicacion = c.get('ubicacion') or c.get('location') or 'N/D'
                duracion = c.get('duracion') or c.get('duration') or 'N/D'
                datos_cursos.append(f"ID:{cid} | Nombre:{c.get('nombre')} | Precio:{precio} | Modalidad:{modalidad} | Ubicación:{ubicacion} | Duración:{duracion}")
            datos_cursos_block = "\n".join(datos_cursos)
            try:
                save_listed_items(phone, 'courses', sorted_courses)
            except Exception:
                pass
        except Exception:
            datos_cursos_block = ''

        try:
            mq = (message_text or '').lower()
            online_triggers = ['online', 'en linea', 'en línea', 'modalidad', 'modalidad online', 'curso en linea', 'cursos en linea', 'cursos en línea', 'modalidad online', 'webinars', 'webinar']
            if any(t in mq for t in online_triggers):
                try:
                    sorted_webinars = sorted(WEBINARS_DATA, key=lambda w: get_item_next_date(w) or None, reverse=True)
                except Exception:
                    sorted_webinars = WEBINARS_DATA

                parts = ["Veo que buscas opciones en modalidad online. Aquí tienes nuestros webinars (ordenados del más próximo al más lejano):\n"]
                from textwrap import shorten
                for w in sorted_webinars:
                    title = w.get('title') or w.get('name') or 'Webinar'
                    desc = w.get('description', '')
                    fechas = w.get('fechas') or []
                    horario = w.get('horario') or []
                    link = w.get('link') or w.get('url') or w.get('enlace') or ''
                    fechas_str = ', '.join([_format_fecha_entry(f) for f in fechas if _format_fecha_entry(f)]) or 'Fechas por confirmar'
                    horario_str = ', '.join([_format_fecha_entry(h) for h in horario if _format_fecha_entry(h)]) or 'Horario por confirmar'
                    short_desc = shorten(desc, width=300, placeholder='...')
                    if link:
                        parts.append(f"• {title}\n  Fechas: {fechas_str}\n  Horario: {horario_str}\n  {short_desc}\n  Enlace: {link}\n")
                    else:
                        parts.append(f"• {title}\n  Fechas: {fechas_str}\n  Horario: {horario_str}\n  {short_desc}\n")

                reply = "\n\n".join(parts)
                try:
                    save_listed_items(phone, 'webinars', sorted_webinars)
                except Exception:
                    pass
                try:
                    send_text_message(phone, reply)
                except Exception:
                    logger.exception('Error sending webinars reply')
                return
            # Detectar si el usuario menciona un producto concreto y guardarlo
            try:
                product_candidate = None
                m2 = re.search(r"\bproducto\s+(?:id\s+)?(\d{1,6})\b", message_text.lower())
                if m2:
                    try:
                        pid = int(m2.group(1))
                        for p in PRODUCTS_DATA:
                            try:
                                if int(p.get('id', -1)) == pid:
                                    product_candidate = p
                                    break
                            except Exception:
                                continue
                    except Exception:
                        product_candidate = None

                if not product_candidate:
                    tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                    if tokens:
                        for p in PRODUCTS_DATA:
                            name = (p.get('nombre') or '').lower()
                            if any(tok in name for tok in tokens):
                                product_candidate = p
                                break

                if product_candidate:
                    try:
                        pid = product_candidate.get('id')
                        pname = product_candidate.get('nombre') or product_candidate.get('title') or 'Producto'
                        save_current_item(phone, 'product', pid, pname, product_candidate)
                        logger.info(f"Saved selected product for {phone}: id={pid}, name={pname}")
                    except Exception:
                        pass
            except Exception:
                pass

            # Detectar si el usuario menciona un webinar concreto y guardarlo
            try:
                webinar_candidate = None
                m3 = re.search(r"\bwebinar\s+(?:id\s+)?(\d{1,6})\b", message_text.lower())
                if m3:
                    try:
                        wid = int(m3.group(1))
                        for w in WEBINARS_DATA:
                            try:
                                if int(w.get('id', -1)) == wid:
                                    webinar_candidate = w
                                    break
                            except Exception:
                                continue
                    except Exception:
                        webinar_candidate = None

                if not webinar_candidate:
                    tokens = [t for t in re.findall(r"\w+", message_text.lower()) if len(t) > 3]
                    if tokens:
                        for w in WEBINARS_DATA:
                            name = (w.get('title') or w.get('name') or '').lower()
                            if any(tok in name for tok in tokens):
                                webinar_candidate = w
                                break

                if webinar_candidate:
                    try:
                        wid = webinar_candidate.get('id')
                        wname = webinar_candidate.get('title') or webinar_candidate.get('name') or 'Webinar'
                        lower_msg = (message_text or '').strip().lower()
                        explicit_selection = False
                        try:
                            if re.match(r"^\d+$", lower_msg):
                                explicit_selection = True
                            if any(v in lower_msg for v in ['quiero', 'seleccionar', 'ese', 'dame', 'quiero el', 'lo quiero']):
                                explicit_selection = True
                        except Exception:
                            explicit_selection = False

                        logger.info(f"Detected webinar_candidate for {phone}: id={wid}, name={wname}; explicit_selection={explicit_selection}")
                        if explicit_selection:
                            save_current_item(phone, 'webinar', wid, wname, webinar_candidate)
                            logger.info(f"Saved selected webinar for {phone}: id={wid}, name={wname}")
                    except Exception:
                        logger.exception('Error handling webinar_candidate selection')
            except Exception as ex:
                logger.exception(f"Error detectando webinar/producto: {ex}")
        except Exception:
            pass
        try:
            sel = get_conversation_memory(phone, 'selected_course')
            if isinstance(sel, dict) and sel.get('id'):
                selected_course_block = f"SELECTED_COURSE: ID:{sel.get('id')} | Nombre:{sel.get('nombre') or sel.get('name')} | Detalles guardados en memoria."
            else:
                selected_course_block = ''
        except Exception:
            selected_course_block = ''

        logger.debug(f"Selected course block: {selected_course_block}")

        json_instruction = (
            "Si el usuario solicita datos detallados (precio, duración, fechas, ubicación, temario), "
            "RESPONDE únicamente con UN OBJETO JSON válido con las claves: type (course|product|webinar), id, name, price, duration, dates (array), location, temario (array|null), temario_pdf (string|null)."
        )

        system_prompt = f"""
            Eres un asesor y consultor de fibremex  especializado en telecomunicaciones y fibra optica, (empresa de fibra óptica y telecomunicaciones) no incluyas mensajes de Hola ni te presentes solo reponde a lo que quiere el usuario . 

            INFORMACIÓN COMPLETA DISPONIBLE:
            {all_info}

            INSTRUCCIONES IMPORTANTES:

            IMPORTANTE: 

            {json_instruction}

            [DATOS_CURSOS]
            Proporciono a continuación una lista compacta con los cursos disponibles y sus atributos exactos. Usa estos datos como fuente única y no inventes nada fuera de este bloque:
            {datos_cursos_block}

            {selected_course_block}

            si preguntan por el precio de los cursos, responde con el precio correspondiente, no digas que lo contactara con el asesor si esta el precio presente darselo.
            darlela ubicacion 
            fechas, 
            costos, 
            precios 
            la informacion que encuentres en el json y en la db darselo tal cual 
"""

        lower_msg = (message_text or '').lower()
        catalog_keywords = ['curso', 'cursos', 'producto', 'productos', 'webinar', 'webinars', 'cursos en linea', 'cursos online', 'cursos en línea', 'temario', 'precio', 'duracion', 'duración', 'fechas', 'ubicacion', 'ubicación']
        try:
            try:
                is_course_query = 'curso' in lower_msg or 'cursos' in lower_msg
            except Exception:
                is_course_query = False

            awaiting_intro = get_conversation_memory(phone, 'awaiting_course_intro_confirmation') or False
            if awaiting_intro:
                ans = (lower_msg or '').strip()
                if any(t in ans for t in ['si', 'sí', 's', 'yes']):
                    try:
                        # Only show full course list if the user's message is not technical
                        if not is_technical_message(message_text):
                            parts = ["Perfecto. Aquí tienes la lista de nuestros cursos (ordenados por fecha próxima):\n"]
                            for idx, c in enumerate(sorted_courses, start=1):
                                name = c.get('nombre') or c.get('title') or 'Curso'
                                dates = c.get('fechas') or c.get('proximas_fechas') or []
                                date_str = ', '.join([str(d) for d in dates]) if dates else 'Fechas por confirmar'
                                parts.append(f"{idx}. {name} — {date_str}")
                            reply = "\n".join(parts)
                            send_text_message(phone, reply)
                        try:
                            save_listed_items(phone, 'courses', sorted_courses)
                        except Exception:
                            pass
                        save_conversation_memory(phone, 'awaiting_course_intro_confirmation', None)
                        return
                    except Exception:
                        pass
                else:
                    try:
                        save_conversation_memory(phone, 'awaiting_course_intro_confirmation', None)
                        send_text_message(phone, "Entendido. ¿En qué puedo ayudarte?")
                        return
                    except Exception:
                        pass

          
            presencial_terms = ['presencial', 'presenciales', 'en persona', 'sede', 'local', 'presencialmente']
            mentions_presencial = any(pt in lower_msg for pt in presencial_terms)
            if is_course_query and mentions_presencial and not re.search(r"\bcurso\s+(?:id\s+)?\d", lower_msg) and not any(k in lower_msg for k in ['temario', 'temario pdf', 'ficha', 'precio']):
                try:
                    # Only prompt to show full list if message is not technical
                    if not is_technical_message(message_text):
                        send_text_message(phone, "¿Deseas ver la lista completa de cursos disponibles?")
                    try:
                        save_conversation_memory(phone, 'awaiting_course_intro_confirmation', True)
                        try:
                            save_listed_items(phone, 'courses', sorted_courses)
                        except Exception:
                            pass
                    except Exception:
                        pass
                    return
                except Exception:
                    pass

            if any(k in lower_msg for k in catalog_keywords):
               
                try:
                    detail_triggers_local = ['precio', 'duracion', 'duración', 'fechas', 'ubicacion', 'ubicación', 'temario', 'contenido']
                    if ('curso' in lower_msg or 'cursos' in lower_msg) and not any(dt in lower_msg for dt in detail_triggers_local):
                        parts = ["Tenemos los siguientes cursos disponibles:\n"]
                        listed = []
                        for idx, c in enumerate(COURSES_DATA, start=1):
                            name = c.get('nombre') or c.get('name') or c.get('title') or 'Curso'
                            desc = c.get('descripcion') or c.get('descripcion_corta') or c.get('description') or ''
                            price = c.get('precio') or c.get('price') or ''
                            dates = c.get('fechas') or c.get('proximas_fechas') or []
                            date_str = ', '.join([_format_fecha_entry(d) for d in dates if _format_fecha_entry(d)]) if dates else ''
                            loc = c.get('ubicacion') or c.get('location') or ''
                            block = []
                            block.append(f"*{name}*")
                            if desc:
                                block.append(f"  Descripción: {desc}")
                            if c.get('modalidad'):
                                block.append(f"  Modalidad: {c.get('modalidad')}")
                            if price:
                                block.append(f"  Precio: {price}")
                            if loc:
                                block.append(f"  Ubicación: {loc}")
                            if date_str:
                                block.append(f"  Próximas fechas: {date_str}")
                            parts.append("\n".join(block))
                            listed.append(c)

                        # Only send full catalog when the user is not asking a technical question
                        if not is_technical_message(message_text):
                            try:
                                save_listed_items(phone, 'courses', listed)
                            except Exception:
                                pass

                            cur = ""
                            max_len = 3000
                            for p in parts:
                                if len(cur) + len(p) + 2 > max_len:
                                    send_text_message(phone, cur)
                                    cur = ""
                                cur = cur + p + "\n\n"
                            if cur.strip():
                                send_text_message(phone, cur.strip())
                            return
                        else:
                            # If it's a technical query, do not show courses; let the AI handle the technical answer
                            logger.debug('Detected technical query - skipping deterministic course catalog response')

                    if ('producto' in lower_msg or 'productos' in lower_msg) and not any(dt in lower_msg for dt in detail_triggers_local):
                        parts = ["Tenemos los siguientes productos disponibles:\n"]
                        listed = []
                        for idx, p in enumerate(PRODUCTS_DATA, start=1):
                            name = p.get('nombre') or p.get('name') or p.get('title') or 'Producto'
                            price = p.get('precio') or p.get('price') or ''
                            specs = p.get('especificaciones') or p.get('specifications') or ''
                            block = [f"{idx}. *{name}*"]
                            if price:
                                block.append(f"  Precio: {price}")
                            if specs and isinstance(specs, (list, tuple)):
                                spec_text = '\n'.join([f"    - {s}" for s in specs])
                                block.append(f"  Especificaciones:\n{spec_text}")
                            parts.append("\n".join(block))
                            listed.append(p)

                        try:
                            save_listed_items(phone, 'products', listed)
                        except Exception:
                            pass

                        cur = ""
                        max_len = 3000
                        for p in parts:
                            if len(cur) + len(p) + 2 > max_len:
                                send_text_message(phone, cur)
                                cur = ""
                            cur = cur + p + "\n\n"
                        if cur.strip():
                            send_text_message(phone, cur.strip())
                        return
                except Exception:
                    logger.exception('Error building deterministic catalog response, falling back')

                handled = handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                if handled:
                    return
        except Exception:
            pass

        
        def _looks_like_error_text(s: Optional[str]) -> bool:
            if not s or not isinstance(s, str):
                return False
            low = s.lower()
            indicators = [
                'traceback', 'exception', 'error', 'failed to', 'failed', 'max retries',
                'connectionpool', 'failed to resolve', 'getaddrinfo', 'nameerror', 'module not found',
                'httperror', 'httperror', 'connection refused', 'connection reset'
            ]
            return any(ind in low for ind in indicators)

        def _safe_send_ai_text(text: Optional[str]):
            """Send AI text to user but replace error-like content with a friendly prompt."""
            try:
                if not text or _looks_like_error_text(text):
                    send_text_message(phone, "No entendí eso, ¿podrías volver a intentar?")
                    return False
                if isinstance(text, str) and len(text) > 4000:
                    send_text_message(phone, text[:3800] + "...\n\n(Respuesta truncada)")
                    return True
                send_text_message(phone, text)
                return True
            except Exception:
                logger.exception('Error enviando respuesta AI de forma segura')
                try:
                    send_text_message(phone, "No entendí eso, ¿podrías volver a intentar?")
                except Exception:
                    logger.debug('No se pudo enviar mensaje de fallback al usuario')
                return False

        try:
            ai_response = chat_with_gemini(
                phone=phone,
                message=message_text,
                system_prompt=system_prompt,
                include_whatsapp_profile=whatsapp_profile or {}
            )
        except Exception:
            logger.exception('chat_with_gemini raised an exception')
            ai_response = None

        if _looks_like_error_text(ai_response):
            logger.warning('chat_with_gemini returned error-like text; suppressing raw output to user')
            ai_response = None

        logger.info("LLM called for marketing message; received raw response (truncated): %s", (ai_response or '')[:500])

        try:
            lower_msg = (message_text or '').lower()
            detail_triggers = ['precio', 'duracion', 'duración', 'fechas', 'ubicacion', 'ubicación', 'temario', 'contenido']
            asked_for_details = any(t in lower_msg for t in detail_triggers)

            if asked_for_details:
                    try:
                        cur_item = get_current_item(phone)
                    except Exception:
                        cur_item = None

                    if cur_item and isinstance(cur_item, dict):
                        resolved = None
                        resolved_type = None
                        try:
                            from pymongo import MongoClient
                            mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                            client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                            db = client.get_database('splitbot')
                            typ = (cur_item.get('type') or cur_item.get('item_type') or cur_item.get('kind') or '')
                            cid = cur_item.get('id') or (cur_item.get('data') and cur_item.get('data').get('id'))
                            coll = None
                            if typ and ('course' in typ.lower() or 'curso' in typ.lower()):
                                coll = db.get_collection('courses')
                                resolved_type = 'course'
                            elif typ and 'product' in typ.lower():
                                coll = db.get_collection('products')
                                resolved_type = 'product'
                            elif typ and 'webinar' in typ.lower():
                                coll = db.get_collection('webinars')
                                resolved_type = 'webinar'

                            def _resolve_by_id(coll, cid):
                                try:
                                    from bson import ObjectId
                                    if isinstance(cid, str) and len(cid) == 24:
                                        try:
                                            d = coll.find_one({'_id': ObjectId(cid)})
                                            if d:
                                                return d
                                        except Exception:
                                            pass
                                except Exception:
                                    pass

                                try:
                                    d = coll.find_one({'id': cid})
                                    if d:
                                        return d
                                except Exception:
                                    pass

                                try:
                                    d = coll.find_one({'id': int(cid)})
                                    if d:
                                        return d
                                except Exception:
                                    pass
                                return None

                            if coll and cid:
                                doc = _resolve_by_id(coll, cid)

                                if doc:
                                    try:
                                        if doc.get('_id') is not None:
                                            doc['id'] = str(doc.get('_id'))
                                            doc.pop('_id', None)
                                    except Exception:
                                        pass
                                    resolved = doc
                        except Exception:
                            resolved = None

                        if not resolved:
                            for lst, k in ((COURSES_DATA, 'course'), (PRODUCTS_DATA, 'product'), (WEBINARS_DATA, 'webinar')):
                                for item in lst:
                                    try:
                                        if str(item.get('id')) == str(cur_item.get('id')) or str(item.get('id')) == str(cur_item.get('data', {}).get('id')):
                                            resolved = item
                                            resolved_type = k
                                            break
                                    except Exception:
                                        continue
                                if resolved:
                                    break

                        if resolved:
                            try:
                                name = resolved.get('nombre') or resolved.get('title') or resolved.get('name') or ''
                                price = resolved.get('precio') or resolved.get('price') or ''
                                duration = resolved.get('duracion') or resolved.get('duration') or ''
                                dates = resolved.get('fechas') or resolved.get('proximas_fechas') or resolved.get('fechas_evento') or []
                                location = resolved.get('ubicacion') or resolved.get('location') or ''
                                temario = resolved.get('temario') or resolved.get('topics') or []
                                temario_pdf = resolved.get('temario_pdf') or resolved.get('temarioPdf') or None

                                out_parts = []
                                out_parts.append(f"*{name}*")
                                if price:
                                    out_parts.append(f"Precio: {price}")
                                if duration:
                                    out_parts.append(f"Duración: {duration}")
                                if dates:
                                    out_parts.append(f"Fechas: {', '.join([str(d) for d in dates])}")
                                if location:
                                    out_parts.append(f"Ubicación: {location}")
                                if temario:
                                    tem_preview = '\n'.join([f"- {t.get('titulo') if isinstance(t, dict) else t}" for t in (temario[:10] if isinstance(temario, list) else [])])
                                    if tem_preview:
                                        out_parts.append(f"Temario:\n{tem_preview}")
                                if temario_pdf:
                                    out_parts.append(f"Temario PDF: {temario_pdf}")

                                send_text_message(phone, "\n\n".join(out_parts))
                                try:
                                    save_current_item(phone, resolved_type or (cur_item.get('type') or 'course'), resolved.get('id'), name, resolved)
                                except Exception:
                                    pass
                                return
                            except Exception:
                                logger.exception('Error building direct DB response for current_item')
                                pass
                        try:
                            num = None
                            mnum = re.search(r"\b([1-9][0-9]?)\b", message_text or "")
                            if mnum:
                                num = int(mnum.group(1))

                            if num is not None:
                                for typ in ['courses', 'products', 'webinars']:
                                    listed = get_listed_items(phone, typ) or []
                                    if listed and 1 <= num <= len(listed):
                                        sel = listed[num-1]
                                        cid = sel.get('id')
                                        try:
                                            from pymongo import MongoClient
                                            mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                                            client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                                            db = client.get_database('splitbot')
                                            coll = db.get_collection('courses') if typ == 'courses' else (db.get_collection('products') if typ == 'products' else db.get_collection('webinars'))
                                            try:
                                                doc = _resolve_by_id(coll, cid)
                                            except Exception:
                                                doc = None
                                            if doc:
                                                try:
                                                    if doc.get('_id') is not None:
                                                        doc['id'] = str(doc.get('_id'))
                                                        doc.pop('_id', None)
                                                except Exception:
                                                    pass
                                                save_current_item(phone, typ[:-1], doc.get('id'), doc.get('nombre') or doc.get('name') or sel.get('name'), doc)
                                                return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                        except Exception:
                                            found = None
                                            for lst_item in (COURSES_DATA if typ == 'courses' else (PRODUCTS_DATA if typ == 'products' else WEBINARS_DATA)):
                                                try:
                                                    if str(lst_item.get('id')) == str(cid) or lst_item.get('nombre') == sel.get('name'):
                                                        found = lst_item
                                                        break
                                                except Exception:
                                                    continue
                                            if found:
                                                save_current_item(phone, typ[:-1], found.get('id'), found.get('nombre') or found.get('name'), found)
                                                return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                            else:
                                for typ in ['courses', 'products', 'webinars']:
                                    listed = get_listed_items(phone, typ) or []
                                    for item in listed:
                                        nm = (item.get('name') or '').lower()
                                        if nm and nm in (message_text or '').lower():
                                           
                                            cid = item.get('id')
                                           
                                            try:
                                                from pymongo import MongoClient
                                                mongo_uri = os.environ.get('MONGODB_URI') or os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
                                                client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
                                                db = client.get_database('splitbot')
                                                coll = db.get_collection('courses') if typ == 'courses' else (db.get_collection('products') if typ == 'products' else db.get_collection('webinars'))
                                                try:
                                                    doc = _resolve_by_id(coll, cid)
                                                except Exception:
                                                    doc = None
                                                if doc:
                                                    try:
                                                        if doc.get('_id') is not None:
                                                            doc['id'] = str(doc.get('_id'))
                                                            doc.pop('_id', None)
                                                    except Exception:
                                                        pass
                                                    save_current_item(phone, typ[:-1], doc.get('id'), doc.get('nombre') or doc.get('name') or item.get('name'), doc)
                                                    return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                            except Exception:
                                                for lst_item in (COURSES_DATA if typ == 'courses' else (PRODUCTS_DATA if typ == 'products' else WEBINARS_DATA)):
                                                    try:
                                                        if str(lst_item.get('id')) == str(cid) or lst_item.get('nombre') == item.get('name'):
                                                            save_current_item(phone, typ[:-1], lst_item.get('id'), lst_item.get('nombre') or lst_item.get('name'), lst_item)
                                                            return handle_course_and_temario_flow(phone, message_text, whatsapp_profile)
                                                    except Exception:
                                                        continue
                        except Exception:
                            logger.debug('Selection-by-number/name logic failed, falling back to LLM parsing')

            parsed = None
            if ai_response and ai_response.strip():
                m = re.search(r"(\{[\s\S]*\})", ai_response)
                json_text = m.group(1) if m else ai_response.strip()
                try:
                    parsed = json.loads(json_text)
                    logger.info("Parsed JSON from LLM response successfully")
                except Exception:
                    parsed = None
                    logger.debug(f"Failed to parse JSON from LLM response. json_text startswith: {str(json_text)[:200]}")

            if parsed and isinstance(parsed, dict):
                try:
                    typ = parsed.get('type', '')
                    name = parsed.get('name') or parsed.get('title') or ''
                    pid = parsed.get('id')
                    price = parsed.get('price')
                    duration = parsed.get('duration')
                    dates = parsed.get('dates') or []
                    location = parsed.get('location')
                    temario = parsed.get('temario') or []
                    temario_pdf = parsed.get('temario_pdf')

                    out_parts = []
                    out_parts.append(f"*{name}*")
                    if price:
                        out_parts.append(f"Precio: {price}")
                    if duration:
                        out_parts.append(f"Duración: {duration}")
                    if dates:
                        out_parts.append(f"Fechas: {', '.join(dates)}")
                    if location:
                        out_parts.append(f"Ubicación: {location}")
                    if temario:
                        tem_preview = '\n'.join([f"- {t}" for t in temario[:10]])
                        out_parts.append(f"Temario:\n{tem_preview}")
                    if temario_pdf:
                        out_parts.append(f"Temario PDF: {temario_pdf}")

                    send_text_message(phone, "\n\n".join(out_parts))
                    logger.info("Sent formatted message built from LLM JSON to %s", phone)
                    try:
                        if typ and pid:
                            if typ.lower() in ['course', 'curso', 'cursos']:
                                save_current_item(phone, 'course', pid, name, parsed)
                            elif typ.lower() in ['product', 'producto', 'products', 'productos']:
                                save_current_item(phone, 'product', pid, name, parsed)
                            elif typ.lower() in ['webinar', 'webinars']:
                                save_current_item(phone, 'webinar', pid, name, parsed)
                    except Exception:
                        pass

                   
                    try:
                        sel = get_conversation_memory(phone, 'selected_course')
                        ai_lower = (ai_response or '').lower()
                        wants_send = False
                        if temario_pdf:
                            wants_send = True
                        elif any(p in ai_lower for p in ['te envío el temario', 'te envio el temario', 'puedo enviarte el temario', 'puedo enviar el temario', 'te puedo enviar el temario', 'te puedo enviar el temario']):
                            wants_send = True

                        if wants_send and isinstance(sel, dict) and sel.get('id'):
                            try:
                                pdf_info = find_pdf_for_user_message('temario', {'selected_course': sel})
                                if pdf_info and pdf_info.get('file_path'):
                                    logger.info(f"Auto-sending temario PDF for selected course (phone={phone}, course={sel.get('id')}) -> {pdf_info.get('pdf_filename')}")
                                    send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                                else:
                                    logger.info(f"No temario PDF found to auto-send for course id={sel.get('id')}")
                            except Exception:
                                logger.exception("Error trying to auto-send temario PDF based on LLM recommendation")
                    except Exception:
                        logger.debug("Skipped auto-send temario logic due to error reading conversation memory or parsing response")
                except Exception:
                    _safe_send_ai_text(ai_response)
            elif parsed and isinstance(parsed, list):
                try:
                    parts = []
                    listed_items = []
                    for idx, it in enumerate(parsed, start=1):
                        if not isinstance(it, dict):
                            parts.append(f"{idx}. {str(it)[:200]}")
                            listed_items.append({'type': 'unknown', 'id': None, 'name': str(it)})
                            continue

                        typ = (it.get('type') or it.get('kind') or '').lower()
                        name = it.get('nombre') or it.get('name') or it.get('title') or it.get('titulo') or 'Sin nombre'
                        price = it.get('precio') or it.get('price') or it.get('cost') or ''
                        dates = it.get('fechas') or it.get('dates') or it.get('proximas_fechas') or []
                        date_str = ', '.join([str(d) for d in dates]) if dates else ''
                        short = []
                        if price:
                            short.append(f"Precio: {price}")
                        if date_str:
                            short.append(f"Fechas: {date_str}")
                        typename = typ if typ else ("curso" if any(k in (name or '').lower() for k in ['curso','taller','capacitación']) else 'item')
                        line = f"{idx}. [{typename.upper()}] {name}"
                        if short:
                            line = line + " — " + " | ".join(short)
                        parts.append(line)
                        listed_items.append({'type': typename, 'id': it.get('id') or it.get('ID') or it.get('Id'), 'name': name, 'data': it})

                    try:
                        types = [li.get('type') for li in listed_items if li.get('type')]
                        coll = 'courses'
                        if types:
                            if all(t and 'product' in t for t in types):
                                coll = 'products'
                            elif all(t and 'webinar' in t for t in types):
                                coll = 'webinars'
                            elif all(t and 'course' in t for t in types):
                                coll = 'courses'
                        save_listed_items(phone, coll, [li.get('data') or li for li in listed_items])
                    except Exception:
                        pass

                    header = "Aquí tienes lo que encontré:\n"
                    max_len = 3000
                    cur = header
                    for line in parts:
                        if len(cur) + len(line) + 2 > max_len:
                            send_text_message(phone, cur)
                            cur = ""
                        cur = cur + line + "\n"
                    if cur.strip():
                        send_text_message(phone, cur.strip())
                    logger.info("Sent formatted list of %d items to %s", len(parts), phone)
                except Exception:
                    if ai_response and ai_response.strip():
                        _safe_send_ai_text(ai_response)
                        logger.info("Sent raw LLM text (sanitized) to %s (fallback)", phone)
            else:
                if ai_response and ai_response.strip():
                    _safe_send_ai_text(ai_response)
                    logger.info("Sent raw LLM text (sanitized) to %s", phone)
                else:
                    logger.info("LLM returned empty, using ml_service fallback")
                    fallback_response = ml_service.answer_course_or_webinar_query(phone, message_text)
                    send_text_message(phone, fallback_response or "Gracias por tu mensaje. ¿En qué puedo ayudarte con estrategias de marketing hoy?")
        except Exception as e:
            logger.exception(f"Error procesando respuesta LLM: {e}")
            logger.info("Using ml_service fallback due to exception while processing LLM response")
            fallback_response = ml_service.answer_course_or_webinar_query(phone, message_text)
            send_text_message(phone, fallback_response or "Gracias por tu mensaje. ¿En qué puedo ayudarte con estrategias de marketing hoy?")

    except Exception as e:
        logger.error(f"Error procesando mensaje de marketing: {e}", exc_info=True)
        send_text_message(phone, "Disculpa, ocurrió un error procesando tu mensaje. Por favor intenta de nuevo.")


def handle_course_and_temario_flow(phone: str, message_text: str, whatsapp_profile: dict = None) -> bool:
    """Maneja selección de curso, respuestas sobre atributos y envío de PDF de temario.

    Retorna True si se manejó la petición (no es necesario pasar a IA), False otherwise.
    """
    msg_lower = (message_text or '').lower()

    # 1) Si el usuario pidió el temario explícitamente
    if is_temario_request(message_text):
        # Si ya hay un curso seleccionado en memoria, enviar su temario
        selected = get_conversation_memory(phone, 'selected_course')
        if isinstance(selected, dict) and selected.get('id'):
            course_id = selected.get('id')
            # Enviar temario en texto
            try:
                temario_msg = get_course_temario_message(course_id)
                send_text_message(phone, temario_msg)
            except Exception:
                pass

            # Intentar enviar PDF si existe
            try:
                    pdf_info = find_pdf_for_user_message('temario', {'selected_course': {'id': course_id, 'name': selected.get('nombre'), 'nombre': selected.get('nombre')}})
                    if pdf_info:
                        try:
                            send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                            try:
                                save_selected_course(phone, course_id, selected.get('nombre') or selected.get('name'), {'pdf_path': pdf_info.get('file_path')})
                            except Exception:
                                pass
                            return True
                        except Exception:
                            pass
            except Exception:
                pass

            return True

        # Si no hay curso seleccionado, pedir que indique cuál
        send_text_message(phone, ask_for_course_number())
        # Guardar bandera en memoria para esperar número (context key)
        save_conversation_memory(phone, 'awaiting_temario_course', True)
        save_conversation_memory(phone, 'awaiting_temario_action', 'pdf')
        return True

    # 2) Si el usuario responde con un número de curso mientras esperamos
    awaiting = get_conversation_memory(phone, 'awaiting_temario_course') or False
    if awaiting:
        course_id = extract_course_number(message_text)
        if not course_id:
            # intentar parsear nombre
            course_id = extract_course_number(message_text)

        if course_id:
            # Guardar selección
            try:
                course = CourseManager.get_course_by_id(course_id)
                if course:
                        save_conversation_memory(phone, 'selected_course', {'id': course_id, 'nombre': course.nombre, 'name': course.nombre})
                        try:
                            save_current_item(phone, 'course', course_id, course.nombre, {'nombre': course.nombre})
                        except Exception:
                            pass
            except Exception:
                pass

            # Enviar temario en texto
            try:
                temario_msg = get_course_temario_message(course_id)
                send_text_message(phone, temario_msg)
            except Exception:
                pass

            # Enviar PDF si se pidió
            try:
                pdf_info = find_pdf_for_user_message(f"curso {course_id}", {'selected_course': get_conversation_memory(phone, 'selected_course')})
                if pdf_info:
                    send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                    try:
                        sc = get_conversation_memory(phone, 'selected_course') or {}
                        sc_name = sc.get('nombre') or sc.get('name') or ''
                        save_selected_course(phone, course_id, sc_name, {'pdf_path': pdf_info.get('file_path')})
                    except Exception:
                        pass
            except Exception:
                pass

            # Limpiar banderas
            save_conversation_memory(phone, 'awaiting_temario_course', None)
            save_conversation_memory(phone, 'awaiting_temario_action', None)
            return True

    awaiting_pdf = get_conversation_memory(phone, 'awaiting_pdf_confirmation') or False
    if awaiting_pdf:
        ans = (message_text or '').strip().lower()
        if ans in ['si', 'sí', 's', 'yes']:
            pending = get_conversation_memory(phone, 'pending_pdf') or {}
            if pending and pending.get('file_path'):
                try:
                    send_document_message(phone, pending.get('file_path'), pending.get('caption'))
                except Exception:
                    pass
            send_text_message(phone, "Perfecto, te envío el PDF del temario ahora.")
        else:
            send_text_message(phone, "Entendido. No enviaré el PDF. Si lo deseas, escribe 'enviar PDF del temario' para intentarlo de nuevo.")

        save_conversation_memory(phone, 'pending_pdf', None)
        save_conversation_memory(phone, 'awaiting_pdf_confirmation', None)
        return True

    attr_keywords = ['precio', 'cost', 'costo', 'precios', 'fecha', 'fechas', 'ubicacion', 'ubicación', 'modalidad', 'duracion', 'duración', 'horario', 'temario']
    if any(k in msg_lower for k in attr_keywords):
        selected = get_conversation_memory(phone, 'selected_course')
        course_id = None
        try:
            global_current = get_current_item(phone)
        except Exception:
            global_current = None
        if isinstance(selected, dict) and selected.get('id'):
            course_id = selected.get('id')
        else:
            try:
                current_item = get_current_item(phone)
                if current_item and current_item.get('type') == 'course' and current_item.get('id'):
                    course_id = current_item.get('id')
            except Exception:
                current_item = None

            if not course_id:
                course_id = extract_course_number(message_text)

        try:
            if global_current and global_current.get('type') == 'product':
                pid = global_current.get('id')
                product = None
                try:
                    for p in PRODUCTS_DATA:
                        try:
                            if str(p.get('id')) == str(pid):
                                product = p
                                break
                        except Exception:
                            continue
                except Exception:
                    product = None

                if product:
                    parts = [f"*{product.get('nombre')}*"]
                    if product.get('precio'):
                        parts.append(f"Precio: {product.get('precio')}")
                    if product.get('descripcion'):
                        parts.append(f"Descripción: {product.get('descripcion')}")
                    if product.get('especificaciones'):
                        specs = '\n'.join([f"- {s}" for s in product.get('especificaciones')])
                        parts.append(f"Especificaciones:\n{specs}")
                    send_text_message(phone, "\n\n".join(parts))
                    return True

        except Exception:
            pass

        try:
            if global_current and global_current.get('type') == 'webinar':
                wid = global_current.get('id')
                webinar = None
                try:
                    for w in WEBINARS_DATA:
                        try:
                            if str(w.get('id')) == str(wid) or str(w.get('title')).lower() == str(global_current.get('name')).lower():
                                webinar = w
                                break
                        except Exception:
                            continue
                except Exception:
                    webinar = None

                if webinar:
                    parts = [f"*{webinar.get('title') or webinar.get('name')}*"]
                    if webinar.get('fechas'):
                        fechas = [_format_fecha_entry(f) for f in webinar.get('fechas')]
                        fechas = [f for f in fechas if f]
                        parts.append(f"Fechas: {', '.join(fechas)}")
                    if webinar.get('horario'):
                        horarios = [_format_fecha_entry(h) for h in webinar.get('horario')]
                        horarios = [h for h in horarios if h]
                        parts.append(f"Horario: {', '.join(horarios)}")
                    if webinar.get('description'):
                        parts.append(f"Descripción: {webinar.get('description')}")
                    if webinar.get('topics'):
                        topics = '\n'.join([f"- {t}" for t in webinar.get('topics')])
                        parts.append(f"Temas:\n{topics}")
                    send_text_message(phone, "\n\n".join(parts))
                    return True

        except Exception:
            pass

        course_json = None
        if not course_id:
            cleaned = (message_text or '').strip().lower()
            if cleaned and len(cleaned) > 2:
                for c in COURSES_DATA:
                    name = (c.get('nombre') or '').lower()
                    short = (c.get('nombre_corto') or '').lower()
                    nodes = ' '.join(c.get('nodos', [])).lower() if c.get('nodos') else ''

                    try:
                        if cleaned == name or (len(cleaned) >= 4 and cleaned in name) or (len(name) >= 6 and name in cleaned):
                            course_json = c
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                        if short and (cleaned == short or (len(cleaned) >= 4 and cleaned in short)):
                            course_json = c
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                        if nodes and cleaned in nodes:
                            course_json = c
                            try:
                                course_id = c.get('id')
                            except Exception:
                                course_id = None
                            break
                    except Exception:
                        continue

                if not course_json and 'RAPIDFUZZ' in globals() and RAPIDFUZZ:
                    try:
                        best = None
                        best_score = 0
                        for c in COURSES_DATA:
                            name = (c.get('nombre') or '').lower()
                            if not name:
                                continue
                            score = rf_fuzz.partial_ratio(cleaned, name)
                            if score > best_score:
                                best_score = score
                                best = c
                        if best and best_score >= 80:
                            course_json = best
                            try:
                                course_id = best.get('id')
                            except Exception:
                                course_id = None
                    except Exception:
                        pass

        if course_id:
            try:
                course = CourseManager.get_course_by_id(course_id)

                course_json = None
                if not course:
                    for c in COURSES_DATA:
                        try:
                            cid_field = c.get('id')
                            if cid_field is not None and str(cid_field) == str(course_id):
                                course_json = c
                                break
                            try:
                                if int(cid_field) == int(course_id):
                                    course_json = c
                                    break
                            except Exception:
                                pass
                        except Exception:
                            pass
                        name_low = (c.get('nombre') or '').lower()
                        short_low = (c.get('nombre_corto') or '').lower()
                        if (str(course_id).lower() in name_low) or (str(course_id).lower() in short_low):
                            course_json = c
                            break

                # Construir respuesta según keyword
                if any(k in msg_lower for k in ['precio', 'costo']):
                    if course:
                        send_text_message(phone, course.get_formatted_precio())
                    elif course_json:
                        precio = course_json.get('precio') or 'Consultar con asesor'
                        resp = f"*INVERSIÓN CURSO:* {course_json.get('nombre')}\n\n*Precio MXN:* {precio}"
                        send_text_message(phone, resp)
                    else:
                        send_text_message(phone, "No encontré información sobre el precio de ese curso. ¿Quieres que te ponga en contacto con un asesor?")
                    return True

                if any(k in msg_lower for k in ['temario', 'contenido', 'programa']):
                    if course:
                        send_text_message(phone, course.get_formatted_temario())
                        course_name = course.nombre
                    elif course_json:
                        # Formatear temario desde JSON
                        tem = []
                        for t in course_json.get('temario', []):
                            titulo = t.get('titulo') if isinstance(t, dict) else str(t)
                            tem.append(f"- {titulo}")
                            if isinstance(t, dict) and t.get('subtemas'):
                                for st in t.get('subtemas'):
                                    tem.append(f"  • {st}")
                        send_text_message(phone, f"📚 *TEMARIO - {course_json.get('nombre')}*\n\n" + "\n".join(tem))
                        course_name = course_json.get('nombre')

                    # enviar PDF si existe
                    try:
                        pdf_info = find_pdf_for_user_message(f"curso {course_id}", {'selected_course': {'id': course_id, 'name': course_name if 'course_name' in locals() else None}})
                        if pdf_info:
                            send_document_message(phone, pdf_info['file_path'], pdf_info.get('caption'))
                            try:
                                save_selected_course(phone, course_id, course_name, {'pdf_path': pdf_info.get('file_path')})
                            except Exception:
                                pass
                    except Exception:
                        pass
                    return True

                if any(k in msg_lower for k in ['duracion', 'duración', 'horario', 'fechas', 'fecha', 'ubicacion']):
                    if course:
                        msg = course.get_formatted_informacion_completa()
                        send_text_message(phone, msg)
                    elif course_json:
                        parts = []
                        if course_json.get('duracion'):
                            parts.append(f"Duración: {course_json.get('duracion')}")
                        if course_json.get('modalidad'):
                            parts.append(f"Modalidad: {course_json.get('modalidad')}")
                        if course_json.get('ubicacion'):
                            parts.append(f"Ubicación: {course_json.get('ubicacion')}")
                        if course_json.get('horario'):
                            parts.append(f"Horario: {course_json.get('horario')}")
                        if course_json.get('proximas_fechas'):
                            fechas = [_format_fecha_entry(f) for f in course_json.get('proximas_fechas')]
                            fechas = [f for f in fechas if f]
                            parts.append(f"Próximas fechas: {', '.join(fechas)}")
                        send_text_message(phone, "\n".join(parts) if parts else "No encontré información detallada de fechas/ubicación para ese curso.")
                    else:
                        send_text_message(phone, "No encontré información sobre ese curso. ¿Puedes escribir el nombre o el número del curso (1-5)?")
                    return True

            except Exception as e:
                logger.debug(f"Error al responder atributos de curso: {e}")


    
    advisor_keywords = [
        'asesor', 'hablar con', 'contactar', 'contacto', 'asesoria', 'hablar con un asesor',
        'inscrib', 'inscripción', 'inscripcion', 'inscribirme', 'registrarme',
        'cotizacion', 'cotización', 'cotizar', 'factura', 'facturación', 'facturacion'
    ]

    asp = advisor_simple_process
    awaiting = get_conversation_memory(phone, 'awaiting_advisor_data') or get_conversation_memory(phone, 'waiting_for_advisor_data') or False
    if awaiting:
       
        try:
            if not asp:
                try:
                    from services.advisor_simple import process_advisor_data as _asp
                    asp = _asp
                except Exception:
                    asp = None

            if asp:
                handled = asp(phone, message_text)
                if handled:
                    return True

            try:
                try:
                    ml_res = ml_service.process_message(message_text or '', conversation_history=[{'text': message_text or '', 'from_client': True}], phone=phone)
                except Exception:
                    ml_res = {'client_data': {}}

                extracted = (ml_res or {}).get('client_data') or {}

                stored = get_conversation_memory(phone, 'advisor_client_data') or {}
                key_map = {
                    'nombre': 'nombre', 'name': 'nombre',
                    'empresa': 'empresa', 'company': 'empresa',
                    'correo': 'email', 'email': 'email',
                    'telefono': 'telefono', 'phone': 'telefono', 'tel': 'telefono'
                }
                for k, v in extracted.items():
                    if not v:
                        continue
                    target = key_map.get(k, k)
                    if not stored.get(target):
                        stored[target] = v

                save_conversation_memory(phone, 'advisor_client_data', stored)

                has_name = bool(stored.get('nombre'))
                has_email = bool(stored.get('email') or stored.get('correo'))
                has_phone = bool(stored.get('telefono') or stored.get('phone'))

                if has_name and (has_email or has_phone):
                    req_type = get_conversation_memory(phone, 'advisor_request_type') or ''
                    category = 'contacto_asesor'
                    if req_type == 'cotizacion':
                        category = 'cotizacion'
                    elif req_type == 'inscripcion':
                        category = 'inscripcion'
                    elif req_type == 'facturacion':
                        category = 'facturacion'

                    ml_results = {
                        'classification': {'category': category},
                        'client_data': stored,
                        'requires_human_attention': True
                    }

                    conv_hist = get_conversation_memory(phone, 'conversation_history') or []
                    try:
                        notify_result = notification_service.process_client_notification(phone, ml_results, conv_hist)
                    except Exception:
                        notify_result = None

                    save_conversation_memory(phone, 'advisor_client_data', None)
                    save_conversation_memory(phone, 'awaiting_advisor_data', None)
                    save_conversation_memory(phone, 'waiting_for_advisor_data', None)
                    save_conversation_memory(phone, 'awaiting_advisor_confirmation', None)
                    save_conversation_memory(phone, 'advisor_request_type', None)

                    try:
                        if notify_result and notify_result.get('notification_sent'):
                            send_text_message(phone, 'Gracias — tus datos fueron confirmados y un asesor ha sido notificado. Te contactarán pronto.')
                        else:
                            if notify_result and notify_result.get('pdf_path'):
                                send_text_message(phone, 'Gracias — he generado el PDF con tus datos y lo he guardado. Un asesor se contactará contigo pronto.')
                            else:
                                send_text_message(phone, 'Gracias — he confirmado tus datos y los he guardado. Un asesor se contactará contigo pronto.')
                    except Exception:
                        logger.debug('Could not send final confirmation message to user')
                    return True

                if not stored.get('nombre'):
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_client_data', stored)
                    send_text_message(phone, 'Gracias. ¿Cuál es tu nombre completo?')
                    return True

                if not stored.get('empresa'):
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_client_data', stored)
                    send_text_message(phone, 'Perfecto. ¿Cuál es el nombre de tu empresa o proyecto? (Si no aplica, responde "N/A")')
                    return True

                if not (stored.get('email') or stored.get('correo')):
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_client_data', stored)
                    send_text_message(phone, 'Por favor compárteme tu correo electrónico (ej: juan@empresa.com).')
                    return True

                if not stored.get('telefono'):
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_client_data', stored)
                    send_text_message(phone, 'Gracias. ¿Cuál es tu número de teléfono de contacto?')
                    return True

                save_conversation_memory(phone, 'advisor_client_data', stored)
                save_conversation_memory(phone, 'awaiting_advisor_data', True)
                return False
            except Exception:
                logger.exception('ML-based advisor fallback failed')
        except Exception as e:
            logger.exception(f"advisor_simple processing failed: {e}")

    advisor_phrases = ['hablar con un asesor', 'hablar con asesor', 'quiero hablar con un asesor', 'ponme en contacto', 'ponme en contacto con un asesor', 'contactar un asesor', 'contacto con asesor', 'contactar asesor', 'necesito un asesor']
    advisor_actions = ['inscrib', 'inscripción', 'inscripcion', 'inscribirme', 'registrarme', 'cotizacion', 'cotización', 'cotizar', 'factura', 'facturación', 'facturacion']

    is_advisor_request = any(p in msg_lower for p in advisor_phrases) or any(a in msg_lower for a in advisor_actions)

    if is_advisor_request:
        awaiting = get_conversation_memory(phone, 'awaiting_advisor_data') or get_conversation_memory(phone, 'waiting_for_advisor_data') or False
        action = 'contact_asesor'
        if any(k in msg_lower for k in ['cotizacion', 'cotización', 'cotizar']):
            action = 'cotizacion'
        elif any(k in msg_lower for k in ['inscrib', 'inscripción', 'inscripcion', 'registrarme']):
            action = 'inscripcion'
        elif any(k in msg_lower for k in ['factura', 'facturación', 'facturacion']):
            action = 'facturacion'

        if not awaiting:
            try:
                from services.advisor_simple import start_advisor_simple
            except Exception as e:
                logger.debug(f"No se pudo importar start_advisor_simple: {e}")
                start_advisor_simple = None

            try:
                if start_advisor_simple:
                    return start_advisor_simple(phone, process_type=action if action in ['cotizacion','inscripcion','facturacion'] else 'general')
                else:
                    save_conversation_memory(phone, 'awaiting_advisor_data', True)
                    save_conversation_memory(phone, 'advisor_request_type', action)
                    save_conversation_memory(phone, 'advisor_client_data', {})
                    send_text_message(phone, "¡Perfecto! 👍 Empecemos. Por favor, dime tu nombre completo.")
                    return True
            except Exception as e:
                logger.exception(f"start_advisor_simple failed: {e}")
                return False

        try:
            from services.advisor_simple import advisor_simple_process as _asp
            asp = _asp
        except Exception as e:
            logger.debug(f"No se pudo importar advisor_simple_process: {e}")
            asp = None

        if asp:
            try:
                handled = asp(phone, message_text)
                if handled:
                    return True
                else:
                    return False
            except Exception as e:
                logger.exception(f"advisor_simple processing failed: {e}")
                return False
        else:
            send_text_message(phone, "Estamos actualizando nuestro flujo de asesoría. Por favor, comparte tu nombre completo y te responderemos pronto.")
            save_conversation_memory(phone, 'awaiting_advisor_data', None)
            return False