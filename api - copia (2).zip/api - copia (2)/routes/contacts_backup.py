from flask import Blueprint, request, jsonify, current_app
from flask_cors import cross_origin
from data.db import get_collection
from datetime import datetime, timedelta
from bson import ObjectId

contacts_bp = Blueprint('contacts', __name__)

def _to_iso(v):
    # acepta datetime o string; devuelve string ISO
    if v is None:
        return None
    try:
        if isinstance(v, datetime):
            return v.isoformat()
        # si ya es str y parece ISO, devolver tal cual
        return str(v)
    except Exception:
        return str(v)

# helper: normalize phone keys so lookups match client phones
def _norm_phone(p):
    try:
        if p is None:
            return None
        s = str(p)
        s = s.strip()
        # remove common separators
        s = s.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
        # remove leading plus
        if s.startswith('+'):
            s = s[1:]
        return s
    except Exception:
        return str(p)

@contacts_bp.route('/monitored', methods=['GET', 'OPTIONS'])
@cross_origin()
def get_monitored_contacts():
    try:
        # Usar la nueva estructura de conversaciones agrupadas por usuario
        conv_col = None
        try:
            conv_col = get_collection('conversaciones')
        except Exception:
            conv_col = get_collection('conversations')

        results = []
        
        # Con la nueva estructura, cada documento ya representa una conversación completa por usuario
        for conversation in conv_col.find().sort("last_message_at", -1).limit(1000):
            phone = conversation.get("phone")
            if not phone:
                continue
                
            try:
                # Datos básicos del contacto
                contact_data = {
                    'phone': phone,
                    'customer_name': conversation.get("customer_name", ""),
                    'lastMessage': conversation.get("last_message", ""),
                    'lastMessageSender': conversation.get("last_message_sender", "user"),
                    'lastMessageAt': _to_iso(conversation.get("last_message_at")),
                    'createdAt': _to_iso(conversation.get("created_at")),
                    'messageCount': conversation.get("message_count", 0),
                    'aiMode': conversation.get("ai_mode", False),
                    'tags': conversation.get("tags", []),
                    'etiqueta_id': conversation.get("etiqueta_id"),
                    'etiqueta_nombre': conversation.get("etiqueta_nombre"),
                    'etiqueta_color': conversation.get("etiqueta_color"),
                    'requiresHumanIntervention': conversation.get("requiresHumanIntervention", False),
                    'interventionReason': conversation.get("interventionReason", ""),
                    'priority': conversation.get("priority", "normal"),
                    'unread': True  # Por simplicidad, marcar como no leído por defecto
                }
                
                results.append(contact_data)
            except Exception as e:
                current_app.logger.error(f"Error procesando contacto {phone}: {e}")
                continue

        return jsonify(results), 200
    except Exception as e:
        current_app.logger.exception("get_monitored_contacts failed")
        return jsonify({"error": str(e)}), 500


@contacts_bp.route('/<phone>/messages', methods=['GET', 'OPTIONS'])
@cross_origin()
def get_messages_for_contact(phone):
    try:
        conv_col = None
        try:
            conv_col = get_collection('conversaciones')
        except Exception:
            conv_col = get_collection('conversations')

        # Buscar la conversación específica para este teléfono (nueva estructura)
        phone_norm = _norm_phone(phone)
        conversation = conv_col.find_one({"phone": phone})
        
        # Fallback: si no encuentra por 'phone', intentar buscar por campos antiguos
        if not conversation:
            conversation = conv_col.find_one({"customer_phone": phone})
        
        messages = []
        
        if conversation and 'messages' in conversation:
            # Nueva estructura: mensajes están en el array 'messages'
            for msg in conversation['messages']:
                try:
                    messages.append({
                        'id': msg.get('id', ''),
                        'text': msg.get('text', ''),
                        'sender': msg.get('sender', 'user'),
                        'message_type': msg.get('message_type', 'text'),
                        'timestamp': _to_iso(msg.get('timestamp', msg.get('created_at'))),
                        'created_at': _to_iso(msg.get('created_at'))
                    })
                except Exception as e:
                    current_app.logger.error(f"Error procesando mensaje: {e}")
                    continue
        
        elif conversation:
            # Estructura antigua: crear mensaje a partir del documento
            messages.append({
                'id': str(conversation.get('_id', '')),
                'text': conversation.get('message', ''),
                'sender': 'user',
                'message_type': conversation.get('message_type', 'text'),
                'timestamp': _to_iso(conversation.get('created_at')),
                'created_at': _to_iso(conversation.get('created_at'))
            })
            
            # Agregar respuesta si existe
            if conversation.get('response'):
                messages.append({
                    'id': f"{conversation.get('_id', '')}_response",
                    'text': conversation.get('response', ''),
                    'sender': 'bot',
                    'message_type': 'text',
                    'timestamp': _to_iso(conversation.get('created_at')),
                    'created_at': _to_iso(conversation.get('created_at'))
                })
        else:
            # Fallback: buscar en estructura legacy
            cursor = conv_col.find({'customer_phone': phone}).sort('created_at', -1).limit(100)
            for d in cursor:
                try:
                    messages.append({
                        'id': str(d.get('_id', '')),
                        'text': d.get('message', ''),
                        'sender': 'user',
                        'message_type': d.get('message_type', 'text'),
                        'timestamp': _to_iso(d.get('created_at')),
                        'created_at': _to_iso(d.get('created_at'))
                    })
                    
                    # Agregar respuesta si existe
                    if d.get('response'):
                        messages.append({
                            'id': f"{d.get('_id', '')}_response",
                            'text': d.get('response', ''),
                            'sender': 'bot',
                            'message_type': 'text',
                            'timestamp': _to_iso(d.get('created_at')),
                            'created_at': _to_iso(d.get('created_at'))
                        })
                except Exception as e:
                    current_app.logger.error(f"Error procesando mensaje legacy: {e}")
                    continue

        # Ordenar mensajes por timestamp
        messages.sort(key=lambda x: x.get('timestamp', ''))

        return jsonify({"phone": phone, "messages": messages}), 200
    except Exception as e:
        current_app.logger.exception("get_messages_for_contact failed")
        return jsonify({"phone": phone, "messages": [], "error": str(e)}), 500


@contacts_bp.route('/<phone>/reply', methods=['POST', 'OPTIONS'])
@cross_origin()
def reply_to_contact(phone):
    """Send a manual text reply to a contact via WhatsApp API (uses routes.whatsapp.send_text_message).
    Emits 'new_message' and 'update_contact' events when successful.
    Always returns JSON so the frontend never receives an HTML error page.
    """
    try:
        data = request.get_json(silent=True) or {}
        text = data.get('text') or data.get('message') or ''
        if not text:
            return jsonify({'ok': False, 'error': 'missing text in body'}), 400

        # Use the shared helper in whatsapp blueprint
        try:
            from routes.whatsapp import send_text_message
        except Exception:
            current_app.logger.exception('Failed to import send_text_message')
            send_text_message = None

        send_result = None
        if send_text_message:
            send_result = send_text_message(phone, text)

        # Persist to DB conversations using new structure
        try:
            conv = None
            try:
                conv = get_collection('conversaciones')
            except Exception:
                conv = None
            if conv is None:
                conv = get_collection('conversations')

            current_time = datetime.utcnow()
            message_id = str(ObjectId())
            
            # Crear mensaje del agente
            agent_message = {
                "id": f"{message_id}_agent",
                "text": text,
                "sender": "agent",
                "message_type": "text",
                "created_at": current_time,
                "timestamp": current_time
            }
            
            # Buscar conversación existente o crear nueva
            conversation = conv.find_one({"phone": phone})
            
            if conversation:
                # Actualizar conversación existente y limpiar flags de intervención
                conv.update_one(
                    {"phone": phone},
                    {
                        "$push": {"messages": agent_message},
                        "$set": {
                            "last_message_at": current_time,
                            "last_message": text,
                            "last_message_sender": "agent",
                            "message_count": len(conversation.get("messages", [])) + 1,
                            "requiresHumanIntervention": False,  # Limpiar flag
                            "interventionReason": "",
                            "priority": "normal"
                        }
                    }
                )
            else:
                # Crear nueva conversación
                new_conversation = {
                    "phone": phone,
                    "customer_id": None,
                    "customer_name": "",
                    "messages": [agent_message],
                    "created_at": current_time,
                    "last_message_at": current_time,
                    "last_message": text,
                    "last_message_sender": "agent",
                    "message_count": 1,
                    "ai_mode": False,
                    "tags": [],
                    "session_id": None,
                    "etiqueta_id": None,
                    "etiqueta_nombre": None,
                    "etiqueta_color": None,
                    "requiresHumanIntervention": False,
                    "interventionReason": "",
                    "priority": "normal"
                }
                conv.insert_one(new_conversation)
                
        except Exception:
            current_app.logger.debug('Could not persist sent message to DB')

        # Emit socket events with enhanced real-time updates
        try:
            sio = getattr(current_app, 'socketio', None)
            if sio:
                # Payload mejorado para mensaje instantáneo
                message_payload = {
                    'phone': phone, 
                    'text': text, 
                    'sender': 'agent',
                    'message_type': 'text',
                    'timestamp': datetime.utcnow().isoformat(),
                    'ts': datetime.utcnow().isoformat(),
                    'id': f"agent_{datetime.utcnow().timestamp()}"
                }
                
                # Payload para actualización de contacto
                contact_payload = {
                    'phone': phone, 
                    'lastMessage': text,
                    'lastMessageSender': 'agent',
                    'lastMessageAt': datetime.utcnow().isoformat(),
                    'requiresHumanIntervention': False  # Limpiar flag si existía
                }
                
                # Emitir eventos inmediatamente
                sio.emit('new_message', message_payload)
                sio.emit('update_contact', contact_payload)
                
                current_app.logger.info(f"📡 Eventos SocketIO emitidos para mensaje manual a {phone}")
        except Exception as e:
            current_app.logger.error(f'Error emitiendo eventos socketio: {e}')

        # Return both ok and success keys for frontend compatibility
        return jsonify({'ok': True, 'success': True, 'sent': bool(send_result)}), 200
    except Exception as e:
        current_app.logger.exception('Failed to reply to contact')
        return jsonify({'ok': False, 'error': str(e)}), 500



@contacts_bp.route('/<phone>/toggle-mode', methods=['POST', 'OPTIONS'])
@cross_origin()
def toggle_ai_mode(phone):
    """Toggle AI mode for a contact (aiMode true/false). Body: {aiMode: true/false}
    Emits 'update_contact' when changed.
    """
    try:
        data = request.get_json(silent=True) or {}
        ai_mode = data.get('aiMode')
        if ai_mode is None:
            return jsonify({'ok': False, 'error': 'missing aiMode in body'}), 400

        conversaciones = get_collection('conversaciones')
        # En la nueva estructura usamos 'phone' como campo principal y 'ai_mode' como campo
        res = conversaciones.update_one({'phone': phone}, {'$set': {'ai_mode': bool(ai_mode)}})
        if res.matched_count == 0:
            # try alternate legacy keys
            res = conversaciones.update_one({'telefono': phone}, {'$set': {'ai_mode': bool(ai_mode)}})
            if res.matched_count == 0:
                res = conversaciones.update_one({'customer_phone': phone}, {'$set': {'ai_mode': bool(ai_mode)}})

        # Emit update with enhanced notification
        try:
            sio = getattr(current_app, 'socketio', None)
            if sio:
                # Notificación de cambio de modo AI
                ai_mode_payload = {
                    'phone': phone, 
                    'aiMode': bool(ai_mode),
                    'ai_mode': bool(ai_mode),  # Compatibilidad con diferentes formatos
                    'timestamp': datetime.utcnow().isoformat(),
                    'modeChangedBy': 'manual'
                }
                
                # Emitir eventos específicos
                sio.emit('update_contact', ai_mode_payload)
                sio.emit('ai_mode_changed', ai_mode_payload)
                
                current_app.logger.info(f"🤖 AI Mode {'HABILITADO' if ai_mode else 'DESHABILITADO'} para {phone}")
        except Exception as e:
            current_app.logger.error(f'Error emitiendo eventos socketio para AI mode: {e}')

        # Responder siempre con success para frontend
        return jsonify({'ok': True, 'success': True, 'aiMode': bool(ai_mode)}), 200
    except Exception as e:
        current_app.logger.exception('Failed to toggle ai mode')
        return jsonify({'ok': False, 'error': str(e)}), 500


# Endpoint to mark messages as read for a contact (accepts POST and OPTIONS)
@contacts_bp.route('/<phone>/read', methods=['POST', 'OPTIONS'])
@cross_origin()
def mark_contact_read(phone):
    """Mark messages for a contact as read. This is a minimal implementation that
    accepts POST and returns 200. It will also emit a socket.io event 'contact_read'
    so connected clients can update UI in real time.
    """
    from flask import current_app

    try:
        payload = request.get_json(silent=True) or {}
        # Log for debugging
        current_app.logger.info(f"Mark read called for {phone} payload={payload}")

        # Emit a socket.io event to notify clients. Use current_app.socketio if attached.
        try:
            socketio = getattr(current_app, 'socketio', None)
            if socketio:
                socketio.emit('contact_read', {'phone': phone})
                current_app.logger.info(f"Emitted contact_read event for {phone}")
            else:
                current_app.logger.warning("socketio not available on current_app")
        except Exception as e:
            current_app.logger.error(f"Error emitting contact_read event: {e}")
            pass

        return jsonify({'ok': True}), 200
    except Exception as e:
        current_app.logger.exception('Failed to mark contact read')
        return jsonify({'ok': False, 'error': str(e)}), 500


@contacts_bp.route('/ws', methods=['GET', 'OPTIONS'])
@cross_origin()
def ws_health():
    # Provide a simple endpoint to verify WebSocket path reachability
    return jsonify({'ok': True, 'ws': True}), 200


# Root route for /contacts — ensure preflight OPTIONS to /contacts succeeds
@contacts_bp.route('/', methods=['GET', 'OPTIONS'])
@cross_origin()
def contacts_root():
    try:
        conversaciones_col = get_collection('conversaciones')
        conv_col = None
        try:
            conv_col = get_collection('conversations')
        except Exception:
            conv_col = get_collection('conversaciones')
        if conv_col is None:
            return jsonify({"error": "Cannot access conversations"}), 500

        pipeline = [
            {"$sort": {"created_at": -1}},
            {"$group": {
                "_id": "$customer_phone",
                "lastMessage": {"$first": "$message"},
                "lastResponse": {"$first": "$response"},
                "lastType": {"$first": "$message_type"},
                "lastCreated": {"$first": "$created_at"}
            }},
        ]
        last_msgs_map = {}
        
        try:
            for doc in conv_col.aggregate(pipeline):
                phone = doc['_id']
                if phone:
                    last_msgs_map[phone] = {
                        'lastMessage': doc.get('lastMessage', ''),
                        'lastResponse': doc.get('lastResponse', ''),
                        'lastType': doc.get('lastType', 'text'),
                        'lastCreated': _to_iso(doc.get('lastCreated'))
                    }
        except Exception as e:
            current_app.logger.error(f"Aggregation pipeline failed: {e}")
            last_msgs_map = {}

        # Fallback: If aggregation fails or returns empty, get data directly
        if not last_msgs_map:
            conversations = conv_col.find().sort("created_at", -1).limit(100)
            for conv in conversations:
                phone = conv.get('customer_phone') or conv.get('phone')
                if phone and phone not in last_msgs_map:
                    last_msgs_map[phone] = {
                        'lastMessage': conv.get('message', ''),
                        'lastResponse': conv.get('response', ''),
                        'lastType': conv.get('message_type', 'text'),
                        'lastCreated': _to_iso(conv.get('created_at'))
                    }

        contacts = []
        for phone, msg_data in last_msgs_map.items():
            contacts.append({
                'phone': phone,
                'lastMessage': msg_data['lastMessage'],
                'lastResponse': msg_data['lastResponse'],
                'lastType': msg_data['lastType'],
                'lastCreated': msg_data['lastCreated']
            })

        return jsonify(contacts), 200
    except Exception as e:
        current_app.logger.exception("contacts_root failed")
        return jsonify({"error": str(e)}), 500


# Also accept the exact '/contacts' path (no trailing slash) to avoid redirects that break CORS preflights
@contacts_bp.route('', methods=['GET', 'OPTIONS'])
@cross_origin()
def contacts_root_no_slash():
    # Same response as the slash route; return the contacts list
    return contacts_root()


# Catch-all OPTIONS handler to respond to preflight for any nested path
@contacts_bp.route('/<path:any_path>', methods=['OPTIONS'])
@cross_origin()
def contacts_options_any(any_path):
    # Return an empty 200 so browser preflight succeeds; CORS headers come from cross_origin/after_request
    return ('', 200)