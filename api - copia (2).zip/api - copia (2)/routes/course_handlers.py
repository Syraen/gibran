"""
Manejadores para funciones relacionadas con cursos
"""
import logging
from typing import Optional, Dict, Any
from api.utils.gestor import conversation_state
from api.models.courses import CourseManager, is_asking_for_temario

logger = logging.getLogger(__name__)

def _import_courses_adapter():
    """Importa dinámicamente el adaptador de cursos"""
    try:
        from utils.courses_adapter import courses_adapter
        return courses_adapter
    except ImportError:
        return None

def advisor_request_prompt():
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'advisor_request_prompt'):
        try:
            return ca.advisor_request_prompt()
        except Exception as e:
            logger.debug(f"advisor_request_prompt adapter error: {e}")
    return (
        "Para que un asesor pueda contactarte, por favor envía:\n"
        "Nombre completo, correo electrónico y una breve descripción de tu solicitud.\n"
        "Ejemplo: 'Juan Pérez, juan@ejemplo.com, quiero información sobre instalación FTTH'."
    )

def get_course_schedule_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_schedule_message'):
        try:
            return ca.get_course_schedule_message(cid)
        except Exception as e:
            logger.debug(f"get_course_schedule_message adapter error: {e}")
    return "Información de fechas no disponible."

def get_course_price_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_price_message'):
        try:
            return ca.get_course_price_message(cid)
        except Exception as e:
            logger.debug(f"get_course_price_message adapter error: {e}")
    return "Información de precios no disponible."

def get_course_location_message(cid):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_location_message'):
        try:
            return ca.get_course_location_message(cid)
        except Exception as e:
            logger.debug(f"get_course_location_message adapter error: {e}")
    return "Información de ubicación no disponible."

def select_course_by_name(phone, text):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'select_course_by_name'):
        try:
            return ca.select_course_by_name(phone, text)
        except Exception as e:
            logger.debug(f"select_course_by_name adapter error: {e}")
    return {'selected': False, 'candidates': [], 'message': 'No encontré cursos que coincidan con esa búsqueda.'}

def parse_course_number_from_text(text):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'parse_course_number_from_text'):
        try:
            return ca.parse_course_number_from_text(text)
        except Exception as e:
            logger.debug(f"parse_course_number_from_text adapter error: {e}")
    # Fallback: simple digit parse
    try:
        t = (text or '').strip()
        if t.isdigit():
            return int(t)
    except Exception:
        pass
    return None

def format_course_for_whatsapp(details):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'format_course_for_whatsapp'):
        try:
            return ca.format_course_for_whatsapp(details)
        except Exception as e:
            logger.debug(f"format_course_for_whatsapp adapter error: {e}")
    return "Información del curso no disponible."

def get_course_details_by_number(num):
    ca = _import_courses_adapter()
    if ca and hasattr(ca, 'get_course_full_details_message'):
        try:
            # Prefer AI-polished suggestion to avoid inventing details
            try:
                from utils.courses_adapter import compose_course_suggestion_via_ai
                course = ca.get_course_by_id(num) if hasattr(ca, 'get_course_by_id') else None
                if course:
                    return compose_course_suggestion_via_ai(course, user_query=None)
            except Exception:
                # Fallback to adapter direct method
                return ca.get_course_full_details_message(num)
        except Exception as e:
            logger.debug(f"get_course_full_details_message adapter error: {e}")

    # Fallback: use temario_handler
    try:
        from utils.temario_handler import get_course_temario_message
        result = get_course_temario_message(num)
        if result and "error" not in result.lower() and "ocurr" not in result.lower():
            return result
    except Exception as e:
        logger.debug(f"temario_handler fallback error: {e}")

    return "Información del curso no disponible."

def find_pdf_for_user_message(message, context=None):
    """Busca PDFs relevantes para el mensaje del usuario"""
    try:
        from utils.temario_handler import find_pdf_for_user_message as temario_find
        return temario_find(message, context)
    except Exception as e:
        logger.debug(f"find_pdf_for_user_message error: {e}")
        return "No se pudo encontrar información del PDF."

# Funciones de compatibilidad y guardado de curso seleccionado
def save_selected_course(phone, course_id, course_name, details=None): 
    """Guardar el curso seleccionado"""
    try: 
        from service.conversation_memory_utils import save_conversation_memory
        save_conversation_memory(phone, 'selected_course', {
            'id': course_id, 
            'name': course_name, 
            'details': details or {}
        })
    except Exception as e: 
        logger.debug(f"Error guardando el curso seleccionado: {e}")

def get_selected_course(phone): 
    """Obtener el curso seleccionado"""
    try: 
        from services.conversation_memory_utils import get_conversation_memory
        return get_conversation_memory(phone, 'selected_course') or None
    except Exception as e: 
        logger.debug(f"Error al obtener el curso seleccionado: {e}")
        return None 

def clear_selected_course(phone): 
    """limpia el curso seleccionado"""
    try: 
        CourseConversationManager.clear_course_selection(phone)
    except Exception as e:
        logger.debug(f"Error limpiando el curso seleccionado: {e}")
        return None

def handle_user_message(user_id: str, message: str) -> str: 
    
    msg = message.lower()

    #Revisar el msj 
    parsed = CourseManager.parse_course_query(message)

   

    #detectar el id del curso 
    if parsed.get("course_id"): 
        cid = parsed["course_id"][0]

        #guarda el contexto del curso 
        conversation_state.set_context(user_id, topic="course", item_type="course", item_id=cid)
        course = CourseManager.get_course_by_id(cid)
        if not course: 
            return "No encontré ese curso. ¿Quieres que te muestre la lista de cursos disponibles?"
            
        #responder segun el tipo de consulta 
        if "temario" in parsed["query_types"]:
            return course.get_formatted_temario()
        if "fechas" in parsed["query_types"]: 
            return course.get_formatted_fechas()
        if "precio" in parsed["query_types"]:
            return course.get_formatted_precios()
        if "costo" in parsed["query_types"]:
            return course.get_formatted_precios()
        return "¿En qué más puedo ayudarte con respecto a este curso?"
    
    ## Si no hay ID pero el usuario pide info general de cursos -> mostrar lista (hasta 5) y guardar contexto
    if any (q in parsed["query_types"] for q in ["temario", "fechas", "precio", "costo"]) or "curso" in message.lower(): 
        courses = CourseManager.get_all_courses()[:5]
        if not courses: 
            return "No hay cursos disponibles en este momento."
        
        # Guardar que mostramos la lista para que el siguiente mensaje con número sea una selección
        conversation_state.set_context(user_id, topic="course_list", item_type="course", data={"visible_count": len(courses)})
        text = "Aqui tienes algunos de nuestros cursos disponibles:\n"
        for i, c in enumerate(courses, start=1): 
            display = c.nombre_corto or c.nombre or f"Curso {i}"
            text += f"{i} {display}\n"
        return text 
    
    #Manejo de selecciones basadas en id 
    ctx = conversation_state.get_context(user_id)
    if ctx and msg.isdigit(): 
        sel = int(msg)
        if ctx["topic"] == "course_list": 
            courses = CourseManager.get_all_course()[:ctx.get("data", {}).get("visible_count", 5)]
            if 1 <= sel <= len(courses):
                chosen = courses[sel - 1]

                #actualiza el contexto al curso seleccionado 
                conversation_state.set_context(user_id, topic="course", item_type="course", item_id=chosen.id)
                return chosen.get_formatted_overview()
            else: 
                return f"Por favor selecciona un número entre 1 y {len(courses)}."
        elif ctx["topic"] == "course": 
            course = CourseManager.get_all_course()[:5]
            if 1 <= sel <= len(courses): 
                chosen = courses[sel - 1]
                conversation_state.set_context(user_id, topic="courses", item_type="course", item_id=chosen.id)
                return chosen.get_formatted_informacion_completa()
            return f"Por favor selecciona un número entre 1 y {len(courses)}."
    return "No entendí tu mensaje. ¿Podrías reformularlo?"

# CourseManager wrapper that uses the adapter when available
class CourseManager:
    @staticmethod
    def parse_course_query(text: str):
        return parse_course_number_from_text(text)

    @staticmethod
    def get_course_by_id(cid):
        ca = _import_courses_adapter()
        if ca and hasattr(ca, 'get_course_by_id'):
            return ca.get_course_by_id(cid)
        return None

    @staticmethod
    def search_courses_by_keywords(keywords, limit=1):
        ca = _import_courses_adapter()
        if ca and hasattr(ca, 'search_courses_by_keywords'):
            return ca.search_courses_by_keywords(keywords, limit)
        return []

class AdvisorRequestManager:
    @staticmethod
    def is_advisor_request(text: str) -> bool:
        advisor_keywords = ['asesor', 'asesoría', 'contactar', 'vendedor', 'representante']
        return any(keyword in text.lower() for keyword in advisor_keywords)

class CourseConversationManager:

    @staticmethod
    def get_selected_course_info(phone):
        try:
            from services.conversation_memory_utils import get_conversation_memory
            return get_conversation_memory(phone, 'selected_course')
        except Exception:
            return None

    @staticmethod
    def select_course(phone, course_id, course_name, selection_method="manual"):
        try:
            from services.conversation_memory_utils import save_conversation_memory
            save_conversation_memory(phone, 'selected_course', {
                'id': course_id,
                'name': course_name,
                'method': selection_method
            })
        except Exception as e:
            logger.debug(f"Error selecting course: {e}")

    @staticmethod
    def clear_course_selection(phone):
        try:
            from services.conversation_memory_utils import save_conversation_memory
            save_conversation_memory(phone, 'selected_course', None)
        except Exception as e:
            logger.debug(f"Error clearing course selection: {e}")

    @staticmethod
    def update_conversation_topic(phone, topic):
        try:
            from services.conversation_memory_utils import save_conversation_memory
            save_conversation_memory(phone, 'conversation_topic', topic)
        except Exception as e:
            logger.debug(f"Error updating conversation topic: {e}")

    @staticmethod
    def detect_course_selection_intent(message_text):
        # Implementación básica de detección de intención de selección de curso
        msg_lower = message_text.lower()
        course_keywords = ['curso', 'temario', 'inscripción', 'fechas', 'precio']
        return any(keyword in msg_lower for keyword in course_keywords)

    @staticmethod
    def handle_course_query(phone, message_text):
        # Manejo básico de consultas de curso
        return CourseConversationManager._handle_course_query_fallback(phone, message_text)

    @staticmethod
    def _handle_course_query_fallback(phone, message_text):
        return "Para información sobre cursos, por favor especifica el número de curso o tema que te interesa."

    @staticmethod
    def _handle_course_selection(phone, selection_intent):
        pass

    @staticmethod
    def _handle_general_course_inquiry(phone, message_text):
        pass

    @staticmethod
    def _handle_selected_course_query(phone, message_text, selected_course):
        pass

    @staticmethod
    def _handle_unspecified_course_query(phone, message_text, query_type):
        pass

    @staticmethod
    def _is_general_course_inquiry(text_lower):
        general_keywords = ['qué cursos', 'que cursos', 'cursos disponibles', 'lista de cursos']
        return any(keyword in text_lower for keyword in general_keywords)

    @staticmethod
    def _detect_course_specific_query(message_text):
        pass

    @staticmethod
    def _extract_course_number_from_message(message_text):
        return parse_course_number_from_text(message_text)

    @staticmethod
    def _extract_course_name_from_message(message_text):
        pass

    @staticmethod
    def _handle_course_switch_offer(phone, message_text, new_selection_intent, current_selection):
        pass

    @staticmethod
    def _handle_temporary_course_query(phone, message_text, temp_selection_intent, current_selection):
        pass

    @staticmethod
    def _get_course_overview(course):
        if not course:
            return "Información no disponible"
        return f"Curso: {course.get('name', 'Sin nombre')}"