"""
Clasificación de intenciones del usuario
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


def classify_user_intent(message_text: str, conversation_history: Optional[list] = None) -> Dict[str, Any]:
    """
    Clasifica la intención del usuario en: técnica, general, cursos, productos, o asesoría
    """
    if not message_text:
        return {'type': 'general', 'confidence': 0.5, 'details': 'Mensaje vacío'}
    
    msg_lower = message_text.lower().strip()

    patterns = {
        'tecnica': {
            'keywords': ['problema', 'problemas', 'error', 'falla', 'no funciona', 'cómo solucionar', 'cómo arreglar',
                         'diagnóstico', 'calibrar', 'configurar', 'instalar', 'conectar', 'instalación',
                         'fusionadora', 'cleaver', 'otdr', 'pérdida de señal', 'atenuación', 'dbm', 'reflectometr',
                         'backscatter', 'splice', 'empalme', 'empalmes', 'fibra rota', 'medición', 'troubleshoot', 'reparar',
                         'conector', 'conectores', 'conectorización', 'conectorizacion', 'conectorizar'],
            'phrases': ['ayuda técnica', 'necesito ayuda', 'no se enciende', 'no arranca', 'no pasa señal', 'cómo reparar'],
            'weight': 1.6
        },
        'general': {
            'keywords': ['hola', 'quién', 'quien', 'horario', 'dónde', 'donde', 'contacto', 'información', 'informacion',
                         'servicios', 'empresa', 'ubicación', 'horarios'],
            'phrases': ['qué hacen', 'quiénes son', 'dónde están ubicados', 'cómo puedo contactarlos', 'información general'],
            'weight': 1.0
        },
        'cursos': {
            'keywords': ['curso', 'cursos', 'temario', 'certificación', 'capacitación', 'formación', 'formacion', 'inscripcion', 'inscribirme', 'recomiendan', 'recomienda', 'webinar', 'webinars', 'seminario', 'seminarios', 'online', 'on-line', 'en línea', 'en linea'],
            'phrases': ['quiero aprender', 'me interesa el curso', 'información del curso', 'cuánto cuesta el curso', 'cuando empieza', 'qué curso recomiendan'],
            'weight': 1.1
        },
        'productos': {
            'keywords': ['bobina', 'ducto', 'tritubo', 'jumper', 'cable', 'precio', 'cotización', 'comprar', 'adquirir', 'disponibilidad', 'stock'],
            'phrases': ['qué productos tienen', 'dónde comprar', 'necesito cotización'],
            'weight': 1.1
        },
        'asesoria': {
            'keywords': ['asesor', 'asesoría', 'asesoria', 'contactar', 'hablar con', 'consultor', 'vendedor', 'representante'],
            'phrases': ['quiero hablar con', 'necesito que me contacten', 'consulta personalizada', 'ayuda especializada'],
            'weight': 1.3
        }
    }

    scores = {}
    details = {}
    
    for category, config in patterns.items():
        score = 0.0
        matched_keywords = []
        matched_phrases = []
        
        # Buscar keywords
        for keyword in config['keywords']:
            if keyword in msg_lower:
                score += config['weight']
                matched_keywords.append(keyword)
        
        # Buscar phrases (mayor peso)
        for phrase in config['phrases']:
            if phrase in msg_lower:
                score += config['weight'] * 2.0  #
                matched_phrases.append(phrase)
        
        scores[category] = score
        details[category] = {
            'score': score,
            'keywords': matched_keywords,
            'phrases': matched_phrases
        }

    # Reglas especiales para evitar falsos positivos
    
    # Detectar verbos de oferta + curso/webinar -> forzar categoría 'cursos'
    offer_verbs = ['ofrecen', 'tienen', 'dan', 'imparten', 'dictan', 'brindan', 'proporcionan']
    if any(verb in msg_lower for verb in offer_verbs) and any(word in msg_lower for word in ['curso', 'cursos', 'webinar', 'webinars']):
        scores['cursos'] += 2.0
        details['cursos']['special_rules'] = details['cursos'].get('special_rules', []) + ['offer_verbs_rule']

    # Detectar interés explícito en aprender sobre un tema técnico
    if any(phrase in msg_lower for phrase in ['me interesa aprender', 'quiero aprender', 'necesito aprender']) and scores.get('tecnica', 0) > 0:
        if any(word in msg_lower for word in ['curso', 'cursos', 'capacitación', 'formación']):
            scores['cursos'] += 1.5
            details['cursos']['special_rules'] = details['cursos'].get('special_rules', []) + ['learning_intent_rule']

    # Encontrar la categoría con mayor puntuación
    if not any(scores.values()):
        return {'type': 'general', 'confidence': 0.3, 'details': 'Sin matches significativos', 'scores': scores}

    max_category = max(scores, key=scores.get)
    max_score = scores[max_category]
    total_score = sum(scores.values())
    
    confidence = max_score / total_score if total_score > 0 else 0.0

    if (max_category != 'tecnica' and 
        scores.get('tecnica', 0) >= max_score * 0.9 and 
        not any(phrase in msg_lower for phrase in ['me interesa el curso', 'quiero el curso', 'inscribirme', 'capacitación'])):
        max_category = 'tecnica'
        confidence = scores['tecnica'] / total_score

    return {
        'type': max_category,
        'confidence': confidence,
        'details': f"{max_category} score={max_score:.2f}, total={total_score:.2f}",
        'scores': scores,
        'matched_details': details
    }


def is_explicit_course_or_webinar_request(text: str) -> bool:
    """Detecta peticiones explícitas de cursos/webinars para evitar false-positives"""
    text_lower = text.lower()
    
    # Frases que indican interés directo en cursos/webinars
    explicit_course_phrases = [
        'lista de cursos', 'qué cursos tienen', 'que cursos tienen', 'cursos disponibles',
        'información de cursos', 'informacion de cursos', 'me interesa un curso',
        'quiero un curso', 'inscribirme a un curso', 'lista de webinars',
        'qué webinars tienen', 'que webinars tienen', 'webinars disponibles'
    ]
    
    return any(phrase in text_lower for phrase in explicit_course_phrases)


def detect_topic_shift(message_text: str) -> bool:
    """Detecta cambios de tema intencionales"""
    topic_shift_keywords = [
        'cambio de tema', 'otra pregunta', 'nuevo tema', 'diferente', 'otra cosa', 
        'hablemos de', 'cuéntame sobre', 'donde esta', 'donde se encuentra',
        'no quiero', 'quiero saber', 'quiero hablar', 'pregunta', 'dime sobre'
    ]
    
    text_lower = message_text.lower()
    return any(keyword in text_lower for keyword in topic_shift_keywords)


def detect_course_exit_commands(message_text: str) -> bool:
    """Detecta comandos para finalizar la conversación enfocada en cursos"""
    clear_course_commands = [
        'finalizar curso', 'terminar curso', 'salir del curso', 'salir curso', 
        'cancelar curso', 'no más cursos', 'no mas cursos'
    ]
    
    text_lower = message_text.lower()
    return any(command in text_lower for command in clear_course_commands)