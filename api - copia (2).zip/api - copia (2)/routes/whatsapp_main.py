"""
WhatsApp Webhook Handler - Archivo principal simplificado
Este archivo contiene solo la lógica principal del webhook y utiliza módulos separados para cada funcionalidad.
"""
import requests
import logging
import json
import traceback
import re
import unicodedata
import os
import copy
import mimetypes
from typing import Optional, Dict, Any
from datetime import datetime
from flask import Blueprint, request, jsonify
from urllib.parse import urljoin

# Configuraciones
from config.config import (
    WHATSAPP_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID,
    WHATSAPP_API_BASE,
    WHATSAPP_VERIFY_TOKEN
)

# Servicios principales
from services.chat_ai import chat_with_gemini

# Módulos organizados por funcionalidad
from .course_handlers import (
    CourseConversationManager, CourseManager, AdvisorRequestManager,
    advisor_request_prompt, get_course_schedule_message, get_course_price_message,
    get_course_location_message, select_course_by_name, parse_course_number_from_text,
    format_course_for_whatsapp, get_course_details_by_number, find_pdf_for_user_message,
    save_selected_course, get_selected_course, clear_selected_course
)

from .intent_classification import (
    classify_user_intent, is_explicit_course_or_webinar_request,
    detect_topic_shift, detect_course_exit_commands
)

from .whatsapp_message_handlers import (
    send_text_message, send_document_message, log_webhook_event,
    set_current_webhook_message_id, clear_current_webhook_message_id
)

from .webinar_handlers import (
    find_db_item_by_keywords, send_db_or_fallback_message,
    handle_webinar_list_request, handle_course_list_request,
    detect_and_update_course_selection, handle_follow_up_selection,
    handle_direct_info_request
)

# Importaciones de servicios de memoria y conversación
from services.conversation_memory_utils import save_conversation_memory, get_conversation_memory

# Configurar logger para este módulo
logger = logging.getLogger(__name__)

# Crear blueprint para rutas de WhatsApp
whatsapp_bp = Blueprint('whatsapp', __name__)


@whatsapp_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verifica el webhook para WhatsApp API"""
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    logger.info(f"Verificación de webhook: mode={mode}, token={token != None}")
    
    if mode == 'subscribe' and token == WHATSAPP_VERIFY_TOKEN:
        logger.info("Webhook verificado exitosamente")
        return challenge
    
    logger.warning("Verificación de webhook fallida")
    return "Verification failed", 403


@whatsapp_bp.route('/debug-webhook', methods=['POST'])
def debug_webhook():
    """Endpoint mínimo para depurar entregas desde Meta/ngrok. Persiste cuerpo y headers y devuelve 200."""
    try:
        raw_body = request.get_data(as_text=True)
        headers = dict(request.headers)
        remote_addr = request.remote_addr or 'unknown'
        
        log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_received.log'))
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"\n=== DEBUG WEBHOOK {datetime.utcnow().isoformat()} ===\n")
            f.write(f"REMOTE_ADDR: {remote_addr}\n")
            f.write(f"HEADERS: {json.dumps(headers)}\n")
            f.write(f"RAW_BODY: {raw_body}\n")
            f.write("=== END DEBUG WEBHOOK ===\n")
            
        logger.info("Debug webhook received and persisted")
        return jsonify({"status": "debug_received"}), 200
        
    except Exception as e:
        logger.error(f"Error en debug webhook: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@whatsapp_bp.route('/webhook', methods=['POST'])
def webhook_handler():
    """Manejador principal del webhook de WhatsApp - Versión simplificada"""
    
    try:
        # Persistir el cuerpo bruto del webhook inmediatamente
        try:
            raw_body = request.get_data(as_text=True)
            headers = dict(request.headers)
            remote_addr = request.remote_addr or 'unknown'
            log_path = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'webhook_raw.log'))
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"\n=== RAW WEBHOOK {datetime.utcnow().isoformat()} ===\n")
                f.write(f"REMOTE_ADDR: {remote_addr}\n")
                f.write(f"HEADERS: {json.dumps(headers)}\n")
                f.write(f"RAW_BODY: {raw_body}\n")
                f.write("=== END RAW WEBHOOK ===\n")
            logger.debug("Raw webhook persisted to logs/webhook_raw.log")
        except Exception as _ex:
            logger.error(f"Failed to persist raw webhook: {_ex}")

        payload = request.json
        logger.info("Webhook POST recibido")
        
        # Registrar información estructurada del webhook
        try:
            has_messages = 'messages' in str(payload)
            has_statuses = 'statuses' in str(payload)
            has_errors = 'errors' in str(payload)
            
            log_webhook_event(
                event_type="webhook_received",
                details={
                    "contains_messages": has_messages,
                    "contains_statuses": has_statuses,
                    "contains_errors": has_errors,
                    "entry_count": len(payload.get('entry', [])),
                    "request_id": request.headers.get('X-Request-Id', 'unknown'),
                    "user_agent": request.headers.get('User-Agent', 'unknown'),
                }
            )
            
        except Exception as e:
            logger.error(f"Error al procesar información de webhook: {e}")
            logger.error(traceback.format_exc())
        
        if not payload:
            logger.warning("Payload vacío recibido")
            return jsonify({"status": "error", "message": "Payload vacío"}), 400
        
        entries = payload.get('entry', [])
        if not entries:
            logger.warning("No hay entries en el payload")
            return jsonify({"status": "ok"}), 200
        
        # Importaciones necesarias para el procesamiento
        from services.chat_ai import query_mongodb
        from utils.ml_adapter import process_message
        from services.conversation_memory import get_conversation_history, clear_topic_context, ConversationMemory
        
        # Procesamiento de mensajes
        for entry in entries:
            changes = entry.get('changes', [])
            for change in changes:
                value = change.get('value', {})
                
                # Clasificar tipo de evento
                payload_type = "unknown"
                if 'statuses' in value and not 'messages' in value:
                    payload_type = "status_update"
                elif 'messages' in value:
                    payload_type = "message"
                elif 'errors' in value:
                    payload_type = "error"
                elif 'metadata' in value:
                    payload_type = "metadata"
                
                logger.info(f"Evento de WhatsApp detectado: {payload_type}")
                
                # Manejar eventos de estado sin generar respuestas
                if payload_type == "status_update":
                    logger.info("Recibida notificación de estado, procesando sin respuesta")
                    statuses = value.get('statuses', [])
                    for status in statuses:
                        status_id = status.get('id')
                        status_status = status.get('status')
                        recipient_id = status.get('recipient_id')
                        logger.info(f"Status de mensaje: ID={status_id}, Status={status_status}, Recipient={recipient_id}")
                    continue
                elif payload_type == "error":
                    errors = value.get('errors', [])
                    for error in errors:
                        logger.error(f"Error de WhatsApp: {error}")
                    continue
                elif payload_type != "message":
                    logger.info(f"Tipo de evento {payload_type} no procesable, ignorando")
                    continue
                    
                # Solo procesar mensajes reales del usuario
                messages = value.get('messages', [])
                if not messages:
                    logger.info("No hay mensajes reales del usuario en este webhook, ignorando")
                    continue
                    
                for message in messages:
                    if not message:
                        logger.warning("Objeto de mensaje vacío, ignorando")
                        continue

                    # Extraer información del mensaje
                    msg_type = message.get('type')
                    
                    # Extraer texto según el tipo
                    if msg_type == 'text':
                        message_text = message.get('text', {}).get('body', '')
                    else:
                        if message.get('text') and isinstance(message.get('text'), dict):
                            message_text = message.get('text', {}).get('body', '')
                        else:
                            message_text = ''

                    if 'timestamp' not in message:
                        logger.warning("Mensaje sin timestamp; se registrará para inspección pero se procesará")

                    # Ignorar mensajes de sistema
                    if message.get('system') or 'notification' in str(message).lower():
                        logger.warning("Mensaje de sistema o notificación detectado, ignorando")
                        continue

                    if not message_text or not str(message_text).strip():
                        logger.warning("Mensaje sin texto extraíble; posible media/attachment - registrando y continuando")

                    # Información del remitente
                    phone = message.get('from')
                    message_id = message.get('id')
                    timestamp = message.get('timestamp')

                    # Marcar mensaje actual para prevenir duplicados
                    set_current_webhook_message_id(message_id)

                    logger.info(f"Mensaje recibido: phone={phone}, text={str(message_text)[:60]}..., timestamp={timestamp}")

                    # Validaciones básicas
                    if not phone or not message_id:
                        logger.warning(f"Mensaje incompleto: phone={phone}, id={message_id}")
                        continue

                    # Evitar reprocesar mensajes
                    if ConversationMemory.is_message_processed(message_id):
                        logger.info(f"Mensaje {message_id} ya fue procesado anteriormente, ignorando")
                        continue

                    # Verificación de timestamp
                    try:
                        if timestamp:
                            msg_time = datetime.fromtimestamp(int(timestamp))
                            time_diff = (datetime.now() - msg_time).total_seconds()
                            
                            if time_diff > 300:  # 5 minutos
                                logger.warning(f"Mensaje antiguo (>{time_diff:.0f}s), procesando con precaución")
                        else:
                            logger.info("Timestamp no disponible, continuando procesamiento")
                    except Exception as e:
                        logger.error(f"Error verificando timestamp del mensaje: {e}")
                        if not str(timestamp).isdigit() or len(str(timestamp)) != 10:
                            logger.warning(f"Timestamp inválido: {timestamp}")
                        
                    # Marcar mensaje como procesado
                    ConversationMemory.mark_message_as_processed(message_id)
                    
                    # Registrar tiempo de procesamiento
                    processing_start_time = datetime.now()
                    
                    # Obtener perfil de WhatsApp si está disponible
                    whatsapp_profile = None
                    if 'contacts' in value and value['contacts']:
                        contact = value['contacts'][0]
                        whatsapp_profile = {
                            "name": contact.get('profile', {}).get('name')
                        }
                        logger.info(f"Perfil de WhatsApp obtenido: {whatsapp_profile}")
                    
                    # Obtener historial de conversación
                    try:
                        conversation_history = get_conversation_history(phone)
                        logger.info(f"Historial recuperado para {phone}: {len(conversation_history)} mensajes")
                    except Exception as history_error:
                        logger.error(f"Error al obtener historial: {history_error}")
                        conversation_history = []
                    
                    # **AQUÍ ES DONDE PROCESAMOS EL MENSAJE DEL USUARIO**
                    process_user_message(phone, message_text, conversation_history, whatsapp_profile)
                    
        # Limpiar ID de mensaje actual
        clear_current_webhook_message_id()
        return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        logger.error(f"Error procesando webhook: {e}", exc_info=True)
        clear_current_webhook_message_id()
        return jsonify({"status": "error", "message": "Error interno"}), 500
    finally:
        clear_current_webhook_message_id()


def process_user_message(phone: str, message_text: str, conversation_history: list, whatsapp_profile: dict = None):
    """
    Procesa un mensaje individual del usuario usando la nueva arquitectura modular.
    Esta es la función principal que orquesta toda la lógica de respuesta.
    """
    try:
        # Clasificar intención del usuario
        intent_classification = classify_user_intent(message_text, conversation_history)
        user_intent_type = intent_classification['type']
        intent_confidence = intent_classification['confidence']
        
        logger.info(f"Clasificación de intención: {user_intent_type} (confianza: {intent_confidence:.2f}) - {intent_classification['details']}")
        
        msg_lower = message_text.lower()
        
        # 1. Verificar si es una solicitud directa de información
        if handle_direct_info_request(phone, message_text):
            return
        
        # 2. Verificar follow-up de selección previa
        if handle_follow_up_selection(phone, message_text):
            return
        
        # 3. Detectar y manejar cambios de curso
        detect_and_update_course_selection(phone, message_text)
        
        # 4. Manejar según la intención clasificada
        if user_intent_type == 'cursos':
            handle_course_intent(phone, message_text, msg_lower)
        elif user_intent_type == 'tecnica':
            handle_technical_intent(phone, message_text, conversation_history)
        elif user_intent_type == 'productos':
            handle_product_intent(phone, message_text)
        elif user_intent_type == 'asesoria':
            handle_advisor_intent(phone, message_text)
        else:  # general
            handle_general_intent(phone, message_text, conversation_history)
            
    except Exception as e:
        logger.error(f"Error procesando mensaje de usuario: {e}", exc_info=True)
        send_text_message(phone, "Disculpa, ocurrió un error procesando tu mensaje. Por favor intenta de nuevo.")


def handle_course_intent(phone: str, message_text: str, msg_lower: str):
    """Maneja intenciones relacionadas con cursos"""
    
    # If user asks about online courses or webinars, respond with webinars list
    try:
        online_triggers = ['online', 'en linea', 'en línea', 'curso en linea', 'cursos en linea', 'cursos en línea', 'modalidad online', 'webinars', 'webinar']
        if any(t in msg_lower for t in online_triggers):
            # delegate to webinar list handler
            try:
                handle_webinar_list_request(phone)
            except Exception:
                logger.exception('Error handling webinar list request')
            return
    except Exception:
        pass

    # Detectar solicitudes específicas de lista
    if any(phrase in msg_lower for phrase in ['lista de cursos', 'qué cursos', 'que cursos', 'cursos disponibles']):
        handle_course_list_request(phone)
        return
        
    if any(phrase in msg_lower for phrase in ['lista de webinars', 'qué webinars', 'que webinars', 'webinars disponibles']):
        handle_webinar_list_request(phone)
        return
    
    # Respuesta sobre costos
    if any(word in msg_lower for word in ['costo', 'costos', 'precio', 'precios', 'cuánto', 'cuanto']):
        send_text_message(phone, "💰 Gratis — se imparte en línea todos los martes")
        return
    
    # Usar el manejador de cursos existente
    try:
        result = CourseConversationManager.handle_course_query(phone, message_text)
        if result:
            send_text_message(phone, result)
        else:
            # Fallback a lista de cursos
            handle_course_list_request(phone)
    except Exception as e:
        logger.error(f"Error en handle_course_intent: {e}")
        handle_course_list_request(phone)


def handle_technical_intent(phone: str, message_text: str, conversation_history: list):
    """Maneja intenciones técnicas usando IA"""
    
    try:
        # Usar el sistema de IA para respuestas técnicas
        ai_response = chat_with_gemini(message_text, conversation_history, phone)
        
        if ai_response and ai_response.strip():
            # Añadir sugerencia de curso si es apropiado
            if any(word in message_text.lower() for word in ['empalme', 'fibra', 'otdr', 'fusionadora', 'conector']):
                ai_response += "\n\n💡 Si te interesa profundizar en este tema, tenemos cursos especializados. Escribe 'cursos' para ver las opciones disponibles."
            
            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Para consultas técnicas detalladas, nuestro equipo estará encantado de ayudarte. ¿Te gustaría que un asesor se ponga en contacto contigo?")
            
    except Exception as e:
        logger.error(f"Error en respuesta técnica: {e}")
        send_text_message(phone, "Para consultas técnicas detalladas, te recomendamos contactar directamente con nuestro equipo de soporte especializado.")


def handle_product_intent(phone: str, message_text: str):
    """Maneja intenciones sobre productos usando el sistema de PDFs inteligente"""
    
    try:
        # Importar el handler de productos
        from services.product_pdf_handler import handle_product_message
        
        # Procesar mensaje con el sistema de productos
        response, pdf_path = handle_product_message(message_text, phone)
        
        if response:
            # Enviar respuesta
            send_text_message(phone, response)
            
            # Si hay un PDF disponible y es una solicitud de ficha técnica
            if pdf_path and any(keyword in message_text.lower() for keyword in ['ficha', 'tecnica', 'datasheet', 'especificaciones']):
                try:
                    # Enviar el PDF como documento
                    from .whatsapp_message_handlers import send_document_message
                    import os
                    
                    if os.path.exists(pdf_path):
                        filename = os.path.basename(pdf_path)
                        send_document_message(phone, pdf_path, filename)
                        logger.info(f"PDF enviado: {filename} a {phone}")
                    else:
                        logger.warning(f"PDF no encontrado en ruta: {pdf_path}")
                        
                except Exception as pdf_error:
                    logger.error(f"Error enviando PDF: {pdf_error}")
                    send_text_message(phone, "El documento técnico está disponible. Si necesitas el PDF, puedes solicitarlo a nuestro equipo comercial.")
        
        else:
            # Fallback si no se identifica como consulta de producto
            fallback_text = ("Contamos con una amplia gama de productos para redes de fibra óptica: bobinas, ductos, tritubos, jumpers, cables y conectores.\n\n"
                           "💡 Para obtener fichas técnicas específicas, menciona el nombre del producto seguido de 'ficha técnica'.\n"
                           "📞 Para cotizaciones y consultas comerciales, un asesor puede contactarte.")
            
            send_text_message(phone, fallback_text)
            
    except Exception as e:
        logger.error(f"Error en handle_product_intent: {e}")
        
        # Fallback en caso de error
        fallback_text = ("Contamos con productos especializados para redes de fibra óptica.\n\n"
                       "Para información técnica detallada y fichas de productos, "
                       "nuestro equipo comercial estará encantado de ayudarte.")
        
        send_text_message(phone, fallback_text)


def handle_advisor_intent(phone: str, message_text: str):
    """Maneja solicitudes de asesoría"""
    
    prompt = advisor_request_prompt()
    send_text_message(phone, prompt)


def handle_general_intent(phone: str, message_text: str, conversation_history: list):
    """Maneja intenciones generales"""
    
    msg_lower = message_text.lower()
    
    # Saludos y información básica
    if any(word in msg_lower for word in ['hola', 'buenos', 'buenas']):
        send_text_message(phone, "¡Hola! Soy el asistente de Splitel. Puedo ayudarte con:\n\n🔧 Consultas técnicas\n📚 Información sobre cursos y webinars\n🛒 Productos y servicios\n📞 Contacto con asesores\n\n¿En qué puedo ayudarte hoy?")
        return
    
    # Información de la empresa
    if any(word in msg_lower for word in ['quién', 'quien', 'empresa', 'splitel']):
        send_text_message(phone, "Splitel es una empresa especializada en soluciones de fibra óptica y redes de telecomunicaciones. Ofrecemos productos, servicios y capacitación técnica especializada.\n\n¿Te gustaría saber más sobre algún servicio específico?")
        return
        
    # Horarios y contacto
    if any(word in msg_lower for word in ['horario', 'contacto', 'teléfono', 'telefono']):
        send_text_message(phone, "📞 Información de contacto:\n• Horario: Lunes a Viernes 9:00 - 18:00\n• Teléfono: [Número de contacto]\n• Email: [Email de contacto]\n\n¿Necesitas que un asesor se comunique contigo?")
        return
    
    # Ubicación
    if any(word in msg_lower for word in ['dónde', 'donde', 'ubicación', 'ubicacion', 'dirección', 'direccion']):
        send_text_message(phone, "📍 Nos encontramos en [Dirección de la empresa].\n\n¿Necesitas direcciones específicas o información sobre cómo llegar?")
        return
    
    # Fallback usando IA para preguntas generales
    try:
        ai_response = chat_with_gemini(message_text, conversation_history, phone)
        if ai_response and ai_response.strip():
            send_text_message(phone, ai_response)
        else:
            send_text_message(phone, "Gracias por tu mensaje. ¿Podrías ser más específico sobre lo que necesitas? Puedo ayudarte con consultas técnicas, información sobre cursos, productos o ponerte en contacto con un asesor.")
    except Exception as e:
        logger.error(f"Error en respuesta general: {e}")
        send_text_message(phone, "Gracias por tu mensaje. ¿Podrías ser más específico sobre lo que necesitas? Puedo ayudarte con consultas técnicas, información sobre cursos, productos o ponerte en contacto con un asesor.")