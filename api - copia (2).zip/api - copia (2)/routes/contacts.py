
from flask import Blueprint, jsonify, request
from data.db import get_collection
from bson import ObjectId
import logging

contacts_bp = Blueprint('contacts', __name__)
logger = logging.getLogger(__name__)

@contacts_bp.route('', methods=['GET', 'OPTIONS'])
@contacts_bp.route('/', methods=['GET', 'OPTIONS'])
def get_contacts():
    """Get all contacts with recent conversations"""
    if request.method == 'OPTIONS':
        return ('', 200)
    
    try:
        logger.info('Fetching contacts from database...')
        
        # Get conversations collection
        conversations_col = get_collection('conversaciones')
        
        # Aggregate to get unique contacts with their last message
        # The conversations collection stores the phone in 'customer_phone'
        pipeline = [
            { '$match': { 'customer_phone': { '$exists': True, '$ne': None, '$ne': '' } } },
            { '$sort': {'created_at': -1} },
            {
                '$group': {
                    '_id': '$customer_phone',
                    'name': {'$first': '$name'},
                    # messages are stored as arrays; leave last_message empty for now
                    'last_message': {'$first': ''},
                    'timestamp': {'$first': '$created_at'},
                    'ai_mode': {'$first': '$ai_mode'},
                    'unread': {'$sum': {'$cond': [{'$eq': ['$read', False]}, 1, 0]}}
                }
            },
            { '$sort': {'timestamp': -1} }
        ]

        contacts = list(conversations_col.aggregate(pipeline))
        
        # Format response
        formatted_contacts = []
        for contact in contacts:
            # normalize to camelCase keys expected by the frontend
            formatted_contacts.append({
                'phone': contact['_id'],
                'name': contact.get('name', contact['_id']),
                'lastMessage': contact.get('last_message', ''),
                'lastMessageTimestamp': (contact.get('timestamp').isoformat() if hasattr(contact.get('timestamp'), 'isoformat') else (str(contact.get('timestamp')) if contact.get('timestamp') else None)),
                'aiMode': contact.get('ai_mode', False),
                'unreadCount': contact.get('unread', 0)
            })
        
        logger.info(f'Found {len(formatted_contacts)} contacts')
        
        return jsonify({
            'ok': True,
            'contacts': formatted_contacts
        }), 200
        
    except Exception as e:
        logger.exception('Error fetching contacts')
        return jsonify({
            'ok': False,
            'error': str(e),
            'contacts': []
        }), 500


@contacts_bp.route('/monitored', methods=['GET', 'OPTIONS'])
@contacts_bp.route('/monitored/', methods=['GET', 'OPTIONS'])
def get_monitored_contacts():
    """Alternative endpoint for monitored contacts"""
    if request.method == 'OPTIONS':
        return ('', 200)
    
    try:
        logger.info('Fetching monitored contacts...')
        
        conversations_col = get_collection('conversaciones')
        
        # Get all unique phone numbers using 'customer_phone'
        pipeline = [
            { '$match': { 'customer_phone': { '$exists': True, '$ne': None, '$ne': '' } } },
            {
                '$group': {
                    '_id': '$customer_phone',
                    'name': {'$first': '$name'},
                    'message_count': {'$sum': 1},
                    'last_timestamp': {'$max': '$created_at'}
                }
            },
            { '$sort': {'last_timestamp': -1} }
        ]
        
        contacts = list(conversations_col.aggregate(pipeline))
        
        formatted_contacts = []
        for contact in contacts:
            # normalize monitored contact keys for frontend
            formatted_contacts.append({
                'phone': contact['_id'],
                'name': contact.get('name', contact['_id']),
                'message_count': contact.get('message_count', 0),
                'lastMessage': '',
                'lastMessageTimestamp': (contact.get('last_timestamp').isoformat() if hasattr(contact.get('last_timestamp'), 'isoformat') else (str(contact.get('last_timestamp')) if contact.get('last_timestamp') else None)),
                'aiMode': False,
                'unreadCount': 0
            })
        
        logger.info(f'Found {len(formatted_contacts)} monitored contacts')
        
        return jsonify({
            'ok': True,
            'contacts': formatted_contacts
        }), 200
        
    except Exception as e:
        logger.exception('Error fetching monitored contacts')
        return jsonify({
            'ok': False,
            'error': str(e),
            'contacts': []
        }), 500


@contacts_bp.route('/<phone>/messages', methods=['GET', 'OPTIONS'])
@contacts_bp.route('/<phone>/messages/', methods=['GET', 'OPTIONS'])
def get_contact_messages(phone):
    """Get all messages for a specific contact"""
    if request.method == 'OPTIONS':
        return ('', 200)
    
    try:
        logger.info(f'Fetching messages for contact: {phone}')
        
        conversations_col = get_collection('conversaciones')

        # Try to support lookups by string phone or numeric phone
        phone_variants = [phone]
        try:
            phone_int = int(phone)
            phone_variants.append(phone_int)
        except Exception:
            phone_int = None

        # Find all conversation documents for this contact (customer_phone or phone)
        cursor = conversations_col.find({'$or': [{'customer_phone': v} for v in phone_variants]})

        # Flatten messages arrays from conversation documents
        formatted_messages = []
        for doc in cursor:
            for m in doc.get('messages', []):
                # user message
                if m.get('user_message'):
                    formatted_messages.append({
                        'id': str(m.get('id')) if m.get('id') else None,
                        'text': m.get('user_message'),
                        'timestamp': m.get('timestamp'),
                        'sender': 'contact',
                        'type': m.get('message_type', 'text'),
                        'isAIResponse': False,
                        'is_manual': False
                    })
                if m.get('bot_response'):
                    formatted_messages.append({
                        'id': str(m.get('id')) if m.get('id') else None,
                        'text': m.get('bot_response'),
                        'timestamp': m.get('timestamp'),
                        'sender': 'agent',
                        'type': m.get('message_type', 'text'),
                        'isAIResponse': not m.get('is_manual', False),  # Si no es manual, es de IA
                        'is_manual': m.get('is_manual', False)  # TRUE para mensajes manuales del agente
                    })

        # Sort by timestamp if present
        try:
            formatted_messages.sort(key=lambda x: x.get('timestamp') or '')
        except Exception:
            pass
        
        logger.info(f'Found {len(formatted_messages)} messages for {phone}')
        
        return jsonify({
            'ok': True,
            'messages': formatted_messages
        }), 200
        
    except Exception as e:
        logger.exception(f'Error fetching messages for {phone}')
        return jsonify({
            'ok': False,
            'error': str(e),
            'messages': []
        }), 500


@contacts_bp.route('/<phone>/messages/<message_id>', methods=['DELETE'])
@contacts_bp.route('/<phone>/messages/<message_id>/', methods=['DELETE'])
def delete_contact_message(phone, message_id):
    """Delete a message by id for a given contact. This will remove the individual message
    entry from any conversation documents that contain it by message id. Returns 200 on success.
    """
    try:
        conversations_col = get_collection('conversaciones')
        if conversations_col is None:
            return jsonify({'ok': False, 'error': 'Conversations collection not available'}), 500

        # Build possible phone variants to match stored documents
        norm_digits = ''.join([c for c in str(phone) if c.isdigit()])
        phone_variants = [phone]
        if norm_digits and norm_digits != str(phone):
            phone_variants.append(norm_digits)
        try:
            phone_variants.append(int(norm_digits))
        except Exception:
            pass

        # Pull documents that match and remove the message from their messages array
        res = conversations_col.update_many(
            {'$or': [{'customer_phone': v} for v in phone_variants]},
            {'$pull': {'messages': {'id': message_id}}}
        )

        # Also attempt to remove from documents that may store messages directly at root (safety)
        # (if your schema stores messages differently adjust accordingly)

        # Emit socket event to notify clients
        try:
            from flask import current_app
            sock = getattr(current_app, 'socketio', None)
            if sock:
                sock.emit('message_deleted', {'phone': norm_digits or phone, 'id': message_id}, namespace='/')
        except Exception:
            logger.exception('Failed emitting message_deleted socket event')

        return jsonify({'ok': True, 'deleted_count': res.modified_count}), 200
    except Exception as e:
        logger.exception('Error deleting message')
        return jsonify({'ok': False, 'error': str(e)}), 500


@contacts_bp.route('/<phone>/messages/<message_id>/delete', methods=['POST', 'OPTIONS'])
@contacts_bp.route('/<phone>/messages/<message_id>/delete/', methods=['POST', 'OPTIONS'])
def delete_contact_message_post(phone, message_id):
    """POST fallback for clients that cannot send DELETE requests (proxy/protocol restrictions).
    This performs the same deletion as the DELETE route and returns the same structure.
    """
    if request.method == 'OPTIONS':
        return ('', 200)
    try:
        # Reuse the same logic as delete_contact_message
        conversations_col = get_collection('conversaciones')
        if conversations_col is None:
            return jsonify({'ok': False, 'error': 'Conversations collection not available'}), 500

        norm_digits = ''.join([c for c in str(phone) if c.isdigit()])
        phone_variants = [phone]
        if norm_digits and norm_digits != str(phone):
            phone_variants.append(norm_digits)
        try:
            phone_variants.append(int(norm_digits))
        except Exception:
            pass

        res = conversations_col.update_many(
            {'$or': [{'customer_phone': v} for v in phone_variants]},
            {'$pull': {'messages': {'id': message_id}}}
        )

        try:
            from flask import current_app
            sock = getattr(current_app, 'socketio', None)
            if sock:
                sock.emit('message_deleted', {'phone': norm_digits or phone, 'id': message_id}, namespace='/')
        except Exception:
            logger.exception('Failed emitting message_deleted socket event (POST fallback)')

        return jsonify({'ok': True, 'deleted_count': res.modified_count}), 200
    except Exception as e:
        logger.exception('Error deleting message (POST fallback)')
        return jsonify({'ok': False, 'error': str(e)}), 500



@contacts_bp.route('/<phone>/toggle-mode', methods=['POST', 'OPTIONS'])
@contacts_bp.route('/<phone>/toggle-mode/', methods=['POST', 'OPTIONS'])
def toggle_mode(phone):
    """Toggle AI mode for a contact. Expects JSON { aiMode: true|false }"""
    if request.method == 'OPTIONS':
        return ('', 200)
    try:
        body = request.get_json(force=True, silent=True) or {}
        ai_mode = body.get('aiMode')
        if ai_mode is None:
            return jsonify({'ok': False, 'error': 'aiMode required'}), 400

        conversations_col = get_collection('conversaciones')
        
        # Normalizar phone para coincidir con customer_phone en DB
        norm_digits = ''.join([c for c in str(phone) if c.isdigit()])
        phone_variants = [phone, norm_digits]
        try:
            phone_variants.append(int(norm_digits))
        except:
            pass
        
        # Update matching documents for this customer_phone
        res = conversations_col.update_many(
            {'$or': [{'customer_phone': v} for v in phone_variants]}, 
            {'$set': {'ai_mode': bool(ai_mode)}}
        )

        logger.info(f'AI mode set to {ai_mode} for {phone} (modified {res.modified_count})')
        
        # Emitir evento socket inmediatamente para actualizar UI
        try:
            from flask import current_app
            sock = getattr(current_app, 'socketio', None)
            if sock:
                toggle_payload = {
                    'phone': norm_digits or phone,
                    'customer_phone': norm_digits or phone,
                    'aiMode': bool(ai_mode)
                }
                logger.info(f'Emitting ai_mode_changed for {phone}: {ai_mode}')
                # flask_socketio.Server.emit does not accept 'broadcast' kw in some versions
                # Emitting without 'broadcast' will send to all clients in the namespace
                sock.emit('ai_mode_changed', toggle_payload, namespace='/')
                logger.info(f'ai_mode_changed emitted successfully')
        except Exception as sock_err:
            logger.exception(f'Failed to emit ai_mode_changed: {sock_err}')
        
        return jsonify({'ok': True, 'aiMode': bool(ai_mode), 'modified': res.modified_count}), 200
    except Exception as e:
        logger.exception('Error toggling ai mode')
        return jsonify({'ok': False, 'error': str(e)}), 500



@contacts_bp.route('/<phone>/reply', methods=['POST', 'OPTIONS'])
@contacts_bp.route('/<phone>/reply/', methods=['POST', 'OPTIONS'])
def reply_to_contact(phone):
    """Accept a reply from the agent UI and persist it to the conversations collection (basic implementation)."""
    if request.method == 'OPTIONS':
        return ('', 200)
    try:
        data = request.get_json(force=True, silent=True) or {}
        text = data.get('text')
        if not text:
            return jsonify({'ok': False, 'error': 'missing text'}), 400

        conversations_col = get_collection('conversaciones')
        from datetime import datetime
        ts = datetime.utcnow().isoformat()

        # Build phone variants to match existing records (raw, digits-only, numeric)
        norm_digits = ''.join([c for c in str(phone) if c.isdigit()])
        phone_variants = [phone]
        if norm_digits and norm_digits != str(phone):
            phone_variants.append(norm_digits)
        phone_int = None
        try:
            if norm_digits:
                phone_int = int(norm_digits)
                phone_variants.append(phone_int)
        except Exception:
            phone_int = None

        # determine ai_mode from existing docs (fallback True)
        existing = conversations_col.find_one({'$or': [{'customer_phone': v} for v in phone_variants]})
        ai_mode = existing.get('ai_mode') if existing and 'ai_mode' in existing else True

        # BLOQUEAR mensajes manuales cuando AI está ON
        if ai_mode:
            logger.warning(f'Reply blocked for {phone}: AI mode is ON, manual messages not allowed')
            return jsonify({
                'ok': False, 
                'error': 'AI mode is ON. Disable AI mode to send manual messages.',
                'aiMode': True,
                'blocked': True
            }), 403

        # AI mode is OFF - permitir mensajes directos del agente (sin respuesta automática)
        # Append the agent message to the messages array (upsert if needed)
        # create unique id for this message so frontend can dedupe/track
        msg_id = str(ObjectId())
        bot_msg_for_db = {
            'id': msg_id,
            'bot_response': text,
            'message_type': 'text',
            'timestamp': ts,
            'is_manual': True,  # Marcar como mensaje manual del agente
            'sender': 'agent'
        }
        # Use filter with $or to match variants and set customer_phone on insert to the digits-only form if available
        upsert_filter = {'$or': [{'customer_phone': v} for v in phone_variants]}
        set_on_insert = {'created_at': ts, 'customer_phone': norm_digits or phone}

        conversations_col.update_one(
            upsert_filter,
            {
                '$setOnInsert': set_on_insert,
                '$set': {'ai_mode': ai_mode},
                '$push': {'messages': bot_msg_for_db}
            },
            upsert=True
        )

        created_user_msg = { 'id': msg_id, 'text': text, 'sender': 'agent', 'timestamp': ts }

        # Attempt to send the message out via WhatsApp
        try:
            from utils.whatsapp import send_text_message
            logger.info(f'Calling send_text_message to {norm_digits or phone} with text length {len(text)}')
            sent_ok = send_text_message(norm_digits or phone, text)
            logger.info(f'WhatsApp send_text_message result for {norm_digits or phone}: {sent_ok}')
        except Exception:
            sent_ok = False
            logger.exception('Error calling send_text_message')

        # Emit socket event to notify clients of new user message
        try:
            from flask import current_app
            sock = getattr(current_app, 'socketio', None)
            if sock:
                payload = {
                    'id': msg_id, 
                    'phone': norm_digits or phone, 
                    'customer_phone': norm_digits or phone, 
                    'text': text, 
                    'sender': 'agent', 
                    'timestamp': ts,
                    'is_manual': True,  # Importante: indicar que es mensaje manual
                    'isAIResponse': False
                }
                logger.info(f'Emitting socket new_message for manual message: {msg_id}')
                try:
                    # flask_socketio Server.emit does not accept 'broadcast' kw in some versions
                    # Emitting without 'broadcast' will send to all clients in the namespace
                    sock.emit('new_message', payload, namespace='/')
                    logger.info(f'Socket new_message emitted successfully for {msg_id}')
                except Exception as emit_err:
                    logger.exception(f'Socket emit new_message failed: {emit_err}')
        except Exception:
            logger.exception('Failed to emit socket for user message')

        # NO generar respuesta automática cuando ai_mode es OFF
        # El agente está enviando mensajes directos al usuario
        
        # Emit update_contact event to refresh contact preview immediately
        try:
            if sock:
                update_payload = {
                    'phone': norm_digits or phone,
                    'customer_phone': norm_digits or phone,
                    'aiMode': ai_mode,
                    'lastMessage': text,
                    'lastMessageTimestamp': ts
                }
                logger.info(f'Emitting socket update_contact for {norm_digits or phone}')
                try:
                    sock.emit('update_contact', update_payload, namespace='/')
                    logger.info(f'Socket update_contact emitted successfully')
                except Exception as emit_err:
                    logger.exception(f'Socket emit update_contact failed: {emit_err}')
        except Exception:
            logger.exception('Failed to emit update_contact')

        logger.info(f'Reply stored for {phone} (ai_mode={ai_mode}, manual message allowed)')
        # Return created message (no AI response when ai_mode is OFF)
        result = {'ok': True, 'aiMode': ai_mode, 'message': created_user_msg, 'sent': bool(sent_ok)}
        return jsonify(result), 200
    except Exception as e:
        logger.exception('Error storing reply')
        return jsonify({'ok': False, 'error': str(e)}), 500
