from flask import Blueprint, request, jsonify, send_file
import logging
import os
from services.product_pdf_handler import product_handler, handle_product_message, is_product_related_message
from services.pdf_search_service import pdf_search_service
from utils.pdf_utils import list_available_pdfs

# Configurar logging
logger = logging.getLogger(__name__)

# Crear blueprint para rutas de productos
product_bp = Blueprint('product', __name__)

@product_bp.route('/api/products/search', methods=['POST'])
def search_product():
    """Buscar información de un producto específico"""
    try:
        data = request.get_json()
        
        if not data or 'query' not in data:
            return jsonify({
                'success': False,
                'error': 'Parámetro "query" requerido'
            }), 400
        
        query = data['query']
        phone = data.get('phone', 'api_user')
        
        logger.info(f"Búsqueda de producto: {query}")
        
        # Procesar consulta
        response, pdf_path = handle_product_message(query, phone)
        
        if response:
            result = {
                'success': True,
                'query': query,
                'response': response,
                'has_pdf': pdf_path is not None,
                'pdf_path': pdf_path
            }
            
            return jsonify(result)
        else:
            return jsonify({
                'success': False,
                'error': 'No se pudo procesar la consulta como una búsqueda de producto'
            }), 400
    
    except Exception as e:
        logger.error(f"Error en búsqueda de producto: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/datasheet', methods=['POST'])
def get_datasheet():
    """Obtener ficha técnica de un producto específico"""
    try:
        data = request.get_json()
        
        if not data or 'product' not in data:
            return jsonify({
                'success': False,
                'error': 'Parámetro "product" requerido'
            }), 400
        
        product_name = data['product']
        
        logger.info(f"Solicitud de ficha técnica: {product_name}")
        
        # Buscar ficha técnica
        datasheet_info = pdf_search_service.get_product_datasheet(product_name)
        
        return jsonify(datasheet_info)
    
    except Exception as e:
        logger.error(f"Error obteniendo ficha técnica: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/pdf/<path:filename>', methods=['GET'])
def download_pdf(filename):
    """Descargar archivo PDF de producto"""
    try:
        pdf_path = os.path.join('pdfs', filename)
        
        if not os.path.exists(pdf_path):
            return jsonify({
                'success': False,
                'error': 'Archivo PDF no encontrado'
            }), 404
        
        return send_file(
            pdf_path,
            as_attachment=True,
            download_name=filename,
            mimetype='application/pdf'
        )
    
    except Exception as e:
        logger.error(f"Error descargando PDF: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/list', methods=['GET'])
def list_products():
    """Listar productos disponibles"""
    try:
        # Obtener productos de metadata
        available_products = product_handler.get_available_products()
        
        # Obtener información de PDFs disponibles
        available_pdfs = list_available_pdfs()
        
        result = {
            'success': True,
            'products': available_products,
            'pdfs': [
                {
                    'filename': pdf['filename'],
                    'page_count': pdf['page_count'],
                    'file_size': pdf['file_size'],
                    'has_text': pdf['has_text']
                }
                for pdf in available_pdfs
            ],
            'total_products': len(available_products),
            'total_pdfs': len(available_pdfs)
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error listando productos: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/question', methods=['POST'])
def answer_product_question():
    """Responder pregunta específica sobre un producto"""
    try:
        data = request.get_json()
        
        if not data or 'product' not in data or 'question' not in data:
            return jsonify({
                'success': False,
                'error': 'Parámetros "product" y "question" requeridos'
            }), 400
        
        product_name = data['product']
        question = data['question']
        
        logger.info(f"Pregunta sobre producto {product_name}: {question}")
        
        # Obtener respuesta
        response = pdf_search_service.search_product_info(product_name, question)
        
        result = {
            'success': True,
            'product': product_name,
            'question': question,
            'answer': response
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error respondiendo pregunta de producto: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/check-message', methods=['POST'])
def check_product_message():
    """Verificar si un mensaje está relacionado con productos"""
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({
                'success': False,
                'error': 'Parámetro "message" requerido'
            }), 400
        
        message = data['message']
        
        is_product_related = is_product_related_message(message)
        is_datasheet_request = product_handler.is_datasheet_request(message)
        is_product_query = product_handler.is_product_query(message)
        
        extracted_product = product_handler.extract_product_name(message) if is_product_related else None
        
        result = {
            'success': True,
            'message': message,
            'is_product_related': is_product_related,
            'is_datasheet_request': is_datasheet_request,
            'is_product_query': is_product_query,
            'extracted_product': extracted_product
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error verificando mensaje de producto: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@product_bp.route('/api/products/debug', methods=['GET'])
def debug_products():
    """Endpoint de debug para verificar el estado del sistema de productos"""
    try:
        # Información de productos
        products_count = len(product_handler.get_available_products())
        
        # Información de PDFs
        pdfs_info = list_available_pdfs()
        pdfs_count = len(pdfs_info)
        
        # Información de directorios
        import os
        pdf_dir_exists = os.path.exists('pdfs')
        info_dir_exists = os.path.exists('info')
        products_dir_exists = os.path.exists('info/products')
        
        result = {
            'success': True,
            'system_status': {
                'pdf_directory_exists': pdf_dir_exists,
                'info_directory_exists': info_dir_exists,
                'products_directory_exists': products_dir_exists,
                'total_products': products_count,
                'total_pdfs': pdfs_count
            },
            'available_pdfs': [pdf['filename'] for pdf in pdfs_info[:10]],  # Primeros 10
            'sample_products': product_handler.get_available_products()[:10]  # Primeros 10
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error en debug de productos: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500