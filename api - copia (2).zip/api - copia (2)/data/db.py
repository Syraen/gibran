import os 
import sys
import types
from datetime import datetime, timedelta, tzinfo
from pymongo import MongoClient
from pymongo.database import Database
from pymongo.collection import Collection
from config.config import MONGODB_DB

#configuracion de pymongo
if 'bson.tz_util' not in sys.modules:
    tz_mod = types.ModuleType('bson.tz_util')

    class _UTC(tzinfo):
        def utcoffset(self, dt):
            return timedelta(0)

        def tzname(self, dt):
            return 'UTC'

        def dst(self, dt):
            return timedelta(0)

    tz_mod.utc = _UTC()
    sys.modules['bson.tz_util'] = tz_mod

#Conexion a mongo (variables) 
client: MongoClient = None
db: Database = None 

#Iniciar Mongo
def init_db(mongodb_url=None):
    global client, db 

    #Conexion al localhost y la db 
    url = mongodb_url or os.environ.get('MONGODB_URL', 'mongodb://localhost:27017/')
    client = MongoClient(url)

    # conectar a la db (use configured name to avoid case mismatches)
    db_name = MONGODB_DB or os.environ.get('MONGODB_DB') or 'splitbot'
    db = client[db_name]

    #crear index para las collectiones 
    try: 
        #conversaciones 

        #numero del usuario
        db.conversaciones.create_index("customer_phone")

        #fecha de creacion 
        db.conversaciones.create_index("created_at")

        #deduplicacion para mensajes 
        db.conversaciones.create_index("message_id", unique=True, sparse=True)

        #productos
        db.products.create_index("name")

        #keywords
        db.keywords.create_index("keyword")

        #courses
        db.courses.create_index("title")

    except Exception as e: 
        print(f"No se pudo crear el index: {e}")

#Obtener la db 
def get_db() -> Database:
    global db 
    if db is None: 
        init_db()
    return db 

#Obtener collectiones 
def get_collection(collection_name: str) -> Collection:
    database = get_db()
    return database[collection_name]

#Cerrar la db 
def close_db():
    global client
    if client:
        client.close()
        